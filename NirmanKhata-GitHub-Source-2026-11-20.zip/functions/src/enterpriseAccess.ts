import { HttpsError } from 'firebase-functions/v2/https';
export const adminRoles = ['admin_editor', 'owner', 'company_admin'];
export const isEnterpriseAdmin = (role: string) => adminRoles.includes(role);
export const moduleTemplates = [
    { id: 'projects', name: 'Projects / Sites', permissions: ['projects.read'], collections: ['projects'] },
    { id: 'purchases', name: 'Purchases', permissions: ['purchases.read'], collections: ['purchaseBills', 'suppliers'] },
    { id: 'sales', name: 'Sales & Client Invoices', permissions: ['sales.read'], collections: ['invoices', 'clients'] },
    { id: 'expenses', name: 'Daily Expenses', permissions: ['expenses.read'], collections: ['expenses'] },
    { id: 'inventory', name: 'Inventory', permissions: ['inventory.read'], collections: ['inventory', 'stockMovements'] },
    { id: 'workers', name: 'Workers & Attendance', permissions: ['workers.read'], collections: ['workers', 'attendance'] },
    { id: 'payroll', name: 'Payroll', permissions: ['payroll.read'], collections: ['salaries', 'advances'] },
    { id: 'banking', name: 'Cash & Bank', permissions: ['banking.read'], collections: ['accounts', 'transactions'] },
    { id: 'reports', name: 'Reports', permissions: ['reports.operational.read', 'reports.financial.read'], collections: [] },
    { id: 'operations', name: 'Construction Operations', permissions: ['siteProgress.read', 'siteProgress.submit', 'siteProgress.review', 'siteProgress.allocate'], collections: [] },
];
export function defaultRoles(all: string[]) {
    return [
        { id: 'admin_editor', name: 'Admin: Editor', permissions: all },
        { id: 'purchase_manager', name: 'Purchase Manager', permissions: ['projects.read', 'purchases.read', 'purchases.create', 'purchases.edit', 'purchases.invoice.upload', 'purchases.invoice.view'] },
        { id: 'accounts', name: 'Accounts', permissions: ['projects.read', 'sales.read', 'sales.create', 'sales.receive', 'expenses.read', 'banking.read', 'reports.financial.read', 'purchases.read', 'purchases.invoice.view', 'payroll.read'] },
        { id: 'project_manager', name: 'Project Manager', permissions: ['projects.read', 'projects.edit', 'siteProgress.read', 'siteProgress.allocate', 'siteProgress.assign', 'reports.operational.read'] },
        { id: 'admin_reviewer', name: 'Admin: Reviewer', permissions: ['projects.read', 'purchases.read', 'purchases.approve', 'purchases.invoice.view', 'purchases.invoice.verify', 'siteProgress.read', 'siteProgress.review'] },
        { id: 'site_supervisor', name: 'Site Supervisor', permissions: ['siteProgress.submit'] },
    ];
}
export function effectivePermissions(member: any, role: any, all: string[]) {
    if (isEnterpriseAdmin(member.role))
        return all;
    const base = Array.isArray(member.permissionOverride) ? member.permissionOverride : (role?.permissions || []);
    return base.filter((p: string) => all.includes(p) && !['team.manage', 'team.read', 'data.migrate', 'siteProgress.manage'].includes(p));
}
export function assertCredentialState(member: any, token: any, allowTemporary = false) {
    if (member.status !== 'active')
        throw new HttpsError('permission-denied', 'This employee account is inactive.');
    if (member.credentialVersion && token?.credentialVersion !== member.credentialVersion)
        throw new HttpsError('unauthenticated', 'Sign in again with your current credentials.');
    if (member.mustChangePassword && !allowTemporary)
        throw new HttpsError('failed-precondition', 'Change your temporary password before accessing ERP data.');
}
export function assertEnterpriseActive(tenant: any) {
    if (!tenant || tenant.status !== 'active')
        throw new HttpsError('permission-denied', 'This enterprise is not active.');
    const sub = tenant.subscription;
    if (!sub || !['active', 'trial'].includes(sub.status) || (sub.endsAt?.toMillis?.() ?? Infinity) <= Date.now() || sub.status === 'trial' && (sub.trialEndsAt?.toMillis?.() ?? Infinity) <= Date.now())
        throw new HttpsError('permission-denied', 'This enterprise license has expired or is suspended.');
}
export function projectIds(member: any): string[] { return member.projectIds || member.siteProgressAccess?.projectIds || []; }
export function assertProject(member: any, id: string) { if (!isEnterpriseAdmin(member.role) && !projectIds(member).includes(id))
    throw new HttpsError('permission-denied', 'This project is not assigned to you.'); }

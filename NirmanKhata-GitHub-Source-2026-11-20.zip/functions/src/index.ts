import { enterpriseAccountHandlers } from './enterpriseAccounts.js';
import { isEnterpriseAdmin, effectivePermissions, assertCredentialState, assertEnterpriseActive, projectIds, assertProject } from './enterpriseAccess.js';
import { migrateConstructionV2 } from './migrations/constructionV2.js';
import { initializeApp } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import { FieldValue, getFirestore } from 'firebase-admin/firestore';
import { getStorage } from 'firebase-admin/storage';
import { createHash, randomBytes, timingSafeEqual, createHmac } from 'node:crypto';
import { defineSecret } from 'firebase-functions/params';
import { HttpsError, onCall, onRequest } from 'firebase-functions/v2/https';

initializeApp();
const db = getFirestore(process.env.FIRESTORE_DATABASE_ID || 'ai-studio-6794c8ab-5e87-4ce8-ad85-d1290fbea6b0');
const razorpayKeyId = defineSecret('RAZORPAY_KEY_ID');
const razorpayKeySecret = defineSecret('RAZORPAY_KEY_SECRET');
const razorpayWebhookSecret = defineSecret('RAZORPAY_WEBHOOK_SECRET');

const permissions = [
  'projects.read','projects.create','projects.edit','projects.delete','projects.approve',
  'purchases.read','purchases.create','purchases.edit','purchases.approve','purchases.pay',
  'purchases.invoice.upload','purchases.invoice.view','purchases.invoice.download','purchases.invoice.edit','purchases.invoice.verify','purchases.invoice.reject',
  'sales.read','sales.create','sales.edit','sales.approve','sales.receive',
  'expenses.read','expenses.create','expenses.approve','inventory.read','inventory.manage',
  'workers.read','workers.manage','attendance.manage','payroll.read','payroll.pay',
  'banking.read','banking.manage','reports.operational.read','reports.financial.read',
  'team.read','team.manage','settings.manage','documents.read','audit.read','data.migrate','data.delete',
  'siteProgress.manage','siteProgress.allocate','siteProgress.assign','siteProgress.submit','siteProgress.read','siteProgress.review','siteProgress.download',
];
const allPermissions = permissions;
const starterPlans = {
  starter: { name: 'Starter', employeeLimit: 3, modules: ['projects','purchases','sales','expenses','workers','payroll','inventory','banking','reports.basic','operations'] },
  professional: { name: 'Professional', employeeLimit: 10, modules: ['*'] },
  business: { name: 'Business', employeeLimit: 25, modules: ['*'], branches: true },
  enterprise: { name: 'Enterprise', employeeLimit: -1, modules: ['*'], branches: true },
};
const safeId = /^[A-Za-z0-9_-]{1,120}$/;
const collections = new Set([
  'projects','suppliers','clients','purchaseBills','expenses','workers','attendance','advances','salaries',
  'subcontractors','subcontractBills','invoices','accounts','transactions','inventory','stockMovements',
  'alerts','auditEvents','boq','requisitions','siteReports','siteTasks','equipment','bankStatementRows','legacyTeamProfiles','legacyBusinessSnapshots','siteProgressCategories',
]);
const collectionPermissions: Record<string, string> = {
  projects: 'projects.edit', suppliers: 'purchases.create', clients: 'sales.create', purchaseBills: 'purchases.create',
  expenses: 'expenses.create', workers: 'workers.manage', attendance: 'attendance.manage', advances: 'payroll.pay',
  salaries: 'payroll.pay', subcontractors: 'purchases.create', subcontractBills: 'purchases.create', invoices: 'sales.create',
  accounts: 'banking.manage', transactions: 'banking.manage', inventory: 'inventory.manage', stockMovements: 'inventory.manage',
  alerts: 'reports.operational.read', boq: 'projects.edit', requisitions: 'purchases.create', siteReports: 'projects.edit',
  siteTasks: 'projects.edit', equipment: 'projects.edit', bankStatementRows: 'banking.manage', legacyTeamProfiles: 'data.migrate', legacyBusinessSnapshots: 'data.migrate',siteProgressCategories:'data.migrate',
};
const collectionModules: Record<string, string> = {
  projects:'projects', suppliers:'purchases', clients:'sales', purchaseBills:'purchases', expenses:'expenses',
  workers:'workers', attendance:'workers', advances:'payroll', salaries:'payroll', subcontractors:'purchases',
  subcontractBills:'purchases', invoices:'sales', accounts:'banking', transactions:'banking', inventory:'inventory',
  stockMovements:'inventory', alerts:'reports.basic', boq:'operations', requisitions:'operations', siteReports:'operations',
  siteTasks:'operations', equipment:'operations', bankStatementRows:'banking', legacyTeamProfiles:'operations', legacyBusinessSnapshots:'operations',siteProgressCategories:'operations',
};
// This generic sync endpoint is limited to operational records whose access is
// fully described by a single module permission. Financial posting, approvals,
// payments, account balances, payroll, documents and audit history require
// dedicated trusted operations and are intentionally excluded.
const syncableCollections = new Set([
  'projects','suppliers','clients','workers','attendance','boq','requisitions',
  'siteReports','siteTasks','equipment',
]);

type CallableRequest = { auth?: { uid: string; token: Record<string, unknown> }; data: Record<string, any>; rawRequest?: any };
function requireUser(request: CallableRequest) {
  const uid = request.auth?.uid;
  if (!uid) throw new HttpsError('unauthenticated', 'Sign in to continue.');
  return uid;
}
async function membership(uid: string, tenantId: string, token?:Record<string,unknown>) {
  if (!safeId.test(tenantId)) throw new HttpsError('invalid-argument', 'Invalid company selection.');
  const ref=db.doc(`tenants/${tenantId}/members/${uid}`),snap=await ref.get();
  if(!snap.exists)throw new HttpsError('permission-denied','Enterprise membership required.');
  assertCredentialState(snap.data(),token);
  const tenant=await db.doc(`tenants/${tenantId}`).get();assertEnterpriseActive(tenant.data());
  const role=await db.doc(`tenants/${tenantId}/roles/${snap.get('role')}`).get();
  return {ref,tenantId,data:{...snap.data(),effectivePermissions:effectivePermissions(snap.data(),role.data(),permissions)} as any,tenant:tenant.data()};
}
async function requirePermission(m: {data:any;tenantId:string;tenant?:any},key:string){
 if(key.startsWith('team.')&&!isEnterpriseAdmin(m.data.role))throw new HttpsError('permission-denied','Only Admin: Editor manages accounts.');
 const granted=m.data.effectivePermissions||[];
 if(!granted.includes(key))throw new HttpsError('permission-denied',`Missing permission: ${key}`);
 const prefix=key.split('.')[0],module=prefix==='siteProgress'?'operations':prefix==='reports'?'reports':prefix;
 if(m.tenant&&!['team','settings','audit','data','documents'].includes(prefix)&&!m.tenant.subscription.modules.some((x:string)=>x==='*'||x===module||x.startsWith(module+'.')))throw new HttpsError('permission-denied','This module is not enabled by your enterprise license.');
}
async function requireAnyPermission(m: {data:any;tenantId:string;tenant?:any},keys:string[]){for(const key of keys){try{await requirePermission(m,key);return}catch{}}throw new HttpsError('permission-denied','Required action is not authorized.');}
async function requireExplicitPermission(m: {data:any;tenantId:string;tenant?:any},key:string){return requirePermission(m,key);}
function requireCompanyAdmin(m:{data:any}){if(!isEnterpriseAdmin(m.data.role))throw new HttpsError('permission-denied','Only Admin: Editor can manage enterprise users.');}
function clean(value: unknown, max = 160) {
  if (typeof value !== 'string') throw new HttpsError('invalid-argument', 'A required text field is invalid.');
  const result = value.trim();
  if (!result || result.length > max) throw new HttpsError('invalid-argument', 'A text field is empty or too long.');
  return result;
}
function slugId() { return db.collection('_ids').doc().id; }
function hash(value: string) { return createHash('sha256').update(value).digest('hex'); }
function safeEqualHex(a: string, b: string) {
  const aa = Buffer.from(a, 'hex'); const bb = Buffer.from(b, 'hex');
  return aa.length === bb.length && timingSafeEqual(aa, bb);
}

export const createCompany = onCall({enforceAppCheck:true},async()=>{throw new HttpsError('permission-denied','This legacy flow is disabled. Use administrator-provisioned enterprise accounts.');});

export const listMyCompanies=onCall({enforceAppCheck:true},async request=>{
 const uid=requireUser(request),snap=await db.collection(`users/${uid}/memberships`).where('status','==','active').get(),companies:any[]=[];
 for(const entry of snap.docs){const [m,t]=await Promise.all([db.doc(`tenants/${entry.id}/members/${uid}`).get(),db.doc(`tenants/${entry.id}`).get()]);if(!m.exists)continue;try{assertCredentialState(m.data(),request.auth?.token,true);assertEnterpriseActive(t.data());companies.push({tenantId:entry.id,name:t.get('profile.name')||entry.get('name'),role:m.get('role'),mustChangePassword:m.get('mustChangePassword')===true});}catch{}}
 return {companies};
});

export const requestProductDemo = onCall({ enforceAppCheck: true }, async (request) => {
  const name=clean(request.data.name,120);const company=clean(request.data.company,120);const email=clean(request.data.email,254).toLowerCase();const phone=typeof request.data.phone==='string'?request.data.phone.trim().slice(0,32):'';
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))throw new HttpsError('invalid-argument','Enter a valid email address.');
  const id=hash(email);const ref=db.doc(`platformLeads/${id}`);const now=Date.now();let created=false;
  await db.runTransaction(async tx=>{
    const prior=await tx.get(ref);
    if(prior.exists&&prior.get('lastRequestedAt')?.toMillis?.()>now-86400000)throw new HttpsError('resource-exhausted','A request for this email was received recently.');
    tx.set(ref,{name,company,email,phone,status:prior.exists?prior.get('status')||'new':'new',createdAt:prior.exists?prior.get('createdAt'):FieldValue.serverTimestamp(),lastRequestedAt:FieldValue.serverTimestamp()}, {merge:true});created=true;
  });
  return {received:created};
});

export const createSupportTicket = onCall({ enforceAppCheck: true }, async (request) => {
  const uid=requireUser(request);const tenantId=clean(request.data.tenantId,120);const subject=clean(request.data.subject,160);const category=clean(request.data.category,60);const message=clean(request.data.message,4000);
  const m=await membership(uid,tenantId,request.auth?.token);const ticketRef=db.collection('platformTickets').doc();const now=FieldValue.serverTimestamp();
  const batch=db.batch();batch.create(ticketRef,{tenantId,createdBy:uid,creatorEmail:m.data.email||null,subject,category,status:'open',createdAt:now,updatedAt:now});batch.create(ticketRef.collection('messages').doc(),{senderUid:uid,senderType:'customer',message,createdAt:now});
  batch.create(db.doc(`tenants/${tenantId}/auditEvents/${slugId()}`),{tenantId,actorUid:uid,action:'support.ticket.created',entityType:'supportTicket',entityId:ticketRef.id,createdAt:now});await batch.commit();return {ticketId:ticketRef.id,status:'open'};
});

export const listMySupportTickets = onCall({ enforceAppCheck: true }, async (request) => {
  const uid=requireUser(request);const tenantId=clean(request.data.tenantId,120);const m=await membership(uid,tenantId,request.auth?.token);
  const snap=await db.collection('platformTickets').where('tenantId','==',tenantId).limit(100).get();
  return {tickets:snap.docs.filter(d=>d.get('createdBy')===uid||isEnterpriseAdmin(m.data.role)).map(d=>({ticketId:d.id,subject:d.get('subject'),category:d.get('category'),status:d.get('status'),createdAt:d.get('createdAt')?.toDate?.()?.toISOString()||null,updatedAt:d.get('updatedAt')?.toDate?.()?.toISOString()||null,createdBy:d.get('createdBy')}))};
});

export const getSupportTicketMessages = onCall({ enforceAppCheck: true }, async (request) => {
  const uid=requireUser(request);const tenantId=clean(request.data.tenantId,120);const ticketId=clean(request.data.ticketId,120);const m=await membership(uid,tenantId,request.auth?.token);const ticket=await db.doc(`platformTickets/${ticketId}`).get();
  if(!ticket.exists||ticket.get('tenantId')!==tenantId||ticket.get('createdBy')!==uid&&!isEnterpriseAdmin(m.data.role))throw new HttpsError('not-found','Support ticket not found.');
  const messages=await db.collection(`platformTickets/${ticketId}/messages`).orderBy('createdAt','asc').limit(100).get();return {messages:messages.docs.map(d=>({id:d.id,senderType:d.get('senderType'),message:d.get('message'),createdAt:d.get('createdAt')?.toDate?.()?.toISOString()||null}))};
});

export const replySupportTicket = onCall({ enforceAppCheck: true }, async (request) => {
  const uid=requireUser(request);const tenantId=clean(request.data.tenantId,120);const ticketId=clean(request.data.ticketId,120);const message=clean(request.data.message,4000);const m=await membership(uid,tenantId,request.auth?.token);
  const ticketRef=db.doc(`platformTickets/${ticketId}`);const ticket=await ticketRef.get();if(!ticket.exists||ticket.get('tenantId')!==tenantId)throw new HttpsError('not-found','Support ticket not found.');
  if(ticket.get('createdBy')!==uid&&!isEnterpriseAdmin(m.data.role))throw new HttpsError('permission-denied','Only the ticket creator or company admin can reply.');
  const batch=db.batch();const now=FieldValue.serverTimestamp();batch.create(ticketRef.collection('messages').doc(),{senderUid:uid,senderType:'customer',message,createdAt:now});batch.update(ticketRef,{status:'open',updatedAt:now});await batch.commit();return {sent:true};
});

export const listPlatformSupportTickets = onCall({ enforceAppCheck: true }, async (request) => {
  const uid=requireUser(request);requirePlatformAdmin(uid);const snap=await db.collection('platformTickets').orderBy('updatedAt','desc').limit(100).get();
  return {tickets:snap.docs.map(d=>({ticketId:d.id,tenantId:d.get('tenantId'),subject:d.get('subject'),category:d.get('category'),status:d.get('status'),creatorEmail:d.get('creatorEmail'),createdAt:d.get('createdAt')?.toDate?.()?.toISOString()||null,updatedAt:d.get('updatedAt')?.toDate?.()?.toISOString()||null}))};
});

export const getPlatformTicketMessages = onCall({ enforceAppCheck: true }, async (request) => {
  const uid=requireUser(request);requirePlatformAdmin(uid);const ticketId=clean(request.data.ticketId,120);const ticket=await db.doc(`platformTickets/${ticketId}`).get();if(!ticket.exists)throw new HttpsError('not-found','Support ticket not found.');
  const messages=await db.collection(`platformTickets/${ticketId}/messages`).orderBy('createdAt','asc').limit(100).get();return {messages:messages.docs.map(d=>({id:d.id,senderType:d.get('senderType'),message:d.get('message'),createdAt:d.get('createdAt')?.toDate?.()?.toISOString()||null}))};
});

export const replyPlatformSupportTicket = onCall({ enforceAppCheck: true }, async (request) => {
  const uid=requireUser(request);requirePlatformAdmin(uid);const ticketId=clean(request.data.ticketId,120);const message=clean(request.data.message,4000);const status=request.data.status||'open';
  if(!['open','waiting_customer','resolved','closed'].includes(status))throw new HttpsError('invalid-argument','Invalid support status.');
  const ticketRef=db.doc(`platformTickets/${ticketId}`);const ticket=await ticketRef.get();if(!ticket.exists)throw new HttpsError('not-found','Support ticket not found.');const now=FieldValue.serverTimestamp();const batch=db.batch();batch.create(ticketRef.collection('messages').doc(),{senderUid:uid,senderType:'platform',message,createdAt:now});batch.update(ticketRef,{status,updatedAt:now,assignedTo:uid});batch.create(db.doc(`platform/auditEvents/${slugId()}`),{actorUid:uid,action:'support.ticket.replied',entityType:'supportTicket',entityId:ticketId,createdAt:now});await batch.commit();return {sent:true};
});

export const createEmployeeInvite = onCall({enforceAppCheck:true},async()=>{throw new HttpsError('permission-denied','This legacy flow is disabled. Use administrator-provisioned enterprise accounts.');});

export const listCompanyTeam = onCall({ enforceAppCheck: true }, async (request) => {
  const uid = requireUser(request);
  const tenantId = clean(request.data.tenantId, 120);
  const m = await membership(uid, tenantId,request.auth?.token);
  requireCompanyAdmin(m);
  const [members, roles] = await Promise.all([
    db.collection(`tenants/${tenantId}/members`).orderBy('joinedAt', 'desc').limit(200).get(),
    db.collection(`tenants/${tenantId}/roles`).get(),
  ]);
  return {
    members: members.docs.map(doc => ({ uid: doc.id, email: doc.get('email') || '', displayName: doc.get('displayName') || '', roleId: doc.get('role') || '', status: doc.get('status') || 'unknown', joinedAt: doc.get('joinedAt')?.toDate?.()?.toISOString() || null })),
    roles: roles.docs.map(doc => ({ id: doc.id, name: doc.get('name') || doc.id, system: doc.get('system') === true, permissions: Array.isArray(doc.get('permissions')) ? doc.get('permissions') : [] })),
  };
});

export const acceptEmployeeInvite = onCall({enforceAppCheck:true},async()=>{throw new HttpsError('permission-denied','This legacy flow is disabled. Use administrator-provisioned enterprise accounts.');});

export const createCustomRole = onCall({ enforceAppCheck: true }, async (request) => {
  const uid = requireUser(request);
  const tenantId = clean(request.data.tenantId, 120);
  const name = clean(request.data.name, 80);
  if(['admin: editor','enterprise super admin','owner','company admin'].includes(name.toLowerCase()))throw new HttpsError('invalid-argument','Use a distinct custom role name.');
  const requested = request.data.permissions;
  if (!Array.isArray(requested) || requested.length > permissions.length || requested.some(p => !permissions.includes(p) || p === 'data.migrate')) throw new HttpsError('invalid-argument', 'One or more permissions are not supported for a custom role.');
  const m = await membership(uid, tenantId,request.auth?.token);
  requireCompanyAdmin(m);
  const ref = db.collection(`tenants/${tenantId}/roles`).doc();
  await db.runTransaction(async tx=>{tx.create(ref,{name,system:false,permissions:[...new Set(requested)],createdBy:uid,createdAt:FieldValue.serverTimestamp()});tx.create(db.doc(`tenants/${tenantId}/auditEvents/${slugId()}`),{tenantId,actorUid:uid,action:'roles.created',entityType:'role',entityId:ref.id,details:{name,permissions:[...new Set(requested)]},createdAt:FieldValue.serverTimestamp()});});
  return { roleId: ref.id };
});

export const updateCustomRole = onCall({ enforceAppCheck: true }, async (request) => {
  const uid=requireUser(request);const tenantId=clean(request.data.tenantId,120);const roleId=clean(request.data.roleId,80);const name=clean(request.data.name,80);const requested=request.data.permissions;
  if(!Array.isArray(requested)||requested.length>permissions.length||requested.some(p=>!permissions.includes(p)||p==='data.migrate'))throw new HttpsError('invalid-argument','One or more permissions are not supported for a custom role.');
  const m=await membership(uid,tenantId,request.auth?.token);requireCompanyAdmin(m);
  if(['admin: editor','enterprise super admin','owner','company admin'].includes(name.toLowerCase()))throw new HttpsError('invalid-argument','Use a distinct custom role name.');
  const ref=db.doc(`tenants/${tenantId}/roles/${roleId}`);await db.runTransaction(async tx=>{const role=await tx.get(ref);if(!role.exists||role.get('system')===true||isEnterpriseAdmin(roleId))throw new HttpsError('permission-denied','System roles cannot be edited.');tx.update(ref,{name,permissions:[...new Set(requested)],updatedAt:FieldValue.serverTimestamp(),updatedBy:uid});tx.create(db.doc(`tenants/${tenantId}/auditEvents/${slugId()}`),{tenantId,actorUid:uid,action:'roles.updated',entityType:'role',entityId:roleId,details:{before:{name:role.get('name'),permissions:role.get('permissions')||[]},after:{name,permissions:[...new Set(requested)]}},createdAt:FieldValue.serverTimestamp()});});
  return {updated:true};
});

export const assignMemberRole = onCall({enforceAppCheck:true},async()=>{throw new HttpsError('permission-denied','This legacy flow is disabled. Use administrator-provisioned enterprise accounts.');});

export const setMemberStatus = onCall({enforceAppCheck:true},async()=>{throw new HttpsError('permission-denied','This legacy flow is disabled. Use administrator-provisioned enterprise accounts.');});

export const migrateLegacyBatch = onCall({ enforceAppCheck: true }, async (request) => {
  const uid = requireUser(request);
  const tenantId = clean(request.data.tenantId, 120);
  const sourceId = clean(request.data.sourceId || 'localStorage-v1', 100);
  const records = request.data.records;
  if (!Array.isArray(records) || records.length < 1 || records.length > 200) throw new HttpsError('invalid-argument', 'Submit between 1 and 200 records per migration batch.');
  const m = await membership(uid, tenantId,request.auth?.token);
  await requirePermission(m, 'data.migrate');
  const batchId = clean(request.data.batchId, 120);
  const batchRef = db.doc(`tenants/${tenantId}/migrationBatches/${batchId}`);
  let accepted = 0;
  let skipped = 0;
  const importRows: Array<{ row: any; sourceRef: FirebaseFirestore.DocumentReference; targetRef: FirebaseFirestore.DocumentReference; digest: string }> = [];
  const seenRows = new Set<string>();
  for (const row of records) {
    if (!row || !collections.has(row.collection) || !safeId.test(row.id) || !row.data || typeof row.data !== 'object') throw new HttpsError('invalid-argument', 'A migration row has an unsupported collection or ID.');
    const rowKey = `${row.collection}:${row.id}`;
    if (seenRows.has(rowKey)) throw new HttpsError('invalid-argument', `A record appears twice in this batch (${rowKey}).`);
    seenRows.add(rowKey);
    const sourceKey = hash(`${sourceId}:${row.collection}:${row.id}`);
    if (JSON.stringify(row.data).length > 50000 || containsInlineFile(row.data)) throw new HttpsError('invalid-argument',`Record ${row.collection}/${row.id} is too large or still contains an inline file. Move its attachment using the secure upload step first.`);
    importRows.push({ row, sourceRef: db.doc(`tenants/${tenantId}/legacyImports/${sourceKey}`), targetRef: db.doc(`tenants/${tenantId}/${row.collection}/${row.id}`), digest: hash(JSON.stringify(row.data)) });
  }
  await db.runTransaction(async tx => {
    let nextAccepted = 0;
    let nextSkipped = 0;
    const previousBatch = await tx.get(batchRef);
    if (previousBatch.exists && previousBatch.get('status') === 'complete') { accepted = previousBatch.get('count') || 0; skipped = previousBatch.get('skipped') || 0; return; }
    const sourceSnapshots = await Promise.all(importRows.map(item => tx.get(item.sourceRef)));
    const targetSnapshots = await Promise.all(importRows.map(item => tx.get(item.targetRef)));
    for (let i=0;i<importRows.length;i++) {
      const item=importRows[i]; const source=sourceSnapshots[i]; const target=targetSnapshots[i];
      if(source.exists) {
        if(source.get('digest')!==item.digest) throw new HttpsError('already-exists',`A legacy record changed after it was imported (${item.row.collection}/${item.row.id}); review it before retrying.`);
        nextSkipped++; continue;
      }
      if(target.exists) throw new HttpsError('already-exists',`A target record with this ID already exists (${item.row.collection}/${item.row.id}).`);
      const oldBusinessId=typeof item.row.data.businessId==='string'?item.row.data.businessId:undefined;
      const data={...item.row.data,id:item.row.id,tenantId,businessId:tenantId,legacy:{sourceId,sourceRecordId:item.row.id,originalBusinessId:oldBusinessId,importedBy:uid}};
      tx.create(item.targetRef,data);
      tx.create(item.sourceRef,{sourceId,collection:item.row.collection,sourceRecordId:item.row.id,digest:item.digest,batchId,importedAt:FieldValue.serverTimestamp()});
      nextAccepted++;
    }
    tx.set(batchRef,{batchId,sourceId,status:'complete',count:nextAccepted,skipped:nextSkipped,importedBy:uid,completedAt:FieldValue.serverTimestamp()});
    tx.create(db.doc(`tenants/${tenantId}/auditEvents/${slugId()}`),{tenantId,actorUid:uid,action:'migration.batch.imported',entityType:'migrationBatch',entityId:batchId,details:{accepted:nextAccepted,skipped:nextSkipped,sourceId},createdAt:FieldValue.serverTimestamp()});
    accepted = nextAccepted; skipped = nextSkipped;
  });
  return { batchId, duplicate: accepted===0, accepted, skipped };
});

function containsInlineFile(value: unknown): boolean {
  if (typeof value === 'string') return /^data:[^;,]+;base64,/i.test(value);
  if (Array.isArray(value)) return value.some(containsInlineFile);
  if (value && typeof value === 'object') return Object.values(value).some(containsInlineFile);
  return false;
}

const documentMimeTypes = new Set(['image/jpeg','image/png','image/webp','application/pdf']);
const maxLegacyDocumentBytes = 10 * 1024 * 1024;

export const createLegacyAttachmentUpload = onCall({ enforceAppCheck: true }, async (request) => {
  const uid=requireUser(request);const tenantId=clean(request.data.tenantId,120);const sourceId=clean(request.data.sourceId,100);
  const collection=clean(request.data.collection,80);const recordId=clean(request.data.recordId,120);const field=clean(request.data.field,100);
  const fileName=clean(request.data.fileName,180).replace(/[\\/\u0000-\u001f]/g,'_');const contentType=request.data.contentType;const size=request.data.size;const sha256=request.data.sha256;
  const m=await membership(uid,tenantId,request.auth?.token);await requirePermission(m,'data.migrate');
  if(!collections.has(collection)||!safeId.test(recordId)||!documentMimeTypes.has(contentType)||!Number.isSafeInteger(size)||size<1||size>maxLegacyDocumentBytes||typeof sha256!=='string'||!/^[a-f0-9]{64}$/.test(sha256)) throw new HttpsError('invalid-argument','This attachment is unsupported or exceeds 10 MB.');
  const documentId=hash(`${sourceId}:${collection}:${recordId}:${field}`);
  const metadataRef=db.doc(`tenants/${tenantId}/documents/${documentId}`);
  const prior=await metadataRef.get();
  if(prior.exists){
    if(prior.get('sha256')!==sha256||prior.get('size')!==size) throw new HttpsError('already-exists','This attachment changed after a previous migration attempt. Review it before continuing.');
    if(prior.get('status')==='active') return {documentId,objectPath:prior.get('objectPath'),alreadyUploaded:true};
  }else{
    await metadataRef.create({tenantId,documentId,sourceId,linkedCollection:collection,linkedRecordId:recordId,field,fileName,contentType,size,sha256,status:'uploading',createdBy:uid,createdAt:FieldValue.serverTimestamp()});
  }
  const objectPath=`tenants/${tenantId}/documents/${documentId}`;
  const file=getStorage().bucket().file(objectPath);
  const [uploadUrl]=await file.getSignedUrl({version:'v4',action:'write',expires:Date.now()+15*60*1000,contentType,extensionHeaders:{'x-goog-meta-sha256':sha256}});
  return {documentId,objectPath,uploadUrl,alreadyUploaded:false};
});

export const finalizeLegacyAttachmentUpload = onCall({ enforceAppCheck: true }, async (request) => {
  const uid=requireUser(request);const tenantId=clean(request.data.tenantId,120);const documentId=clean(request.data.documentId,100);
  const m=await membership(uid,tenantId,request.auth?.token);await requirePermission(m,'data.migrate');
  const ref=db.doc(`tenants/${tenantId}/documents/${documentId}`);const docSnap=await ref.get();
  if(!docSnap.exists||docSnap.get('status')!=='uploading'||docSnap.get('createdBy')!==uid) throw new HttpsError('not-found','The pending attachment was not found.');
  const objectPath=`tenants/${tenantId}/documents/${documentId}`;const file=getStorage().bucket().file(objectPath);
  const [meta]=await file.getMetadata();const [bytes]=await file.download();const actualHash=createHash('sha256').update(bytes).digest('hex');
  const signatureOk=meta.contentType==='application/pdf'?bytes.subarray(0,5).toString()==='%PDF-':meta.contentType==='image/jpeg'?bytes[0]===0xff&&bytes[1]===0xd8&&bytes[2]===0xff:meta.contentType==='image/png'?bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])):meta.contentType==='image/webp'?bytes.subarray(0,4).toString()==='RIFF'&&bytes.subarray(8,12).toString()==='WEBP':false;
  if(Number(meta.size)!==docSnap.get('size')||meta.contentType!==docSnap.get('contentType')||meta.metadata?.sha256!==docSnap.get('sha256')||actualHash!==docSnap.get('sha256')||!signatureOk||Number(meta.size)>maxLegacyDocumentBytes){
    await file.delete({ignoreNotFound:true});await ref.update({status:'rejected',rejectedAt:FieldValue.serverTimestamp()});throw new HttpsError('data-loss','The uploaded attachment did not match the expected file. It was rejected.');
  }
  await ref.update({status:'active',objectPath,md5Hash:meta.md5Hash||null,confirmedAt:FieldValue.serverTimestamp()});
  return {documentId,objectPath,size:Number(meta.size),contentType:meta.contentType};
});

export const createDocumentDownloadUrl = onCall({ enforceAppCheck: true }, async (request) => {
  const uid=requireUser(request);const tenantId=clean(request.data.tenantId,120);const documentId=clean(request.data.documentId,100);
  const m=await membership(uid,tenantId,request.auth?.token);await requirePermission(m,'documents.read');
  const ref=db.doc(`tenants/${tenantId}/documents/${documentId}`);const snap=await ref.get();
  if(!snap.exists||snap.get('status')!=='active') throw new HttpsError('not-found','The document is unavailable.');if(!isEnterpriseAdmin(m.data.role)){let project=snap.get('projectId');if(!project&&collections.has(snap.get('linkedCollection'))&&safeId.test(snap.get('linkedRecordId'))){const record=await db.doc(`tenants/${tenantId}/${snap.get('linkedCollection')}/${snap.get('linkedRecordId')}`).get();project=record.get('projectId');}assertProject(m.data,project);}
  const file=getStorage().bucket().file(snap.get('objectPath'));
  const [downloadUrl]=await file.getSignedUrl({version:'v4',action:'read',expires:Date.now()+5*60*1000,responseDisposition:`attachment; filename="${String(snap.get('fileName')).replace(/["\\\r\n]/g,'_')}"`});
  return {downloadUrl,expiresInSeconds:300,fileName:snap.get('fileName'),contentType:snap.get('contentType')};
});

export const syncTenantCollection = onCall({ enforceAppCheck: true }, async (request) => {
  const uid = requireUser(request);
  const tenantId = clean(request.data.tenantId, 120);
  const collection = clean(request.data.collection, 80);
  const records = request.data.records;
  const deletedIds = request.data.deletedIds || [];
  if (!syncableCollections.has(collection) || !Array.isArray(records) || !Array.isArray(deletedIds) || records.length + deletedIds.length > 300) {
    throw new HttpsError('invalid-argument', 'Invalid or oversized company data update.');
  }
  const m = await membership(uid, tenantId,request.auth?.token);
  await requirePermission(m, collectionPermissions[collection] || 'projects.edit');
  if (deletedIds.length) await requireExplicitPermission(m, collection === 'projects' ? 'projects.delete' : 'data.delete');
  const tenantRef = db.doc(`tenants/${tenantId}`);
  const tenant = await tenantRef.get();
  const sub = tenant.get('subscription');
  const trialEnded = sub?.status === 'trial' && sub.trialEndsAt?.toMillis?.() <= Date.now();
  if (!tenant.exists || tenant.get('status') !== 'active' || !sub || ['expired','suspended'].includes(sub.status) || trialEnded) {
    throw new HttpsError('failed-precondition', 'This company is currently read-only.');
  }
  const planModules = sub.modules || [];
  const moduleName = collectionModules[collection] || collection;
  if (!planModules.includes('*') && !planModules.includes(moduleName)) {
    throw new HttpsError('permission-denied', 'This module is not included in the company plan.');
  }
  const refs = records.map((row: any) => {
    if (!row || typeof row.id !== 'string' || !safeId.test(row.id) || !row.data || typeof row.data !== 'object' || JSON.stringify(row.data).length > 50000) {
      throw new HttpsError('invalid-argument', 'A company record is invalid or too large.');
    }
    return { id: row.id, ref: db.doc(`tenants/${tenantId}/${collection}/${row.id}`), data: row.data };
  });
  if (deletedIds.some((id: unknown) => typeof id !== 'string' || !safeId.test(id))) throw new HttpsError('invalid-argument', 'A deleted record ID is invalid.');
  await db.runTransaction(async tx=>{
   const deletedRefs=(deletedIds as string[]).map(id=>db.doc(`tenants/${tenantId}/${collection}/${id}`));
   const previous=await Promise.all([...refs.map(x=>tx.get(x.ref)),...deletedRefs.map(x=>tx.get(x))]);
   if(!isEnterpriseAdmin(m.data.role)){
    refs.forEach((row,i)=>{assertProject(m.data,collection==='projects'?row.id:row.data.projectId);if(previous[i].exists)assertProject(m.data,collection==='projects'?row.id:previous[i].get('projectId'));});
    deletedRefs.forEach((ref,i)=>{if(previous[refs.length+i].exists)assertProject(m.data,collection==='projects'?ref.id:previous[refs.length+i].get('projectId'));});
   }
   const now=FieldValue.serverTimestamp();
   refs.forEach(row=>tx.set(row.ref,{...row.data,id:row.id,tenantId,businessId:tenantId,updatedAt:now},{merge:true}));
   deletedRefs.forEach(ref=>tx.delete(ref));
   tx.create(db.doc(`tenants/${tenantId}/auditEvents/${slugId()}`),{tenantId,actorUid:uid,action:'data.collection.synced',entityType:collection,entityId:`${records.length} records`,details:{updated:records.length,deleted:deletedIds.length},createdAt:now});
  });
  return { updated: records.length, deleted: deletedIds.length };
});

const purchaseInvoiceMimeTypes = new Set(['application/pdf','image/jpeg','image/png']);
const maxPurchaseInvoiceBytes = 10 * 1024 * 1024;

export const createPurchaseInvoiceUpload = onCall({ enforceAppCheck: true }, async (request) => {
  const uid=requireUser(request);const tenantId=clean(request.data.tenantId,120);const billId=clean(request.data.billId,120);
  const fileName=clean(request.data.fileName,180).replace(/[\\/\u0000-\u001f]/g,'_');const contentType=request.data.contentType;const size=request.data.size;const sha256=request.data.sha256;
  if(!safeId.test(billId)||!purchaseInvoiceMimeTypes.has(contentType)||!Number.isSafeInteger(size)||size<1||size>maxPurchaseInvoiceBytes||typeof sha256!=='string'||!/^[a-f0-9]{64}$/.test(sha256))throw new HttpsError('invalid-argument','Choose a PDF, JPG, JPEG or PNG invoice no larger than 10 MB.');
  const m=await membership(uid,tenantId,request.auth?.token);await requireAnyPermission(m,['purchases.invoice.upload','purchases.create']);
  const tenant=await db.doc(`tenants/${tenantId}`).get();const sub=tenant.get('subscription');
  if(!tenant.exists||tenant.get('status')!=='active'||!sub||['expired','suspended'].includes(sub.status)||sub.status==='trial'&&sub.trialEndsAt?.toMillis?.()<=Date.now())throw new HttpsError('failed-precondition','This company cannot upload purchase documents in its current plan state.');
  const projectId=clean(request.data.projectId,120);assertProject(m.data,projectId);if(!(await db.doc(`tenants/${tenantId}/projects/${projectId}`).get()).exists)throw new HttpsError('invalid-argument','Assigned project not found.');const documentId=slugId();const objectPath=`tenants/${tenantId}/purchaseInvoices/${billId}/${documentId}`;
  await db.doc(`tenants/${tenantId}/documents/${documentId}`).create({tenantId,projectId,documentId,linkedCollection:'purchaseBills',linkedRecordId:billId,fileName,contentType,size,sha256,objectPath,status:'uploading',documentType:'original_purchase_invoice',createdBy:uid,createdAt:FieldValue.serverTimestamp()});
  const file=getStorage().bucket().file(objectPath);const [uploadUrl]=await file.getSignedUrl({version:'v4',action:'write',expires:Date.now()+15*60*1000,contentType,extensionHeaders:{'x-goog-meta-sha256':sha256}});
  return {documentId,uploadUrl,contentType,size,fileName};
});

export const finalizePurchaseInvoiceUpload = onCall({ enforceAppCheck: true }, async (request) => {
  const uid=requireUser(request);const tenantId=clean(request.data.tenantId,120);const documentId=clean(request.data.documentId,120);const m=await membership(uid,tenantId,request.auth?.token);await requireAnyPermission(m,['purchases.invoice.upload','purchases.create']);
  const ref=db.doc(`tenants/${tenantId}/documents/${documentId}`);const snap=await ref.get();
  if(!snap.exists||snap.get('status')!=='uploading'||snap.get('createdBy')!==uid||snap.get('linkedCollection')!=='purchaseBills')throw new HttpsError('not-found','The pending purchase invoice upload was not found.');
  assertProject(m.data,snap.get('projectId'));const file=getStorage().bucket().file(snap.get('objectPath'));const [meta]=await file.getMetadata();const [contents]=await file.download();const actualHash=createHash('sha256').update(contents).digest('hex');
  const signatureOk=meta.contentType==='application/pdf'?contents.subarray(0,5).toString()==='%PDF-':meta.contentType==='image/jpeg'?contents[0]===0xff&&contents[1]===0xd8&&contents[2]===0xff:meta.contentType==='image/png'?contents.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])):false;
  if(Number(meta.size)!==snap.get('size')||meta.contentType!==snap.get('contentType')||Number(meta.size)>maxPurchaseInvoiceBytes||actualHash!==snap.get('sha256')||!signatureOk){
    await file.delete({ignoreNotFound:true});await ref.update({status:'rejected',rejectedAt:FieldValue.serverTimestamp()});throw new HttpsError('data-loss','The invoice upload did not pass file verification and was rejected.');
  }
  await ref.update({status:'active',confirmedAt:FieldValue.serverTimestamp(),storageGeneration:meta.generation||null});
  await db.doc(`tenants/${tenantId}/auditEvents/${slugId()}`).create({tenantId,actorUid:uid,action:'purchase.invoice.uploaded',entityType:'purchaseBill',entityId:snap.get('linkedRecordId'),details:{documentId,fileName:snap.get('fileName'),size:Number(meta.size)},createdAt:FieldValue.serverTimestamp()});
  return {documentId,fileName:snap.get('fileName'),contentType:snap.get('contentType'),size:Number(meta.size)};
});

export const savePurchaseBillRecord = onCall({ enforceAppCheck: true }, async (request) => {
  const uid=requireUser(request);const tenantId=clean(request.data.tenantId,120);const bill=request.data.bill;const documentId=typeof request.data.documentId==='string'?clean(request.data.documentId,120):'';
  if(!bill||typeof bill!=='object'||!safeId.test(bill.id)||!safeId.test(bill.projectId)||!safeId.test(bill.supplierId)||typeof bill.supplierName!=='string'||!bill.supplierName.trim()||bill.supplierName.length>180||typeof bill.invoiceNumber!=='string'||!bill.invoiceNumber.trim()||bill.invoiceNumber.length>120||typeof bill.invoiceDate!=='string'||bill.invoiceDate.length>20||typeof bill.category!=='string'||bill.category.length>100||typeof bill.materialDetails!=='string'||bill.materialDetails.length>4000||typeof bill.isGstRecoverable!=='boolean')throw new HttpsError('invalid-argument','The purchase invoice details are incomplete or invalid.');
  for(const key of ['taxableAmount','cgstAmount','sgstAmount','igstAmount','totalGstAmount','discount','totalAmount'])if(!Number.isFinite(bill[key])||bill[key]<0||bill[key]>1_000_000_000)throw new HttpsError('invalid-argument',`The ${key} value is invalid.`);
  const m=await membership(uid,tenantId,request.auth?.token);await requireAnyPermission(m,['purchases.create']);assertProject(m.data,bill.projectId);if(!(await db.doc(`tenants/${tenantId}/projects/${bill.projectId}`).get()).exists)throw new HttpsError('invalid-argument','Project not found.');
  const tenantRef=db.doc(`tenants/${tenantId}`);const tenant=await tenantRef.get();const sub=tenant.get('subscription');
  if(!tenant.exists||tenant.get('status')!=='active'||!sub||['expired','suspended'].includes(sub.status)||sub.status==='trial'&&sub.trialEndsAt?.toMillis?.()<=Date.now())throw new HttpsError('failed-precondition','This company is currently read-only.');
  if(!(sub.modules||[]).includes('*')&&!(sub.modules||[]).includes('purchases'))throw new HttpsError('permission-denied','Purchases are not included in this company plan.');
  let document:any=null;if(documentId){const docSnap=await db.doc(`tenants/${tenantId}/documents/${documentId}`).get();if(!docSnap.exists||docSnap.get('status')!=='active'||docSnap.get('linkedRecordId')!==bill.id||docSnap.get('linkedCollection')!=='purchaseBills'||docSnap.get('createdBy')!==uid)throw new HttpsError('failed-precondition','The attached original invoice is not available for this purchase record.');document={documentId,fileName:docSnap.get('fileName'),contentType:docSnap.get('contentType'),size:docSnap.get('size'),uploadedBy:uid,uploadedAt:docSnap.get('confirmedAt')||docSnap.get('createdAt')};}
  const billRef=db.doc(`tenants/${tenantId}/purchaseBills/${bill.id}`);const now=FieldValue.serverTimestamp();
  await db.runTransaction(async tx=>{const prior=await tx.get(billRef);if(prior.exists){const same=prior.get('createdBy')===uid&&prior.get('invoiceNumber')===bill.invoiceNumber.trim()&&prior.get('supplierId')===bill.supplierId&&prior.get('totalAmount')===bill.totalAmount&&prior.get('documentId')===(document?.documentId||null);if(same)return;throw new HttpsError('already-exists','This purchase invoice record already exists.');}tx.create(billRef,{id:bill.id,tenantId,businessId:tenantId,projectId:bill.projectId,projectName:typeof bill.projectName==='string'?bill.projectName.slice(0,160):'',projectCode:typeof bill.projectCode==='string'?bill.projectCode.slice(0,40):'',supplierId:bill.supplierId,supplierName:bill.supplierName.trim(),supplierGstin:typeof bill.supplierGstin==='string'?bill.supplierGstin.slice(0,30):null,invoiceNumber:bill.invoiceNumber.trim(),invoiceDate:bill.invoiceDate,dueDate:typeof bill.dueDate==='string'?bill.dueDate.slice(0,20):'',category:bill.category,materialDetails:bill.materialDetails,taxableAmount:bill.taxableAmount,cgstAmount:bill.cgstAmount,sgstAmount:bill.sgstAmount,igstAmount:bill.igstAmount,totalGstAmount:bill.totalGstAmount,isGstRecoverable:bill.isGstRecoverable,discount:bill.discount,totalAmount:bill.totalAmount,amountPaid:0,verificationStatus:'pending_verification',verifiedBy:null,verifiedAt:null,approvalStatus:'pending_approval',paymentStatus:'unpaid',documentId:document?.documentId||null,documentName:document?.fileName||null,documentContentType:document?.contentType||null,documentSize:document?.size||null,documentUploadedBy:document?.uploadedBy||null,documentUploadedAt:document?.uploadedAt||null,createdBy:uid,createdAt:now});tx.create(db.doc(`tenants/${tenantId}/auditEvents/${slugId()}`),{tenantId,actorUid:uid,action:'purchase.invoice.created',entityType:'purchaseBill',entityId:bill.id,details:{hasOriginalInvoice:Boolean(documentId)},createdAt:now});});
  return {id:bill.id,tenantId,verificationStatus:'pending_verification',documentId:document?.documentId||null};
});

export const listCompanyPurchaseBills = onCall({ enforceAppCheck: true }, async (request) => {
  const uid=requireUser(request);const tenantId=clean(request.data.tenantId,120);const m=await membership(uid,tenantId,request.auth?.token);await requireAnyPermission(m,['purchases.read','purchases.invoice.view']);
  const snapshot=await db.collection(`tenants/${tenantId}/purchaseBills`).orderBy('createdAt','desc').limit(200).get();
  return {bills:snapshot.docs.filter(doc=>isEnterpriseAdmin(m.data.role)||projectIds(m.data).includes(doc.get('projectId'))).map(doc=>({id:doc.id,...doc.data(),createdAt:doc.get('createdAt')?.toDate?.()?.toISOString()||null,verifiedAt:doc.get('verifiedAt')?.toDate?.()?.toISOString()||null,documentUploadedAt:doc.get('documentUploadedAt')?.toDate?.()?.toISOString()||null}))};
});

export const getPurchaseInvoiceAccess = onCall({ enforceAppCheck: true }, async (request) => {
  const uid=requireUser(request);const tenantId=clean(request.data.tenantId,120);const billId=clean(request.data.billId,120);const documentId=clean(request.data.documentId,120);const disposition=request.data.disposition==='attachment'?'attachment':'inline';
  const m=await membership(uid,tenantId,request.auth?.token);await requireAnyPermission(m,disposition==='attachment'?['purchases.invoice.download','purchases.read']:['purchases.invoice.view','purchases.read']);
  const [bill,docSnap]=await Promise.all([db.doc(`tenants/${tenantId}/purchaseBills/${billId}`).get(),db.doc(`tenants/${tenantId}/documents/${documentId}`).get()]);
  if(!bill.exists||bill.get('documentId')!==documentId||!docSnap.exists||docSnap.get('status')!=='active'||docSnap.get('linkedRecordId')!==billId||docSnap.get('linkedCollection')!=='purchaseBills')throw new HttpsError('not-found','The original invoice document is not available.');
  assertProject(m.data,bill.get('projectId'));const name=String(docSnap.get('fileName')||'invoice').replace(/["\\\r\n]/g,'_');const contentType=docSnap.get('contentType');
  const [url]=await getStorage().bucket().file(docSnap.get('objectPath')).getSignedUrl({version:'v4',action:'read',expires:Date.now()+5*60*1000,responseDisposition:`${disposition}; filename="${name}"`,responseType:contentType});
  await db.doc(`tenants/${tenantId}/auditEvents/${slugId()}`).create({tenantId,actorUid:uid,action:disposition==='attachment'?'purchase.invoice.downloaded':'purchase.invoice.viewed',entityType:'purchaseBill',entityId:billId,details:{documentId},createdAt:FieldValue.serverTimestamp()});
  return {url,fileName:docSnap.get('fileName'),contentType,size:docSnap.get('size'),expiresInSeconds:300};
});

export const verifyPurchaseInvoice = onCall({ enforceAppCheck: true }, async (request) => {
  const uid=requireUser(request);const tenantId=clean(request.data.tenantId,120);const billId=clean(request.data.billId,120);const status=request.data.status;
  if(!['verified','rejected'].includes(status))throw new HttpsError('invalid-argument','Select Verified or Rejected.');
  const m=await membership(uid,tenantId,request.auth?.token);await requireAnyPermission(m,status==='verified'?['purchases.invoice.verify','purchases.approve']:['purchases.invoice.reject','purchases.approve']);
  const billRef=db.doc(`tenants/${tenantId}/purchaseBills/${billId}`);const user=await getAuth().getUser(uid);const now=FieldValue.serverTimestamp();
  await db.runTransaction(async tx=>{const bill=await tx.get(billRef);if(!bill.exists)throw new HttpsError('not-found','Purchase invoice record not found.');assertProject(m.data,bill.get('projectId'));const documentId=bill.get('documentId');if(!documentId)throw new HttpsError('failed-precondition','Attach an original invoice before verifying or rejecting the figures.');const document=await tx.get(db.doc(`tenants/${tenantId}/documents/${documentId}`));if(!document.exists||document.get('status')!=='active'||document.get('linkedRecordId')!==billId)throw new HttpsError('failed-precondition','The original invoice document is unavailable for verification.');tx.update(billRef,{verificationStatus:status,verifiedBy:{uid,name:user.displayName||user.email||uid},verifiedAt:now,verificationNotes:typeof request.data.notes==='string'?request.data.notes.slice(0,1000):null});tx.create(db.doc(`tenants/${tenantId}/auditEvents/${slugId()}`),{tenantId,actorUid:uid,action:`purchase.invoice.${status}`,entityType:'purchaseBill',entityId:billId,createdAt:now});});
  return {verified:true,status};
});

const progressPhotoTypes = new Set(['image/jpeg','image/png']);
const maxProgressPhotoBytes = 15 * 1024 * 1024;
const quantityRound=(value:number)=>Math.round((value+Number.EPSILON)*1e6)/1e6;
function progressIds(value:unknown,max=100):string[]{if(!Array.isArray(value)||value.length>max||value.some(v=>typeof v!=='string'||!safeId.test(v)))throw new HttpsError('invalid-argument','Invalid access list.');return [...new Set(value as string[])];}
async function progressAllowed(m:{data:any;tenantId:string},projectId:string,level:'submit'|'read'|'review'='submit'){
  if(isEnterpriseAdmin(m.data.role))return true;const a=m.data.siteProgressAccess||{};if(!(a.projectIds||[]).includes(projectId))return false;
  if(level==='submit'&&!['submit','review'].includes(a.permissionLevel))return false;if(level==='read'&&!['read','review'].includes(a.permissionLevel))return false;if(level==='review'&&a.permissionLevel!=='review')return false;return true;
}
function getJpegExif(bytes:Buffer):{raw:string;offset:string|null}|null{try{let p=2;while(p+4<bytes.length&&bytes[p]===255){const marker=bytes[p+1],len=bytes.readUInt16BE(p+2);if(marker===225&&bytes.subarray(p+4,p+10).toString('ascii')==='Exif\0\0'){const base=p+10,le=bytes.toString('ascii',base,base+2)==='II',u16=(x:number)=>le?bytes.readUInt16LE(x):bytes.readUInt16BE(x),u32=(x:number)=>le?bytes.readUInt32LE(x):bytes.readUInt32BE(x),ascii=(ifd:number,tag:number)=>{for(let i=0,n=u16(ifd),e=ifd+2;i<n;i++,e+=12)if(u16(e)===tag){const count=u32(e+4),off=count<=4?e+8:base+u32(e+8);return bytes.toString('ascii',off,off+Math.min(count,40)).replace(/\0.*$/,'');}return null;};const root=base+u32(base+4);let exif:number|undefined;for(let i=0,n=u16(root),e=root+2;i<n;i++,e+=12)if(u16(e)===34665)exif=base+u32(e+8);if(exif===undefined)return null;const raw=ascii(exif,36867)||ascii(exif,36868),offset=ascii(exif,36881)||ascii(exif,36880);return raw?{raw,offset}:null;}if(len<2)break;p+=len+2;}}catch{}return null;}
function exifIso(e:{raw:string;offset:string|null}|null):string|null{if(!e||!e.offset||! /^\d{4}:\d{2}:\d{2} \d{2}:\d{2}:\d{2}$/.test(e.raw)||! /^[+-]\d{2}:?\d{2}$/.test(e.offset))return null;const raw=e.raw.replace(/^(.{4}):(.{2}):(.{2}) /,'$1-$2-$3T'),offset=e.offset.includes(':')?e.offset:e.offset.slice(0,3)+':'+e.offset.slice(3),ms=Date.parse(raw+offset);return Number.isNaN(ms)?null:new Date(ms).toISOString();}

export const listSiteProgressWorkspace=onCall({enforceAppCheck:true},async request=>{
 const uid=requireUser(request),tenantId=clean(request.data.tenantId,120),m=await membership(uid,tenantId,request.auth?.token),role=await db.doc('tenants/'+tenantId+'/roles/'+m.data.role).get(),perms=m.data.effectivePermissions||[],isAdmin=isEnterpriseAdmin(m.data.role),manage=isAdmin,allocate=isAdmin||perms.includes('siteProgress.allocate'),read=isAdmin||perms.includes('siteProgress.read')||perms.includes('siteProgress.review'),submit=!isAdmin&&perms.includes('siteProgress.submit'),review=isAdmin||perms.includes('siteProgress.review');
 await requireAnyPermission(m,['siteProgress.read','siteProgress.submit','siteProgress.review','siteProgress.allocate']);
 const afterId=typeof request.data.pageAfter==='string'?request.data.pageAfter:'',afterSnap=afterId?await db.doc('tenants/'+tenantId+'/siteProgressReports/'+clean(afterId,120)).get():null,reportsQuery=db.collection('tenants/'+tenantId+'/siteProgressReports').orderBy('submittedAt','desc'),[ps,cs,ws,rs,ms,tenant]=await Promise.all([db.collection('tenants/'+tenantId+'/projects').limit(1000).get(),db.collection('tenants/'+tenantId+'/siteProgressCategories').get(),db.collection('tenants/'+tenantId+'/siteProgressWorkItems').limit(2000).get(),(afterSnap?.exists?reportsQuery.startAfter(afterSnap):reportsQuery).limit(100).get(),allocate?db.collection('tenants/'+tenantId+'/members').where('status','==','active').limit(500).get():Promise.resolve(null),db.doc('tenants/'+tenantId).get()]);
 const assignedProjectIds=new Set<string>(m.data.siteProgressAccess?.projectIds||[]),assignedItems=ws.docs.filter(d=>(d.get('assignedToUids')||[]).includes(uid)&&(!Array.isArray(m.data.projectIds)||m.data.projectIds.includes(d.get('projectId')))),itemProjectIds=new Set(assignedItems.map(d=>d.get('projectId'))),projects=ps.docs.filter(d=>isAdmin||assignedProjectIds.has(d.id)||itemProjectIds.has(d.id)).map(d=>({id:d.id,name:d.get('name')||d.get('projectName')||d.id,code:d.get('code')||'',description:d.get('description')||'',status:d.get('status')||'Active'})),pids=new Set(projects.map(p=>p.id));
 const workItems=ws.docs.filter(d=>pids.has(d.get('projectId'))&&(isAdmin||assignedItems.some(x=>x.id===d.id)||read&&assignedProjectIds.has(d.get('projectId'))&&['read','review'].includes(m.data.siteProgressAccess?.permissionLevel))).map(d=>({...d.data(),id:d.id,approvedQuantity:Number(d.get('approvedQuantity')||0),remainingQuantity:Math.max(0,quantityRound(Number(d.get('targetQuantity')||0)-Number(d.get('approvedQuantity')||0))),completionPercent:Number(d.get('targetQuantity')||0)>0?Math.min(100,Number(d.get('approvedQuantity')||0)/Number(d.get('targetQuantity'))*100):0}));
 const workItemIds=new Set(workItems.map(x=>x.id)),assignedCategories=new Set<string>([...(m.data.siteProgressAccess?.categoryIds||[]),...workItems.map((x:any)=>x.categoryId)]),categories=cs.docs.filter(d=>((d.get('projectIds')||[]).length===0||(d.get('projectIds')||[]).some((id:string)=>pids.has(id))||manage&&d.get('legacyUnassigned')===true)&&(isAdmin||manage||assignedCategories.has(d.id)||(d.get('memberUids')||[]).includes(uid))).map(d=>({id:d.id,...d.data()})),visibleCategoryIds=new Set(categories.map(c=>c.id));
 const reports=rs.docs.filter(d=>{const own=d.get('submittedBy')===uid,itemId=d.get('workItemId'),legacy=!itemId;return own&&workItemIds.has(itemId)||isAdmin&&legacy||itemId&&workItemIds.has(itemId)&&(isAdmin||read||d.get('submittedBy')===uid)}).map(d=>({id:d.id,...d.data(),submittedAt:d.get('submittedAt')?.toDate?.()?.toISOString()||null,uploadAt:d.get('uploadAt')?.toDate?.()?.toISOString()||null}));
 const today=new Intl.DateTimeFormat('en-CA',{timeZone:tenant.get('profile.timezone')||'Asia/Kolkata'}).format(new Date()),[todaySnap,pendingSnap]=await Promise.all([db.collection('tenants/'+tenantId+'/siteProgressReports').where('workDate','==',today).limit(1000).get(),db.collection('tenants/'+tenantId+'/siteProgressReports').where('status','==','Pending Review').limit(1000).get()]),visibleReport=(d:FirebaseFirestore.QueryDocumentSnapshot)=>isAdmin||workItemIds.has(d.get('workItemId'))&&(read||d.get('submittedBy')===uid);
 const summary={allocated:workItems.filter((x:any)=>x.status!=='Archived').length,completed:workItems.filter((x:any)=>x.status==='Completed'||x.completionPercent>=100).length,inProgress:workItems.filter((x:any)=>x.status==='In Progress').length,delayed:workItems.filter((x:any)=>x.status!=='Completed'&&x.status!=='Archived'&&x.targetDate&&x.targetDate<today).length,reportedToday:todaySnap.docs.filter(visibleReport).length,quantitiesToday:todaySnap.docs.filter(visibleReport).reduce((totals:Record<string,{reported:number;approved:number}>,d)=>{const unit=d.get('unit')||'Unspecified';totals[unit]||={reported:0,approved:0};totals[unit].reported+=Number(d.get('quantity')||0);if(['Approved','Verified'].includes(d.get('status')))totals[unit].approved+=Number(d.get('approvedQuantity')??d.get('quantity')??0);return totals;},{}),pendingReview:pendingSnap.docs.filter(visibleReport).length};
 return {permissions:{isAdmin,manage,allocate,read,submit,review},timezone:tenant.get('profile.timezone')||'Asia/Kolkata',myAccess:m.data.siteProgressAccess||null,projects,categories,workItems,reports,nextPage:rs.docs.length===100?rs.docs[rs.docs.length-1].id:null,summary,members:ms?.docs.filter(d=>isAdmin||(d.get('siteProgressAccess')?.projectIds||[]).some((id:string)=>assignedProjectIds.has(id))).map(d=>({uid:d.id,email:d.get('email')||'',displayName:d.get('displayName')||'',role:d.get('role'),isEnterpriseAdmin:isEnterpriseAdmin(d.get('role')),access:d.get('siteProgressAccess')||null}))||[]};
});
export const saveSiteProgressCategory=onCall({enforceAppCheck:true},async request=>{
 const uid=requireUser(request),tenantId=clean(request.data.tenantId,120),m=await membership(uid,tenantId,request.auth?.token);if(!isEnterpriseAdmin(m.data.role))throw new HttpsError('permission-denied','Only enterprise administrators manage categories and access.');
 const name=clean(request.data.name,100).replace(/\s+/g,' '),normalizedName=name.toLocaleLowerCase('en'),description=typeof request.data.description==='string'?request.data.description.trim().slice(0,1000):'',workCode=typeof request.data.workCode==='string'?request.data.workCode.trim().slice(0,40):'',defaultUnit=typeof request.data.defaultUnit==='string'?request.data.defaultUnit.trim().slice(0,30):'',subcategories=Array.isArray(request.data.subcategories)?[...new Set(request.data.subcategories.filter((x:unknown)=>typeof x==='string').map((x:string)=>x.trim().replace(/\s+/g,' ')).filter(Boolean).map((x:string)=>x.slice(0,100)))].slice(0,50):[],projectIds=progressIds(Array.isArray(request.data.projectIds)?request.data.projectIds:(request.data.projectId?[request.data.projectId]:[]),20),memberUids=progressIds(request.data.memberUids||[],200),categoryId=typeof request.data.categoryId==='string'?clean(request.data.categoryId,120):slugId(),status=request.data.status||(request.data.active===false?'Inactive':'Active');
 if(!safeId.test(categoryId)||request.data.legacyUnassigned===true&&!projectIds.length||!['Active','Inactive'].includes(status))throw new HttpsError('invalid-argument','Choose a project for an imported category and a valid category status.');
 if(projectIds.some(id=>!isEnterpriseAdmin(m.data.role)&&!m.data.siteProgressAccess?.projectIds?.includes(id)))throw new HttpsError('permission-denied','You may only manage categories for projects assigned to you.');
 const [projects,members]=await Promise.all([Promise.all(projectIds.map(id=>db.doc('tenants/'+tenantId+'/projects/'+id).get())),Promise.all(memberUids.map(id=>db.doc('tenants/'+tenantId+'/members/'+id).get()))]);if(projects.some(x=>!x.exists)||members.some(x=>!x.exists||x.get('status')!=='active'))throw new HttpsError('failed-precondition','Selected projects must belong to this company and members must be active.');
 const ref=db.doc('tenants/'+tenantId+'/siteProgressCategories/'+categoryId),existing=await ref.get();if(existing.get('archivedAt'))throw new HttpsError('failed-precondition','Archived categories cannot be edited or reactivated.');
 const allCategories=await db.collection('tenants/'+tenantId+'/siteProgressCategories').get();if(allCategories.docs.some(d=>d.id!==categoryId&&String(d.get('normalizedName')||String(d.get('name')||'').trim().replace(/\s+/g,' ').toLocaleLowerCase('en'))===normalizedName))throw new HttpsError('already-exists','A work category with this name already exists in this enterprise.');
 const markerRefs=[db.doc('tenants/'+tenantId+'/siteProgressCategoryNames/'+hash(normalizedName))],oldProjectIds=existing.exists?(existing.get('projectIds')||[]):[],oldName=String(existing.get('normalizedName')||String(existing.get('name')||'').trim().replace(/\s+/g,' ').toLocaleLowerCase('en')),oldMarkerRefs=[db.doc('tenants/'+tenantId+'/siteProgressCategoryNames/'+hash(oldName)),...oldProjectIds.map((projectId:string)=>db.doc('tenants/'+tenantId+'/siteProgressCategoryNames/'+hash(projectId+'|'+oldName)))],now=FieldValue.serverTimestamp(),auditRef=db.doc('tenants/'+tenantId+'/auditEvents/'+slugId());
 await db.runTransaction(async tx=>{const [current,...markers]=await Promise.all([tx.get(ref),...markerRefs.map(x=>tx.get(x))]);if(current.exists&&current.get('archivedAt'))throw new HttpsError('failed-precondition','Archived categories cannot be edited or reactivated.');for(let i=0;i<markers.length;i++)if(markers[i].exists&&markers[i].get('categoryId')!==categoryId)throw new HttpsError('already-exists','A category with this name already exists in this enterprise.');for(let i=0;i<markerRefs.length;i++)tx.set(markerRefs[i],{categoryId,projectId:projectIds[0]||null,normalizedName,tenantId,updatedAt:now});for(const oldRef of oldMarkerRefs)if(!markerRefs.some(x=>x.path===oldRef.path))tx.delete(oldRef);tx.set(ref,{id:categoryId,tenantId,name,normalizedName,workCode,defaultUnit,subcategories,description,projectId:projectIds[0]||null,projectIds,scope:projectIds.length?'projects':'enterprise',memberUids,status,active:status==='Active',legacyUnassigned:false,quantityEnabled:request.data.quantityEnabled===true,unit:typeof request.data.unit==='string'?request.data.unit.slice(0,30):'',createdBy:current.get('createdBy')||uid,createdAt:current.get('createdAt')||now,updatedBy:uid,updatedAt:now},{merge:true});tx.create(auditRef,{tenantId,actorUid:uid,action:current.exists?'siteProgress.category.updated':'siteProgress.category.created',entityType:'siteProgressCategory',entityId:categoryId,details:{projectIds,status,workCode},createdAt:now});});return {categoryId};
});
export const archiveSiteProgressCategory=onCall({enforceAppCheck:true},async request=>{const uid=requireUser(request),tenantId=clean(request.data.tenantId,120),categoryId=clean(request.data.categoryId,120),m=await membership(uid,tenantId,request.auth?.token);if(!isEnterpriseAdmin(m.data.role))throw new HttpsError('permission-denied','Only enterprise administrators manage categories and access.');const ref=db.doc('tenants/'+tenantId+'/siteProgressCategories/'+categoryId),snap=await ref.get();if(!snap.exists)throw new HttpsError('not-found','Work category not found.');const projects=(snap.get('projectIds')||[]) as string[];if(!isEnterpriseAdmin(m.data.role)&&projects.some(id=>!m.data.siteProgressAccess?.projectIds?.includes(id)))throw new HttpsError('permission-denied','You may only archive categories for assigned projects.');const now=FieldValue.serverTimestamp();await db.runTransaction(async tx=>{const current=await tx.get(ref);if(!current.exists)throw new HttpsError('not-found','Work category not found.');tx.update(ref,{active:false,status:'Archived',archivedAt:current.get('archivedAt')||now,archivedBy:uid,updatedBy:uid,updatedAt:now});tx.create(db.doc('tenants/'+tenantId+'/auditEvents/'+slugId()),{tenantId,actorUid:uid,action:'siteProgress.category.archived',entityType:'siteProgressCategory',entityId:categoryId,details:{projectIds:current.get('projectIds')||[]},createdAt:now});});return {archived:true};});
const validWorkDate=(value:unknown)=>typeof value==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(value)&&!Number.isNaN(Date.parse(value+'T00:00:00.000Z'))&&new Date(value+'T00:00:00.000Z').toISOString().slice(0,10)===value;
export const saveSiteProgressWorkItem=onCall({enforceAppCheck:true},async request=>{
 const uid=requireUser(request),tenantId=clean(request.data.tenantId,120),m=await membership(uid,tenantId,request.auth?.token),isAdmin=isEnterpriseAdmin(m.data.role),actorRole=isAdmin?null:await db.doc('tenants/'+tenantId+'/roles/'+m.data.role).get();await requirePermission(m,'siteProgress.allocate');
 const item=request.data.workItem;if(!item||typeof item!=='object')throw new HttpsError('invalid-argument','Work item details are required.');const id=typeof item.id==='string'&&item.id?clean(item.id,120):slugId(),projectId=clean(item.projectId,120),categoryId=clean(item.categoryId,120),name=clean(item.name,140),description=typeof item.description==='string'?item.description.trim().slice(0,2000):'',unit=clean(item.unit,30),target=Number(item.targetQuantity),assignedToUids=progressIds(item.assignedToUids,200),priority=item.priority||'Normal',status=item.status||'Planned',startDate=item.startDate||null,targetDate=item.targetDate||null;
 if(!safeId.test(id)||!/[a-zA-Z\u0900-\u097f]/.test(unit)||!Number.isFinite(target)||target<0.000001||target>1e9||quantityRound(target)!==target||!assignedToUids.length||!['Low','Normal','High','Urgent'].includes(priority)||!['Planned','In Progress','On Hold','Completed','Archived'].includes(status)||startDate&&!validWorkDate(startDate)||targetDate&&!validWorkDate(targetDate))throw new HttpsError('invalid-argument','Check the target quantity, assignments, dates, priority, and status.');
 if(!isAdmin&&!(m.data.siteProgressAccess?.projectIds||[]).includes(projectId))throw new HttpsError('permission-denied','You can only allocate work on projects assigned to you.');
 if(!isAdmin&&assignedToUids.some(x=>x!==uid)&&!m.data.effectivePermissions.includes('siteProgress.assign'))throw new HttpsError('permission-denied','You need explicit permission to assign work to another employee.');const projectRef=db.doc('tenants/'+tenantId+'/projects/'+projectId),categoryRef=db.doc('tenants/'+tenantId+'/siteProgressCategories/'+categoryId),itemRef=db.doc('tenants/'+tenantId+'/siteProgressWorkItems/'+id),memberRefs=assignedToUids.map(x=>db.doc('tenants/'+tenantId+'/members/'+x)),[project,category,members,existing,memberRoles]=await Promise.all([projectRef.get(),categoryRef.get(),Promise.all(memberRefs.map(x=>x.get())),itemRef.get(),Promise.all(assignedToUids.map(async x=>{const member=await db.doc('tenants/'+tenantId+'/members/'+x).get();return db.doc('tenants/'+tenantId+'/roles/'+member.get('role')).get()}))]);
 if(!project.exists)throw new HttpsError('failed-precondition','The selected project does not belong to this company.');if(!category.exists||!category.get('active')||category.get('archivedAt')||category.get('legacyUnassigned')||(category.get('projectIds')||[]).length&&!(category.get('projectIds')||[]).includes(projectId))throw new HttpsError('failed-precondition','Choose an active work category available to this project.');if(members.some((x,i)=>!x.exists||x.get('status')!=='active'||(!isEnterpriseAdmin(x.get('role'))&&!memberRoles[i].get('permissions')?.some((p:string)=>['siteProgress.submit','siteProgress.read','siteProgress.review'].includes(p)))))throw new HttpsError('failed-precondition','Assigned users must be active and have the site progress submit permission.');
 if(startDate&&targetDate&&startDate>targetDate)throw new HttpsError('invalid-argument','Completion date cannot precede start date.');if(item.subcategory&&!(category.get('subcategories')||[]).includes(item.subcategory))throw new HttpsError('invalid-argument','Choose a subcategory belonging to this category.');
 const now=FieldValue.serverTimestamp(),memberLabels=members.map(x=>({uid:x.id,name:x.get('displayName')||x.get('email')||x.id})),auditRef=db.doc('tenants/'+tenantId+'/auditEvents/'+slugId());await db.runTransaction(async tx=>{const current=await tx.get(itemRef),approved=Number(current.get('approvedQuantity')||0);if(current.exists&&current.get('projectId')!==projectId)throw new HttpsError('failed-precondition','A work item cannot move between projects.');if(current.exists&&(current.get('unit')!==unit||current.get('categoryId')!==categoryId)){const priorReports=await tx.get(db.collection('tenants/'+tenantId+'/siteProgressReports').where('workItemId','==',id).limit(1));if(!priorReports.empty)throw new HttpsError('failed-precondition','Unit and category cannot change after reporting begins. Create a new allocation.');}if(status==='Completed'&&approved<target)throw new HttpsError('failed-precondition','Completion requires approved quantities to meet the target.');if(approved>target)throw new HttpsError('failed-precondition','Target quantity cannot be reduced below already approved work.');tx.set(itemRef,{id,tenantId,projectId,projectName:project.get('name')||project.get('projectName')||projectId,categoryId,categoryName:category.get('name'),subcategory:typeof item.subcategory==='string'?item.subcategory.trim().slice(0,100):'',name,description,targetQuantity:target,unit,assignedToUids,assignedMembers:memberLabels,startDate,targetDate,priority,status,approvedQuantity:approved,createdBy:current.get('createdBy')||uid,createdAt:current.get('createdAt')||now,updatedBy:uid,updatedAt:now,archivedAt:status==='Archived'?(current.get('archivedAt')||now):null},{merge:true});tx.create(auditRef,{tenantId,actorUid:uid,action:current.exists?'siteProgress.workItem.updated':'siteProgress.workItem.allocated',entityType:'siteProgressWorkItem',entityId:id,details:{projectId,categoryId,targetQuantity:target,assignedToUids},createdAt:now});});return {workItemId:id};
});
export const assignSiteProgressAccess=onCall({enforceAppCheck:true},async request=>{
 const uid=requireUser(request),tenantId=clean(request.data.tenantId,120),memberUid=clean(request.data.memberUid,128),m=await membership(uid,tenantId,request.auth?.token);if(!isEnterpriseAdmin(m.data.role))throw new HttpsError('permission-denied','Only enterprise administrators manage categories and access.');const projectIds=progressIds(request.data.projectIds),categoryIds=progressIds(request.data.categoryIds),level=request.data.permissionLevel;if(!['submit','read','review'].includes(level))throw new HttpsError('invalid-argument','Invalid permission level.');if(!isEnterpriseAdmin(m.data.role)&&projectIds.some(id=>!(m.data.siteProgressAccess?.projectIds||[]).includes(id)))throw new HttpsError('permission-denied','You cannot delegate projects not assigned to you.');
 const [member,projects,categories]=await Promise.all([db.doc('tenants/'+tenantId+'/members/'+memberUid).get(),Promise.all(projectIds.map(id=>db.doc('tenants/'+tenantId+'/projects/'+id).get())),Promise.all(categoryIds.map(id=>db.doc('tenants/'+tenantId+'/siteProgressCategories/'+id).get()))]);if(!member.exists||member.get('status')!=='active'||projects.some(x=>!x.exists)||categories.some(x=>!x.exists||!x.get('active')||(x.get('projectIds')||[]).some((p:string)=>!projectIds.includes(p))))throw new HttpsError('failed-precondition','Choose an active member and synced projects/categories.');const now=FieldValue.serverTimestamp();await member.ref.set({projectIds,siteProgressAccess:{projectIds,categoryIds,permissionLevel:level,grantedBy:uid,updatedAt:now}},{merge:true});await db.doc('tenants/'+tenantId+'/auditEvents/'+slugId()).create({tenantId,actorUid:uid,action:'siteProgress.access.updated',entityType:'membership',entityId:memberUid,details:{projectIds,categoryIds,permissionLevel:level},createdAt:now});return {updated:true};
});
export const createSiteProgressPhotoUpload=onCall({enforceAppCheck:true},async request=>{
 const uid=requireUser(request),tenantId=clean(request.data.tenantId,120),reportId=clean(request.data.reportId,120),workItemId=clean(request.data.workItemId,120),fileName=clean(request.data.fileName,180).replace(/[\/\u0000-\u001f]/g,'_'),type=request.data.contentType,size=request.data.size,source=request.data.source,m=await membership(uid,tenantId,request.auth?.token);
 await requirePermission(m,'siteProgress.submit');if(isEnterpriseAdmin(m.data.role))throw new HttpsError('permission-denied','Enterprise administrators manage and review progress; site members submit reports.');
 if(!safeId.test(reportId)||!safeId.test(workItemId)||!progressPhotoTypes.has(type)||!Number.isSafeInteger(size)||size<1||size>maxProgressPhotoBytes||typeof request.data.sha256!=='string'||! /^[a-f0-9]{64}$/.test(request.data.sha256)||!['camera','gallery'].includes(source))throw new HttpsError('invalid-argument','Photo or assigned work details are invalid.');
 const item=await db.doc('tenants/'+tenantId+'/siteProgressWorkItems/'+workItemId).get();if(!item.exists||item.get('status')==='Archived'||!item.get('assignedToUids')?.includes(uid))throw new HttpsError('permission-denied','This work item is not assigned to your account.');
 if(Array.isArray(m.data.projectIds))assertProject(m.data,item.get('projectId'));const category=await db.doc('tenants/'+tenantId+'/siteProgressCategories/'+item.get('categoryId')).get();if(!category.exists||!category.get('active')||category.get('archivedAt'))throw new HttpsError('failed-precondition','The work category is no longer active.');
 const photoId=slugId(),path='tenants/'+tenantId+'/siteProgress/'+workItemId+'/'+reportId+'/'+photoId;await db.doc('tenants/'+tenantId+'/siteProgressPhotos/'+photoId).create({tenantId,photoId,reportId,workItemId,projectId:item.get('projectId'),categoryId:item.get('categoryId'),objectPath:path,fileName,contentType:type,size,sha256:request.data.sha256,source,status:'uploading',createdBy:uid,uploadRequestedAt:FieldValue.serverTimestamp()});const [uploadUrl]=await getStorage().bucket().file(path).getSignedUrl({version:'v4',action:'write',expires:Date.now()+900000,contentType:type,extensionHeaders:{'x-goog-meta-sha256':request.data.sha256},queryParams:{ifGenerationMatch:'0'}});return {photoId,uploadUrl};
});
export const finalizeSiteProgressPhotoUpload=onCall({enforceAppCheck:true},async request=>{
 const uid=requireUser(request),tenantId=clean(request.data.tenantId,120),photoId=clean(request.data.photoId,120),m=await membership(uid,tenantId,request.auth?.token);await requireAnyPermission(m,['siteProgress.submit','siteProgress.manage']);const ref=db.doc('tenants/'+tenantId+'/siteProgressPhotos/'+photoId),snap=await ref.get();if(!snap.exists||snap.get('status')!=='uploading'||snap.get('createdBy')!==uid)throw new HttpsError('not-found','Pending photo upload not found.');const assigned=await db.doc('tenants/'+tenantId+'/siteProgressWorkItems/'+snap.get('workItemId')).get();if(Array.isArray(m.data.projectIds))assertProject(m.data,assigned.get('projectId'));if(!assigned.exists||assigned.get('status')==='Archived'||!(assigned.get('assignedToUids')||[]).includes(uid))throw new HttpsError('permission-denied','Work is no longer assigned.');const file=getStorage().bucket().file(snap.get('objectPath')),[meta]=await file.getMetadata(),[bytes]=await file.download(),type=String(meta.contentType||''),ok=type==='image/jpeg'?bytes[0]===255&&bytes[1]===216&&bytes[2]===255:type==='image/png'?bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])):false,actualHash=createHash('sha256').update(bytes).digest('hex');if(!ok||!progressPhotoTypes.has(type)||Number(meta.size)!==snap.get('size')||Number(meta.size)>maxProgressPhotoBytes||actualHash!==snap.get('sha256')||meta.metadata?.sha256!==snap.get('sha256')){await file.delete({ignoreNotFound:true});await ref.update({status:'rejected'});throw new HttpsError('data-loss','Photo verification failed.');}const exif=type==='image/jpeg'?getJpegExif(bytes):null,captureAt=exifIso(exif);await ref.update({status:'active',size:Number(meta.size),uploadAt:FieldValue.serverTimestamp(),captureTimeRaw:exif?.raw||null,captureOffset:exif?.offset||null,captureAt,captureTimeSource:exif?'exif_metadata':'unavailable'});await db.doc('tenants/'+tenantId+'/auditEvents/'+slugId()).create({tenantId,actorUid:uid,action:'siteProgress.photo.uploaded',entityType:'siteProgressReport',entityId:snap.get('reportId'),details:{photoId},createdAt:FieldValue.serverTimestamp()});return {photoId,captureAt,captureTimeRaw:exif?.raw||null,captureOffset:exif?.offset||null,captureTimeSource:exif?'exif_metadata':'unavailable'};
});
export const submitSiteProgressReport=onCall({enforceAppCheck:true},async request=>{
 const uid=requireUser(request),tenantId=clean(request.data.tenantId,120),r=request.data.report,m=await membership(uid,tenantId,request.auth?.token);if(!r||typeof r!=='object')throw new HttpsError('invalid-argument','Report details are required.');await requirePermission(m,'siteProgress.submit');if(isEnterpriseAdmin(m.data.role))throw new HttpsError('permission-denied','Enterprise administrators do not submit site reports.');
 const id=clean(r.id,120),workItemId=clean(r.workItemId,120),workDate=r.workDate,quantity=Number(r.quantity),description=clean(r.description||r.remarks,2000),photoIds=progressIds(r.photoIds,5);if(!safeId.test(id)||!safeId.test(workItemId)||!validWorkDate(workDate)||!Number.isFinite(quantity)||quantity<0.000001||quantity>1e9||quantityRound(quantity)!==quantity||!photoIds.length)throw new HttpsError('invalid-argument','Enter a valid work date, positive completed quantity, description, and at least one photo.');
 const itemRef=db.doc('tenants/'+tenantId+'/siteProgressWorkItems/'+workItemId),reportRef=db.doc('tenants/'+tenantId+'/siteProgressReports/'+id),[item,photoSnaps,user]=await Promise.all([itemRef.get(),Promise.all(photoIds.map(x=>db.doc('tenants/'+tenantId+'/siteProgressPhotos/'+x).get())),getAuth().getUser(uid)]);if(!item.exists||item.get('status')==='Archived'||!item.get('assignedToUids')?.includes(uid))throw new HttpsError('permission-denied','This work item is not assigned to your account.');if(Array.isArray(m.data.projectIds))assertProject(m.data,item.get('projectId'));const liveCategory=await db.doc('tenants/'+tenantId+'/siteProgressCategories/'+item.get('categoryId')).get();if(!liveCategory.exists||!liveCategory.get('active')||liveCategory.get('archivedAt'))throw new HttpsError('failed-precondition','This work category is no longer active.');if(photoSnaps.some(x=>!x.exists||x.get('status')!=='active'||x.get('reportId')!==id||x.get('workItemId')!==workItemId||x.get('createdBy')!==uid))throw new HttpsError('failed-precondition','All uploaded photos must belong to this report and work item.');
 const now=FieldValue.serverTimestamp(),historyRef=db.doc('tenants/'+tenantId+'/siteProgressReportHistory/'+slugId()),auditRef=db.doc('tenants/'+tenantId+'/auditEvents/'+slugId()),result=await db.runTransaction(async tx=>{const [currentItem,currentReport,...currentPhotos]=await Promise.all([tx.get(itemRef),tx.get(reportRef),...photoSnaps.map(p=>tx.get(p.ref))]);if(currentReport.exists){if(currentReport.get('submittedBy')===uid&&currentReport.get('workItemId')===workItemId&&currentReport.get('workDate')===workDate&&currentReport.get('quantity')===quantity&&currentReport.get('description')===description&&JSON.stringify(currentReport.get('photoIds'))===JSON.stringify(photoIds))return {duplicate:true,reportId:id};throw new HttpsError('already-exists','This report ID is already in use.');}if(!currentItem.exists||currentItem.get('status')==='Archived'||!currentItem.get('assignedToUids')?.includes(uid))throw new HttpsError('permission-denied','The work assignment changed before submission.');if(currentPhotos.some(p=>!p.exists||p.get('status')!=='active'||p.get('reportId')!==id||p.get('workItemId')!==workItemId))throw new HttpsError('failed-precondition','A report photo is no longer available.');const earlierReports=await tx.get(db.collection('tenants/'+tenantId+'/siteProgressReports').where('workItemId','==',workItemId));if(earlierReports.docs.some(d=>d.get('submittedBy')===uid&&d.get('workDate')===workDate))throw new HttpsError('already-exists','A report already exists for this work and date. Request a correction.');const duplicateRef=db.doc('tenants/'+tenantId+'/siteProgressSubmissionKeys/'+hash(uid+'|'+workItemId+'|'+workDate)),duplicate=await tx.get(duplicateRef);if(duplicate.exists)throw new HttpsError('already-exists','A daily report already exists for this work and date. Ask the reviewer to correct the existing report.');tx.create(duplicateRef,{tenantId,reportId:id,submittedBy:uid,workItemId,workDate});const remaining=Math.max(0,quantityRound(Number(currentItem.get('targetQuantity')||0)-Number(currentItem.get('approvedQuantity')||0))),exceedsRemaining=quantity>remaining;tx.create(reportRef,{id,tenantId,workItemId,projectId:currentItem.get('projectId'),projectName:currentItem.get('projectName'),categoryId:currentItem.get('categoryId'),categoryName:currentItem.get('categoryName'),workItemName:currentItem.get('name'),unit:currentItem.get('unit'),description,workDate,quantity,approvedQuantity:0,exceedsRemaining,photoIds,submittedBy:uid,submittedByName:user.displayName||user.email||uid,status:'Pending Review',adminRemarks:null,submittedAt:now,createdAt:now,updatedAt:now});for(const p of currentPhotos)tx.update(p.ref,{reportSubmitted:true});tx.update(itemRef,{lastProgressDate:workDate,updatedAt:now});tx.create(historyRef,{tenantId,reportId:id,workItemId,actorUid:uid,action:'submitted',status:'Pending Review',quantity,createdAt:now});tx.create(auditRef,{tenantId,actorUid:uid,action:'siteProgress.report.submitted',entityType:'siteProgressReport',entityId:id,details:{workItemId,quantity,exceedsRemaining},createdAt:now});return {duplicate:false,reportId:id,exceedsRemaining};});return result;
});
export const reviewSiteProgressReport=onCall({enforceAppCheck:true},async request=>{
 const uid=requireUser(request),tenantId=clean(request.data.tenantId,120),id=clean(request.data.reportId,120),status=request.data.status,remarks=typeof request.data.remarks==='string'?request.data.remarks.trim().slice(0,1000):'',m=await membership(uid,tenantId,request.auth?.token);await requirePermission(m,'siteProgress.review');if(!['Approved','Rejected','Correction Required','Under Review','Verified'].includes(status))throw new HttpsError('invalid-argument','Invalid review status.');const reportRef=db.doc('tenants/'+tenantId+'/siteProgressReports/'+id),report=await reportRef.get();if(!report.exists)throw new HttpsError('not-found','Report unavailable.');if(!await progressAllowed(m,report.get('projectId'),'review'))throw new HttpsError('permission-denied','You do not have review access for this project.');const workItemId=report.get('workItemId');
 if(!workItemId){const now=FieldValue.serverTimestamp(),batch=db.batch();batch.update(reportRef,{status,adminRemarks:remarks||null,reviewedBy:uid,reviewedAt:now,updatedAt:now});batch.create(db.doc('tenants/'+tenantId+'/siteProgressReportHistory/'+slugId()),{tenantId,reportId:id,actorUid:uid,action:status.toLowerCase().replace(' ','_'),status,remarks,createdAt:now});batch.create(db.doc('tenants/'+tenantId+'/auditEvents/'+slugId()),{tenantId,actorUid:uid,action:'siteProgress.legacyReport.reviewed',entityType:'siteProgressReport',entityId:id,details:{status,remarks},createdAt:now});await batch.commit();return {status,approvedQuantity:0};}
 const itemRef=db.doc('tenants/'+tenantId+'/siteProgressWorkItems/'+workItemId),historyRef=db.doc('tenants/'+tenantId+'/siteProgressReportHistory/'+slugId()),auditRef=db.doc('tenants/'+tenantId+'/auditEvents/'+slugId()),requested=Number(request.data.approvedQuantity);return db.runTransaction(async tx=>{const [currentReport,item]=await Promise.all([tx.get(reportRef),tx.get(itemRef)]);if(!currentReport.exists||!item.exists)throw new HttpsError('not-found','Report or work assignment unavailable.');if(!await progressAllowed(m,item.get('projectId'),'review'))throw new HttpsError('permission-denied','Review access is not assigned to this project.');const wasApproved=currentReport.get('status')==='Approved'||currentReport.get('status')==='Verified',oldAccepted=wasApproved?Number(currentReport.get('approvedQuantity')??currentReport.get('quantity')??0):0;let accepted=0;if(status==='Approved'||status==='Verified'){accepted=request.data.approvedQuantity===undefined?Number(currentReport.get('quantity')||0):requested;if(!Number.isFinite(accepted)||accepted<0||accepted>Number(currentReport.get('quantity')||0))throw new HttpsError('invalid-argument','Approved quantity must be between zero and the submitted quantity.');const otherApproved=quantityRound(Number(item.get('approvedQuantity')||0)-oldAccepted),remaining=Math.max(0,quantityRound(Number(item.get('targetQuantity')||0)-otherApproved));if(accepted>remaining)throw new HttpsError('failed-precondition','Approved quantity exceeds the remaining assigned target. Reduce the approved amount or update the work target first.');}const total=Math.max(0,quantityRound(Number(item.get('approvedQuantity')||0)-oldAccepted+accepted)),nextStatus=status==='Verified'?'Approved':status,now=FieldValue.serverTimestamp();tx.update(reportRef,{status:nextStatus,approvedQuantity:accepted,adminRemarks:remarks||null,reviewedBy:uid,reviewedAt:now,updatedAt:now});tx.update(itemRef,{approvedQuantity:total,status:item.get('status')==='Archived'?'Archived':total>=Number(item.get('targetQuantity')||0)?'Completed':total>0||item.get('status')==='Completed'?'In Progress':item.get('status'),updatedAt:now});tx.create(historyRef,{tenantId,reportId:id,workItemId,actorUid:uid,action:nextStatus.toLowerCase().replace(' ','_'),fromStatus:currentReport.get('status'),status:nextStatus,reportedQuantity:currentReport.get('quantity'),previousApprovedQuantity:oldAccepted,approvedQuantity:accepted,remarks,createdAt:now});tx.create(auditRef,{tenantId,actorUid:uid,action:'siteProgress.report.reviewed',entityType:'siteProgressReport',entityId:id,details:{workItemId,fromStatus:currentReport.get('status'),status:nextStatus,previousApprovedQuantity:oldAccepted,approvedQuantity:accepted,remarks},createdAt:now});return {status:nextStatus,approvedQuantity:accepted,totalApproved:total,remainingQuantity:Math.max(0,quantityRound(Number(item.get('targetQuantity')||0)-total))};});
});
export const listSiteProgressReportHistory=onCall({enforceAppCheck:true},async request=>{
 const uid=requireUser(request),tenantId=clean(request.data.tenantId,120),id=clean(request.data.reportId,120),m=await membership(uid,tenantId,request.auth?.token),report=await db.doc('tenants/'+tenantId+'/siteProgressReports/'+id).get();if(!report.exists)throw new HttpsError('not-found','Report unavailable.');const own=report.get('submittedBy')===uid;if(own){await requireAnyPermission(m,['siteProgress.submit','siteProgress.read','siteProgress.review']);if(!isEnterpriseAdmin(m.data.role)){const itemId=report.get('workItemId'),item=itemId?await db.doc('tenants/'+tenantId+'/siteProgressWorkItems/'+itemId).get():null;if(!(item?.get('assignedToUids')||[]).includes(uid)&&!await progressAllowed(m,report.get('projectId'),'read'))throw new HttpsError('permission-denied','Current project access required.');}}else{await requireAnyPermission(m,['siteProgress.read','siteProgress.review','siteProgress.manage']);if(!await progressAllowed(m,report.get('projectId'),'read'))throw new HttpsError('not-found','Report unavailable.');}const snap=await db.collection('tenants/'+tenantId+'/siteProgressReportHistory').where('reportId','==',id).limit(50).get();return {events:snap.docs.map(d=>({...d.data(),id:d.id,createdAt:d.get('createdAt')?.toDate?.()?.toISOString()||null})).sort((a:any,b:any)=>(b.createdAt||'').localeCompare(a.createdAt||''))};
});
export const getSiteProgressPhotoAccess=onCall({enforceAppCheck:true},async request=>{
 const uid=requireUser(request),tenantId=clean(request.data.tenantId,120),id=clean(request.data.reportId,120),photoId=clean(request.data.photoId,120),download=request.data.disposition==='attachment',preview=request.data.disposition==='preview',m=await membership(uid,tenantId,request.auth?.token),role=await db.doc('tenants/'+tenantId+'/roles/'+m.data.role).get(),perms=m.data.effectivePermissions||[],isAdmin=isEnterpriseAdmin(m.data.role),mayRead=isAdmin||perms.some((p:string)=>['siteProgress.read','siteProgress.review','siteProgress.manage'].includes(p)),report=await db.doc('tenants/'+tenantId+'/siteProgressReports/'+id).get();if(!report.exists||!(report.get('photoIds')||[]).includes(photoId))throw new HttpsError('not-found','Photo unavailable.');
 await requireAnyPermission(m,['siteProgress.read','siteProgress.submit','siteProgress.review']);const own=report.get('submittedBy')===uid,workItemId=report.get('workItemId'),projectId=report.get('projectId'),categoryId=report.get('categoryId');if(download&&!perms.includes('siteProgress.download')&&!isAdmin)throw new HttpsError('permission-denied','Photo download permission required.');if(!download&&!own&&!mayRead)throw new HttpsError('permission-denied','Photo view permission required.');
 let assignedItem=false;if(workItemId){const item=await db.doc('tenants/'+tenantId+'/siteProgressWorkItems/'+workItemId).get();if(!item.exists||item.get('projectId')!==projectId||item.get('categoryId')!==categoryId)throw new HttpsError('not-found','Photo unavailable.');assignedItem=(item.get('assignedToUids')||[]).includes(uid);if(Array.isArray(m.data.projectIds))assertProject(m.data,projectId);if(!isAdmin&&!assignedItem&&!await progressAllowed(m,projectId,'read'))throw new HttpsError('not-found','Photo unavailable.');}else if(!isAdmin&&!own&&!await progressAllowed(m,projectId,'read'))throw new HttpsError('not-found','Photo unavailable.');
 const category=await db.doc('tenants/'+tenantId+'/siteProgressCategories/'+categoryId).get();if(!isAdmin&&!own&&!assignedItem&&!await progressAllowed(m,projectId,'read'))throw new HttpsError('not-found','Photo unavailable.');const photo=await db.doc('tenants/'+tenantId+'/siteProgressPhotos/'+photoId).get();if(!photo.exists||photo.get('reportSubmitted')!==true||photo.get('categoryId')!==categoryId||photo.get('projectId')!==projectId||photo.get('workItemId')!==workItemId)throw new HttpsError('not-found','Photo unavailable.');const name=String(photo.get('fileName')).replace(/["\\\r\n]/g,'_'),[url]=await getStorage().bucket().file(photo.get('objectPath')).getSignedUrl({version:'v4',action:'read',expires:Date.now()+300000,responseDisposition:(download?'attachment':'inline')+'; filename="'+name+'"',responseType:photo.get('contentType')});if(!preview)await db.doc('tenants/'+tenantId+'/auditEvents/'+slugId()).create({tenantId,actorUid:uid,action:download?'siteProgress.photo.downloaded':'siteProgress.photo.viewed',entityType:'siteProgressReport',entityId:id,details:{photoId,workItemId},createdAt:FieldValue.serverTimestamp()});return {photoId,url,fileName:photo.get('fileName'),contentType:photo.get('contentType'),size:photo.get('size'),source:photo.get('source')||'gallery',uploadAt:photo.get('uploadAt')?.toDate?.()?.toISOString()||null,captureAt:photo.get('captureAt')||null,captureTimeRaw:photo.get('captureTimeRaw')||null,captureOffset:photo.get('captureOffset')||null,captureTimeSource:photo.get('captureTimeSource')||'unavailable'};
});

export const createRazorpayOrder = onCall({ secrets: [razorpayKeyId, razorpayKeySecret], enforceAppCheck: true }, async (request) => {
  const uid = requireUser(request);
  const tenantId = clean(request.data.tenantId, 120);
  const planId = clean(request.data.planId, 40);
  const planRef = db.doc(`platform/plans/${planId}`);
  const [m, planSnap] = await Promise.all([membership(uid, tenantId,request.auth?.token), planRef.get()]);
  await requirePermission(m, 'settings.manage');
  if (!planSnap.exists || planSnap.get('active') !== true || !Number.isSafeInteger(planSnap.get('amountPaise')) || planSnap.get('amountPaise') < 100) throw new HttpsError('failed-precondition', 'The selected subscription plan is unavailable.');
  const amount = planSnap.get('amountPaise');
  const auth = Buffer.from(`${razorpayKeyId.value()}:${razorpayKeySecret.value()}`).toString('base64');
  const resp = await fetch('https://api.razorpay.com/v1/orders', { method: 'POST', headers: { authorization: `Basic ${auth}`, 'content-type': 'application/json' }, body: JSON.stringify({ amount, currency: 'INR', receipt: `nk-${tenantId}-${Date.now()}`, notes: { tenantId, planId, initiatedBy: uid } }) });
  if (!resp.ok) throw new HttpsError('unavailable', 'The payment provider could not create an order. No subscription was activated.');
  const order = await resp.json() as any;
  await db.doc(`tenants/${tenantId}/paymentOrders/${order.id}`).create({ orderId: order.id, tenantId, planId, amountPaise: amount, currency: 'INR', status: 'created', createdBy: uid, createdAt: FieldValue.serverTimestamp() });
  return { orderId: order.id, amount: order.amount, currency: order.currency, keyId: razorpayKeyId.value() };
});

export const razorpayWebhook = onRequest({ secrets: [razorpayKeySecret, razorpayWebhookSecret], cors: false }, async (req, res) => {
  if (req.method !== 'POST') { res.status(405).send('Method not allowed'); return; }
  const signature = req.header('x-razorpay-signature') || '';
  const expected = createHmac('sha256', razorpayWebhookSecret.value()).update(req.rawBody).digest('hex');
  if (!safeEqualHex(signature, expected)) { res.status(401).send('Invalid signature'); return; }
  const eventId = req.header('x-razorpay-event-id');
  if (!eventId || !safeId.test(eventId)) { res.status(400).send('Missing event ID'); return; }
  const eventRef = db.doc(`platform/webhookEvents/events/${eventId}`);
  const event = req.body;
  try {
    await db.runTransaction(async tx => {
      const prior = await tx.get(eventRef);
      if (prior.exists) return;
      tx.create(eventRef, { provider: 'razorpay', type: event.event || 'unknown', receivedAt: FieldValue.serverTimestamp(), status: 'received' });
      if (event.event !== 'payment.captured') return;
      const payment = event.payload?.payment?.entity;
      if (payment?.status !== 'captured' || payment?.currency !== 'INR') return;
      const tenantId = payment?.notes?.tenantId;
      const planId = payment?.notes?.planId;
      if (!tenantId || !planId || !safeId.test(tenantId)) return;
      const orderRef = db.doc(`tenants/${tenantId}/paymentOrders/${payment.order_id}`);
      const order = await tx.get(orderRef);
      if (!order.exists || order.get('status') === 'paid' || order.get('amountPaise') !== payment.amount || order.get('planId') !== planId) return;
      const plan = await tx.get(db.doc(`platform/plans/${planId}`));
      if (!plan.exists) return;
      tx.update(orderRef, { status: 'paid', paymentId: payment.id, paidAt: FieldValue.serverTimestamp() });
      tx.set(db.doc(`tenants/${tenantId}`), { subscription: { planId, status: 'active', employeeLimit: plan.get('employeeLimit'), modules: plan.get('modules'), activatedAt: FieldValue.serverTimestamp(), paidThrough: plan.get('periodDays') ? new Date(Date.now() + plan.get('periodDays') * 86400000) : null } }, { merge: true });
      tx.create(db.doc(`tenants/${tenantId}/auditEvents/${slugId()}`), { tenantId, actorUid: 'system:razorpay', action: 'subscription.payment.confirmed', entityType: 'subscription', entityId: payment.id, createdAt: FieldValue.serverTimestamp() });
    });
    res.status(200).send('ok');
  } catch (e) { console.error('Webhook processing failed', e); res.status(500).send('retry'); }
});

export const seedPlatformPlans = onCall(async (request) => {
  const uid = requireUser(request);
  const allowed = (process.env.PLATFORM_ADMIN_UIDS || '').split(',').map(s => s.trim()).filter(Boolean);
  if (!allowed.includes(uid)) throw new HttpsError('permission-denied', 'Platform administrator access is not configured for this account.');
  const defaults = [
    { id: 'starter', name: 'Starter', amountPaise: 0, employeeLimit: 3, modules: starterPlans.starter.modules, periodDays: 30 },
    { id: 'professional', name: 'Professional', amountPaise: 0, employeeLimit: 10, modules: ['*'], periodDays: 30 },
    { id: 'business', name: 'Business', amountPaise: 0, employeeLimit: 25, modules: ['*'], periodDays: 30 },
    { id: 'enterprise', name: 'Enterprise', amountPaise: 0, employeeLimit: -1, modules: ['*'], periodDays: 30 },
  ];
  const batch = db.batch();
  defaults.forEach(plan => batch.set(db.doc(`platform/plans/${plan.id}`), { ...plan, active: false, configured: false, updatedAt: FieldValue.serverTimestamp() }, { merge: true }));
  await batch.commit();
  return { seeded: defaults.length, note: 'Pricing intentionally inactive until configured by the platform owner.' };
});

// Public marketing display only: expose the fields needed for pricing and
// never return internal billing metadata or tenant/payment records.
export const listPublicPlans = onCall({ enforceAppCheck: true }, async () => {
  const snapshot = await db.collection('platform/plans').where('active', '==', true).get();
  return {
    plans: snapshot.docs.map(doc => {
      const plan = doc.data();
      return {
        id: doc.id,
        name: clean(plan.name, 80) || doc.id,
        amountPaise: Number.isSafeInteger(plan.amountPaise) && plan.amountPaise >= 0 ? plan.amountPaise : null,
        employeeLimit: Number.isSafeInteger(plan.employeeLimit) ? plan.employeeLimit : null,
        periodDays: Number.isSafeInteger(plan.periodDays) ? plan.periodDays : null,
        modules: Array.isArray(plan.modules) ? plan.modules.filter((x: unknown) => typeof x === 'string').slice(0, 50) : [],
      };
    }).sort((a, b) => (a.amountPaise ?? Number.MAX_SAFE_INTEGER) - (b.amountPaise ?? Number.MAX_SAFE_INTEGER)),
  };
});

function requirePlatformAdmin(uid: string) {
  const allowlist = (process.env.PLATFORM_ADMIN_UIDS || '').split(',').map(s => s.trim()).filter(Boolean);
  if (!allowlist.includes(uid)) throw new HttpsError('permission-denied', 'Platform administrator access is not configured for this account.');
}

export const getPlatformOverview = onCall({ enforceAppCheck: true }, async (request) => {
  const uid = requireUser(request); requirePlatformAdmin(uid);
  const [companies, plans, tickets, leads, companyCount, activeCount, trialCount, suspendedCount, membershipsCount, paidCount, pendingCount] = await Promise.all([
    db.collection('tenants').orderBy('createdAt', 'desc').limit(100).get(),
    db.collection('platform/plans').get(),
    db.collection('platformTickets').orderBy('updatedAt', 'desc').limit(100).get(),
    db.collection('platformLeads').orderBy('lastRequestedAt','desc').limit(50).get(),
    db.collection('tenants').count().get(),
    db.collection('tenants').where('status','==','active').count().get(),
    db.collection('tenants').where('subscription.status','==','trial').count().get(),
    db.collection('tenants').where('status','==','suspended').count().get(),
    db.collectionGroup('members').where('status','==','active').count().get(),
    db.collectionGroup('paymentOrders').where('status','==','paid').count().get(),
    db.collectionGroup('paymentOrders').where('status','==','created').count().get(),
  ]);
  const items = companies.docs.map(d => ({ tenantId: d.id, name: d.get('profile.name') || '(Unnamed company)', status: d.get('status') || 'unknown', subscriptionStatus: d.get('subscription.status') || 'none', planId: d.get('subscription.planId') || 'none', createdAt: d.get('createdAt')?.toDate?.()?.toISOString() || null, employeeLimit: d.get('subscription.employeeLimit') ?? 0 }));
  return {
    metrics: { companies: companyCount.data().count, activeCompanies: activeCount.data().count, trials: trialCount.data().count, suspended: suspendedCount.data().count, registeredUsers: membershipsCount.data().count, paidTransactions: paidCount.data().count, pendingPayments: pendingCount.data().count, mrrPaise: null, arrPaise: null },
    companies: items, plans: plans.docs.map(d=>({ id:d.id,...d.data() })), openSupportTickets: tickets.docs.filter(d=>!['closed','resolved'].includes(d.get('status'))).length,
    demoRequests: leads.docs.map(d=>({id:d.id,name:d.get('name'),company:d.get('company'),email:d.get('email'),phone:d.get('phone')||'',status:d.get('status')||'new',lastRequestedAt:d.get('lastRequestedAt')?.toDate?.()?.toISOString()||null})),
  };
});

export const configureSubscriptionPlan = onCall({ enforceAppCheck: true }, async (request) => {
  const uid = requireUser(request); requirePlatformAdmin(uid);
  const planId = clean(request.data.planId, 40);
  const name = clean(request.data.name, 80);
  const amountPaise = request.data.amountPaise;
  const employeeLimit = request.data.employeeLimit;
  const periodDays = request.data.periodDays;
  const modules = request.data.modules;
  if (!Number.isSafeInteger(amountPaise) || amountPaise < 0 || !Number.isSafeInteger(employeeLimit) || employeeLimit < -1 || !Number.isSafeInteger(periodDays) || periodDays < 1 || periodDays > 366 || !Array.isArray(modules) || modules.length > 50 || modules.some((x: unknown)=>typeof x!=='string'||x.length>80)) {
    throw new HttpsError('invalid-argument','Plan pricing or limits are invalid.');
  }
  const active = request.data.active === true;
  if (active && amountPaise === 0 && planId !== 'starter') throw new HttpsError('failed-precondition','Paid plans require a configured non-zero price.');
  await db.doc(`platform/plans/${planId}`).set({ name, amountPaise, employeeLimit, periodDays, modules, active, configured: true, updatedAt: FieldValue.serverTimestamp(), updatedBy: uid }, { merge: true });
  await db.doc(`platform/auditEvents/${slugId()}`).create({ actorUid: uid, action:'plan.configured', entityType:'plan', entityId:planId, createdAt:FieldValue.serverTimestamp() });
  return { saved: true, active };
});

export const setCompanyPlatformStatus = onCall({ enforceAppCheck: true }, async (request) => {
  const uid = requireUser(request); requirePlatformAdmin(uid);
  const tenantId = clean(request.data.tenantId, 120);
  const status = request.data.status;
  if (!['active','suspended'].includes(status)) throw new HttpsError('invalid-argument','Invalid company status.');
  const ref = db.doc(`tenants/${tenantId}`);
  await db.runTransaction(async tx=>{
    const tenant=await tx.get(ref);
    if(!tenant.exists) throw new HttpsError('not-found','Company not found.');
    tx.update(ref,{status,updatedAt:FieldValue.serverTimestamp()});
    tx.create(db.doc(`platform/auditEvents/${slugId()}`),{actorUid:uid,action:`company.${status}`,entityType:'tenant',entityId:tenantId,createdAt:FieldValue.serverTimestamp()});
    tx.create(db.doc(`tenants/${tenantId}/auditEvents/${slugId()}`),{tenantId,actorUid:uid,action:`platform.${status}`,entityType:'tenant',entityId:tenantId,createdAt:FieldValue.serverTimestamp()});
  });
  return { updated:true };
});

export const updateDemoRequestStatus = onCall({ enforceAppCheck: true }, async (request) => {
  const uid=requireUser(request);requirePlatformAdmin(uid);const leadId=clean(request.data.leadId,80);const status=request.data.status;
  if(!/^[a-f0-9]{64}$/.test(leadId)||!['new','contacted','scheduled','closed'].includes(status))throw new HttpsError('invalid-argument','Demo request status is invalid.');
  const ref=db.doc(`platformLeads/${leadId}`);await db.runTransaction(async tx=>{const lead=await tx.get(ref);if(!lead.exists)throw new HttpsError('not-found','Demo request not found.');tx.update(ref,{status,updatedAt:FieldValue.serverTimestamp(),updatedBy:uid});tx.create(db.doc(`platform/auditEvents/${slugId()}`),{actorUid:uid,action:'demo_request.status.updated',entityType:'demoRequest',entityId:leadId,details:{status},createdAt:FieldValue.serverTimestamp()})});
  return {updated:true};
});

export const saveConstructionProject=onCall({enforceAppCheck:true},async request=>{
 const uid=requireUser(request),tenantId=clean(request.data.tenantId,120),m=await membership(uid,tenantId,request.auth?.token);
 if(!isEnterpriseAdmin(m.data.role))throw new HttpsError('permission-denied','Only enterprise administrators manage construction sites.');await requirePermission(m,'projects.create');
 const id=request.data.id?clean(request.data.id,120):slugId(),name=clean(request.data.name,160),description=typeof request.data.description==='string'?request.data.description.trim().slice(0,2000):'',status=request.data.status||'Active';
 if(!safeId.test(id)||!['Active','On Hold','Completed','Archived'].includes(status))throw new HttpsError('invalid-argument','Invalid project details.');
 const ref=db.doc('tenants/'+tenantId+'/projects/'+id);await db.runTransaction(async tx=>{const old=await tx.get(ref),now=FieldValue.serverTimestamp();tx.set(ref,{id,tenantId,name,description,status,createdBy:old.get('createdBy')||uid,createdAt:old.get('createdAt')||now,updatedAt:now},{merge:true});tx.create(db.doc('tenants/'+tenantId+'/auditEvents/'+slugId()),{tenantId,actorUid:uid,action:old.exists?'construction.project.updated':'construction.project.created',entityId:id,createdAt:now});});return {projectId:id};
});
export const initializeConstructionWorkflow=onCall({enforceAppCheck:true},async request=>{
 const uid=requireUser(request),tenantId=clean(request.data.tenantId,120),m=await membership(uid,tenantId,request.auth?.token);if(!isEnterpriseAdmin(m.data.role))throw new HttpsError('permission-denied','Only enterprise administrators initialize construction roles.');
 return migrateConstructionV2(db,tenantId,uid,()=>FieldValue.serverTimestamp());
});

export const listConstructionWorkHistory=onCall({enforceAppCheck:true},async request=>{
 const uid=requireUser(request),tenantId=clean(request.data.tenantId,120),id=clean(request.data.workItemId,120),m=await membership(uid,tenantId,request.auth?.token),item=await db.doc('tenants/'+tenantId+'/siteProgressWorkItems/'+id).get();
 await requireAnyPermission(m,['siteProgress.read','siteProgress.submit','siteProgress.review','siteProgress.allocate']);if(!item.exists)throw new HttpsError('not-found','Work unavailable.');if(Array.isArray(m.data.projectIds))assertProject(m.data,item.get('projectId'));const assigned=(item.get('assignedToUids')||[]).includes(uid);if(!assigned){await requireAnyPermission(m,['siteProgress.read','siteProgress.review']);if(!await progressAllowed(m,item.get('projectId'),'read'))throw new HttpsError('permission-denied','Project access required.');}
 const snap=await db.collection('tenants/'+tenantId+'/siteProgressReports').where('workItemId','==',id).get();return {reports:snap.docs.filter(d=>!assigned||isEnterpriseAdmin(m.data.role)||d.get('submittedBy')===uid||['read','review'].includes(m.data.siteProgressAccess?.permissionLevel)).map(d=>({...d.data(),id:d.id,submittedAt:d.get('submittedAt')?.toDate?.()?.toISOString()||null})).sort((a:any,b:any)=>String(b.workDate).localeCompare(String(a.workDate)))};
});

const accounts=enterpriseAccountHandlers(db,getAuth(),permissions,requirePlatformAdmin);
export const {initializeEnterpriseAccounts,provisionEnterprise,createEnterpriseEmployee,updateEnterpriseEmployee,resetEnterpriseEmployeePassword,completeEnterprisePasswordChange,getMyEnterpriseAccess,listEnterpriseAccounts,setEnterpriseLicense}=accounts;

export const listAuthorizedModuleRecords=onCall({enforceAppCheck:true},async request=>{
 const uid=requireUser(request),tenantId=clean(request.data.tenantId,120),m=await membership(uid,tenantId,request.auth?.token),moduleId=clean(request.data.moduleId,80),collection=clean(request.data.collection,80),module=await db.doc(`tenants/${tenantId}/accessModules/${moduleId}`).get();
 if(!module.exists||!(module.get('collections')||[]).includes(collection))throw new HttpsError('permission-denied','Collection is not available in this module.');await requireAnyPermission(m,module.get('permissions')||[]);
 let query=db.collection(`tenants/${tenantId}/${collection}`).orderBy('__name__').limit(100);const cursor=request.data.cursor;if(cursor){if(!safeId.test(cursor))throw new HttpsError('invalid-argument','Invalid cursor.');query=query.startAfter(cursor);}
 const snap=await query.get(),shared=['suppliers','clients'];return {records:snap.docs.filter(d=>isEnterpriseAdmin(m.data.role)||(collection==='projects'?projectIds(m.data).includes(d.id):d.get('projectId')?projectIds(m.data).includes(d.get('projectId')):shared.includes(collection))).map(d=>({id:d.id,...d.data()})),nextCursor:snap.docs.length===100?snap.docs.at(-1)!.id:null};
});

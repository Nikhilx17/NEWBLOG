import { migrateEnterpriseAccountsV1 } from './migrations/enterpriseAccountsV1.js';
import { randomBytes, createHash } from 'node:crypto';
import { FieldValue, type Firestore } from 'firebase-admin/firestore';
import type { Auth } from 'firebase-admin/auth';
import { HttpsError, onCall } from 'firebase-functions/v2/https';
import { adminRoles, isEnterpriseAdmin, defaultRoles, moduleTemplates, effectivePermissions, assertCredentialState, assertEnterpriseActive, projectIds, assertProject } from './enterpriseAccess.js';
const hash = (s: string) => createHash('sha256').update(s).digest('hex');
const version = () => randomBytes(24).toString('hex');
const id = (v: any) => { if (typeof v !== 'string' || !/^[A-Za-z0-9_-]{1,120}$/.test(v))
    throw new HttpsError('invalid-argument', 'Invalid record ID.'); return v; };
const text = (v: any, max = 120) => { if (typeof v !== 'string' || !v.trim() || v.trim().length > max)
    throw new HttpsError('invalid-argument', 'A required field is missing or too long.'); return v.trim(); };
const username = (v: any) => { const s = text(v, 64).toLowerCase(); if (!/^[a-z0-9][a-z0-9._-]{2,63}$/.test(s))
    throw new HttpsError('invalid-argument', 'Username must be 3–64 letters, numbers, dots, underscores or hyphens.'); return s; };
const password = (v: any) => { if (typeof v !== 'string' || v.length < 12 || v.length > 128 || !/[a-z]/.test(v) || !/[A-Z]/.test(v) || !/[0-9]/.test(v))
    throw new HttpsError('invalid-argument', 'Use 12–128 characters with uppercase, lowercase and a number.'); return v; };
const list = (v: any) => { if (!Array.isArray(v) || v.length > 1000)
    throw new HttpsError('invalid-argument', 'Invalid project list.'); return [...new Set(v.map(id))]; };
export function enterpriseAccountHandlers(db: Firestore, auth: Auth, all: string[], platform: (uid: string) => void) {
    const uid = (r: any) => { if (!r.auth?.uid)
        throw new HttpsError('unauthenticated', 'Sign in to continue.'); return r.auth.uid as string; };
    const permissionList = (v: any) => { if (!Array.isArray(v) || v.some(p => !all.includes(p) || ['team.manage', 'team.read', 'data.migrate', 'siteProgress.manage'].includes(p)))
        throw new HttpsError('invalid-argument', 'Invalid employee permission selection.'); return [...new Set(v)] as string[]; };
    async function member(r: any, temporary = false) { const actor = uid(r), tenantId = id(r.data.tenantId), snap = await db.doc(`tenants/${tenantId}/members/${actor}`).get(); if (!snap.exists)
        throw new HttpsError('permission-denied', 'Enterprise membership required.'); assertCredentialState(snap.data(), r.auth.token, temporary); const tenant = await db.doc(`tenants/${tenantId}`).get(); assertEnterpriseActive(tenant.data()); return { actor, tenantId, snap, tenant }; }
    async function admin(r: any) { const m = await member(r); if (!isEnterpriseAdmin(m.snap.get('role')))
        throw new HttpsError('permission-denied', 'Only Admin: Editor can manage enterprise users.'); return m; }
    const event = (tenantId: string, actor: string, action: string, target: string, details: any = {}) => ({ tenantId, actorUid: actor, action, entityType: 'enterpriseUser', entityId: target, details, createdAt: FieldValue.serverTimestamp() });
    const auditRef = (t: string) => db.collection(`tenants/${t}/auditEvents`).doc();
    async function createIdentity(data: any) { try {
        return await auth.createUser(data);
    }
    catch (e: any) {
        if (!['auth/uid-already-exists', 'auth/email-already-exists'].includes(e.code))
            throw e;
        const existing = await auth.getUser(data.uid);
        const memberships = await db.collection(`users/${data.uid}/memberships`).get();
        if (!existing.disabled || existing.email !== data.email || !memberships.empty)
            throw new HttpsError('already-exists', 'The login username is already in use.');
        return auth.updateUser(data.uid, { password: data.password, displayName: data.displayName });
    } }
    async function enable(uid: string, member: any) { await auth.setCustomUserClaims(uid, { ...(await auth.getUser(uid)).customClaims, credentialVersion: member.credentialVersion }); await auth.updateUser(uid, { disabled: member.status !== 'active' }); }
    const initializeEnterpriseAccounts = onCall({ enforceAppCheck: true }, async (r) => { const m = await admin(r); return migrateEnterpriseAccountsV1(db, m.tenantId, m.actor, all); });
    const provisionEnterprise = onCall({ enforceAppCheck: true }, async (r) => {
        const actor = uid(r);
        platform(actor);
        const requestId = id(r.data.requestId), tenantId = 'ent_' + hash(actor + '|' + requestId).slice(0, 32), adminUid = 'usr_' + hash(tenantId + '|admin').slice(0, 40), name = text(r.data.name), login = username(r.data.username), temporaryPassword = password(r.data.temporaryPassword), employeeLimit = Number(r.data.employeeLimit), modules = r.data.modules;
        if (!Number.isInteger(employeeLimit) || employeeLimit < -1 || !Array.isArray(modules) || !modules.length || modules.some((m: any) => m !== '*' && !moduleTemplates.some(t => t.id === m)))
            throw new HttpsError('invalid-argument', 'Check license limit and modules.');
        const ref = db.doc(`tenants/${tenantId}`), existing = await ref.get();
        if (existing.exists) {
            if (existing.get('provisionRequestId') !== requestId || existing.get('createdBy') !== actor)
                throw new HttpsError('already-exists', 'Enterprise already exists.');
            const m = await db.doc(`tenants/${tenantId}/members/${adminUid}`).get();
            if (m.get('username') !== login)
                throw new HttpsError('already-exists', 'Provisioning retry details changed.');
            await enable(adminUid, m.data());
            return { tenantId, uid: adminUid, username: login, duplicate: true };
        }
        await createIdentity({ uid: adminUid, email: login + '@login.nirmankhata.invalid', password: temporaryPassword, displayName: text(r.data.adminName || 'Enterprise Administrator'), disabled: true });
        let committed = false;
        try {
            const cv = version();
            await db.runTransaction(async (tx) => { const current = await tx.get(ref); if (current.exists)
                throw new HttpsError('already-exists', 'Enterprise already provisioned.'); const now = FieldValue.serverTimestamp(); tx.create(ref, { tenantId, profile: { name }, status: 'active', createdBy: actor, createdAt: now, provisionRequestId: requestId, accessRevision: 1, subscription: { planId: 'managed', status: 'active', employeeLimit, modules, endsAt: null } }); tx.create(db.doc(`tenants/${tenantId}/members/${adminUid}`), { uid: adminUid, username: login, displayName: text(r.data.adminName || 'Enterprise Administrator'), role: 'admin_editor', status: 'active', projectIds: [], mustChangePassword: true, credentialVersion: cv, createdBy: actor, joinedAt: now }); tx.create(db.doc(`users/${adminUid}/memberships/${tenantId}`), { tenantId, name, role: 'admin_editor', status: 'active' }); for (const role of defaultRoles(all))
                tx.create(db.doc(`tenants/${tenantId}/roles/${role.id}`), { name: role.name, permissions: role.permissions, system: true, createdAt: now }); for (const m of moduleTemplates)
                tx.create(db.doc(`tenants/${tenantId}/accessModules/${m.id}`), m); tx.create(db.doc(`tenants/${tenantId}/schemaMigrations/enterprise_accounts_v1`), { version: 1, appliedBy: actor, appliedAt: now }); tx.create(auditRef(tenantId), event(tenantId, actor, 'enterprise.provisioned', adminUid)); tx.create(db.collection('platform/auditEvents').doc(), { actorUid: actor, action: 'enterprise.provisioned', entityId: tenantId, createdAt: now }); });
            committed = true;
            const m = await db.doc(`tenants/${tenantId}/members/${adminUid}`).get();
            await enable(adminUid, m.data());
            return { tenantId, uid: adminUid, username: login };
        }
        catch (e) {
            if (!committed)
                await auth.deleteUser(adminUid);
            throw e;
        }
    });
    const createEnterpriseEmployee = onCall({ enforceAppCheck: true }, async (r) => {
        const m = await admin(r), requestId = id(r.data.requestId), employeeUid = 'usr_' + hash(m.tenantId + '|' + requestId).slice(0, 40), login = username(r.data.username), name = text(r.data.displayName), temporaryPassword = password(r.data.temporaryPassword), roleId = id(r.data.roleId), projects = list(r.data.projectIds || []), override = r.data.permissionOverride === null || r.data.permissionOverride === undefined ? null : permissionList(r.data.permissionOverride), status = r.data.status || 'active';
        if (!['active', 'deactivated'].includes(status) || isEnterpriseAdmin(roleId))
            throw new HttpsError('invalid-argument', 'Choose an employee role and valid status.');
        const ref = db.doc(`tenants/${m.tenantId}/members/${employeeUid}`), existing = await ref.get();
        if (existing.exists) {
            if (existing.get('createRequestId') !== requestId || existing.get('createdBy') !== m.actor || existing.get('username') !== login)
                throw new HttpsError('already-exists', 'Employee already exists.');
            await enable(employeeUid, existing.data());
            return { uid: employeeUid, username: login, duplicate: true };
        }
        await createIdentity({ uid: employeeUid, email: login + '@login.nirmankhata.invalid', password: temporaryPassword, displayName: name, disabled: true });
        let committed = false;
        try {
            await db.runTransaction(async (tx) => { const [tenant, role, active, ...projectSnaps] = await Promise.all([tx.get(m.tenant.ref), tx.get(db.doc(`tenants/${m.tenantId}/roles/${roleId}`)), tx.get(db.collection(`tenants/${m.tenantId}/members`).where('status', '==', 'active')), ...projects.map(p => tx.get(db.doc(`tenants/${m.tenantId}/projects/${p}`)))]); assertEnterpriseActive(tenant.data()); if (!role.exists || projectSnaps.some(p => !p.exists))
                throw new HttpsError('invalid-argument', 'Role or projects do not belong to this enterprise.'); const limit = tenant.get('subscription.employeeLimit'), count = active.docs.filter(d => !isEnterpriseAdmin(d.get('role'))).length; if (status === 'active' && limit >= 0 && count >= limit)
                throw new HttpsError('resource-exhausted', 'Enterprise employee limit reached.'); const now = FieldValue.serverTimestamp(); tx.create(ref, { uid: employeeUid, username: login, displayName: name, role: roleId, permissionOverride: override, projectIds: projects, siteProgressAccess: { projectIds: projects, categoryIds: [], permissionLevel: (override || role.get('permissions') || []).includes('siteProgress.review') ? 'review' : (override || role.get('permissions') || []).includes('siteProgress.read') ? 'read' : 'submit' }, status, mustChangePassword: true, credentialVersion: version(), createdBy: m.actor, createRequestId: requestId, joinedAt: now }); tx.create(db.doc(`users/${employeeUid}/memberships/${m.tenantId}`), { tenantId: m.tenantId, name: tenant.get('profile.name'), role: roleId, status }); tx.update(m.tenant.ref, { accessRevision: Number(tenant.get('accessRevision') || 0) + 1 }); tx.create(auditRef(m.tenantId), event(m.tenantId, m.actor, 'employee.created', employeeUid, { username: login, roleId, projectIds: projects, status })); });
            committed = true;
            await enable(employeeUid, (await ref.get()).data());
            return { uid: employeeUid, username: login };
        }
        catch (e) {
            if (!committed)
                await auth.deleteUser(employeeUid);
            throw e;
        }
    });
    const updateEnterpriseEmployee = onCall({ enforceAppCheck: true }, async (r) => {
        const m = await admin(r), target = id(r.data.memberUid);
        if (target === m.actor)
            throw new HttpsError('failed-precondition', 'You cannot change your own access here.');
        const ref = db.doc(`tenants/${m.tenantId}/members/${target}`);
        const changedSession = await db.runTransaction(async (tx) => { const [current, tenant, active] = await Promise.all([tx.get(ref), tx.get(m.tenant.ref), tx.get(db.collection(`tenants/${m.tenantId}/members`).where('status', '==', 'active'))]); if (!current.exists)
            throw new HttpsError('not-found', 'Employee not found.'); const roleId = id(r.data.roleId || current.get('role')), status = r.data.status || current.get('status'), projects = r.data.projectIds === undefined ? projectIds(current.data()) : list(r.data.projectIds), override = r.data.permissionOverride === undefined ? (current.get('permissionOverride') ?? null) : r.data.permissionOverride === null ? null : permissionList(r.data.permissionOverride); if (!['active', 'deactivated'].includes(status))
            throw new HttpsError('invalid-argument', 'Invalid status.'); if (isEnterpriseAdmin(roleId) && !isEnterpriseAdmin(current.get('role')))
            throw new HttpsError('permission-denied', 'Employee management cannot grant Enterprise Super Admin access.'); if (isEnterpriseAdmin(current.get('role')) && (!isEnterpriseAdmin(roleId) || status !== 'active') && active.docs.filter(d => isEnterpriseAdmin(d.get('role'))).length <= 1)
            throw new HttpsError('failed-precondition', 'The final active Admin: Editor cannot be removed or demoted.'); const [role, ...ps] = await Promise.all([tx.get(db.doc(`tenants/${m.tenantId}/roles/${roleId}`)), ...projects.map(p => tx.get(db.doc(`tenants/${m.tenantId}/projects/${p}`)))]); if (!role.exists || ps.some(p => !p.exists))
            throw new HttpsError('invalid-argument', 'Invalid role or project assignment.'); const count = active.docs.filter(d => d.id !== target && !isEnterpriseAdmin(d.get('role'))).length, limit = tenant.get('subscription.employeeLimit'); if (status === 'active' && !isEnterpriseAdmin(roleId) && limit >= 0 && count >= limit)
            throw new HttpsError('resource-exhausted', 'Enterprise employee limit reached.'); const patch: any = { role: roleId, status, projectIds: projects, permissionOverride: override, siteProgressAccess: { projectIds: projects, categoryIds: [], permissionLevel: (override || role.get('permissions') || []).includes('siteProgress.review') ? 'review' : (override || role.get('permissions') || []).includes('siteProgress.read') ? 'read' : 'submit' }, updatedAt: FieldValue.serverTimestamp() }; if (current.get('status') !== status && current.get('credentialVersion'))
            patch.credentialVersion = version(); tx.update(ref, patch); tx.set(db.doc(`users/${target}/memberships/${m.tenantId}`), { role: roleId, status }, { merge: true }); tx.update(m.tenant.ref, { accessRevision: Number(tenant.get('accessRevision') || 0) + 1 }); tx.create(auditRef(m.tenantId), event(m.tenantId, m.actor, 'employee.access.updated', target, { before: { role: current.get('role'), status: current.get('status'), projectIds: projectIds(current.data()), permissionOverride: current.get('permissionOverride') ?? null }, after: { role: roleId, status, projectIds: projects, permissionOverride: override } })); return current.get('status') !== status; });
        const current = await ref.get();
        if (changedSession && current.get('credentialVersion')) {
            await auth.revokeRefreshTokens(target);
            await enable(target, current.data());
        }
        return { updated: true };
    });
    const resetEnterpriseEmployeePassword = onCall({ enforceAppCheck: true }, async (r) => {
        const m = await admin(r), target = id(r.data.memberUid), temporaryPassword = password(r.data.temporaryPassword);
        if (target === m.actor)
            throw new HttpsError('failed-precondition', 'Use a separate authorized administrator to reset your account.');
        const ref = db.doc(`tenants/${m.tenantId}/members/${target}`), current = await ref.get();
        if (!current.exists || !current.get('credentialVersion') || !current.get('username') || isEnterpriseAdmin(current.get('role')))
            throw new HttpsError('permission-denied', 'Only employee passwords may be reset here.');
        if (Date.now() / 1000 - Number(r.auth?.token.auth_time || 0) > 600)
            throw new HttpsError('unauthenticated', 'Sign in again before resetting credentials.');
        const cv = version();
        await ref.update({ mustChangePassword: true, credentialVersion: cv, passwordResetAt: FieldValue.serverTimestamp() });
        await auth.revokeRefreshTokens(target);
        await auth.updateUser(target, { password: temporaryPassword });
        await enable(target, { ...current.data(), credentialVersion: cv });
        await auditRef(m.tenantId).create(event(m.tenantId, m.actor, 'employee.password.reset', target));
        return { reset: true };
    });
    const completeEnterprisePasswordChange = onCall({ enforceAppCheck: true }, async (r) => {
        const m = await member(r, true), newPassword = password(r.data.newPassword);
        if (!m.snap.get('mustChangePassword'))
            throw new HttpsError('failed-precondition', 'No temporary password change is pending.');
        if (Date.now() / 1000 - Number(r.auth?.token.auth_time || 0) > 600)
            throw new HttpsError('unauthenticated', 'Sign in again before changing credentials.');
        await auth.updateUser(m.actor, { password: newPassword });
        await auth.revokeRefreshTokens(m.actor);
        const cv = version();
        await m.snap.ref.update({ mustChangePassword: false, credentialVersion: cv, passwordChangedAt: FieldValue.serverTimestamp() });
        await enable(m.actor, { ...m.snap.data(), credentialVersion: cv });
        await auditRef(m.tenantId).create(event(m.tenantId, m.actor, 'employee.password.changed', m.actor));
        return { changed: true, signInAgain: true };
    });
    const getMyEnterpriseAccess = onCall({ enforceAppCheck: true }, async (r) => {
        const m = await member(r, true);
        if (m.snap.get('mustChangePassword'))
            return { tenantId: m.tenantId, mustChangePassword: true, username: m.snap.get('username') || '', canManageUsers: false, permissions: [], modules: [] };
        const role = await db.doc(`tenants/${m.tenantId}/roles/${m.snap.get('role')}`).get(), granted = effectivePermissions(m.snap.data(), role.data(), all), sub = m.tenant.get('subscription'), modules = await db.collection(`tenants/${m.tenantId}/accessModules`).get();
        return { tenantId: m.tenantId, mustChangePassword: false, username: m.snap.get('username') || '', displayName: m.snap.get('displayName'), role: m.snap.get('role'), roleName: isEnterpriseAdmin(m.snap.get('role')) ? 'Admin: Editor' : role.get('name'), canManageUsers: isEnterpriseAdmin(m.snap.get('role')), permissions: granted, projectIds: projectIds(m.snap.data()), modules: modules.docs.filter(d => (sub.modules.includes('*') || sub.modules.includes(d.id)) && (isEnterpriseAdmin(m.snap.get('role')) || (d.get('permissions') || []).some((p: string) => granted.includes(p)))).map(d => ({ id: d.id, ...d.data() })) };
    });
    const listEnterpriseAccounts = onCall({ enforceAppCheck: true }, async (r) => { const m = await admin(r); const [members, roles, projects, events] = await Promise.all([db.collection(`tenants/${m.tenantId}/members`).get(), db.collection(`tenants/${m.tenantId}/roles`).get(), db.collection(`tenants/${m.tenantId}/projects`).get(), db.collection(`tenants/${m.tenantId}/auditEvents`).orderBy('createdAt', 'desc').limit(100).get()]); return { members: members.docs.map(d => ({ uid: d.id, username: d.get('username') || d.get('email') || '', displayName: d.get('displayName') || '', isEnterpriseAdmin: isEnterpriseAdmin(d.get('role')), roleId: d.get('role'), status: d.get('status'), projectIds: projectIds(d.data()), permissionOverride: d.get('permissionOverride') ?? null, mustChangePassword: d.get('mustChangePassword') === true })), roles: roles.docs.map(d => ({ id: d.id, isEnterpriseAdmin: isEnterpriseAdmin(d.id), name: isEnterpriseAdmin(d.id) ? 'Admin: Editor' : d.get('name'), permissions: d.get('permissions') || [], system: d.get('system') === true })), projects: projects.docs.map(d => ({ id: d.id, name: d.get('name') || d.id })), permissionCatalog: all.filter(p => !['team.manage', 'team.read', 'data.migrate', 'siteProgress.manage'].includes(p)), audit: events.docs.filter(d => /employee|roles|accounts/.test(d.get('action') || '')).map(d => ({ id: d.id, action: d.get('action'), actorUid: d.get('actorUid'), entityId: d.get('entityId'), details: d.get('details') || {}, createdAt: d.get('createdAt')?.toDate?.()?.toISOString() || null })) }; });
    const setEnterpriseLicense = onCall({ enforceAppCheck: true }, async (r) => { const actor = uid(r); platform(actor); const tenantId = id(r.data.tenantId), status = r.data.status, limit = Number(r.data.employeeLimit), modules = r.data.modules, days = Number(r.data.days || 30); if (!['active', 'suspended', 'expired'].includes(status) || !Number.isInteger(limit) || limit < -1 || !Array.isArray(modules) || !modules.length || modules.some((m: any) => m !== '*' && !moduleTemplates.some(t => t.id === m)) || !Number.isInteger(days) || days < 1 || days > 3660)
        throw new HttpsError('invalid-argument', 'Invalid subscription settings.'); const ref = db.doc(`tenants/${tenantId}`); await db.runTransaction(async (tx) => { if (!(await tx.get(ref)).exists)
        throw new HttpsError('not-found', 'Enterprise not found.'); tx.update(ref, { status: status === 'suspended' ? 'suspended' : 'active', subscription: { planId: 'managed', status, employeeLimit: limit, modules, endsAt: new Date(Date.now() + days * 86400000) }, updatedAt: FieldValue.serverTimestamp() }); tx.create(db.collection('platform/auditEvents').doc(), { actorUid: actor, action: 'enterprise.license.updated', entityId: tenantId, details: { status, employeeLimit: limit, modules, days }, createdAt: FieldValue.serverTimestamp() }); }); return { updated: true }; });
    return { initializeEnterpriseAccounts, provisionEnterprise, createEnterpriseEmployee, updateEnterpriseEmployee, resetEnterpriseEmployeePassword, completeEnterprisePasswordChange, getMyEnterpriseAccess, listEnterpriseAccounts, setEnterpriseLicense };
}

import { FieldValue, type Firestore } from 'firebase-admin/firestore';
import { defaultRoles, moduleTemplates } from '../enterpriseAccess.js';
/** Adds templates and the module registry without replacing identities or operational records. */
export async function migrateEnterpriseAccountsV1(db: Firestore, tenantId: string, actor: string, all: string[]) {
    return db.runTransaction(async (tx) => {
        const marker = db.doc(`tenants/${tenantId}/schemaMigrations/enterprise_accounts_v1`);
        if ((await tx.get(marker)).exists)
            return { alreadyApplied: true };
        const roles = defaultRoles(all), refs = roles.map(r => db.doc(`tenants/${tenantId}/roles/${r.id}`));
        const prior = await Promise.all(refs.map(ref => tx.get(ref)));
        roles.forEach((r, i) => { if (!prior[i].exists)
            tx.create(refs[i], { name: r.name, permissions: r.permissions, system: true, createdAt: FieldValue.serverTimestamp() }); });
        moduleTemplates.forEach(m => tx.set(db.doc(`tenants/${tenantId}/accessModules/${m.id}`), m));
        tx.create(marker, { version: 1, appliedBy: actor, appliedAt: FieldValue.serverTimestamp() });
        tx.create(db.collection(`tenants/${tenantId}/auditEvents`).doc(), { tenantId, actorUid: actor, action: 'accounts.schema.initialized', entityId: tenantId, createdAt: FieldValue.serverTimestamp() });
        return { alreadyApplied: false };
    });
}

import type { Firestore } from 'firebase-admin/firestore';

/** Additive, per-enterprise migration. Never replaces roles or historical reports. */
export async function migrateConstructionV2(db: Firestore, tenantId: string, uid: string, timestamp: () => unknown) {
 return db.runTransaction(async tx => {
  const markerRef = db.doc(`tenants/${tenantId}/schemaMigrations/construction_v2`);
  if ((await tx.get(markerRef)).exists) return { alreadyApplied: true };
  const roles = [
   { id: 'site_manager', name: 'Site Manager', permissions: ['siteProgress.read'] },
   { id: 'site_supervisor', name: 'Site Supervisor', permissions: ['siteProgress.submit'] },
  ];
  const snapshots = await Promise.all(roles.map(role => tx.get(db.doc(`tenants/${tenantId}/roles/${role.id}`))));
  roles.forEach((role, index) => {
   if (!snapshots[index].exists) tx.create(snapshots[index].ref, { name: role.name, system: true, permissions: role.permissions, createdAt: timestamp() });
  });
  tx.create(markerRef, { tenantId, version: 2, appliedBy: uid, appliedAt: timestamp(), historicalReportsPreserved: true });
  return { alreadyApplied: false };
 });
}

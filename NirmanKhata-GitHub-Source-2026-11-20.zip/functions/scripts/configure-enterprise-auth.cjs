// Run with an authorized deployment identity (Application Default Credentials).
// Default: inspect only. Pass --apply to disable client signup and self-deletion.
const {initializeApp,applicationDefault}=require('firebase-admin/app');
const fs=require('node:fs');
const path=require('node:path');
(async()=>{
 const projectId=process.env.GOOGLE_CLOUD_PROJECT||JSON.parse(fs.readFileSync(path.resolve(__dirname,'../../firebase-applet-config.json'),'utf8')).projectId;
 if(!/^[a-z][a-z0-9-]{4,61}[a-z0-9]$/.test(projectId))throw new Error('Invalid Firebase project ID.');
 const credential=applicationDefault();initializeApp({credential,projectId});
 const {access_token}=await credential.getAccessToken();
 const url=`https://identitytoolkit.googleapis.com/admin/v2/projects/${projectId}/config`;
 const headers={Authorization:`Bearer ${access_token}`,'Content-Type':'application/json'};
 const existing=await fetch(url,{headers});if(!existing.ok)throw new Error(`Unable to read authentication configuration: HTTP ${existing.status}`);
 const current=await existing.json();console.log(JSON.stringify({projectId,currentClientPermissions:current.client?.permissions||{},apply:process.argv.includes('--apply')},null,2));
 if(!process.argv.includes('--apply')){console.log('Read-only inspection. Pass --apply to disable public signup and client account deletion.');return;}
 const response=await fetch(url+'?updateMask=client.permissions.disabledUserSignup,client.permissions.disabledUserDeletion',{method:'PATCH',headers,body:JSON.stringify({client:{permissions:{disabledUserSignup:true,disabledUserDeletion:true}}})});
 if(!response.ok)throw new Error(`Authentication configuration update failed: HTTP ${response.status}`);
 const result=await response.json();if(result.client?.permissions?.disabledUserSignup!==true||result.client?.permissions?.disabledUserDeletion!==true)throw new Error('Provider did not confirm the requested restrictions.');
 console.log('Confirmed: client signup and client account deletion are disabled. Server-side account management remains available.');
})().catch(error=>{console.error(error.message);process.exitCode=1;});

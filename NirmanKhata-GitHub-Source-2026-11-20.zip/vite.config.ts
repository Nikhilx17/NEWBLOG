import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import {fileURLToPath} from 'node:url';
import {defineConfig} from 'vite';

export default defineConfig(() => {
  return {
    plugins: [react(), tailwindcss()],
    // Avoid Vite discovering an incompatible PostCSS config outside this project.
    css: {
      postcss: {},
    },
    resolve: {
      alias: {
        '@': fileURLToPath(new URL('.',import.meta.url)),
      },
    },
    server: {
      proxy:{'/api':'http://127.0.0.1:3001','/healthz':'http://127.0.0.1:3001','/readyz':'http://127.0.0.1:3001'},
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify—file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});

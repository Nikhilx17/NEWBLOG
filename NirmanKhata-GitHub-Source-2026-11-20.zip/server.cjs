// Listen synchronously before importing dependencies or connecting to MySQL.
const http=require('node:http');
let handler;
const server=http.createServer((req,res)=>{if(handler)return handler(req,res);res.statusCode=req.url==='/healthz'?200:503;res.setHeader('Content-Type','application/json');res.end(JSON.stringify({ok:req.url==='/healthz',starting:true,service:'NirmanKhata ERP'}));});
server.listen(Number(process.env.PORT||3000),'0.0.0.0',()=>console.log(JSON.stringify({timestamp:new Date().toISOString(),level:'INFO',message:'ERP HTTP listener ready'})));
import('./server/app.mjs').then(module=>{handler=module.default;}).catch(error=>console.error(JSON.stringify({timestamp:new Date().toISOString(),level:'ERROR',message:'Application initialization failed',code:error.code||'INITIALIZATION'})));
process.on('SIGTERM',()=>{server.close(()=>process.exit(0));setTimeout(()=>process.exit(0),10000).unref();});
module.exports=server;

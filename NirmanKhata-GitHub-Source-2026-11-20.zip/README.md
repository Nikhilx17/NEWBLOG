# NirmanKhata ERP

The existing React 19 / TypeScript / Vite / Tailwind ERP now has a same-origin Express / MySQL backend for Hostinger managed Node.js hosting. Production authentication uses server sessions and username/password accounts. The old Firebase implementation remains in the source for reference and migration; the native production entry does not use it.

Verified dedicated staging: https://wishful-khaki-sheep-70.hostingersite.com/app

## Owner guide

Sign in as Platform Owner to create an enterprise and its initial **Admin: Editor** account. Admin: Editor is the enterprise Super Admin. That administrator completes the company profile and creates employees in User & Access Management. Employees receive a temporary password and must replace it on first login. There is no employee self-registration or OTP.

Work Allocation & Progress lets the enterprise administrator create categories, allocate quantities to assigned employees, review submissions and original photos, and approve quantities. Supervisors start in Daily Work Reporting. Pending reports do not count toward approved progress. Two accepted quantities of 12 and 20 against 100 produce 32 approved, 68 remaining and 32%.

Existing purchases, banking, expenses, clients, invoices, inventory, attendance, payroll, subcontractors, projects, budgets and operations screens use server commands and tenant-scoped MySQL snapshots. UI save errors appear in the connection banner; do not treat a closed modal alone as proof of a completed save.

## Development

Use Node.js 24 and `npm ci`. Create protected server variables using `.env.example`; never put credentials in VITE_ variables. For a local MySQL database, run the backend with `node --env-file=.env server.cjs` and PORT=3001, then `npm run dev` for the frontend on port 3000. The Vite proxy forwards /api to port 3001. Production receives variables from Hostinger, builds with `npm run build`, and starts `server.cjs` using the hosting-provided PORT.

`npm run lint` checks types. `npm test` includes native security/backup/startup tests and preserved legacy Firebase handler tests with service doubles. `scripts/staging-smoke.mjs` and `scripts/staging-extended.mjs` exercise actual HTTPS/MySQL staging APIs; their private runtime inputs are excluded from releases. Never aim the data-creating scripts at customer production records.

See [deployment and recovery](docs/HOSTINGER_PRODUCTION.md), [audit](docs/HOSTINGER_AUDIT.md), [test evidence](docs/HOSTINGER_TEST_RESULTS.md), and [actual changed files](docs/HOSTINGER_CHANGED_FILES.md). The prior Firebase README is preserved at docs/LEGACY_FIREBASE_README.md.

## Historical records

No existing website, Firebase data or browser data is automatically overwritten. In User & Access Management, use Historical Data, Backups & File Retention to review browser records on their original origin or choose an existing JSON export. Back up and review the source before confirming import. Original browser storage is retained. Records with conflicting IDs stop rather than overwrite existing business data. Real customer historical data migration has not been verified without its source export/access.

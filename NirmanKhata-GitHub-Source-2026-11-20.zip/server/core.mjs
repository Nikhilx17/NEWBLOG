import {randomBytes,scrypt as scryptCb,timingSafeEqual,createHash} from 'node:crypto';
import {promisify} from 'node:util';
export const scrypt=promisify(scryptCb);
export const uuid=()=>randomBytes(16).toString('hex');
export const hash=v=>createHash('sha256').update(v).digest('hex');
export const json=v=>typeof v==='string'?JSON.parse(v):v;
export class ApiError extends Error{constructor(status,message){super(message);this.status=status;}}
export function assert(condition,message,status=400){if(!condition)throw new ApiError(status,message);}
export function text(v,max=120){assert(typeof v==='string'&&v.trim()&&v.trim().length<=max,'A required text field is missing or too long.');return v.trim();}
export function id(v){const s=text(v);assert(/^[A-Za-z0-9_-]+$/.test(s),'Invalid identifier.');return s;}
export function loginId(v){const s=text(v,64).toLowerCase();assert(/^[a-z0-9][a-z0-9._-]{2,63}$/.test(s),'Use a 3–64 character login ID with letters, numbers, dots, underscores or hyphens.');return s;}
export function strongPassword(v){assert(typeof v==='string'&&v.length>=12&&v.length<=128&&/[a-z]/.test(v)&&/[A-Z]/.test(v)&&/[0-9]/.test(v),'Password must contain 12–128 characters, uppercase, lowercase and a number.');return v;}
export async function passwordHash(v){strongPassword(v);const salt=randomBytes(16).toString('hex'),derived=await scrypt(v,salt,64,{N:32768,r:8,p:1,maxmem:64*1024*1024});return 'scrypt$32768$'+salt+'$'+derived.toString('hex');}
export async function verifyPassword(v,stored){if(typeof v!=='string'||v.length>128)return false;const [,cost,salt,expected]=String(stored||'').split('$');if(!salt||!expected)return false;const bytes=Buffer.from(expected,'hex'),actual=await scrypt(v,salt,64,{N:Number(cost),r:8,p:1,maxmem:64*1024*1024});return actual.length===bytes.length&&timingSafeEqual(actual,bytes);}
export const round=v=>Math.round((Number(v)+Number.EPSILON)*1e6)/1e6;
export function quantity(v,allowZero=false){const n=Number(v);assert(Number.isFinite(n)&&n>=(allowZero?0:.000001)&&n<=1e9&&round(n)===n,'Enter a valid nonnegative quantity with up to six decimal places.');return n;}
export function date(v){assert(typeof v==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(v)&&!Number.isNaN(Date.parse(v+'T00:00:00Z'))&&new Date(v+'T00:00:00Z').toISOString().slice(0,10)===v,'Invalid date.');return v;}
export const admin=u=>u.role_id==='admin_editor';
export const catalog={
 'work-assignment':{label:'Work Assignment',permission:'siteProgress.allocate',module:'operations'},
 'dpr-approvals':{label:'DPR Approvals',permission:'siteProgress.review',any:['siteProgress.review','siteProgress.read'],module:'operations'},
 'site-desk':{label:'Manager / Site Desk',permission:'projects.read',any:['projects.read','purchases.read','purchases.create','purchases.receive'],module:'projects'},
 dashboard:{label:'Main Dashboard',permission:'reports.operational.read',module:'reports'},projects:{label:'Projects / Sites',permission:'projects.read',module:'projects'},'work-progress':{label:'Work Allocation & Progress',permission:'siteProgress.submit',any:['siteProgress.read','siteProgress.submit','siteProgress.allocate','siteProgress.review'],module:'operations'},purchases:{label:'Purchases',permission:'purchases.read',module:'purchases'},suppliers:{label:'Suppliers',permission:'purchases.read',module:'purchases'},expenses:{label:'Daily Expenses',permission:'expenses.read',module:'expenses'},workers:{label:'Workers',permission:'workers.read',module:'workers'},reports:{label:'Financial Reports',permission:'reports.financial.read',module:'reports'},inventory:{label:'Inventory',permission:'inventory.read',module:'inventory'},alerts:{label:'Notifications',permission:'reports.operational.read',module:'reports'},settings:{label:'Business Profile',permission:'settings.manage',module:'administration'},team:{label:'User & Access Management',permission:'users.manage',module:'administration'},
 'daily-site-register':{label:'Daily Site Register',permission:'projects.read',any:['projects.read'],module:'projects'}
};
export const allPermissions=[...new Set([...Object.values(catalog).map(v=>v.permission),...['projects','purchases','sales','expenses','inventory','workers','attendance','payroll','banking','subcontractors','siteProgress','users','roles'].flatMap(m=>['read','create','edit','submit','review','approve','reject','archive','export','manage'].map(a=>m+'.'+a)), 'siteProgress.allocate','siteProgress.assign','siteProgress.download','siteProgress.manage','settings.manage','audit.read','data.import','data.backup','purchases.pay','purchases.receive','sales.receive','subcontractors.pay'])];
export const roleTemplates=[
 {id:'admin_editor',name:'Admin: Editor',uiRole:'owner',permissions:allPermissions},
 {id:'purchase_manager',name:'Purchase Manager',uiRole:'purchase_manager',permissions:['projects.read','purchases.read','purchases.create','purchases.edit','purchases.submit','purchases.export']},
 {id:'accounts',name:'Accounts',uiRole:'accountant',permissions:['projects.read','purchases.read','purchases.pay','purchases.receive','sales.receive','subcontractors.pay','sales.read','sales.create','sales.edit','sales.approve','expenses.read','expenses.create','expenses.archive','banking.read','banking.manage','payroll.read','payroll.manage','reports.financial.read','reports.operational.read','subcontractors.read']},
 {id:'project_manager',name:'Project Manager',uiRole:'project_manager',permissions:['projects.read','projects.edit','siteProgress.read','siteProgress.allocate','siteProgress.assign','inventory.read','inventory.manage','attendance.manage','workers.read','workers.manage','subcontractors.read','subcontractors.manage','reports.operational.read']},
 {id:'admin_reviewer',name:'Admin: Reviewer',uiRole:'auditor',permissions:['projects.read','purchases.read','purchases.review','purchases.approve','purchases.reject','siteProgress.read','siteProgress.review','reports.operational.read']},
 {id:'site_supervisor',name:'Site Supervisor',uiRole:'site_supervisor',permissions:['siteProgress.submit','attendance.manage']}
];
export function granted(u,p){if(admin(u))return true;if(p.startsWith('users.')||p.startsWith('roles.')||['siteProgress.manage','data.import','data.backup','settings.manage'].includes(p))return false;return u.permissions.includes(p);}
export function permit(u,p){assert(granted(u,p),'You do not have permission for this action.',403);const prefix=p.split('.')[0],module=({siteProgress:'operations',subcontractors:'projects',attendance:'workers'})[prefix]||prefix;if(!['users','roles','settings','audit','data'].includes(module))assert(u.subscription.modules.includes('*')||u.subscription.modules.includes(module),'This module is not enabled by your enterprise license.',403);}
export function project(u,p){assert(admin(u)||u.projectIds.includes(p),'This project is not assigned to you.',403);}
export const allowedTabs=u=>Object.entries(catalog).filter(([key,v])=>(key!=='work-progress'||!admin(u)&&!['siteProgress.allocate','siteProgress.read','siteProgress.review'].some(p=>granted(u,p)))&&(key!=='operations'||admin(u)||granted(u,'projects.read'))&&(admin(u)||(v.any||[v.permission]).some(p=>granted(u,p)))&&(v.module==='administration'||u.subscription.modules.includes('*')||u.subscription.modules.includes(v.module))).map(([key,v])=>({id:key,label:v.label}));

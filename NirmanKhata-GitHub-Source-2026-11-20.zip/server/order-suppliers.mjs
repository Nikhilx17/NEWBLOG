import {rows} from './database.mjs';
import {assert,hash,uuid,permit,granted,admin,text} from './core.mjs';
import {getRecord,putRecord} from './records.mjs';
import {normalizedItem} from '../src/lib/siteWorkflow.mjs';
const visible=(u,row)=>!row.project_id||admin(u)||u.projectIds.includes(row.project_id);
const unpack=row=>typeof row.data==='string'?JSON.parse(row.data):row.data;
export async function searchOrderSuppliers(c,u,query=''){
 const permission=['purchases.read','purchases.create'].find(p=>granted(u,p));assert(permission,'Supplier access is not granted.',403);permit(u,permission);assert(typeof query==='string'&&query.length<=160,'Search text is too long.');
 const q=normalizedItem(query),scope=admin(u)?'':` AND (project_id IS NULL${u.projectIds.length?' OR project_id IN ('+u.projectIds.map(()=>'?').join(',')+')':''})`,norm="COALESCE(JSON_UNQUOTE(JSON_EXTRACT(data,'$.normalizedName')),LOWER(JSON_UNQUOTE(JSON_EXTRACT(data,'$.name'))))";
 const found=await rows(c,`SELECT data FROM erp_records WHERE enterprise_id=? AND kind='suppliers' AND archived=0${scope} AND LOCATE(?,${norm})>0 ORDER BY CASE WHEN LEFT(${norm},CHAR_LENGTH(?))=? THEN 0 ELSE 1 END,JSON_UNQUOTE(JSON_EXTRACT(data,'$.name')) LIMIT 20`,[u.enterprise_id,...(admin(u)?[]:u.projectIds),q,q,q]);
 return {suggestions:found.map(unpack).map(s=>({id:s.id,name:s.name,gstin:s.gstin||'',phone:s.phone||'',address:s.address||''}))};
}
export async function rememberOrderSupplier(c,u,v){
 const name=String(v.supplier||'').normalize('NFKC').trim().replace(/\s+/g,' ');if(!name)return {};
 text(name,160);const gstin=String(v.supplierGstin||'').trim().toUpperCase(),phone=String(v.supplierPhone||'').trim(),address=String(v.supplierAddress||'').trim();
 assert(!gstin||/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][1-9A-Z]Z[0-9A-Z]$/.test(gstin),'GSTIN format is invalid.');assert(phone.length<=40&&address.length<=1500,'Party contact details are too long.');
 let existing=v.supplierId?await getRecord(c,u,'suppliers',v.supplierId,true):null;
 if(existing)assert(normalizedItem(existing.name)===normalizedItem(name),'Select the matching supplier or clear the selection before entering a new name.');
 if(!existing){const all=await rows(c,"SELECT data,project_id FROM erp_records WHERE enterprise_id=? AND kind='suppliers' AND archived=0 FOR UPDATE",[u.enterprise_id]);existing=all.filter(r=>visible(u,r)).map(unpack).find(s=>normalizedItem(s.name)===normalizedItem(name));}
 assert(!existing?.gstin||!gstin||existing.gstin.toUpperCase()===gstin,'This party already has a different GSTIN. Select the correct existing party or use a distinct legal name.',409);
 if(!existing){existing={id:hash('supplier|'+normalizedItem(name)),name,normalizedName:normalizedItem(name),gstin,phone,address,category:'Construction Material',paymentTermsDays:0,openingBalance:0,createdAt:new Date().toISOString()};await putRecord(c,u,'suppliers',existing,true);}
 else if((!existing.gstin&&gstin)||(!existing.phone&&phone)||(!existing.address&&address))existing=await putRecord(c,u,'suppliers',{...existing,gstin:existing.gstin||gstin,phone:existing.phone||phone,address:existing.address||address});
 return {supplierId:existing.id,supplier:existing.name,supplierGstin:gstin||existing.gstin||'',supplierPhone:phone||existing.phone||'',supplierAddress:address||existing.address||''};
}

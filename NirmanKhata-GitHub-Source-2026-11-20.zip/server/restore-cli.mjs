// Offline recovery only: use a NEW database and private data directory.
import 'dotenv/config';
import {initialize,database} from './database.mjs';
import {restoreEmptyDatabase} from './backup.mjs';
if(process.env.ERP_RESTORE_EMPTY_DATABASE!=='YES'||!process.argv[2]){console.error('Set ERP_RESTORE_EMPTY_DATABASE=YES and supply an encrypted archive. Restore refuses nonempty enterprise tables.');process.exit(2);}
// Prevent automatic owner bootstrap from making the recovery database nonempty.
process.env.ERP_BOOTSTRAP_USERNAME='';process.env.ERP_BOOTSTRAP_PASSWORD='';
try{await initialize();const result=await restoreEmptyDatabase(process.argv[2]);console.log(JSON.stringify(result));}finally{await database().end();}

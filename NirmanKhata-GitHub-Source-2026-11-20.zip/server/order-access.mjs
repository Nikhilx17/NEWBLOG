import {permit,project,granted,admin,assert} from './core.mjs';
import {getRecord} from './records.mjs';
export async function orderAccess(c,u,orderId,receive=false){
 const p=receive?'purchases.receive':['purchases.read','purchases.create','purchases.receive'].find(p=>granted(u,p));assert(p,'Purchase order access is not granted.',403);permit(u,p);
 const order=await getRecord(c,u,'siteOrders',orderId);project(u,order.projectId);if(receive)assert(order.status==='Ordered','Only an ordered item can be received.',409);return order;
}

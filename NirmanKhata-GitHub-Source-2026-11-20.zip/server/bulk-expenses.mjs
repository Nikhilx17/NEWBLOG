import {rows} from './database.mjs';
import {assert,id,hash,json,permit,project} from './core.mjs';
import {validateExpenseBatch} from '../src/lib/bulkExpenses.mjs';
// /api/command supplies the existing enterprise lock, SQL transaction and request idempotency.
export async function saveBulkExpenses(c,u,input,createExpense){
 permit(u,'expenses.create');const submissionId=id(input?.submissionId),entries=validateExpenseBatch(input?.rows),signature=hash(JSON.stringify(entries));
 const prior=await rows(c,'SELECT data FROM erp_records WHERE enterprise_id=? AND kind=? AND id=? FOR UPDATE',[u.enterprise_id,'expenseBatch',submissionId]);
 if(prior.length){const saved=json(prior[0].data);assert(saved.actorId===u.id,'This submission belongs to another user.',403);assert(saved.signature===signature,'This batch was already saved with different values. Check Saved Expenses before starting another batch.',409);return saved.result;}
 // Validate access before the first financial write. Existing create command validates actual projects and accounts.
 for(const entry of entries)if(!entry.isShared)project(u,entry.projectId);
 const saved=[];
 for(const [i,entry] of entries.entries()){
  try{saved.push(await createExpense({...entry,id:hash(u.enterprise_id+'|expense-row|'+entry.id),bulkSubmissionId:submissionId,paidBy:u.name,approvalStatus:'approved'}));}
  catch(error){error.message='Row '+(i+1)+': '+error.message+' The entire batch was not saved.';error.fields||={};error.fields['rows.'+i+'.accountId']=error.message;throw error;}
 }
 const result={submissionId,count:saved.length,total:Math.round(saved.reduce((sum,e)=>sum+e.amount,0)*1e6)/1e6,expenseIds:saved.map(e=>e.id)};
 await c.execute('INSERT INTO erp_records(enterprise_id,kind,id,project_id,data) VALUES (?,?,?,?,?)',[u.enterprise_id,'expenseBatch',submissionId,null,JSON.stringify({actorId:u.id,signature,result})]);
 return result;
}

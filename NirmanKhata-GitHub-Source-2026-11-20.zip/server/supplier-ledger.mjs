import {rows} from './database.mjs';
import {assert,id,json,quantity,round,permit,admin,granted,hash} from './core.mjs';
import {getRecord,putRecord,audit} from './records.mjs';
import {supplierLedger} from '../src/lib/supplierLedger.mjs';
const list=async(c,u,kind)=>(await rows(c,'SELECT data,project_id,version FROM erp_records WHERE enterprise_id=? AND kind=? AND archived=0',[u.enterprise_id,kind])).filter(r=>!r.project_id||admin(u)||u.projectIds.includes(r.project_id)).map(r=>({...json(r.data),__version:r.version}));
export async function supplierLedgerRpc(c,u,name,d){
 if(['createSupplierPaymentProofUpload','finalizeSupplierPaymentProof','recordSupplierOrderPayment'].includes(name))assert(false,'Use Paid / Unpaid payment information. Account deductions and payment uploads have been removed.',410);
 if(!['listSupplierOrderLedger','setSupplierOrderPaymentStatus'].includes(name))return null;
 if(name==='listSupplierOrderLedger'){
  permit(u,'purchases.read');const suppliers=await list(c,u,'suppliers'),orders=(await list(c,u,'siteOrders')).filter(o=>!d.projectId||o.projectId===d.projectId),historical=await list(c,u,'supplierOrderPayments'),statuses=await list(c,u,'supplierOrderPaymentStatus'),overridden=new Set(statuses.map(p=>p.orderId)),payments=[...historical.filter(p=>!overridden.has(p.orderId)),...statuses],bills=(await list(c,u,'purchaseBills')).filter(b=>!d.projectId||b.projectId===d.projectId);
  const ledgers=suppliers.map(s=>supplierLedger(s,orders,payments,bills)).filter(s=>!d.projectId||s.orders.length||s.legacy.bills.length);
  for(const s of ledgers)for(const order of s.orders){const state=statuses.find(p=>p.orderId===order.id);order.paidAmount=round(payments.filter(p=>p.orderId===order.id).reduce((n,p)=>n+Number(p.amount||0),0));order.pendingAmount=round(Math.max(0,Number(order.amount)-order.paidAmount));order.paymentStatus=order.paidAmount<=0?'Unpaid':order.pendingAmount===0?'Paid':'Part Paid';order.paymentVersion=state?.__version||0;}
  return {suppliers:ledgers,canPay:granted(u,'purchases.pay')};
 }
 permit(u,'purchases.pay');const order=await getRecord(c,u,'siteOrders',d.orderId,true);assert(['Ordered','Delivered'].includes(order.status)&&order.supplierId,'Select a placed purchase order.');const amount=quantity(d.paidAmount,true);assert(amount<=Number(order.amount),'Paid amount cannot exceed the purchase order amount.');const recordId=hash('supplier-payment-status|'+order.id),prior=(await rows(c,'SELECT data,version FROM erp_records WHERE enterprise_id=? AND kind=? AND id=? FOR UPDATE',[u.enterprise_id,'supplierOrderPaymentStatus',recordId]))[0];assert(Number.isSafeInteger(d.version)&&d.version===(prior?.version||0),'Payment information changed in another session. Refresh before updating it.',409);
 const value={id:recordId,projectId:order.projectId,supplierId:order.supplierId,orderId:order.id,amount,status:amount===0?'Unpaid':amount===Number(order.amount)?'Paid':'Part Paid',updatedBy:u.id,updatedAt:new Date().toISOString()};await putRecord(c,u,'supplierOrderPaymentStatus',value,!prior);await audit(c,u,'supplier.payment.informed',order.id,{previous:prior?json(prior.data).amount:null,paidAmount:amount,pendingAmount:round(Number(order.amount)-amount)});return {paidAmount:amount,pendingAmount:round(Number(order.amount)-amount),status:value.status};
}

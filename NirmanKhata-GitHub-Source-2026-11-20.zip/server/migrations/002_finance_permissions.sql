-- Add payment capabilities only to the built-in Accounts template; preserve custom roles and overrides.
UPDATE roles SET permissions=JSON_ARRAY_APPEND(permissions,'$','purchases.pay') WHERE id='accounts' AND system_role=1 AND NOT JSON_CONTAINS(permissions,JSON_QUOTE('purchases.pay'));
UPDATE roles SET permissions=JSON_ARRAY_APPEND(permissions,'$','sales.receive') WHERE id='accounts' AND system_role=1 AND NOT JSON_CONTAINS(permissions,JSON_QUOTE('sales.receive'));
UPDATE roles SET permissions=JSON_ARRAY_APPEND(permissions,'$','subcontractors.pay') WHERE id='accounts' AND system_role=1 AND NOT JSON_CONTAINS(permissions,JSON_QUOTE('subcontractors.pay'));

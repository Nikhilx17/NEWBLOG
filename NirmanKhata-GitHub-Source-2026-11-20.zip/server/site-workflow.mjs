import {searchOrderSuppliers,rememberOrderSupplier} from './order-suppliers.mjs';
import {rows} from './database.mjs';
import {assert,id,text,json,uuid,quantity,date,round,permit,project,admin,granted,hash} from './core.mjs';
import {getRecord,putRecord,audit} from './records.mjs';
import {constructionRpc} from './construction.mjs';
import {orderAccess} from './order-access.mjs';
import {issueUpload,authorizeFile,finalizeUpload} from './files.mjs';
import {orderReminder,driveFolderUrl,normalizedItem,siteDay} from '../src/lib/siteWorkflow.mjs';
const list=async(c,u,kind)=>(await rows(c,'SELECT data,version FROM erp_records WHERE enterprise_id=? AND kind=? AND archived=0',[u.enterprise_id,kind])).map(r=>({...json(r.data),__version:r.version})).filter(r=>!r.projectId||admin(u)||u.projectIds.includes(r.projectId));
export async function siteWorkflowRpc(c,u,name,d){
 if(!['searchOrderSuppliers','allocateSiteDeskWork','listSiteDesk','savePlannedOrder','markSiteOrderOrdered','createDeliveryPhotoUpload','finalizeDeliveryPhotoUpload','receiveSiteOrder','saveSiteFolder','setWorkMaterialPlan'].includes(name))return null;
 if(name==='searchOrderSuppliers')return searchOrderSuppliers(c,u,d.query||'');
 if(name==='listSiteDesk'){
  const ps=(await rows(c,'SELECT id,data FROM project_sites WHERE enterprise_id=? AND archived=0',[u.enterprise_id])).filter(p=>admin(u)||u.projectIds.includes(p.id)).map(p=>({id:p.id,...json(p.data)}));
  const purchase=['purchases.read','purchases.create','purchases.receive'].find(p=>granted(u,p));if(purchase)permit(u,purchase);else{const permission=['siteProgress.submit','siteProgress.read','siteProgress.allocate','siteProgress.review','projects.read'].find(p=>granted(u,p));assert(permission,'Site desk access is not granted.',403);permit(u,permission);}
  const orders=purchase?await list(c,u,'siteOrders'):[],inventory=admin(u)||granted(u,'purchases.create')||granted(u,'inventory.read')?await list(c,u,'inventory'):[];
  const work=['siteProgress.read','siteProgress.allocate','siteProgress.review','siteProgress.submit'].some(p=>granted(u,p))?await constructionRpc(c,u,'listSiteProgressWorkspace',{}):null;
  const reports=work?.reports||[],reserved={};for(const r of reports)for(const v of r.materialUsage||[]){const key=v.itemId;reserved[key]=round((reserved[key]||0)+Math.max(0,v.heldQuantity-v.approvedQuantity));}
  return {projects:ps,orders,reminders:orders.map(o=>orderReminder(o)).filter(Boolean),inventory:inventory.map(item=>({...item,reserved:reserved[item.id]||0})),folders:await list(c,u,'siteFolders'),work,day:siteDay(),approvedMaterialCost:round(reports.reduce((sum,r)=>sum+Number(r.approvedMaterialCost||0),0)),permissions:{order:granted(u,'purchases.create'),receive:granted(u,'purchases.receive'),folders:granted(u,'projects.edit'),allocate:granted(u,'siteProgress.allocate')}};
 }
 if(name==='allocateSiteDeskWork'){assert(false,'Use the Work Assignment screen for scheduled daily activities.',410);
  permit(u,'siteProgress.allocate');let categoryId=d.workItem.categoryId;
  if(!categoryId)categoryId=(await constructionRpc(c,u,'saveSiteProgressCategory',{name:d.categoryName,defaultUnit:d.workItem.unit,subcategories:[]})).categoryId;
  const saved=await constructionRpc(c,u,'saveSiteProgressWorkItem',{workItem:{...d.workItem,categoryId}});
  await siteWorkflowRpc(c,u,'setWorkMaterialPlan',{workItemId:saved.workItemId,materialPlan:d.materialPlan||[]});return saved;
 }
 if(name==='savePlannedOrder'){
  permit(u,'purchases.create');const v=d.order,projectId=id(v.projectId);project(u,projectId);const old=v.id?await getRecord(c,u,'siteOrders',v.id,true):null;assert(!old||old.status==='Not Ordered','An ordered purchase cannot be edited.',409);const order={id:old?.id||uuid(),projectId,name:text(v.name,140),quantity:quantity(v.quantity),unit:text(v.unit,30),amount:quantity(v.amount,true),orderDate:date(v.orderDate),expectedDate:v.expectedDate?date(v.expectedDate):null,supplier:String(v.supplier||'').slice(0,200),status:'Not Ordered',createdBy:u.id};Object.assign(order,await rememberOrderSupplier(c,u,v));order.description=String(v.description||'').slice(0,2000);if(old)order.__version=v.__version;await putRecord(c,u,'siteOrders',order,!old);await audit(c,u,'order.planned',order.id,order);return {orderId:order.id};
 }
 if(name==='markSiteOrderOrdered'){
  permit(u,'purchases.create');const order=await getRecord(c,u,'siteOrders',d.orderId,true);assert(order.status!=='Delivered','This order has already been delivered.',409);if(order.status==='Ordered')return {orderId:order.id};
  const items=await list(c,u,'inventory');let item=items.find(i=>(!i.projectId||i.projectId===order.projectId)&&normalizedItem(i.name)===normalizedItem(order.name)&&normalizedItem(i.unit)===normalizedItem(order.unit));
  if(!item){item={id:hash(order.projectId+'|'+normalizedItem(order.name)+'|'+normalizedItem(order.unit)),name:order.name,projectId:order.projectId,unit:order.unit,category:'Construction Material',currentStock:0,openingStock:0,averagePurchasePrice:0,stockValue:0};await putRecord(c,u,'inventory',item,true);}
  order.itemId=item.id;order.status='Ordered';order.orderedAt=new Date().toISOString();await putRecord(c,u,'siteOrders',order);await audit(c,u,'order.ordered',order.id,{itemId:item.id});return {orderId:order.id,itemId:item.id};
 }
 if(name==='createDeliveryPhotoUpload'){await orderAccess(c,u,d.orderId,true);return issueUpload(c,u,d,'delivery');}
 if(name==='finalizeDeliveryPhotoUpload')return finalizeUpload(c,u,d.documentId);
 if(name==='receiveSiteOrder'){
  const order=await getRecord(c,u,'siteOrders',d.orderId,true);permit(u,'purchases.receive');if(order.status==='Delivered'){assert(order.documentId===d.documentId,'Delivery was already recorded with another receipt.',409);return {orderId:order.id,duplicate:true};}await orderAccess(c,u,order.id,true);
  assert(date(d.deliveryDate)<=siteDay(),'Delivery date cannot be in the future.');const f=await authorizeFile(c,u,d.documentId);assert(f.uploaded_by===u.id&&f.report_token==='delivery:'+order.id&&f.project_id===order.projectId,'Attach this order’s actual delivery receipt.');
  const item=await getRecord(c,u,'inventory',order.itemId,true),stock=round(Number(item.currentStock)+order.quantity),value=round(Number(item.stockValue??item.currentStock*item.averagePurchasePrice)+order.amount);
  await putRecord(c,u,'inventory',{...item,currentStock:stock,averagePurchasePrice:round(value/stock),stockValue:value});await putRecord(c,u,'stockMovements',{id:hash('delivery|'+order.id),itemId:item.id,itemName:item.name,movementType:'purchase_in',quantity:order.quantity,unitCost:round(order.amount/order.quantity),totalValue:order.amount,projectId:order.projectId,date:date(d.deliveryDate),referenceNo:order.id,documentId:f.id,notes:'Delivered against planned purchase order'},true);
  order.status='Delivered';order.documentId=f.id;order.deliveredAt=new Date().toISOString();order.deliveryDate=d.deliveryDate;order.receivedBy=u.name;await putRecord(c,u,'siteOrders',order);await audit(c,u,'order.delivered',order.id,{quantity:order.quantity,documentId:f.id});return {orderId:order.id};
 }
 if(name==='saveSiteFolder'){permit(u,'projects.edit');const projectId=id(d.projectId);project(u,projectId);const folder={id:d.id||uuid(),projectId,title:text(d.title,100),url:driveFolderUrl(d.url)};if(d.id)await getRecord(c,u,'siteFolders',d.id,true);await putRecord(c,u,'siteFolders',folder,!d.id);await audit(c,u,'site.folder.saved',folder.id);return {id:folder.id};}
 if(name==='setWorkMaterialPlan'){permit(u,'siteProgress.allocate');const w=(await rows(c,'SELECT * FROM allocated_work_items WHERE enterprise_id=? AND id=? FOR UPDATE',[u.enterprise_id,id(d.workItemId)]))[0];assert(w,'Work not found.',404);assert(json(w.data).workflowVersion!==3,'Edit daily-task material rules through Work Assignment so history is preserved.',409);project(u,w.project_id);const plan=d.materialPlan;assert(Array.isArray(plan)&&plan.length<=20&&new Set(plan.map(p=>p.itemId)).size===plan.length,'Choose distinct materials.');for(const p of plan){const item=await getRecord(c,u,'inventory',p.itemId);assert(!item.projectId||item.projectId===w.project_id,'Choose a material for this site.');quantity(p.perWorkUnit);}const value={...json(w.data),materialPlan:plan.map(p=>({itemId:id(p.itemId),perWorkUnit:quantity(p.perWorkUnit)}))};await c.execute('UPDATE allocated_work_items SET data=? WHERE enterprise_id=? AND id=?',[JSON.stringify(value),u.enterprise_id,w.id]);await audit(c,u,'work.materials.linked',w.id,{materialPlan:value.materialPlan});return {updated:true};}
}

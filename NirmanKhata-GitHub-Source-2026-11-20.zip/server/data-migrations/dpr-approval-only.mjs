import {rows} from '../database.mjs';
import {assert,admin,json,hash,round} from '../core.mjs';
import {getRecord,putRecord,audit} from '../records.mjs';
import {createBackup} from '../backup.mjs';
// Run within the existing enterprise transaction/lock. No historical report is deleted.
// An encrypted database+file backup is mandatory and is created before any release.
export async function migrateDprApprovalOnly(c,u){
 assert(admin(u),'Enterprise admin access is required.',403);
 const reports=(await rows(c,'SELECT * FROM daily_progress_reports WHERE enterprise_id=? FOR UPDATE',[u.enterprise_id])).filter(r=>{const d=json(r.data);return d.workflowVersion!==3&&(d.materialUsage||[]).some(m=>Number(m.heldQuantity)>Number(m.approvedQuantity||0));});
 if(!reports.length)return {migrated:0,backupId:null};
 const backup=await createBackup(c,u);let released=0;
 for(const report of reports){const data=json(report.data),before=structuredClone(data);for(const usage of data.materialUsage||[]){const q=round(Number(usage.heldQuantity||0)-Number(usage.approvedQuantity||0));if(q<=0)continue;const item=await getRecord(c,u,'inventory',usage.itemId,true),stock=round(Number(item.currentStock)+q),value=round(Number(item.stockValue??item.currentStock*item.averagePurchasePrice)+q*Number(usage.unitCost||0));await putRecord(c,u,'inventory',{...item,currentStock:stock,stockValue:value,averagePurchasePrice:stock?round(value/stock):item.averagePurchasePrice});usage.heldQuantity=Number(usage.approvedQuantity||0);released++;await putRecord(c,u,'stockMovements',{id:hash('dpr-approval-only|'+report.id+'|'+item.id),projectId:data.projectId,itemId:item.id,itemName:item.name,reportId:report.id,movementType:'reservation_release',quantity:q,unitCost:Number(usage.unitCost||0),totalValue:round(q*Number(usage.unitCost||0)),notes:'Policy migration: release unapproved DPR reservation; approved consumption retained.'},true);}
  data.stockPolicy='Approval Only';await putRecord(c,u,'dprPolicyMigration',{id:hash('dpr-policy|'+report.id),projectId:data.projectId,reportId:report.id,backupId:backup.backupId,before,after:data},true);await c.execute('UPDATE daily_progress_reports SET data=? WHERE enterprise_id=? AND id=?',[JSON.stringify(data),u.enterprise_id,report.id]);
 }
 await audit(c,u,'daily.dpr.approval-only.migrated',null,{reports:reports.length,releasedMaterialRows:released,backupId:backup.backupId});return {migrated:reports.length,releasedMaterialRows:released,backupId:backup.backupId};
}

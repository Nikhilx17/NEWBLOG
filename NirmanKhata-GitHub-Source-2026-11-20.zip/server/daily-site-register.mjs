import {rows} from './database.mjs';
import {assert,id,json,hash,permit,project,admin,granted} from './core.mjs';
import {audit} from './records.mjs';
import {buildRegisterCatalog,validateRegisterCatalog,prepareCompactRegister,isCement} from '../src/lib/compactSiteRegister.mjs';
import {normalizeRegisterEntry,withCementBalances} from '../src/lib/dailySiteRegister.mjs';
import {MASTER_TYPES,normalizeMasterName,collectRegisterMasters,toDynamicRegister,withMaterialBalances,validateDynamicRegister,rankMasterSuggestions} from '../src/lib/dynamicSiteRegister.mjs';

const kind='dailySiteRegister',masterKind='dailyRegisterMaster';
function access(u,write=false){
  assert(u.subscription.modules.includes('*')||u.subscription.modules.includes('projects'),'This module is not enabled by your enterprise license.',403);
  const permission=(write?['projects.edit','siteProgress.submit']:['projects.read','siteProgress.submit']).find(p=>granted(u,p));
  assert(permission,'You do not have permission for this register action.',403);permit(u,permission);
}
function canEdit(u){try{access(u,true);return true}catch{return false}}
async function remember(c,u,projectId,entry){
  for(const master of collectRegisterMasters(entry)){
    const masterId=hash(projectId+'|'+master.type+'|'+master.normalizedName);
    await c.execute('INSERT IGNORE INTO erp_records(enterprise_id,kind,id,project_id,data) VALUES (?,?,?,?,?)',[u.enterprise_id,masterKind,masterId,projectId,JSON.stringify({...master,id:masterId,projectId,businessId:u.enterprise_id})]);
  }
}
async function suggestions(c,u,projectId,data){
  assert(MASTER_TYPES.includes(data.type),'Invalid reusable entry type.');
  assert(typeof (data.query??'')==='string'&&(data.query??'').length<=160,'Search text is too long.');
  const q=normalizeMasterName(data.query),norm="JSON_UNQUOTE(JSON_EXTRACT(data,'$.normalizedName'))";
  const masters=await rows(c,`SELECT data FROM erp_records WHERE enterprise_id=? AND kind=? AND project_id=? AND archived=0 AND JSON_UNQUOTE(JSON_EXTRACT(data,'$.type'))=? AND LOCATE(?,${norm})>0 ORDER BY CASE WHEN ${norm}=? THEN 0 WHEN LEFT(${norm},CHAR_LENGTH(?))=? THEN 1 WHEN LOCATE(CONCAT(' ',?),${norm})>0 THEN 2 ELSE 3 END,id LIMIT 20`,[u.enterprise_id,masterKind,projectId,data.type,q,q,q,q,q]);
  // Legacy register values remain discoverable without modifying historical rows on read.
  const legacy=await rows(c,"SELECT data FROM erp_records WHERE enterprise_id=? AND kind=? AND project_id=? AND archived=0 AND JSON_EXTRACT(data,'$.schemaVersion') IS NULL",[u.enterprise_id,kind,projectId]);
  const values=[...masters.map(row=>({...json(row.data),source:'master'})),...legacy.flatMap(row=>collectRegisterMasters(toDynamicRegister(json(row.data))).filter(m=>m.type===data.type).map(m=>({...m,source:'history'})))];
  // Reuse inventory names only where the existing inventory permission allows it.
  if(data.type==='material'){
    let inventoryAllowed=false;try{permit(u,'inventory.read');inventoryAllowed=true}catch{}
    if(inventoryAllowed){
      const inventory=await rows(c,"SELECT data FROM erp_records WHERE enterprise_id=? AND kind='inventory' AND archived=0 AND (project_id IS NULL OR project_id=?) AND LOCATE(?,LOWER(JSON_UNQUOTE(JSON_EXTRACT(data,'$.name'))))>0 LIMIT 20",[u.enterprise_id,projectId,q]);
      values.push(...inventory.map(row=>{const item=json(row.data);return {name:item.name,defaultUnit:item.unit||'',source:'inventory'};}));
    }
  }
  const found=rankMasterSuggestions(values,q);
  return {suggestions:found.map(m=>({name:m.name,defaultUnit:m.defaultUnit||'',source:m.source})),canCreate:canEdit(u)&&Boolean(q)&&!found.some(m=>normalizeMasterName(m.name)===q)};
}
export async function dailySiteRegisterRpc(c,u,name,data) {
  if (!['getDailySiteRegister','saveDailySiteRegister','searchDailyRegisterMasters','saveCompactDailyRegister'].includes(name)) return null;
  access(u,name==='saveDailySiteRegister'||name==='saveCompactDailyRegister');
  const projects=(await rows(c,'SELECT id,data FROM project_sites WHERE enterprise_id=? AND archived=0',[u.enterprise_id]))
    .filter(p=>admin(u)||u.projectIds.includes(p.id)).map(p=>({id:p.id,name:json(p.data).name}));
  if (!data.projectId && name==='getDailySiteRegister') return {projects,entries:[],canEdit:canEdit(u)};
  const projectId=id(data.projectId);project(u,projectId);
  assert(projects.some(p=>p.id===projectId),'Project not found.',404);
  if(name==='searchDailyRegisterMasters')return suggestions(c,u,projectId,data);
  if(name==='saveCompactDailyRegister'){
    const date=normalizeRegisterEntry({date:data.entry?.date}).date,recordId=hash(projectId+'|'+date),setupId=hash(projectId+'|daily-register-setup');
    const previous=await rows(c,'SELECT version,data FROM erp_records WHERE enterprise_id=? AND kind=? AND id=? FOR UPDATE',[u.enterprise_id,kind,recordId]);
    assert(Number.isSafeInteger(data.version)&&data.version>=0&&(previous[0]?.version||0)===data.version,'This date changed in another session. Your input is kept; reload the saved date before retrying.',409);
    const historical=previous[0]?toDynamicRegister(json(previous[0].data)):{progress:[],customSections:[],ledger:[]};
    assert(Array.isArray(data.entry?.ledger??[]),'Invalid cement rows.');
    const prepared=prepareCompactRegister({...data.entry,progress:historical.progress,customSections:historical.customSections,ledger:[...historical.ledger.filter(row=>!isCement(row.name)),...(data.entry.ledger||[]).filter(row=>row&&isCement(row.name))]}),entry=prepared.entry;
    let catalogSaved=false;
    if(data.catalog){
      const catalog=validateRegisterCatalog(data.catalog),prior=await rows(c,'SELECT version,data FROM erp_records WHERE enterprise_id=? AND kind=? AND id=? FOR UPDATE',[u.enterprise_id,'dailyRegisterSetup',setupId]);
      if(!prior.length||JSON.stringify(json(prior[0].data))!==JSON.stringify(catalog)){
        assert(Number.isSafeInteger(data.catalogVersion)&&(prior[0]?.version||0)===data.catalogVersion,'The site item list changed in another session. Your input is kept; reload before changing the list.',409);
        const payload=JSON.stringify(catalog);
        if(prior.length)await c.execute('UPDATE erp_records SET data=?,version=version+1,updated_at=UTC_TIMESTAMP(3) WHERE enterprise_id=? AND kind=? AND id=?',[payload,u.enterprise_id,'dailyRegisterSetup',setupId]);
        else await c.execute('INSERT INTO erp_records(enterprise_id,kind,id,project_id,data) VALUES (?,?,?,?,?)',[u.enterprise_id,'dailyRegisterSetup',setupId,projectId,payload]);
        await remember(c,u,projectId,{materials:catalog.materials,equipment:catalog.equipment,labour:catalog.labour,utilities:[],ledger:[],progress:[],customSections:[]});catalogSaved=true;
      }
    }
    assert(!prepared.empty||catalogSaved,'Enter a quantity, machinery session, cement movement or labour count before saving.');
    if(!prepared.empty){
      await remember(c,u,projectId,entry);const payload=JSON.stringify({...entry,id:recordId,projectId,businessId:u.enterprise_id});
      if(previous.length)await c.execute('UPDATE erp_records SET data=?,version=version+1,updated_at=UTC_TIMESTAMP(3) WHERE enterprise_id=? AND kind=? AND id=?',[payload,u.enterprise_id,kind,recordId]);
      else await c.execute('INSERT INTO erp_records(enterprise_id,kind,id,project_id,data) VALUES (?,?,?,?,?)',[u.enterprise_id,kind,recordId,projectId,payload]);
    }
    await audit(c,u,'dailySiteRegister.saved',recordId,{projectId,date:entry.date,catalogSaved,dailyEntrySaved:!prepared.empty});
    const workspace=await dailySiteRegisterRpc(c,u,'getDailySiteRegister',{projectId,compact:true});
    return {...workspace,notice:prepared.empty?'Item names saved. No blank daily records were created.':'Daily register saved.'};
  }

  if (name==='saveDailySiteRegister') {
    const entry=data.entry?.schemaVersion===2&&!data.entry.legacy?validateDynamicRegister(data.entry):normalizeRegisterEntry(data.entry),recordId=hash(projectId+'|'+entry.date);
    assert(Number.isSafeInteger(data.version)&&data.version>=0,'Reload the entry before saving.');
    const previous=await rows(c,'SELECT version,data FROM erp_records WHERE enterprise_id=? AND kind=? AND id=? FOR UPDATE',[u.enterprise_id,kind,recordId]);
    assert((previous[0]?.version||0)===data.version,'This date changed in another session. Your entries are preserved; reload the saved date before retrying.',409);
    assert(!previous[0]||json(previous[0].data)?.schemaVersion!==2||entry.schemaVersion===2,'This date uses dynamic rows. Refresh the application before editing it; the saved rows were not changed.',409);
    // Validation and stale-version checks precede master creation. The caller wraps all writes in one transaction.
    if(entry.schemaVersion===2)await remember(c,u,projectId,entry);
    const payload=JSON.stringify({...entry,id:recordId,projectId,businessId:u.enterprise_id});
    if (previous.length) await c.execute('UPDATE erp_records SET data=?,version=version+1,updated_at=UTC_TIMESTAMP(3) WHERE enterprise_id=? AND kind=? AND id=?',[payload,u.enterprise_id,kind,recordId]);
    else await c.execute('INSERT INTO erp_records(enterprise_id,kind,id,project_id,data) VALUES (?,?,?,?,?)',[u.enterprise_id,kind,recordId,projectId,payload]);
    await audit(c,u,previous.length?'dailySiteRegister.updated':'dailySiteRegister.created',recordId,{projectId,date:entry.date,schemaVersion:entry.schemaVersion||1});
  }
  const records=await rows(c,'SELECT data,version FROM erp_records WHERE enterprise_id=? AND kind=? AND project_id=? AND archived=0',[u.enterprise_id,kind,projectId]);
  const entries=withCementBalances(records.map(row=>({...json(row.data),version:row.version})));
  const result={projects,entries:withMaterialBalances(entries),canEdit:canEdit(u)};
  if(data.compact){
    const setup=await rows(c,'SELECT data,version FROM erp_records WHERE enterprise_id=? AND kind=? AND project_id=? AND archived=0',[u.enterprise_id,'dailyRegisterSetup',projectId]);
    const masters=await rows(c,'SELECT data,version FROM erp_records WHERE enterprise_id=? AND kind=? AND project_id=? AND archived=0',[u.enterprise_id,masterKind,projectId]);
    return {...result,catalog:buildRegisterCatalog(result.entries,masters.map(row=>json(row.data)),setup[0]?json(setup[0].data):null),catalogVersion:setup[0]?.version||0};
  }
  return result;
}

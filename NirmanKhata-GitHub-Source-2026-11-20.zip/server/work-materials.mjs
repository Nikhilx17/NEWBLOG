import {assert,quantity,round,uuid,json} from './core.mjs';
import {getRecord,putRecord,audit} from './records.mjs';
export async function reserveWorkMaterials(c,u,w,q,reportId){
 const plan=json(w.data).materialPlan||[],usage=[];
 for(const rule of [...plan].sort((a,b)=>a.itemId.localeCompare(b.itemId))){
  const item=await getRecord(c,u,'inventory',rule.itemId,true),used=round(quantity(rule.perWorkUnit)*q),cost=Number(item.averagePurchasePrice||0);
  assert(!item.projectId||item.projectId===w.project_id,'Material belongs to another site.',403);assert(Number(item.currentStock)>=used,'Not enough available '+item.name+' for this report.',409);
  await putRecord(c,u,'inventory',{...item,currentStock:round(item.currentStock-used),stockValue:round((item.currentStock-used)*cost)});
  usage.push({itemId:item.id,name:item.name,unit:item.unit,perWorkUnit:rule.perWorkUnit,reportedQuantity:used,heldQuantity:used,approvedQuantity:0,unitCost:cost,approvedCost:0});
  await putRecord(c,u,'stockMovements',{id:uuid(),itemId:item.id,itemName:item.name,movementType:'work_reservation',quantity:used,unitCost:cost,totalValue:round(used*cost),projectId:w.project_id,date:new Date().toISOString().slice(0,10),reportId,notes:'Reserved pending DPR approval; not yet approved consumption.'},true);
 }
 return usage;
}
export async function reconcileWorkMaterials(c,u,report,status,approvedQty,data){
 for(const usage of data.materialUsage||[]){
  const desired=round((status==='Approved'?approvedQty:['Under Review','Pending Review'].includes(status)?Number(report.quantity):0)*usage.perWorkUnit),delta=round(desired-usage.heldQuantity),approved=round((status==='Approved'?approvedQty:0)*usage.perWorkUnit),oldApproved=Number(usage.approvedQuantity||0);
  if(delta){const item=await getRecord(c,u,'inventory',usage.itemId,true),available=round(Number(item.currentStock)-delta);assert(available>=0,'Not enough stock to approve this corrected report.',409);const value=round(Number(item.stockValue??Number(item.currentStock)*Number(item.averagePurchasePrice||0))-delta*usage.unitCost),average=available?round(value/available):Number(item.averagePurchasePrice||0);await putRecord(c,u,'inventory',{...item,currentStock:available,stockValue:value,averagePurchasePrice:average});}
  if(delta||approved!==oldApproved)await putRecord(c,u,'stockMovements',{id:uuid(),itemId:usage.itemId,itemName:usage.name,projectId:data.projectId,reportId:report.id,date:new Date().toISOString().slice(0,10),movementType:'dpr_reconciliation',quantity:Math.abs(delta),stockDelta:-delta,approvedQuantityDelta:round(approved-oldApproved),unitCost:usage.unitCost,totalValue:round((approved-oldApproved)*usage.unitCost),notes:'DPR '+status+'; available stock changes only by stockDelta.'},true);
  usage.heldQuantity=desired;usage.approvedQuantity=approved;usage.approvedCost=round(approved*usage.unitCost);
 }
 data.approvedMaterialCost=round((data.materialUsage||[]).reduce((sum,r)=>sum+r.approvedCost,0));
}

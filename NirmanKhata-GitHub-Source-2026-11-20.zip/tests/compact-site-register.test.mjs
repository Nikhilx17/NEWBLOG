import test from 'node:test';
import assert from 'node:assert/strict';
import {buildRegisterCatalog,compactDraft,prepareCompactRegister,machineryTotals,cementRegisterRows,validateRegisterCatalog} from '../src/lib/compactSiteRegister.mjs';
import {emptyDynamicRegister,withMaterialBalances} from '../src/lib/dynamicSiteRegister.mjs';

test('reference items are editable templates with no invented ambiguous units',()=>{
 const catalog=buildRegisterCatalog([]);assert.equal(catalog.materials.length,6);assert.equal(catalog.materials.find(r=>r.name==='Cement').unit,'');assert.equal(catalog.materials.find(r=>r.name==='Pani Ki Tanki').unit,'');assert.deepEqual(catalog.labour.map(r=>r.name),['Mistri','Helper']);assert.equal(catalog.equipment[0].name,'JCB');
 const custom={materials:[{id:'custom',name:'Fly Ash',unit:'Ton'}],equipment:[],labour:[]};assert.deepEqual(buildRegisterCatalog([],[],custom),custom);
});
test('saved spelling and units survive templates; new dates never carry daily quantities',()=>{
 const old={...emptyDynamicRegister('2026-11-17'),materials:[{id:'m',name:'Tanker',quantity:2,unit:'Trip',remarks:'detail'}]};const catalog=buildRegisterCatalog([old]);assert.equal(catalog.materials.filter(r=>/tanker|tankar/i.test(r.name)).length,1);assert.equal(catalog.materials[0].unit,'Trip');const draft=compactDraft(undefined,'2026-11-18',catalog,[old]);assert.ok(draft.materials.every(r=>r.quantity===''));assert.equal(prepareCompactRegister(draft).empty,true);
});
test('blank rows omitted; zero retained; validation maps back to the displayed row',()=>{
 const draft=compactDraft(undefined,'2026-11-20',buildRegisterCatalog([]));draft.materials[2].quantity=0;let value=prepareCompactRegister(draft);assert.equal(value.entry.materials.length,1);assert.equal(value.entry.materials[0].name,'Dust');draft.materials[2].quantity=-2;assert.throws(()=>prepareCompactRegister(draft),e=>Boolean(e.fields['materials.2.quantity']));
 draft.materials[2].quantity='';draft.materials[3].quantity=5;draft.materials[3]._origin='utilities';assert.throws(()=>prepareCompactRegister(draft),e=>Boolean(e.fields['materials.3.unit']));
});
test('multiple machinery sessions total 5h30m and overnight sessions work',()=>{
 const equipment=[{id:'a',name:'JCB',startTime:'10:30',endTime:'13:00'},{id:'b',name:'JCB',startTime:'14:20',endTime:'17:20'},{id:'c',name:'Hydra Crane',category:'Lifting',startTime:'23:30',endTime:'01:00'}];const value=prepareCompactRegister({...emptyDynamicRegister('2026-11-20'),equipment}).entry;assert.equal(machineryTotals(value.equipment)[0].minutes,330);assert.equal(value.equipment[2].durationMinutes,90);assert.equal(value.equipment[2].category,'Lifting');
});
test('cement carries forward and recalculates after past edits without counting material quantities',()=>{
 const day=(date,credit,debit)=>({...emptyDynamicRegister(date),materials:[{id:'m',name:'Cement',quantity:999,unit:'Bags'}],ledger:[{id:'c',name:'Cement',credit,debit,unit:'Bags'}]});const first=day('2026-11-18',100,27),second=day('2026-11-19',0,13);assert.deepEqual(cementRegisterRows(withMaterialBalances([second,first])).map(r=>r.balance),[73,60]);first.ledger[0].credit=120;assert.deepEqual(cementRegisterRows(withMaterialBalances([first,second])).map(r=>r.balance),[93,80]);
});
test('normalized duplicate templates rejected; labour must be whole counts',()=>{
 assert.throws(()=>validateRegisterCatalog({materials:[{id:'a',name:' Cement ',unit:'Bags'},{id:'b',name:'CEMENT',unit:'bags'}],equipment:[],labour:[]}),/Check/);assert.throws(()=>prepareCompactRegister({...emptyDynamicRegister('2026-11-20'),labour:[{id:'l',name:'Mistri',workers:1.5}]}),/whole number/);
});


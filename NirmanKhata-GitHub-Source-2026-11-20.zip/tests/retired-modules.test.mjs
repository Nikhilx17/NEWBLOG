import test from 'node:test';import assert from 'node:assert/strict';
import {allowedTabs} from '../server/core.mjs';import {command} from '../server/records.mjs';
import {RETIRED_TABS,RETIRED_COMMANDS} from '../src/lib/retiredModules.mjs';
test('retired modules are absent even for enterprise admin while operational modules remain',()=>{const tabs=allowedTabs({role_id:'admin_editor',permissions:[],subscription:{modules:['*']}}).map(t=>t.id);for(const tab of RETIRED_TABS)assert.equal(tabs.includes(tab),false);for(const tab of ['site-desk','work-assignment','dpr-approvals','inventory','expenses','daily-site-register','purchases','projects'])assert.ok(tabs.includes(tab));});
test('retired standalone writes return Gone without touching the database',async()=>{const c={execute(){throw Error('No database mutation expected')}};for(const name of RETIRED_COMMANDS)await assert.rejects(command(c,{role_id:'admin_editor'},name,[]),error=>error.status===410);});

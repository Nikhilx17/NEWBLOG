import test from 'node:test';
import assert from 'node:assert/strict';
import {unzipSync,strFromU8} from 'fflate';
import {buildExcelBytes,buildCSV} from '../src/lib/exportUtils.ts';
test('Excel export remains a valid XLSX package and escapes text without executable formulas',()=>{const files=unzipSync(buildExcelBytes([{Name:'A & B <Company>',Amount:12,Value:'=HYPERLINK("bad")'}],'Site/Report'));assert.ok(files['[Content_Types].xml']);const sheet=strFromU8(files['xl/worksheets/sheet1.xml']);assert.ok(sheet.includes('&amp;'));assert.ok(sheet.includes('&lt;Company&gt;'));assert.ok(sheet.includes('<v>12</v>'));assert.equal(sheet.includes('<f>'),false)});
test('CSV export neutralizes spreadsheet formula injection and retains real row breaks',()=>{const csv=buildCSV([{Name:'=1+1',Amount:-12},{Name:'Other',Amount:20}]);assert.equal(csv.charCodeAt(0),65279);assert.ok(csv.includes("'=1+1"));assert.ok(csv.includes('\r\n'));assert.ok(csv.includes('"-12"'))});

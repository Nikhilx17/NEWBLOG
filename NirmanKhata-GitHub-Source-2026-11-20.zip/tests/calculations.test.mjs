import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateProjectIncurredCost,
  calculateProjectMaterialCost,
  calculateWorkingCapital,
  safePercentage,
} from '../src/lib/calculations.ts';

test('material cost uses taxable amount for recoverable GST and excludes rejected bills', () => {
  const bills = [
    { projectId: 'p1', approvalStatus: 'approved', isGstRecoverable: true, taxableAmount: 1000, totalAmount: 1180 },
    { projectId: 'p1', approvalStatus: 'pending', isGstRecoverable: false, totalAmount: 500 },
    { projectId: 'p1', approvalStatus: 'rejected', isGstRecoverable: false, totalAmount: 900 },
    { projectId: 'p2', approvalStatus: 'approved', isGstRecoverable: false, totalAmount: 700 },
  ];
  assert.equal(calculateProjectMaterialCost('p1', bills), 1500);
});

test('project incurred cost preserves category totals and rounds the combined total', () => {
  const result = calculateProjectIncurredCost(
    'p1',
    [{ projectId: 'p1', approvalStatus: 'approved', isGstRecoverable: false, totalAmount: 100.25 }],
    [{ projectId: 'p1', approvalStatus: 'approved', amount: 20.1 }],
    [{ projectId: 'p1', supervisorApproved: true, dailyWageEarned: 30.2 }],
    [{ projectId: 'p1', approvalStatus: 'approved', grossAmount: 40.15 }],
  );
  assert.deepEqual(result, {
    materialCost: 100.25,
    labourCost: 30.2,
    expensesCost: 20.1,
    subcontractorCost: 40.15,
    totalIncurredCost: 190.7,
  });
});

test('safe percentage and working capital guard zero liabilities', () => {
  assert.equal(safePercentage(12, 0), 0);
  assert.deepEqual(calculateWorkingCapital(100, 25, 0, 0), {
    workingCapital: 125,
    quickRatio: 99,
    isHealthy: true,
  });
});

import assert from 'node:assert/strict';
import vm from 'node:vm';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createRequire} from 'node:module';
const require=createRequire(new URL('../../functions/lib/index.js',import.meta.url));
export function harness(){
 const records=new Map(),objects=new Map(),authUsers=new Map();let sequence=0;
 const snapshot=path=>({id:path.split('/').at(-1),ref:doc(path),exists:records.has(path),get:key=>key.split('.').reduce((v,k)=>v?.[k],records.get(path)),data:()=>records.get(path)});
 const put=(path,data,merge=false)=>records.set(path,merge?{...records.get(path),...data}:data);
 function doc(path){return {path,id:path.split('/').at(-1),get:async()=>snapshot(path),create:async data=>{assert.ok(!records.has(path));put(path,data)},set:async(data,opts)=>put(path,data,opts?.merge),update:async data=>put(path,data,true)}}
 function collection(path,filters=[],count=Infinity,sort=null,after=null){return {doc:(id='generated'+(++sequence))=>doc(path+'/'+id),where:(k,op,v)=>collection(path,[...filters,[k,v]],count,sort,after),limit:n=>collection(path,filters,n,sort,after),orderBy:(k,d)=>collection(path,filters,count,[k,d],after),startAfter:s=>collection(path,filters,count,sort,typeof s==='string'?s:s.id),get:async()=>{let docs=[...records.keys()].filter(k=>k.startsWith(path+'/')&&k.slice(path.length+1).indexOf('/')<0).map(snapshot).filter(s=>filters.every(([k,v])=>s.get(k)===v));if(sort)docs.sort((a,b)=>String(a.get(sort[0])).localeCompare(String(b.get(sort[0])))*(sort[1]==='desc'?-1:1));if(after)docs=docs.slice(docs.findIndex(d=>d.id===after)+1);docs=docs.slice(0,count);return {docs,empty:docs.length===0}}}}
 const db={doc,collection,runTransaction:async fn=>{const writes=[];let writing=false;const result=await fn({get:async ref=>{assert.equal(writing,false,'Firestore requires every read before writes');return ref.get()},create:(r,d)=>{writing=true;writes.push(()=>r.create(d))},set:(r,d,o)=>{writing=true;writes.push(()=>r.set(d,o))},update:(r,d)=>{writing=true;writes.push(()=>r.update(d))},delete:r=>{writing=true;writes.push(()=>records.delete(r.path))}});for(const write of writes)await write();return result}};
 class HttpsError extends Error{constructor(code,msg){super(msg);this.code=code}}
 const auth={createUser:async data=>{if(authUsers.has(data.uid)||[...authUsers.values()].some(u=>u.email===data.email)){const e=new Error('Account already exists');e.code='auth/uid-already-exists';throw e;}authUsers.set(data.uid,{...data,password:'[managed by auth service]'});return {uid:data.uid}},getUser:async uid=>authUsers.get(uid)||{displayName:uid,email:uid+'@test.invalid'},updateUser:async(uid,data)=>{const old=authUsers.get(uid)||{uid};authUsers.set(uid,{...old,...data,...(data.password?{password:'[managed by auth service]'}:{})});return authUsers.get(uid)},setCustomUserClaims:async(uid,claims)=>{const old=authUsers.get(uid)||{uid};authUsers.set(uid,{...old,customClaims:claims})},revokeRefreshTokens:async uid=>{const old=authUsers.get(uid)||{uid};authUsers.set(uid,{...old,revoked:true})},deleteUser:async uid=>authUsers.delete(uid)};
 const mocks={
 'firebase-admin/app':{initializeApp(){}},'firebase-admin/firestore':{getFirestore:()=>db,FieldValue:{serverTimestamp:()=>({toDate:()=>new Date('2026-11-19T05:00:00Z')})}},
 'firebase-admin/auth':{getAuth:()=>auth},
 'firebase-admin/storage':{getStorage:()=>({bucket:()=>({file:path=>({getSignedUrl:async()=>['https://test.invalid/'+path],getMetadata:async()=>[objects.get(path)?.meta],download:async()=>[objects.get(path)?.bytes],delete:async()=>objects.delete(path)})})})},
 'firebase-functions/params':{defineSecret:()=>({value:()=>''})},'firebase-functions/v2/https':{HttpsError,onCall:(_opts,handler)=>handler,onRequest:()=>()=>{}}
 };
 const cache=new Map();
 function loadModule(filename){if(cache.has(filename))return cache.get(filename);const exports={};cache.set(filename,exports);vm.runInNewContext(fs.readFileSync(filename,'utf8'),{exports,require:name=>mocks[name]||(name.startsWith('.')?loadModule(path.resolve(path.dirname(filename),name)):require(name)),process:{env:{...process.env,PLATFORM_ADMIN_UIDS:'platform'}},Buffer,console,Date,Set,Map});return exports;}
 const exports=loadModule(fileURLToPath(new URL('../../functions/lib/index.js',import.meta.url)));
 const seed=(path,data)=>put('tenants/A/'+path,data);
 seed('members/admin',{role:'owner',status:'active'});seed('members/supervisor',{role:'site_supervisor',status:'active'});seed('members/other',{role:'site_supervisor',status:'active'});seed('members/manager',{role:'site_manager',status:'active',siteProgressAccess:{projectIds:['project'],permissionLevel:'read'}});
 put('tenants/A',{profile:{name:'Enterprise A'},status:'active',subscription:{status:'active',employeeLimit:-1,modules:['*']}});
 const call=(name,uid,data={},token)=>exports[name]({auth:uid?{uid,token:token||{auth_time:Math.floor(Date.now()/1000),...authUsers.get(uid)?.customClaims}}:undefined,data:{tenantId:'A',...data}});
 return {records,objects,seed,call,authUsers};
}
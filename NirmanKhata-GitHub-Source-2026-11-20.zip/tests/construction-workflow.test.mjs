import {harness} from './helpers/serviceHarness.mjs';
import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import fs from 'node:fs';
import {createRequire} from 'node:module';
const require=createRequire(new URL('../functions/lib/index.js',import.meta.url));
// Runs the compiled production callable handlers. Firestore/Auth/Storage are test doubles;
// this suite does not claim emulator, browser, real-photo or deployed-cloud coverage.

async function setup(){const h=harness();await h.call('initializeConstructionWorkflow','admin');await h.call('saveConstructionProject','admin',{id:'project',name:'Project A'});const {categoryId}=await h.call('saveSiteProgressCategory','admin',{name:'Tile Installation',defaultUnit:'sq ft',projectIds:[],memberUids:[]});const {workItemId}=await h.call('saveSiteProgressWorkItem','admin',{workItem:{id:'',projectId:'project',categoryId,name:'Ground Floor Tile Installation',targetQuantity:100,unit:'sq ft',assignedToUids:['supervisor'],status:'In Progress'}});return {...h,categoryId,workItemId}}
async function report(h,id,quantity,date='2026-11-19'){
 const photoIds=[id+'photo1',id+'photo2'];for(const photoId of photoIds)h.seed('siteProgressPhotos/'+photoId,{tenantId:'A',status:'active',createdBy:'supervisor',reportId:id,workItemId:h.workItemId,categoryId:h.categoryId,projectId:'project',objectPath:photoId,fileName:photoId+'.jpg',contentType:'image/jpeg'});
 const payload={id,workItemId:h.workItemId,quantity,description:'Completed ground-floor living area',workDate:date,photoIds};await h.call('submitSiteProgressReport','supervisor',{report:payload});return payload;
}
test('production handlers: 100 target, two photos, 12 then 20, reload and isolated access',async()=>{
 const h=await setup();let workspace=await h.call('listSiteProgressWorkspace','supervisor');assert.equal(workspace.workItems.length,1);assert.equal(workspace.permissions.manage,false);
 const payload=await report(h,'day1',12);workspace=await h.call('listSiteProgressWorkspace','admin');assert.equal(workspace.reports[0].photoIds.length,2);assert.equal(workspace.reports[0].status,'Pending Review');assert.equal(workspace.workItems[0].approvedQuantity,0);
 const access=await h.call('getSiteProgressPhotoAccess','admin',{reportId:'day1',photoId:payload.photoIds[0]});assert.match(access.url,/test.invalid/);
 let result=await h.call('reviewSiteProgressReport','admin',{reportId:'day1',status:'Approved',approvedQuantity:12});assert.equal(result.totalApproved,12);assert.equal(result.remainingQuantity,88);
 await h.call('submitSiteProgressReport','supervisor',{report:payload});await h.call('reviewSiteProgressReport','admin',{reportId:'day1',status:'Approved',approvedQuantity:12});
 await report(h,'day2',20,'2026-11-20');await h.call('reviewSiteProgressReport','admin',{reportId:'day2',status:'Approved',approvedQuantity:20});
 workspace=await h.call('listSiteProgressWorkspace','supervisor');assert.equal(workspace.workItems[0].approvedQuantity,32);assert.equal(workspace.workItems[0].remainingQuantity,68);assert.equal(workspace.workItems[0].completionPercent,32);
 assert.equal((await h.call('listSiteProgressWorkspace','other')).workItems.length,0);
 await assert.rejects(h.call('getSiteProgressPhotoAccess','other',{reportId:'day1',photoId:payload.photoIds[0]}));await assert.rejects(h.call('listSiteProgressWorkspace','admin',{tenantId:'B'}));
 const manager=await h.call('listSiteProgressWorkspace','manager');assert.equal(manager.permissions.allocate,false);assert.equal(manager.permissions.review,false);assert.equal(manager.permissions.submit,false);assert.equal(manager.workItems.length,1);
 await assert.rejects(h.call('reviewSiteProgressReport','manager',{reportId:'day1',status:'Approved'}));
 const history=await h.call('listConstructionWorkHistory','admin',{workItemId:h.workItemId});assert.equal(history.reports.length,2);
});
test('corrections, zero approved quantity, rejection and excess quantities preserve totals',async()=>{
 const h=await setup();await report(h,'day1',12);await h.call('reviewSiteProgressReport','admin',{reportId:'day1',status:'Approved',approvedQuantity:12});await h.call('reviewSiteProgressReport','admin',{reportId:'day1',status:'Approved',approvedQuantity:0});let result=await h.call('reviewSiteProgressReport','admin',{reportId:'day1',status:'Approved',approvedQuantity:5});assert.equal(result.totalApproved,5);
 result=await h.call('reviewSiteProgressReport','admin',{reportId:'day1',status:'Rejected'});assert.equal(result.totalApproved,0);
 await report(h,'excess',110,'2026-11-20');await assert.rejects(h.call('reviewSiteProgressReport','admin',{reportId:'excess',status:'Approved',approvedQuantity:110}));
 assert.ok((await h.call('listSiteProgressReportHistory','admin',{reportId:'day1'})).events.length>=4);
});
test('duplicate day, negative quantity, changed retry payload, target/unit edits and category privilege denied',async()=>{
 const h=await setup();const payload=await report(h,'day1',12);
 await assert.rejects(h.call('submitSiteProgressReport','supervisor',{report:{...payload,quantity:-1}}));await assert.rejects(h.call('submitSiteProgressReport','supervisor',{report:{...payload,quantity:20}}));await assert.rejects(report(h,'duplicate',12));
 await assert.rejects(h.call('saveSiteProgressCategory','manager',{name:'Unauthorized',projectIds:[],memberUids:[]}));
 await assert.rejects(h.call('saveSiteProgressWorkItem','admin',{workItem:{id:h.workItemId,projectId:'project',categoryId:h.categoryId,name:'Tiles',unit:'kg',targetQuantity:100,assignedToUids:['supervisor']}}));
 await h.call('reviewSiteProgressReport','admin',{reportId:'day1',status:'Approved',approvedQuantity:12});await assert.rejects(h.call('saveSiteProgressWorkItem','admin',{workItem:{id:h.workItemId,projectId:'project',categoryId:h.categoryId,name:'Tiles',unit:'sq ft',targetQuantity:10,assignedToUids:['supervisor']}}));
});
test('additive migration is idempotent and retains historical records and existing roles',async()=>{
 const h=harness();h.seed('siteProgressReports/legacy',{description:'Historical report'});h.seed('roles/site_manager',{name:'Custom manager',permissions:['custom']});await h.call('initializeConstructionWorkflow','admin');const repeat=await h.call('initializeConstructionWorkflow','admin');assert.equal(repeat.alreadyApplied,true);assert.equal(h.records.get('tenants/A/siteProgressReports/legacy').description,'Historical report');assert.deepEqual(h.records.get('tenants/A/roles/site_manager').permissions,['custom']);
});
test('photo upload verifies ownership, digest and original bytes; assignment alone permits finalization',async()=>{
 const h=await setup();const bytes=Buffer.from([255,216,255,224,0,2,255,217]);const sha256=require('node:crypto').createHash('sha256').update(bytes).digest('hex');
 const upload=await h.call('createSiteProgressPhotoUpload','supervisor',{reportId:'uploadreport',workItemId:h.workItemId,fileName:'fixture.jpg',contentType:'image/jpeg',size:bytes.length,sha256,source:'gallery'});
 const photo=h.records.get('tenants/A/siteProgressPhotos/'+upload.photoId);h.objects.set(photo.objectPath,{meta:{size:String(bytes.length),contentType:'image/jpeg',metadata:{sha256}},bytes});
 await assert.rejects(h.call('finalizeSiteProgressPhotoUpload','other',{photoId:upload.photoId}));await h.call('finalizeSiteProgressPhotoUpload','supervisor',{photoId:upload.photoId});assert.equal(photo.status,'uploading');assert.equal(h.records.get('tenants/A/siteProgressPhotos/'+upload.photoId).status,'active');
 await assert.rejects(h.call('createSiteProgressPhotoUpload','supervisor',{reportId:'r',workItemId:h.workItemId,fileName:'huge.jpg',contentType:'image/jpeg',size:16*1024*1024,sha256,source:'gallery'}));
 const invalid=await h.call('createSiteProgressPhotoUpload','supervisor',{reportId:'badreport',workItemId:h.workItemId,fileName:'bad.jpg',contentType:'image/jpeg',size:bytes.length,sha256,source:'gallery'});const bad=h.records.get('tenants/A/siteProgressPhotos/'+invalid.photoId);h.objects.set(bad.objectPath,{meta:{size:String(bytes.length),contentType:'image/jpeg',metadata:{sha256}},bytes:Buffer.alloc(bytes.length)});await assert.rejects(h.call('finalizeSiteProgressPhotoUpload','supervisor',{photoId:invalid.photoId}));assert.equal(h.objects.has(bad.objectPath),false);
});
test('archived categories retain report visibility and audit history',async()=>{
 const h=await setup();await report(h,'history',12);await h.call('archiveSiteProgressCategory','admin',{categoryId:h.categoryId});const workspace=await h.call('listSiteProgressWorkspace','admin');assert.equal(workspace.reports.length,1);assert.equal(workspace.workItems.length,1);assert.ok((await h.call('listSiteProgressReportHistory','admin',{reportId:'history'})).events.length);await assert.rejects(report(h,'newreport',20,'2026-11-20'));
});
test('explicit manager review permission is still limited to assigned projects',async()=>{
 const h=await setup();const payload=await report(h,'day1',12);h.seed('roles/site_manager',{permissions:['siteProgress.read','siteProgress.review']});await assert.rejects(h.call('reviewSiteProgressReport','manager',{reportId:'day1',status:'Approved'}));
 await h.call('assignSiteProgressAccess','admin',{memberUid:'manager',projectIds:['project'],categoryIds:[],permissionLevel:'review'});const result=await h.call('reviewSiteProgressReport','manager',{reportId:'day1',status:'Approved',approvedQuantity:12});assert.equal(result.totalApproved,12);assert.ok((await h.call('getSiteProgressPhotoAccess','manager',{reportId:'day1',photoId:payload.photoIds[0]})).url);
 h.seed('members/manager',{role:'site_manager',status:'active',siteProgressAccess:{projectIds:[],permissionLevel:'review'}});await assert.rejects(h.call('reviewSiteProgressReport','manager',{reportId:'day1',status:'Rejected'}));
});

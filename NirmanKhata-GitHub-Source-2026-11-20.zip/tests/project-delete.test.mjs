import test from 'node:test';
import assert from 'node:assert/strict';
import {command} from '../server/records.mjs';

function fixture(){
  const projects=[{enterprise:'A',id:'site-1',archived:0},{enterprise:'B',id:'site-2',archived:0}],history=[{kind:'purchaseBills',projectId:'site-1',amount:118},{kind:'dailySiteRegister',projectId:'site-1',tankar:2},{kind:'daily_progress_reports',projectId:'site-1',quantity:12}],audits=[];
  const c={async execute(sql,p){
    if(sql.startsWith('SELECT id FROM project_sites'))return [projects.filter(row=>row.enterprise===p[0]&&row.id===p[1]&&!row.archived)];
    if(sql.startsWith('UPDATE project_sites SET archived=1')){for(const row of projects)if(row.enterprise===p[0]&&row.id===p[1])row.archived=1;return [{}];}
    if(sql.startsWith('INSERT INTO audit_logs')){audits.push(p);return [{}];}
    throw Error('Unexpected query: '+sql);
  }};
  const admin={id:'admin-A',enterprise_id:'A',role_id:'admin_editor',permissions:[],subscription:{modules:['projects']}};
  return {c,admin,projects,history,audits};
}
test('project deletion archives only the requested enterprise project and preserves history',async()=>{
  const f=fixture(),before=JSON.stringify(f.history),result=await command(f.c,f.admin,'deleteProject',['site-1']);
  assert.deepEqual(result,{archived:true,projectId:'site-1'});
  assert.equal(f.projects[0].archived,1);assert.equal(f.projects[1].archived,0);
  assert.equal(JSON.stringify(f.history),before);
  assert.equal(f.audits[0][3],'project.archived');assert.equal(f.audits[0][4],'site-1');
  await assert.rejects(()=>command(f.c,f.admin,'deleteProject',['site-1']),e=>e.status===404);
});
test('project deletion rejects foreign and nonexistent project IDs without an update or audit',async()=>{
  const f=fixture();
  for(const id of ['site-2','nonexistent'])await assert.rejects(()=>command(f.c,f.admin,'deleteProject',[id]),e=>e.status===404);
  assert.ok(f.projects.every(p=>!p.archived));assert.equal(f.audits.length,0);
});
test('employees cannot delete projects even if given an archive permission',async()=>{
  const f=fixture(),employee={...f.admin,role_id:'project_manager',permissions:['projects.archive']};
  await assert.rejects(()=>command(f.c,employee,'deleteProject',['site-1']),e=>e.status===403);
  assert.ok(f.projects.every(p=>!p.archived));assert.equal(f.audits.length,0);
});

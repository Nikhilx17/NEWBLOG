import test from 'node:test';
import assert from 'node:assert/strict';
import {emptyDynamicRegister,validateDynamicRegister,normalizeMasterName,collectRegisterMasters,toDynamicRegister,withMaterialBalances,equipmentMinutes,rankMasterSuggestions} from '../src/lib/dynamicSiteRegister.mjs';

const entry=()=>({...emptyDynamicRegister('2026-11-20'),materials:[{id:'m1',name:'Tanker',quantity:'2',unit:'Nos',remarks:'Site water supply'}]});
test('dynamic names and units are unrestricted and normalized without duplicate master records',()=>{
  const input=entry();input.materials.push({id:'m2',name:'  FLY   Ash ',quantity:3.5,unit:'Ton',remarks:''});input.utilities.push({id:'u1',name:' TANKER ',quantity:2,unit:' nos ',remarks:''});
  const result=validateDynamicRegister(input),masters=collectRegisterMasters(result);
  assert.equal(result.materials[1].name,'FLY Ash');assert.equal(result.materials[1].quantity,3.5);
  assert.equal(masters.filter(m=>m.type==='material'&&m.normalizedName==='tanker').length,1);
  assert.equal(normalizeMasterName(' CEMENT\u00a0 OPC '),'cement opc');
});
test('autocomplete ranks exact and prefix matches before partial-word and substring matches',()=>{
  const matches=rankMasterSuggestions([{name:'Water Tanker'},{name:'Tanker'},{name:'TANKER Deluxe'},{name:'Metal tanker truck'}],'tan');
  assert.deepEqual(matches.map(m=>m.name),['Tanker','TANKER Deluxe','Metal tanker truck','Water Tanker']);
  assert.equal(rankMasterSuggestions([{name:'Cement'},{name:'cement'}],'cem').length,1);
});
test('ledger balances are cumulative by material and unit and recompute after backdated correction',()=>{
  const a={...entry(),ledger:[{id:'l1',name:'Cement',credit:100,debit:27,unit:'Bags'}]},b={...entry(),date:'2026-11-21',ledger:[{id:'l2',name:' cement ',credit:0,debit:13,unit:'bags'},{id:'l3',name:'Cement',credit:3,debit:1,unit:'Ton'}]};
  let records=withMaterialBalances([b,a]);assert.equal(records[0].ledger[0].balance,73);assert.equal(records[1].ledger[0].balance,60);assert.equal(records[1].ledger[1].balance,2);
  records=withMaterialBalances([{...a,ledger:[{...a.ledger[0],credit:120}]},b]);assert.equal(records[1].ledger[0].balance,80);
});
test('equipment duration handles overnight work and ignores forged duration values',()=>{
  assert.equal(equipmentMinutes('09:00','13:00'),240);assert.equal(equipmentMinutes('23:30','01:00'),90);
  const input={...entry(),equipment:[{id:'e1',name:'Crawler crane',startTime:'23:30',endTime:'01:00',meterReading:42,remarks:'',durationMinutes:9999}]};
  assert.equal(validateDynamicRegister(input).equipment[0].durationMinutes,90);
});
test('validation returns field paths, rejects duplicates and leaves source data unchanged',()=>{
  const input=entry();input.materials.push({id:'m2',name:'New invalid item',quantity:-1,unit:'nos',remarks:''},{id:'m3',name:' tanker ',quantity:2,unit:'nos',remarks:'Site water supply'});const source=structuredClone(input);
  assert.throws(()=>validateDynamicRegister(input),error=>Boolean(error.status===400&&error.fields['materials.1.quantity']&&error.fields['materials.2.name']));
  assert.deepEqual(input,source);
  assert.throws(()=>validateDynamicRegister(emptyDynamicRegister('2026-11-20')),error=>Boolean(error.fields.register));
  assert.throws(()=>validateDynamicRegister({...entry(),date:'2026-02-30'}),error=>Boolean(error.fields.date));
});
test('labour, work categories and custom sections persist as typed dynamic rows',()=>{
  const input={...entry(),labour:[{id:'lab1',name:'Solar technician',workers:4,remarks:'Roof'}],progress:[{id:'p1',description:'Solar panels installed',category:'Renewable systems',quantity:8,unit:'Panels',remarks:''}],customSections:[{id:'s1',name:'Safety inspections',rows:[{id:'c1',name:'Harness checks',quantity:6,unit:'Nos',remarks:''}]}]};
  const result=validateDynamicRegister(input),masters=collectRegisterMasters(result);
  assert.equal(result.labour[0].workers,4);assert.equal(result.customSections[0].rows[0].quantity,6);
  for(const [type,name] of [['labour','Solar technician'],['workCategory','Renewable systems'],['customCategory','Safety inspections'],['customItem','Harness checks']])assert.ok(masters.some(m=>m.type===type&&m.name===name));
});
test('old fixed records convert without losing quantities, working times, labour or cement balances',()=>{
  const original={date:'2026-11-18',tankar:2,patharTorrly:6,dust:4,waterLitres:1000,waterCount:2,jcbStart:'10:30',jcbEnd:'13:00',cement:100,ett:5500,cementCredit:100,cementDebit:27,mistri:6,helper:6};
  const converted=toDynamicRegister(original);assert.equal(converted.materials.length,5);assert.equal(converted.utilities.length,2);assert.equal(converted.equipment[0].durationMinutes,150);assert.equal(converted.labour.length,2);assert.equal(withMaterialBalances([converted])[0].ledger[0].balance,73);assert.equal(original.schemaVersion,undefined);
  assert.doesNotThrow(()=>validateDynamicRegister(converted));
});

test('repeated materials with different site remarks are valid and share one reusable master',()=>{const input=entry();input.materials.push({...input.materials[0],id:'m2',remarks:'Second building'});const result=validateDynamicRegister(input);assert.equal(result.materials.length,2);assert.equal(collectRegisterMasters(result).filter(m=>m.type==='material').length,1)});

import test from 'node:test';
import assert from 'node:assert/strict';
import {REGISTER_ITEMS,normalizeRegisterEntry,formatRegisterMaterial,withCementBalances} from '../src/lib/dailySiteRegister.mjs';
import {dailySiteRegisterRpc} from '../server/daily-site-register.mjs';

test('register contains exactly the seven screenshot items and formats Nos, litres and JCB times',()=>{
  assert.deepEqual(REGISTER_ITEMS.map(i=>i.label),['Tankar','Pathar Torrly','Dust','Pani Ki Tanki','JCB','Cement','ETT']);
  const entry=normalizeRegisterEntry({date:'2026-11-17',tankar:'2',patharTorrly:6,dust:4,waterLitres:1000,waterCount:2,jcbStart:'10:30',jcbEnd:'13:00',cement:100,ett:5500,mistri:6,helper:6});
  assert.equal(formatRegisterMaterial(entry,'tankar'),'2 Nos');
  assert.equal(formatRegisterMaterial(entry,'water'),'1000 Ltr (2 Nos)');
  assert.equal(formatRegisterMaterial(entry,'jcb'),'10:30 AM TO 1:00 PM');
  assert.equal(formatRegisterMaterial(entry,'ett'),'5500 Nos');
  assert.equal(entry.mistri,6);assert.equal(entry.helper,6);
  assert.equal(formatRegisterMaterial(normalizeRegisterEntry({date:'2026-11-18',tankar:0}),'tankar'),'0 Nos');
});

test('cement balance carries across dates and recalculates every later date after an edit',()=>{
  const first={date:'2026-11-18',cementCredit:100,cementDebit:27};
  const second={date:'2026-11-19',cementCredit:0,cementDebit:13};
  const rows=withCementBalances([second,first]);
  assert.deepEqual(rows.map(r=>r.cementBalance),[73,60]);
  assert.deepEqual(withCementBalances([{...first,cementCredit:120},second]).map(r=>r.cementBalance),[93,80]);
  assert.equal(first.cementBalance,undefined,'calculations do not mutate stored entries');
  assert.equal(withCementBalances([{date:'2026-11-18',cementCredit:.3,cementDebit:.1},{date:'2026-11-19',cementDebit:.1}])[1].cementBalance,.1);
});

test('register validates dates, numeric quantities and complete working-time pairs',()=>{
  for(const patch of [{tankar:-1},{dust:'not a number'},{mistri:true},{helper:Infinity},{cementCredit:.00000001},{date:'2026-02-30'},{jcbStart:'25:00',jcbEnd:'26:00'},{jcbStart:'10:30'},{jcbStart:'14:00',jcbEnd:'13:00'}]){
    assert.throws(()=>normalizeRegisterEntry({date:'2026-11-18',...patch}),e=>e.status===400);
  }
  assert.equal(normalizeRegisterEntry({date:'2026-11-18',dust:'1.5',cementBalance:999999}).dust,1.5);
  assert.equal(normalizeRegisterEntry({date:'2026-11-18',cementBalance:999999}).cementBalance,undefined,'client cannot set derived balances');
});

// SQL adapter tests the production handler, query scope and stored payloads.
// It is a test double, not a claim of a live MySQL deployment test.
export function registerTestDatabase(state={projects:[],records:[],audits:[]}) {
  return {state,async execute(sql,params){
    if(sql.startsWith('SELECT id,data FROM project_sites'))return [state.projects.filter(p=>p.enterprise_id===params[0]&&!p.archived)];
    if(sql.startsWith('SELECT version,data FROM erp_records'))return [state.records.filter(r=>r.enterprise_id===params[0]&&r.kind===params[1]&&r.id===params[2])];
    if(sql.startsWith('SELECT data,version FROM erp_records'))return [state.records.filter(r=>r.enterprise_id===params[0]&&r.kind===params[1]&&r.project_id===params[2]&&!r.archived)];
    if(sql.startsWith('INSERT INTO erp_records')){const [enterprise_id,kind,id,project_id,data]=params;state.records.push({enterprise_id,kind,id,project_id,data,version:1});return [{}];}
    if(sql.startsWith('UPDATE erp_records')){const [data,enterprise,kind,id]=params;const row=state.records.find(r=>r.enterprise_id===enterprise&&r.kind===kind&&r.id===id);assert.ok(row);row.data=data;row.version++;return [{}];}
    if(sql.startsWith('INSERT INTO audit_logs')){state.audits.push(params);return [{}];}
    throw new Error('Unexpected SQL in register test: '+sql);
  }};
}
const manager={id:'user-A',enterprise_id:'A',role_id:'project_manager',permissions:['projects.read','projects.edit'],projectIds:['site-A'],subscription:{modules:['projects']}};
function database(){return registerTestDatabase({projects:[{id:'site-A',enterprise_id:'A',data:{name:'Site A'}},{id:'other-site',enterprise_id:'A',data:{name:'Other site'}},{id:'site-A',enterprise_id:'B',data:{name:'Enterprise B site'}}],records:[{enterprise_id:'A',kind:'purchaseBills',id:'existing-bill',project_id:'site-A',data:'{"totalAmount":118}',version:7}],audits:[]});}
test('production register handler saves, reloads and edits date records without duplicate days or unrelated changes',async()=>{
  const c=database(),unrelated=JSON.stringify(c.state.records[0]);
  const save=(entry,version=0)=>dailySiteRegisterRpc(c,manager,'saveDailySiteRegister',{projectId:'site-A',entry,version});
  await save({date:'2026-11-18',tankar:2,cement:100,cementCredit:100,cementDebit:27,mistri:6,helper:6});
  await save({date:'2026-11-19',patharTorrly:13,dust:3,cementDebit:13,mistri:6,helper:6});
  // New connection / handler instance reads the same stored rows.
  const reloaded=await dailySiteRegisterRpc(registerTestDatabase(c.state),manager,'getDailySiteRegister',{projectId:'site-A'});
  assert.equal(reloaded.entries.length,2);assert.deepEqual(reloaded.entries.map(r=>r.cementBalance),[73,60]);
  assert.equal(reloaded.entries[0].tankar,2);assert.equal(reloaded.entries[1].helper,6);
  const updated=await save({...reloaded.entries[0],tankar:3,cementCredit:120},1);
  assert.equal(updated.entries.length,2);assert.equal(updated.entries[0].version,2);
  assert.equal(updated.entries[0].tankar,3);assert.deepEqual(updated.entries.map(r=>r.cementBalance),[93,80]);
  await assert.rejects(()=>save({...reloaded.entries[0],tankar:99},1),e=>e.status===409);
  assert.equal(JSON.stringify(c.state.records[0]),unrelated);
  assert.ok(c.state.audits.some(a=>a[3]==='dailySiteRegister.updated'));
});

test('register reuses existing project read/edit access and isolates projects and enterprises',async()=>{
  const c=database(),list=await dailySiteRegisterRpc(c,manager,'getDailySiteRegister',{});
  assert.deepEqual(list.projects.map(p=>p.id),['site-A']);
  await assert.rejects(()=>dailySiteRegisterRpc(c,manager,'getDailySiteRegister',{projectId:'other-site'}),e=>e.status===403);
  const readOnly={...manager,permissions:['projects.read']};
  assert.equal((await dailySiteRegisterRpc(c,readOnly,'getDailySiteRegister',{})).canEdit,false);
  await assert.rejects(()=>dailySiteRegisterRpc(c,readOnly,'saveDailySiteRegister',{projectId:'site-A',entry:{date:'2026-11-18'},version:0}),e=>e.status===403);
  await dailySiteRegisterRpc(c,manager,'saveDailySiteRegister',{projectId:'site-A',entry:{date:'2026-11-18',tankar:2},version:0});
  const other={...manager,id:'user-B',enterprise_id:'B'};
  assert.equal((await dailySiteRegisterRpc(c,other,'getDailySiteRegister',{projectId:'site-A'})).entries.length,0);
  await dailySiteRegisterRpc(c,other,'saveDailySiteRegister',{projectId:'site-A',entry:{date:'2026-11-18',tankar:9},version:0});
  assert.equal((await dailySiteRegisterRpc(c,manager,'getDailySiteRegister',{projectId:'site-A'})).entries[0].tankar,2);
  assert.equal(await dailySiteRegisterRpc(c,manager,'unrelatedExistingRpc',{}),null);
});

# COMPLETE SOFTWARE AUDIT REPORT: NIRMANKHATA ERP

**Auditor:** Senior Software Auditor & ERP Workflow Analyst  
**Project Name:** NirmanKhata — Contractor Profit & Expense ERP  
**Target Environment:** Node.js (v22+) / Express 4 / MySQL / React 19 / TypeScript / Vite / Tailwind CSS  
**Audit Date:** November 2026  
**Status:** Audit Completed (Read-Only Inspection — No Software Changes Applied)

---

## 1. PROJECT OVERVIEW

### 1.1 Executive Summary
**NirmanKhata ERP** is an enterprise-grade contractor management and real-time profit tracking platform designed specifically for the Indian construction and contracting sector. The software handles civil, electrical, plumbing, mechanical, and interior contracting workflows. Its operational focus is bridging the gap between site execution (daily labour muster, material receipt, equipment logs, physical work progress) and head-office accounting (purchase bills, supplier ledgers, operational expenses, cash/bank accounts, contract variations, and live project profitability).

### 1.2 Technology Stack
* **Frontend:**
  * **Core:** React 19.0.1, React DOM 19.0.1, TypeScript 7.0.2
  * **Bundler & Tooling:** Vite 8.3.0, `@tailwindcss/vite` 4.3.3, Tailwind CSS 4.3.3, `@vitejs/plugin-react` 6.1.1
  * **Typography & Icons:** `@fontsource-variable/plus-jakarta-sans`, `lucide-react` 0.546.0
  * **Utilities:** `jspdf` 4.2.1 (PDF client generation), `fflate` 0.8.3 (ZIP/compression), `motion` 12.23.24
* **Backend:**
  * **Runtime & Framework:** Node.js >=22.12.0, Express 4.22.0
  * **Security & Middleware:** `helmet` 8.0.0 (strict CSP, frame/object guard), `dotenv` 17.2.3, custom HttpOnly same-origin session management (`__Host-erp_session` / `erp_session`)
  * **Database Driver:** `mysql2` 3.0.0 (promise-based connection pool with UTC timezone locking and ACID transactions)
  * **Media & File Processing:** `sharp` 0.35.5 (server-side image verification, sanitization, EXIF stripping, and WebP thumbnail generation)
  * **Cryptography:** Native `node:crypto` using `scrypt` (cost: 32768, r: 8, p: 1) for passwords, `AES-256-GCM` with random IVs for encrypted database/file backups, and `SHA-256` for idempotency and upload integrity.
* **Database Architecture:**
  * Authoritative storage: MySQL relational database.
  * Multi-tenancy: Logical isolation via `enterprise_id` column across all operational and master tables with strict foreign key constraints (`ON DELETE RESTRICT` / `ON DELETE CASCADE` appropriately).
  * Storage Engine: MySQL InnoDB with row-level locking (`FOR UPDATE`), transaction isolation, and JSON columns for dynamic state snapshots and metadata.

### 1.3 Architectural Evolution & Dual-Layer State
The codebase contains evidence of two architectural phases:
1. **Preserved Legacy Cloud-Native Layer (Firebase):**
   * Located in `functions/` (Cloud Functions in TypeScript), `src/lib/firebase.ts`, `src/components/auth/SaaSAccess.tsx`, `EnterpriseWorkspace.tsx`, and `SiteProgressWorkspace.tsx`.
   * Designed for Google Cloud / Firebase (Firestore, Firebase Auth, Firebase Storage).
   * **Current State:** Retained strictly for historical reference, backward compatibility, and client-side data migration. It is **not** mounted in the active production runtime.
2. **Authoritative Production Layer (Native Node.js / Express / MySQL):**
   * Located in `server/` (`app.mjs`, `core.mjs`, `records.mjs`, `daily-dpr.mjs`, `daily-site-register.mjs`, `supplier-ledger.mjs`, `site-workflow.mjs`, `bulk-expenses.mjs`, `files.mjs`, `backup.mjs`) and initialized via `server.cjs`.
   * Mounted on the frontend via `src/components/auth/HostingerApp.tsx` inside `src/App.tsx`.
   * Eliminates third-party client auth SDKs in favor of same-origin HttpOnly cookies, server-side transactions, private directory file storage, and encrypted offline `.erpbak` packages.

---

## 2. COMPLETE PAGE LIST

The software contains **24 distinct active functional application views/modals** in the live production runtime, plus **10 unrouted marketing website pages** preserved in `src/components/auth/SaaSAccess.tsx`.

### Active Application Pages & Screens

| # | Page / View Name | Code Component | Primary Purpose | Access Level |
|---|---|---|---|---|
| 1 | **Sign In / Login Screen** | `HostingerApp.tsx` (`Login`) | Authenticate enterprise staff and platform owner via Username/Login ID and Password. | Public / Unauthenticated |
| 2 | **Temporary Password Change** | `HostingerApp.tsx` (`PasswordChange`) | Force password reset for new employees or after admin credential reset. | Session with `must_change_password=1` |
| 3 | **Business Profile Onboarding** | `HostingerApp.tsx` (`Onboarding`) | Initial one-time legal entity setup (GSTIN, PAN, address) for Admin: Editor. | Admin: Editor (Incomplete Profile) |
| 4 | **Platform Administration** | `HostingerApp.tsx` (`PlatformEnterpriseAccounts`) | Provision new enterprise accounts, set seat limits, enable/suspend licenses. | Platform Owner (`platform_owner=1`) |
| 5 | **Manager / Site Desk** | `SiteDeskView.tsx` (`site-desk`) | Central operational cockpit: purchase alerts, pending DPR reviews, site orders, deliveries. | All Roles (Scoped Permissions) |
| 6 | **Main Dashboard** | `DashboardView.tsx` (`dashboard`) | Executive financial cockpit: Live profit, receivables aging, supplier payables, liquid cash. | Roles with `reports.operational.read` |
| 7 | **All Projects** | `ProjectsView.tsx` (`projects`) | Master list of all assigned projects with contract values, costs, and progress. | Roles with `projects.read` |
| 8 | **Project Detail Cockpit** | `ProjectDetailView.tsx` (`project-detail`) | Detailed financial breakdown of a single project (P&L, material bills, expenses, variations). | Roles with `projects.read` |
| 9 | **Create / Edit Project Modal** | `CreateEditProjectModal.tsx` | Form to create a new project or edit existing contract parameters. | Admin: Editor & Project Manager |
| 10 | **Daily Site Register** | `DailySiteRegisterView.tsx` (`daily-site-register`) | Comprehensive site register: Materials, Equipment run hours, Cement balance, Labour muster. | Assigned Site Staff & Admin |
| 11 | **Work Assignment** | `DailyDprView.tsx` (`work-assignment`) | Schedule daily physical tasks, allocate target quantities, and assign supervisors. | Manager / Admin (`siteProgress.allocate`) |
| 12 | **DPR Approvals** | `DailyDprView.tsx` (`dpr-approvals`) | Review site supervisor daily reports, verify work photos, approve/reverse material usage. | Manager / Admin (`siteProgress.review`) |
| 13 | **Today's Assigned Work** | `DailyDprView.tsx` (`work-progress`) | Field supervisor daily interface: view daily tasks, input actual work done, take site photos. | Site Supervisor (`siteProgress.submit`) |
| 14 | **Purchase Orders** | `PurchaseOrdersView.tsx` (`purchases`) | Schedule planned material orders, manage suppliers, mark items ordered. | Roles with `purchases.read` / `create` |
| 15 | **Supplier Invoices** | `PurchasesView.tsx` (`SupplierInvoicesView`) | View supplier tax invoices, verify invoice numbers, approve bills for payment. | Roles with `purchases.read` / `review` |
| 16 | **Upload Bill Modal** | `InvoiceUploadModal.tsx` | Enter vendor bill details, attach original PDF/image invoice, check duplicate invoices. | Roles with `purchases.create` |
| 17 | **Suppliers & Ledgers** | `SuppliersView.tsx` (`suppliers`) | Supplier list, total orders, delivered amounts, external payment recordings. | Roles with `purchases.read` |
| 18 | **Daily Site Expenses** | `DailyExpensesView.tsx` (`expenses`) | Bulk grid entry for site petty cash, fuel, rentals; saved expenses filter and reversal. | Roles with `expenses.read` / `create` |
| 19 | **Workers & Staff** | `WorkersView.tsx` (`workers`) | Roster of tradesmen, helpers, and engineers; wage rates; active/inactive status toggle. | Roles with `workers.read` |
| 20 | **Financial Reports (20)** | `FinancialReportsView.tsx` (`reports`) | 20 contractor reports with Excel, CSV, PDF export, and live print preview. | Roles with `reports.financial.read` |
| 21 | **Material Inventory** | `InventoryView.tsx` (`inventory`) | Warehouse stock, SKU tracking, average cost valuation, and issue stock to site project. | Roles with `inventory.read` |
| 22 | **Smart Alerts** | `NotificationsView.tsx` (`alerts`) | System alerts for budget overruns, low stock, payment delays, and pending approvals. | Roles with `reports.operational.read` |
| 23 | **User & Access Management**| `TeamPermissionsView.tsx` (`team`) | Create employee logins, generate temporary passwords, assign roles & projects, audit log. | Admin: Editor (`users.manage`) |
| 24 | **Business Profile** | `BusinessSettingsView.tsx` (`settings`) | Edit company profile, legal GST/PAN details, default bank details, download backup. | Admin: Editor (`settings.manage`) |

### Preserved Marketing & Public Pages (in `SaaSAccess.tsx`)
25. **Marketing Homepage** (`/`): Landing page with feature showcases, illustrative ERP previews, and contractor value propositions.
26. **Features Page** (`/features`): Breakdown of modules (Projects, Purchases, Billing, Workforce, Inventory, Reports).
27. **Industries Page** (`/industries`): Industry-specific information for Civil, Electrical, Plumbing, and Finishing contractors.
28. **Pricing Page** (`/pricing`): Plan listings (invokes `listPublicPlans` Firebase function).
29. **About Page** (`/about`): Background on NirmanKhata platform vision.
30. **Contact / Walkthrough Page** (`/contact`): Form to book product demonstrations (`requestProductDemo`).
31. **FAQ Page** (`/faq`): Answers to questions regarding onboarding, pricing, and employee accounts.
32. **Privacy Policy** (`/privacy`): Data confidentiality and tenant boundary statements.
33. **Terms of Service** (`/terms`): SaaS commercial terms.
34. **Refund Policy** (`/refund`): Cancellation and refund policy information.

---

## 3. MENU AND NAVIGATION STRUCTURE

### 3.1 Sidebar Navigation Hierarchy
The main navigation is organized into **5 logical sections** comprising **16 sidebar menu items** (filtered dynamically based on the authenticated user's role and granted permissions).

```
[NK] NirmanKhata Contractor ERP
│
├── 1. FINANCIAL COCKPIT
│   ├── [LayoutDashboard] Manager / Site Desk (id: 'site-desk')
│   └── [LayoutDashboard] Main Dashboard (id: 'dashboard')
│
├── 2. PROJECTS & CONTRACTS
│   ├── [Building] All Projects (id: 'projects')
│   ├── [FileSpreadsheet] Daily Site Register (id: 'daily-site-register')
│   ├── [ClipboardCheck] Work Assignment (id: 'work-assignment') [Managers/Admins only]
│   ├── [ClipboardCheck] DPR Approvals (id: 'dpr-approvals') [Managers/Admins only]
│   └── [ClipboardCheck] Today's Assigned Work (id: 'work-progress') [Site Supervisors only]
│
├── 3. PURCHASES & EXPENSES
│   ├── [ShoppingCart] Purchase Orders (id: 'purchases') [Dynamic Badge: Unpaid Bills Count]
│   ├── [Users2] Suppliers & Ledgers (id: 'suppliers')
│   ├── [Receipt] Daily Site Expenses (id: 'expenses')
│   └── [Package] Material Inventory (id: 'inventory') [Hidden if enableInventory is false]
│
├── 4. LABOUR & WORKFORCE
│   └── [HardHat] Workers & Staff (id: 'workers')
│
└── 5. REPORTS & CONTROLS
    ├── [FileBarChart] Financial Reports (20) (id: 'reports')
    ├── [Bell] Smart Alerts (id: 'alerts') [Dynamic Badge: Active Alerts Count]
    ├── [Users2] User & Access Management (id: 'team') [Admin: Editor only]
    └── [Settings] Business Profile (id: 'settings') [Admin: Editor only]
```

### 3.2 Top Header (Navbar) Navigation
* **Mobile Sidebar Toggle:** Hamburger icon visible only on smaller viewports (<1024px).
* **Company Brand Badge:** Displays initials of company name and registered contractor trade type.
* **Global Project Switcher Dropdown:**
  * Option 1: `🏢 All Projects (<count>)` (sets `activeProjectId = 'all'`)
  * Dynamic Options: List of active assigned projects formatted as `<code> - <name>`.
  * Selecting a project filters data across Dashboard, Purchase Orders, Expenses, Daily Site Register, and Inventory.
* **Quick Entry Button (`+ Quick Entry`):**
  * Opens a dropdown menu for instant shortcuts:
    * `Record Daily Site Expense` (Requires `expenses.create` -> Navigates to `expenses`)
    * `Add Purchase Order` (Requires `purchases.create` -> Navigates to `purchases`)
    * `Create New Project` (Requires `projects.create` -> Opens `CreateEditProjectModal`)
* **Financial Alerts Shield:**
  * Displays active alert counter with a red pulsing dot if alerts exist.
  * Clicking navigates directly to the `alerts` tab.
* **User Identity & Role Pill:**
  * Shows first initial of user's name, display name, and color-coded role badge (e.g. Purple for Admin: Editor, Emerald for Project Manager, Amber for Site Supervisor).
  * In the authenticated production server mode, persona switching and demo reset options are disabled to prevent session corruption.
* **Persistent Bottom Status Banner:**
  * Fixed at bottom right. Displays live server connection state (`Connected to enterprise database`), pending save spinner (`Saving changes to the server...`), or red error notifications.
  * Contains quick action buttons: **Sign out** and **Refresh records**.

### 3.3 Navigation Anomalies & Duplicate Findings
1. **Identical Icons in Projects Section:** `Work Assignment`, `DPR Approvals`, and `Today's Assigned Work` all use the identical `ClipboardCheck` icon.
2. **Repeated Cockpit Icon:** `Manager / Site Desk` and `Main Dashboard` both use `LayoutDashboard`.
3. **Repeated User Icon:** `Suppliers & Ledgers` and `User & Access Management` both use `Users2`.
4. **Conditional Module Mutual Exclusion:** The backend intentionally excludes `work-progress` for administrators and managers, while giving them `work-assignment` and `dpr-approvals`. Field supervisors receive `work-progress` and are blocked from `work-assignment` and `dpr-approvals`.

---

## 4. PAGE-BY-PAGE FEATURES AND BUTTONS

---

### Page 1: Sign In / Login Screen (`Login` in `HostingerApp.tsx`)
* **Purpose:** Initial gatekeeper for all enterprise employees and platform owners.
* **Visible Elements:**
  * NirmanKhata "NK" brand badge and title.
  * Input: **Username / Login ID** (Required text).
  * Input: **Password** (Required password field).
  * Helper text: "Forgot your password? Ask your enterprise Admin: Editor to reset your temporary password."
* **Buttons:**
  * `Sign In` (Submit):
    * **Action:** POST to `/api/auth/login`. Sets HttpOnly session cookie, updates login rate limit bucket (15-minute lock on 8 failed attempts per user or 60 per IP).
    * **Status:** **Fully Functional**.
* **Data Flow / Connection:** Authenticates session. If `mustChangePassword=true`, redirects to Password Change screen; if initial admin with incomplete profile, redirects to Business Profile Onboarding; otherwise loads `/api/state` and renders ERP dashboard.

---

### Page 2: Temporary Password Change (`PasswordChange` in `HostingerApp.tsx`)
* **Purpose:** Mandatory credential gate for all newly provisioned accounts or after an admin password reset.
* **Visible Elements:**
  * Title: "Change Temporary Password".
  * Input: **New Password** (Required, minimum 12 characters).
  * Input: **Confirm Password** (Required).
  * Validation notice: "12–128 characters, with uppercase, lowercase and a number. Use a password different from the temporary one."
* **Buttons:**
  * `Save Password & Sign In Again` (Submit):
    * **Action:** Client-side equality validation. Sends RPC `completeEnterprisePasswordChange`. Clears old temporary session cookie.
    * **Status:** **Fully Functional**.
* **Data Flow / Connection:** Rotates user's session version in MySQL, updates password hash using `scrypt`, and directs user to sign in with their new permanent password.

---

### Page 3: Business Profile Onboarding (`Onboarding` in `HostingerApp.tsx`)
* **Purpose:** First-run company configuration mandatory for Admin: Editor before any operational ERP features unlock.
* **Visible Elements:**
  * Inputs: Company Legal Name, Company Display Name, GSTIN (optional), PAN (optional), Registered Address, City, State, Pincode, Company Email, Phone Number, Business Type dropdown, Financial Year, Currency, Company Logo file uploader.
* **Buttons:**
  * `Save Business Profile` (Submit):
    * **Action:** If logo selected, uploads file to `/api/uploads` and finalizes ticket. POSTs complete profile payload to `/api/profile`. Marks `profileComplete = true`.
    * **Status:** **Fully Functional**.
* **Data Flow / Connection:** Updates `enterprises.profile` in MySQL and immediately triggers ERP workspace hydration.

---

### Page 4: Platform Administration Cockpit (`PlatformEnterpriseAccounts` in `HostingerApp.tsx`)
* **Purpose:** Platform Owner control center for managing enterprise tenants, subscriptions, and licenses.
* **Visible Elements:**
  * Provisioning form with inputs: Enterprise Name, Administrator Name, Admin Login Username, Temporary Password, Employee Limit, Enabled Modules.
  * License Management Accordion: Enterprise selector dropdown, Status dropdown (Active, Suspended, Expired), Employee Limit, Modules, Duration in days.
  * Enterprise Licenses summary cards listing name, status, and seat limits.
* **Buttons:**
  * `Generate admin login ID`: Auto-generates slug based on enterprise name + random suffix. (**Functional**)
  * `Generate temporary password`: Generates high-entropy 20-character secure string. (**Functional**)
  * `Create Enterprise & Admin: Editor` (Submit): Calls RPC `provisionEnterprise`. Creates tenant record, default roles, and initial `admin_editor` user. (**Fully Functional**)
  * `Save License` (Submit): Calls RPC `setEnterpriseLicense`. Updates subscription dates and limits. (**Fully Functional**)
  * `Sign out`: POST to `/api/auth/logout`. Clears session. (**Fully Functional**)

---

### Page 5: Manager / Site Desk (`SiteDeskView.tsx`)
* **Purpose:** High-level daily coordination screen for project managers and site engineers.
* **Visible Elements:**
  * Global Project Selector.
  * 4 KPI Summary Cards:
    1. Purchase Alerts (Orders due within 2 days)
    2. Awaiting Delivery (Orders in 'Ordered' status)
    3. Pending DPR Review / Today's Tasks
    4. Approved Material Used (Total currency value)
  * Purchase Alerts Notice Banner (when orders are due/overdue).
  * Section Navigation Pills: `Purchase & Delivery`, `Work & Approval`, `My Inventory`, `Site Documents`.
* **Section: Purchase & Delivery:**
  * Buttons:
    * `Plan purchase`: Opens inline planned order creation form. (**Functional**)
    * `Save plan`: Submits RPC `savePlannedOrder`. (**Functional**)
    * `Cancel`: Hides order form. (**Functional**)
    * `Edit` (on order row): Reopens order for editing. (**Functional - only for 'Not Ordered'**)
    * `Mark Ordered` (on order row): Submits RPC `markSiteOrderOrdered`. Creates inventory tracking item if absent. (**Functional**)
    * `View receipt`: Opens `/api/files/<id>` in new tab for delivered goods. (**Functional**)
    * `Submit photo & confirm delivered`: Uploads delivery challan photo and submits RPC `receiveSiteOrder`. Updates inventory quantity atomically. (**Functional**)
* **Section: Work & Approval:**
  * Buttons:
    * `Work Assignment`: Navigates to `work-assignment` tab. (**Functional**)
    * `DPR Approvals`: Navigates to `dpr-approvals` tab. (**Functional**)
    * `Today's Assigned Work`: Navigates to `work-progress` tab. (**Functional**)
* **Section: My Inventory:**
  * Read-only table of available site stock, reserved/pending quantities, unit cost, and stock valuation.
* **Section: Site Documents:**
  * Buttons:
    * `Add folder button`: Opens form for Google Drive link. (**Functional**)
    * `Save button`: Submits RPC `saveSiteFolder`. (**Functional**)
    * Drive Folder Pill: Opens Google Drive URL in new window. (**Functional**)
    * `Rename / edit`: Re-edits title/URL. (**Functional**)

---

### Page 6: Main Dashboard (`DashboardView.tsx`)
* **Purpose:** Executive financial overview displaying real-time cash flow, project profitability, unpaid bills, and collections.
* **Visible Elements:**
  * Header Gradient Banner: Active project scope, Live Business Financial Position, Bank & Cash in Hand, Recorded Profit.
  * Attention Required Alert Bar (if alerts exist, with `View All` button linking to `alerts`).
  * 8 Key Financial Stat Cards:
    1. Money Received from Clients (Collected revenue)
    2. Money Still to Collect (Receivables aging)
    3. Supplier Bills Still Unpaid (Total payables with overdue count; click navigates to `purchases`)
    4. Total Labour & Wages Paid (Muster wages + staff)
    5. Total Project Cost Incurred (Click navigates to `expenses`)
    6. Actual Recorded Profit (Billed revenue minus incurred cost, with margin %)
    7. Money Needed to Finish Projects (Estimated cost to complete)
    8. Liquid Cash & Bank Balance (Current working capital indicator)
  * Educational Banner: Explains difference between Accounting Profit and In-Hand Cash.
  * Active Project Financial Overview Table: Lists every project with Contract Value, Incurred Cost, Cost to Complete, Billed, Collected, Recorded Profit, Margin %, and Progress bar.
  * Expenditure Breakdown Progress Bars: Materials, Labour, Subcontractors, Machinery/Fuel.
  * Receivables Aging Grid: 0-30 Days, 31-60 Days, 61-90 Days, >90 Days breakdown.
* **Buttons:**
  * `View All (<count>)`: Navigates to `alerts`. (**Functional**)
  * `Manage All Projects`: Navigates to `projects`. (**Functional**)
  * Table row click: Calls `onSelectProject(id)` and navigates to `project-detail`. (**Functional**)
  * Card clicks on Payables and Costs: Deep-links to `purchases` and `expenses`. (**Functional**)

---

### Page 7: All Projects (`ProjectsView.tsx`)
* **Purpose:** Project portfolio management; provides high-level status and navigation to project detail.
* **Visible Elements:**
  * Search bar (matches project name, code, client).
  * Filter Dropdown: Status (All, Active, Planning, On Hold, Completed).
  * Filter Dropdown: Category (All, Civil & Building, Electrical, Plumbing, Interior).
  * Project Cards Grid: Each card shows Project Code, Status Pill, Project Name, Client Name, Site Address, Revised Contract, Actual Incurred, Client Billed, Recorded Profit, and Physical Progress Bar.
* **Buttons:**
  * `Create New Project`: Opens `CreateEditProjectModal`. (**Functional**)
  * Card Body Click: Sets selected project and navigates to `project-detail`. (**Functional**)
  * `Delete` button (on card): Only visible to `admin_editor`. Opens Delete Confirmation Modal. (**Functional**)
  * `Delete Project` (in Modal): Calls `deleteProject(id)`. Archives project in MySQL while preserving linked records. (**Fully Functional**)
  * `Cancel` (in Modal): Closes delete modal. (**Functional**)

---

### Page 8: Project Detail Cockpit (`ProjectDetailView.tsx`)
* **Purpose:** In-depth financial and operational drill-down for a selected contract.
* **Visible Elements:**
  * Breadcrumb back button.
  * Project Code, Category, Status badge, Client Name, Site Address, Project Manager.
  * Commercial Figures Banner: Original Contract, Approved Variations, Revised Contract, Actual Incurred, Cost to Complete, Recorded Profit.
  * Navigation Tabs: `Financial Summary & P&L`, `Material Purchases`, `Site Daily Expenses`.
  * **Tab 1 (Overview):** Live P&L Statement (Revenue, Materials, Labour, Subcontract, Overheads, Net Profit), Budget Variance Progress Bar, Contractor Retention Notice.
  * **Tab 2 (Materials):** List of purchase bills assigned to this project with invoice number, supplier, items, date, total, paid, and status.
  * **Tab 3 (Expenses):** List of site expenses assigned to this project with date, category, description, vendor, method, and amount.
* **Buttons:**
  * `Back to All Projects`: Navigates back to `projects`. (**Functional**)
  * `Add Variation Work`: Opens Variation Work Modal. (**Functional**)
  * `Confirm Variation` (in Modal): Calls `updateProject` to increase `approvedVariations` and `revisedContractAmount`. (**Fully Functional**)
  * `Cancel` (in Modal): Dismisses variation modal. (**Functional**)
  * `+ Upload Supplier Bill` (Tab 2): Navigates to `purchases`. (**Functional**)
  * `+ Record Expense` (Tab 3): Navigates to `expenses`. (**Functional**)

---

### Page 9: Create / Edit Project Modal (`CreateEditProjectModal.tsx`)
* **Purpose:** Comprehensive modal form to register a new contract or edit project parameters.
* **Visible Elements:**
  * Form inputs: Project Name, Auto-generated Project Code, Client selector, Trade Category dropdown, Site Address, Start Date, Expected End Date, Original Contract Amount (₹), Estimated Planned Budget (₹), Client Retention Percentage (%), Project Manager, Status dropdown, Project Notes.
* **Buttons:**
  * `Close (X)`: Dismisses modal. (**Functional**)
  * `Cancel`: Dismisses modal. (**Functional**)
  * `Save Project` (Submit):
    * **Action:** Calls context `addProject` or `updateProject`. Dispatches `/api/command` (`addProject` or `updateProject`).
    * **Status:** **Fully Functional**.

---

### Page 10: Daily Site Register (`DailySiteRegisterView.tsx`)
* **Purpose:** Dynamic, unified site register capturing daily materials, plant & machinery run times, cement balances, and labour attendance.
* **Visible Elements:**
  * Header with `View Saved Register` toggle button.
  * Project selector dropdown, Date picker, `Previous Day`, `Today`, `Next Day` navigation controls.
  * Summary Cards: Materials Count, Equipment Sessions, Cement Closing Balance, Total Labour Count.
  * **Section 1: Material Entries:**
    * Grid: #, Item Name (autocomplete), Quantity, Unit (autocomplete), Remarks, Edit/Done button.
    * Buttons: `Add Item` (opens modal), `Edit` (toggles inline edit), `Remove item` (removes row from draft). (**Functional**)
  * **Section 2: Plant & Equipment Log:**
    * Grid: Machinery/Vehicle selector, Start Time, End Time, Working Duration (auto-calculated, supports overnight shifts), Remove button.
    * Buttons: `Add Equipment` (opens modal), `Add Working Session` (adds empty session row), Remove trash icon. (**Functional**)
    * Session duration summaries per machine.
  * **Section 3: Cement Register:**
    * Dynamic equation display: `Opening Balance + Credit (In) − Debit (Out) = Closing Balance`.
    * Unit autocomplete, Credit input, Debit input. (**Functional**)
  * **Section 4: Labour Attendance:**
    * Grid: #, Labour Type, Count (Nos), Edit/Done button.
    * Buttons: `Add Labour Type` (opens modal), Edit button, Workers count input. (**Functional**)
  * **Sticky Footer:**
    * `Clear Entry`: Clears current inputs without deleting saved database rows. (**Functional**)
    * `Save Daily Register`: Submits RPC `saveCompactDailyRegister` with version concurrency check and idempotency key. (**Fully Functional**)
  * **Saved Register View (when toggled):**
    * Multi-day Excel-style comparison table for Materials, Machinery run hours, Cement movements, and Labour counts. Clicking any date reopens that historical record for editing. (**Fully Functional**)

---

### Page 11: Work Assignment (`DailyDprView.tsx` with `mode="assignment"`)
* **Purpose:** Allows project managers and administrators to schedule dated activities, assign target quantities, and designate site supervisors.
* **Visible Elements:**
  * Site selector dropdown, Assignment Calendar date picker.
  * Metrics strip: Assigned Tasks, Submitted DPRs, Pending Approvals, Not Reported, Approved Material Cost.
  * List of assigned tasks for the selected date showing: Planned quantity, Location/Block, Instructions, Supervisor Name, Status.
* **Buttons:**
  * `Assign work`: Opens work assignment form. (**Functional**)
  * `Add activity`: Appends an activity block to the assignment form. (**Functional**)
  * `Remove activity` (Trash icon): Deletes activity block. (**Functional**)
  * `Add material rule`: Specifies material consumption ratio from inventory (e.g. 0.4 bags cement per 1 sq ft). (**Functional**)
  * `Save assignments` (Submit): Calls RPC `saveDailyAssignments`. Saves allocated work items in MySQL. (**Fully Functional**)
  * `Cancel`: Discards assignment form. (**Functional**)
  * `Edit / Reassign`: Reopens active assignment with reason prompt. (**Functional**)
  * `Remove task`: Prompts for withdrawal reason and calls RPC `removeDailyAssignment`. (**Functional**)
  * `View history`: Opens modal showing revisions and approvals. (**Functional**)

---

### Page 12: DPR Approvals (`DailyDprView.tsx` with `mode="approvals"`)
* **Purpose:** Review interface for project managers to inspect supervisor reports, examine original site photos, accept/reject quantities, and separately authorize inventory deductions.
* **Visible Elements:**
  * Site and calendar selector.
  * Task approval cards displaying: Reported quantity, Planned quantity, Balance, % completion, Supervisor remarks, Non-completion reasons.
  * Material consumption proposal card: Lists materials required based on approved quantity and planned ratios, with warehouse availability and estimated cost.
* **Buttons:**
  * `View <N> photos`: Opens full-screen private photo gallery viewer. (**Functional**)
  * `Approve Task`: Calls RPC `reviewDailyDprTask` with `status='Approved'`. Updates approved quantity in MySQL. Does **not** deduct inventory yet. (**Fully Functional**)
  * `Reject Task`: Calls RPC `reviewDailyDprTask` with `status='Rejected'`. Requires a mandatory review reason. (**Fully Functional**)
  * `Request Correction`: Calls RPC `reviewDailyDprTask` with `status='Correction Required'`. Unlocks the report for supervisor correction. (**Fully Functional**)
  * `Confirm approval of over-target work`: Checkbox required when reported quantity exceeds planned target. (**Functional**)
  * `Approve Material Consumption`: Submits RPC `approveDailyDprMaterials`. Deducts stock from inventory and records `stockMovements` entry. (**Fully Functional**)
  * `Reverse material approval`: Prompts for audit reason and submits RPC `reverseDailyDprMaterials`. Refunds stock to inventory. (**Fully Functional**)

---

### Page 13: Today's Assigned Work (`DailyDprView.tsx` with `mode="daily"`)
* **Purpose:** Mobile-friendly daily reporting screen exclusively for Site Supervisors.
* **Visible Elements:**
  * Header displaying current date, supervisor name, and site selector.
  * Cards for each task assigned to this supervisor for today.
  * Inputs per task:
    * Actual completed quantity.
    * Supervisor remarks (optional).
    * Reason for incomplete / zero work (mandatory if actual < planned).
  * Photo attachment count and preview list.
* **Buttons:**
  * `Take photo`: Triggers device camera directly via HTML5 `<input capture="environment">`. (**Functional**)
  * `Upload photos`: Opens gallery/file selector for JPG/PNG files up to 15 MB. (**Functional**)
  * `Remove` (on photo): Removes photo before submission. (**Functional**)
  * `SUBMIT DAILY DPR` (Sticky footer):
    * **Action:** Uploads photos to `/api/uploads` with SHA-256 integrity verification. Submits RPC `submitDailyDpr`. Locks reports as `Pending Manager Approval`.
    * **Status:** **Fully Functional**.
  * `Correct DPR`: Visible in history when a manager has requested correction. Opens past date in correction mode. (**Functional**)

---

### Page 14: Purchase Orders (`PurchaseOrdersView.tsx`)
* **Purpose:** Procurement planning: schedule upcoming purchases, link parties, and track delivery status.
* **Visible Elements:**
  * KPI strip: Scheduled (Not Ordered), Ordered, Delivered counts.
  * Search input (party name, GST, material, ID).
  * Status filter dropdown: All, Scheduled, Ordered, Delivered.
  * Purchase Orders Table: Scheduled Date, Party / GST, Project, Item / Quantity, Order Amount, Status, Action buttons.
* **Buttons:**
  * `Supplier Invoices`: Switches view to `SupplierInvoicesView`. (**Functional**)
  * `Add Purchase Order`: Opens purchase order creation form. (**Functional**)
  * `Save Scheduled Purchase Order` (Submit): Dispatches RPC `savePlannedOrder`. Saves party to supplier master automatically. Sets alert 2 days prior to scheduled order date. (**Fully Functional**)
  * `Cancel`: Closes order form. (**Functional**)
  * `Edit` (on table row): Edits scheduled order before it is placed. (**Functional**)
  * `Mark Ordered` (on table row): Dispatches RPC `markSiteOrderOrdered`. Marks item as ordered, creates inventory item, and enables site delivery. (**Fully Functional**)
  * `Delivery` (on table row): Navigates to `site-desk` for challan photo submission. (**Functional**)
  * `View Receipt` (on table row): Opens delivery receipt photo in new tab. (**Functional**)

---

### Page 15: Supplier Invoices (`SupplierInvoicesView` in `PurchasesView.tsx`)
* **Purpose:** Review supplier tax invoices, inspect uploaded PDFs/images, verify figures, and record payments.
* **Visible Elements:**
  * Outstanding Payables KPI, Total Payments Cleared KPI, Pending Approvals KPI.
  * Search bar, Payment status filter (All, Unpaid, Partially Paid, Paid, Overdue), Approval filter.
  * Bills Table: Invoice No, Supplier, Project, Category, Date, Taxable, GST, Total, Paid, Verification Status, Approval Status, Action buttons.
* **Buttons:**
  * `Back to Purchase Orders`: Toggles back to `PurchaseOrdersView`. (**Functional**)
  * `Upload Bill`: Opens `InvoiceUploadModal`. (**Functional**)
  * `View Invoice` (Eye icon): Opens full-screen private invoice document viewer. (**Functional**)
  * `Verify Invoice` (Check icon): Calls RPC `verifyPurchaseInvoice`. Sets status to `verified`. (**Fully Functional**)
  * `Reject` (X icon): Sets verification status to `rejected`. (**Fully Functional**)
  * `Approve Bill` (ShieldCheck icon): Approves verified invoice for accounting and payment. (**Fully Functional**)
  * `Record Payment` (CreditCard icon): Opens payment modal to disburse funds. (**Functional**)
  * `Confirm & Deduct from Bank` (in Payment Modal): Dispatches `/api/command` `recordSupplierPayment`. Deducts amount from selected bank account, creates bank transaction, updates bill payment status. (**Fully Functional**)
  * Document Viewer Controls: `Zoom In`, `Zoom Out`, `Full Screen`, `Download`, `Close`. (**Fully Functional**)

---

### Page 16: Upload Bill Modal (`InvoiceUploadModal.tsx`)
* **Purpose:** Modal form to enter supplier bills and attach original tax invoice documents.
* **Visible Elements:**
  * Left pane: Live preview of selected PDF or image file.
  * Right pane form: Supplier Name, Supplier GSTIN, Invoice Number, Invoice Date, Due Date, Project selector, Category, Material Details, Taxable Amount (₹), Auto-calculated CGST/SGST/IGST, Total Amount (₹), GST Recoverable checkbox.
  * Duplicate invoice detection warning banner.
* **Buttons:**
  * `Close (X)` / `Cancel`: Discards modal. (**Functional**)
  * `Select File`: File input accepting PDF, JPG, PNG up to 10 MB. (**Functional**)
  * `Save Bill & Document` (Submit):
    * **Action:** Uploads file to private storage, executes `addPurchaseBill` command in MySQL, links supplier, validates that taxable + taxes match total amount.
    * **Status:** **Fully Functional**.

---

### Page 17: Suppliers & Ledgers (`SuppliersView.tsx`)
* **Purpose:** Overview of all suppliers created via purchase orders, showing order totals, delivered values, payments, and running balances.
* **Visible Elements:**
  * Search input (supplier name, GST, phone).
  * Master Suppliers Table: Supplier / GST, Placed POs, Ordered amount, Delivered amount, Paid amount, Pending balance, Action.
  * Supplier Detail Drill-down (when a supplier is selected):
    * Supplier contact card (GSTIN, Phone, Address).
    * Financial metrics: Ordered, Delivered, Paid, Pending.
    * Orders Table: Order date, Material/Qty, Delivery status, Order amount, Paid, Pending, Payment status, Inform Payment controls.
    * Historical invoice records accordion.
* **Buttons:**
  * `View ledger`: Opens supplier drill-down ledger. (**Functional**)
  * `Back to suppliers`: Returns to master supplier list. (**Functional**)
  * `Paid`: Quick-marks an order as fully paid. Dispatches RPC `setSupplierOrderPaymentStatus`. (**Fully Functional**)
  * `Unpaid`: Quick-marks an order as unpaid (0 paid). (**Fully Functional**)
  * `Save amount`: Saves partial payment amount for an order without touching banking accounts. (**Fully Functional**)

---

### Page 18: Daily Site Expenses (`DailyExpensesView.tsx`)
* **Purpose:** Fast tabular grid entry for day-to-day site expenses (diesel, tea, transport, minor repairs) and review/reversal of saved expenses.
* **Visible Elements:**
  * Tab 1: **Grid Entry**; Tab 2: **Saved Expenses**.
  * Summary Cards: Total Valid Expense (₹), Number of Entries, Incomplete count.
  * Spreadsheet Grid Table:
    * #, Category dropdown, Description input, Paid From Account dropdown, Payment Method dropdown, Vendor/Recipient input, Amount (₹) input, Trash remove button.
    * Expandable Row Details: Expense Date, Project selector (or Shared Company Expense), Bill/Reference No, Remarks, `Copy defaults` button.
  * Keyboard shortcut guidance pill (Tab, Enter, Ctrl+Enter, Ctrl+S).
* **Buttons:**
  * `New Row` / `Add Row`: Appends a fresh row to the entry grid. (**Functional**)
  * `Copy defaults`: Clones date, project, account, and category from existing row. (**Functional**)
  * `Remove row` (Trash icon): Deletes row from draft. (**Functional**)
  * `Clear All`: Resets entry grid. (**Functional**)
  * `Save Expenses & Deduct Accounts` (Submit):
    * **Action:** Validates batch, dispatches command `saveBulkExpenses`. Atomically creates expense rows, deducts funds from selected cash/bank accounts, and generates account transactions in MySQL.
    * **Status:** **Fully Functional**.
  * **Saved Expenses Tab:**
    * Filters: From date, To date, Project, Category, Payment Account, Search text.
    * Filtered expenses table with detailed drill-down accordion.
    * Delete (Trash icon) on row: Prompts confirmation, dispatches command `deleteExpense`. Reverses expense and refunds cash back to the original bank account. (**Fully Functional**)

---

### Page 19: Workers & Staff (`WorkersView.tsx`)
* **Purpose:** Roster of construction tradesmen, daily-wage labourers, and site supervisory staff.
* **Visible Elements:**
  * KPI Cards: Total Registered Workforce, Daily Wage Laborers count, Monthly Site Staff count.
  * Search bar (name, phone, trade) and Trade filter dropdown.
  * Workers Cards Grid: Displays Worker Name, Trade pill, Phone, Standard Wage Rate (₹/day or month), Overtime Rate, UPI/Bank details, and Active/Inactive toggle icon.
* **Buttons:**
  * `Register New Worker`: Opens registration modal. (**Functional**)
  * Active/Inactive Toggle (CheckCircle/XCircle icon): Calls `updateWorker(id, { active: !active })`. Dispatches command `updateWorker`. (**Fully Functional**)
  * `Register Worker` (in Modal): Calls `addWorker`. Saves new worker to MySQL. (**Fully Functional**)
  * `Cancel` (in Modal): Closes registration modal. (**Functional**)

---

### Page 20: Financial Reports (20 Reports) (`FinancialReportsView.tsx`)
* **Purpose:** Generation and multi-format export of 20 core contractor reports.
* **Visible Elements:**
  * Left sidebar list of 20 reports:
    1. Project Profit and Loss
    2. Consolidated Business Profit & Loss
    3. Project Budget versus Actual
    4. Estimated Cost to Complete
    5. Supplier Ledger & Running Statements
    6. Purchase Register
    7. Unpaid Supplier Bills
    8. Client Receivables & Aging
    9. Client Billing Register (RA Bills)
    10. Cash and Bank Book
    11. Daily Site Expense Report
    12. Worker Attendance Muster Report
    13. Salary Register
    14. Worker Advance Register
    15. Subcontractor Payment Report
    16. Material Inventory & Usage Report
    17. Monthly Income & Expenditure
    18. GST Transaction Summary
    19. Project ROI & Profit Margin Comparison
    20. Audit & Reconciliation Report
  * Project filter dropdown.
  * Interactive preview table of the generated report.
* **Buttons:**
  * `Excel`: Generates sanitized `.xlsx` file using `fflate` with formula-injection neutralization (`exportToExcel`). (**Fully Functional**)
  * `CSV`: Generates `.csv` file with RFC 4180 escaping (`exportToCSV`). (**Fully Functional**)
  * `PDF`: Generates formal PDF report using `jspdf` (`generatePDFReport`). (**Fully Functional**)
  * `Print`: Triggers browser print dialog (`window.print()`). (**Fully Functional**)
* **Important Audit Finding:** As detailed in Section 5, only **Reports 1, 2, 7, and 8** have dedicated calculation engines. Reports 3–6 and 9–20 display a generic 15-row transaction fallback in the UI table preview.

---

### Page 21: Material Inventory & Site Stores (`InventoryView.tsx`)
* **Purpose:** Central warehouse inventory tracking, stock movements, and site issues.
* **Visible Elements:**
  * KPI Cards: Total Inventory Valuation (₹), Tracked SKUs count, Low Stock Alerts count.
  * Search bar (material name, SKU, category).
  * Inventory Table: Material Name & SKU, Category, Unit, Current Stock, Average Unit Rate, Total Stock Value, Status badge (In Stock / Low Stock).
* **Buttons:**
  * `Add Material Item`: Opens item registration modal. (**Functional**)
  * `Issue Stock to Project`: Opens material issue modal. (**Functional**)
  * `Add Material` (in Modal): Dispatches `/api/command` `addInventoryItem`. Creates inventory record in MySQL. (**Fully Functional**)
  * `Issue to Site Project` (in Modal): Dispatches `/api/command` `recordStockMovement`. Deducts stock from warehouse, increases project consumption cost. (**Fully Functional**)
  * `Cancel` (in Modals): Closes modals. (**Functional**)

---

### Page 22: Smart Alerts (`NotificationsView.tsx`)
* **Purpose:** Notification feed alerting management to cost overruns, payment delays, and pending approvals.
* **Visible Elements:**
  * List of alert cards color-coded by severity: High (Rose), Medium (Amber), Info (Blue).
  * Each card shows: Severity icon, Title, Explanatory message, Trigger date.
* **Buttons:**
  * `Take Action`: Navigates to the relevant module tab (e.g. `purchases`, `expenses`). (**Functional**)
  * `Dismiss alert` (X icon): Calls `dismissAlert(id)`. Dispatches `/api/command` `dismissAlert` which archives the alert record in MySQL. (**Fully Functional**)

---

### Page 23: User & Access Management (`TeamPermissionsView.tsx` + `UserAccessManagement.tsx`)
* **Purpose:** Enterprise identity management, role administration, project authorization, and access auditing.
* **Visible Elements:**
  * Employees Table: Employee Name, Login ID, Role, Status (Active/Deactivated, Password change required badge), Assigned Projects list, Action buttons.
  * Custom Roles Accordion: Dropdown to pick/create role, Role name input, 30+ granular permission checkboxes.
  * Account & Permission History Accordion: Immutable audit log displaying action, timestamp, actor, target user, and before/after permission diffs.
  * Historical Browser Team Profiles Accordion: Read-only display of legacy browser profiles.
* **Buttons:**
  * `Initialize default roles`: Submits RPC `initializeEnterpriseAccounts`. Idempotently seeds standard system role templates. (**Fully Functional**)
  * `+ Create Employee`: Opens employee creation drawer. (**Functional**)
  * `Edit access` (on table row): Opens drawer to edit role, project assignments, active status, or granular permission overrides. (**Functional**)
  * `Reset password` (on table row): Prompts for new temporary password. Revokes active sessions and forces password reset on next login. (**Fully Functional**)
  * `Generate temporary password` (in Drawer & Reset Modal): Generates secure temporary password. (**Functional**)
  * `Save Employee` (in Drawer): Dispatches RPC `createEnterpriseEmployee` or `updateEnterpriseEmployee`. Validates employee seat limit in MySQL. (**Fully Functional**)
  * `Save Role` (in Custom Roles): Dispatches RPC `createCustomRole` or `updateCustomRole`. (**Fully Functional**)
  * **Native Admin Tools (Accordion):**
    * `Review browser records`: Collects legacy localStorage records for migration. (**Functional**)
    * `Choose JSON backup`: Parses external JSON backup. (**Functional**)
    * `Download encrypted enterprise backup`: Calls RPC `createBackup` and downloads `.erpbak` archive. (**Fully Functional**)
    * `Review abandoned uploads`: Calls RPC `cleanupUploads` to identify and delete orphaned files older than 24 hours. (**Fully Functional**)

---

### Page 24: Business Profile & Configurations (`BusinessSettingsView.tsx`)
* **Purpose:** Organization settings, GSTIN/PAN configuration, bank invoice footer details, and full database backups.
* **Visible Elements:**
  * Company Legal Profile Form: Legal Name, Display Name, Trade Category, GSTIN, PAN, Phone, Email, Registered Address, City, State, Pincode.
  * Default Bank Details Form: Bank Name, Account Number, IFSC Code, Branch.
  * Accounting Preferences: Active Financial Year, Base Currency (`INR (₹)`), Enable Inventory toggle.
  * Database & Data Management Section.
* **Buttons:**
  * `Save Business Profile` (Submit):
    * **Action:** Calls `updateBusiness`. POSTs complete JSON to `/api/profile`. Updates `enterprises.profile` in MySQL.
    * **Status:** **Fully Functional**.
  * `Download Encrypted Database & File Backup`: Calls RPC `createBackup` and downloads `.erpbak` file. (**Fully Functional**)
  * `Reset Demo Sample Data` / `Wipe Clean`: Disabled in server production mode to prevent data loss. Displays warning. (**Safeguarded / Blocked**)

---

## 5. FUNCTIONAL AND NON-FUNCTIONAL FEATURES

### 5.1 Verified Fully Working Features (Backed by MySQL & Server APIs)
1. **Authentication & Session Security:** HttpOnly cookie sessions, scrypt password hashing, session version rotation on password change or deactivation, login rate-limiting (brute-force lock).
2. **First-Time Password Change & Forced Resets:** Flow ensures no employee can access business data with a default/temporary password.
3. **Multi-Tenant Data Isolation:** Scoped queries using `enterprise_id` and assigned `projectIds`. Platform owner cannot view business records; employees cannot view unassigned projects.
4. **Daily Site Register (Dynamic v2):** Full dynamic rows for materials, machinery run hours (with overnight calculations), cement running balance carry-forward, and labour muster with autocomplete suggestions.
5. **Work Assignment & Scheduled DPRs:** Manager schedules activities; assigned supervisor submits actuals with 1–5 photos; manager reviews; idempotent approval prevents double-counting.
6. **Separate Material Consumption Authorization:** DPR quantity approval does not deduct stock; a separate material approval is required, preventing accidental inventory drain.
7. **Purchase Orders & Site Delivery Receipt:** Scheduled PO alerts 2 days prior; 'Mark Ordered' pushes item to inventory; site delivery requires challan photo and updates stock.
8. **Bulk Site Expenses:** Fast spreadsheet grid entry with keyboard shortcuts (Ctrl+S, Enter), project and shared expense tagging, account fund deduction, and expense reversal.
9. **Encrypted Enterprise Backups:** AES-256-GCM full database and private original file backup into `.erpbak` packages.
10. **File Upload & Image Sanitization:** Private storage, EXIF stripping, Sharp WebP thumbnail creation, and SHA-256 hash checks.
11. **Project Archival:** Admin: Editor can delete projects, archiving the record while retaining linked accounting and history.

### 5.2 Non-Functional, Incomplete or Display-Only Features
1. **Financial Reports UI Fallback (16 of 20 Reports):**
   * *Status:* **Incomplete / Display-Only**.
   * *Detail:* While Reports 1 (`project_pl`), 2 (`consolidated_pl`), 7 (`unpaid_supplier_bills`), and 8 (`client_receivables_aging`) run actual calculations, Reports 3–6 and 9–20 fall back to rendering the first 15 records from the `transactions` table. The exports (Excel/CSV/PDF) export this fallback data rather than dedicated calculations for those 16 reports.
2. **Platform Dashboard MRR Metric:**
   * *Status:* **Display-Only**.
   * *Detail:* In `PlatformEnterpriseAccounts` / `PlatformAdmin`, Monthly Recurring Revenue (MRR) displays `"Not aggregated"`. No recurring subscription billing engine is integrated.
3. **Public SaaS Marketing Website (`SaaSAccess.tsx`):**
   * *Status:* **Dormant / Unmounted**.
   * *Detail:* The marketing website pages (pricing, features, contact) and public registration forms exist in the source code but are bypassed by `App.tsx`, which mounts `HostingerApp` directly.
4. **Online Subscription Checkout:**
   * *Status:* **Non-Functional**.
   * *Detail:* There is no active payment gateway (Razorpay, Stripe) connected for customer self-serve SaaS subscriptions. Licenses must be provisioned manually by the Platform Owner.
5. **Email & SMS Notifications:**
   * *Status:* **Not Implemented**.
   * *Detail:* Employee credentials, password resets, and purchase alerts are displayed on-screen or managed in-app; no SMTP or SMS gateway is configured.

### 5.3 Explicitly Retired Features (HTTP 410 Gone)
The enterprise owners explicitly retired several legacy browser-only or obsolete modules. Calling their commands returns HTTP 410:
* **Retired Standalone Commands:** `addSupplier`, `updateSupplier`, `addClient`, `updateClient`, `addClientInvoice`, `updateClientInvoice`, `recordClientReceipt`, `saveOperations`, `transferFunds`, `recordAttendance`, `recordBulkAttendance`, `approveAttendance`, `addWorkerAdvance`, `disburseSalary`, `addSubcontractor`, `updateSubcontractor`, `addSubcontractBill`, `approveSubcontractBill`, `paySubcontractBill`.
* **Retired Tabs:** `profit-analytics`, `clients`, `invoices`, `audit`, `project-budget`, `banking`, `operations`, `attendance`, `salary`, `subcontractors`.
* *Surviving Alternative:* Suppliers are managed through Purchase Orders; site expenses handle cash outflows; daily labour is captured in the Daily Site Register; project billing is tracked in Project Contracts.

---

## 6. COMPLETE SOFTWARE WORKFLOW

```mermaid
flowchart TD
    %% Bootstrap and Setup
    PO[Platform Owner] -->|1. Provisions Enterprise & Admin: Editor| DB[(MySQL Database)]
    SA[Admin: Editor] -->|2. Signs in with Temp Password| PC[Change Password Screen]
    PC -->|3. Sets Permanent Password| OB[Business Onboarding]
    OB -->|4. Saves Legal Profile & Bank Info| UM[User & Access Management]
    
    %% Employee Provisioning
    UM -->|5. Creates Employees & Assigns Projects| EMP[Employees / Site Supervisors]
    EMP -->|6. Sign in & Change Temp Password| WORK[Operational Dashboards]
    
    %% Construction Workflow
    subgraph Construction_Execution [Daily Construction Workflow]
        MGR[Project Manager] -->|7. Schedules Work & Target Qty| WA[Work Assignment]
        WA -->|8. Daily Task Appears on Date| SUP[Site Supervisor]
        SUP -->|9. Submits Actual Work + Site Photos| DPR[Daily Progress Report]
        DPR -->|10. Reviews & Approves Quantity| REV[DPR Approvals]
        REV -->|11. Separately Approves Materials| MAT[Material Consumption]
        MAT -->|12. Deducts Stock Automatically| INV[Material Inventory]
    end
    
    %% Procurement Workflow
    subgraph Procurement_Flow [Purchases & Expenses Workflow]
        PO_PLAN[Purchase Manager / PM] -->|13. Schedules Purchase Order| PO_LIST[Purchase Orders]
        PO_LIST -->|14. Marks Ordered| PO_ORDERED[Ordered State]
        PO_ORDERED -->|15. Arrives at Site + Challan Photo| DESK[Site Desk Delivery]
        DESK -->|16. Adds to Warehouse Stock| INV
        PO_ORDERED -->|17. Informs Payment Outside Software| SUPP[Supplier Ledger]
        SITE_EXP[Site Staff] -->|18. Records Bulk Site Expenses| EXP[Daily Site Expenses]
        EXP -->|19. Deducts Cash/Bank Balance| BANK[Cash & Bank Accounts]
    end
    
    %% Financial Rollup
    INV --> ROLLUP[Project & Business Profit Engine]
    EXP --> ROLLUP
    MAT --> ROLLUP
    ROLLUP --> DASH[Main Financial Dashboard]
    ROLLUP --> PRJ[Project Detail Cockpit]
    ROLLUP --> REP[Financial Reports Engine]
```

### Detailed Workflow Step-by-Step

#### 1. Setup & Provisioning Workflow
1. The **Platform Owner** logs into the platform console and creates an Enterprise tenant with an initial **Admin: Editor** account, defining seat limits and module access.
2. The **Admin: Editor** signs in using their temporary credentials, is immediately intercepted by the Password Change Gate, and sets a permanent password (>=12 chars).
3. The **Admin: Editor** is presented with the one-time **Business Profile Onboarding** form, entering company name, GSTIN, PAN, address, and logo.
4. The **Admin: Editor** navigates to **User & Access Management** and creates employee accounts (Project Managers, Accounts, Purchase Managers, Site Supervisors), assigning each to specific projects.

#### 2. Daily Site Operations Workflow
1. **Work Scheduling:** Project Manager opens **Work Assignment**, selects a project and tomorrow's date, adds activities (e.g. "Ground Floor Tile Work", target: 100 sq ft), assigns a site supervisor, and defines optional material consumption ratios (e.g. 0.4 bags cement per sq ft).
2. **Field Execution:** On the scheduled date, the assigned **Site Supervisor** opens **Today's Assigned Work** on phone or tablet. They enter actual progress (e.g. 12 sq ft), add remarks (or a mandatory reason if work was incomplete), take live photos via the camera, and click **SUBMIT DAILY DPR**.
3. **Manager Review:** The Project Manager opens **DPR Approvals**, reviews the reported quantity, and inspects full-size photos. The manager clicks **Approve Task** (updating approved progress to 12 sq ft, remaining 88 sq ft, 12% progress).
4. **Material Authorization:** The manager inspects the **Material Consumption Proposal**. Clicking **Approve Material Consumption** executes an atomic inventory transaction: warehouse cement stock decreases, and material cost is added to the project.

#### 3. Procurement & Site Expense Workflow
1. **Purchase Planning:** Purchase Manager opens **Purchase Orders** and schedules a material purchase (e.g. 200 bags cement, ₹70,000) for a target date. The supplier is auto-saved to master records.
2. **Ordering:** Two days before the order date, a purchase alert appears on the Manager Site Desk. When ordered, user clicks **Mark Ordered**.
3. **Site Receipt:** When materials arrive at the job site, the supervisor opens **Site Desk**, selects the ordered item, takes a photo of the delivery challan, and submits. The system marks the order delivered and increments inventory stock.
4. **Daily Expenses:** Site staff spend cash on diesel, vehicle hire, and tea. In **Daily Site Expenses**, they enter rows in the bulk grid, select the cash account, and click **Save Expenses**. The funds are deducted from the account balance in real time.

#### 4. Financial Tracking & Profitability
1. As expenses and verified material bills accumulate, the **Project Detail Cockpit** and **Main Dashboard** automatically recalculate:
   * $\text{Revised Contract} = \text{Original Contract} + \text{Approved Variations}$
   * $\text{Actual Incurred Cost} = \text{Materials} + \text{Labour} + \text{Subcontract} + \text{Expenses}$
   * $\text{Recorded Profit} = \text{Client Billed Revenue} - \text{Actual Incurred Cost}$
   * $\text{Liquid Cash} = \sum \text{Bank Accounts} + \sum \text{Petty Cash}$
   * $\text{Working Capital} = \text{Liquid Cash} + \text{Receivables} - \text{Payables} - \text{Pending Wages}$

---

## 7. USER ROLES AND PERMISSIONS

### 7.1 Built-in System Roles
The software defines **7 distinct roles** with strictly partitioned capabilities:

| Role Name | Identifier | UI Label | Primary Responsibilities |
|---|---|---|---|
| **Platform Owner** | `platform_owner=1` | Platform Owner | Enterprise tenant provisioning, license activation/suspension. Cannot view customer financial data. |
| **Admin: Editor** | `admin_editor` | Admin: Editor (Super Admin) | Enterprise owner. Full access to all business profiles, user management, project creation, financial approvals, backups. |
| **Project Manager** | `project_manager` | Project Manager | Project editing, work allocation, inventory management, daily site register, worker oversight. |
| **Accounts** | `accounts` | Accounts | Recording supplier payments, bill verification, daily expense logging, banking oversight, financial reports. |
| **Purchase Manager**| `purchase_manager` | Purchase Manager | Purchase planning, supplier master management, purchase order submission, invoice upload. |
| **Admin: Reviewer** | `admin_reviewer` | Read-Only Auditor | Auditing and inspection; bill verification; DPR task review; viewing operational and financial reports. |
| **Site Supervisor** | `site_supervisor` | Site Supervisor | Field reporting only: daily DPR submissions, delivery challan photo uploads, Daily Site Register data entry. |

### 7.2 Role Permission Matrix

| Module / Action | Platform Owner | Admin: Editor | Project Manager | Accounts | Purchase Manager | Admin: Reviewer | Site Supervisor |
|---|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| **Platform Provisioning** | **YES** | NO | NO | NO | NO | NO | NO |
| **Manage Users & Credentials** | NO | **YES** | NO | NO | NO | NO | NO |
| **Business Profile / Settings** | NO | **YES** | NO | NO | NO | NO | NO |
| **Download Database Backups** | NO | **YES** | NO | NO | NO | NO | NO |
| **Create / Delete Projects** | NO | **YES** | NO | NO | NO | NO | NO |
| **View Assigned Projects** | NO | **YES** | **YES** | **YES** | **YES** | **YES** | **YES** |
| **Allocate Work (DPR)** | NO | **YES** | **YES** | NO | NO | NO | NO |
| **Submit Daily Work (DPR)** | NO | NO | NO | NO | NO | NO | **YES** |
| **Review / Approve Work (DPR)**| NO | **YES** | **YES** | NO | NO | **YES** | NO |
| **Approve Material Stock Usage**| NO | **YES** | **YES** | NO | NO | NO | NO |
| **Create Purchase Orders** | NO | **YES** | NO | NO | **YES** | NO | NO |
| **Verify / Review Bills** | NO | **YES** | NO | **YES** | NO | **YES** | NO |
| **Approve Bills for Payment** | NO | **YES** | NO | NO | NO | **YES** | NO |
| **Record Supplier Payments** | NO | **YES** | NO | **YES** | NO | NO | NO |
| **Record Daily Site Expenses** | NO | **YES** | NO | **YES** | NO | NO | NO |
| **Reverse / Delete Expenses** | NO | **YES** | NO | NO | NO | NO | NO |
| **Add / Issue Inventory Stock**| NO | **YES** | **YES** | NO | NO | NO | NO |
| **Manage Workers Muster** | NO | **YES** | **YES** | NO | NO | NO | NO |
| **Daily Site Register Entry** | NO | **YES** | **YES** | NO | NO | NO | **YES** |
| **View Financial Reports** | NO | **YES** | NO | **YES** | NO | NO | NO |

### 7.3 Custom Roles & Granular Overrides
* The database allows the Admin: Editor to define **Custom Roles** stored in the `roles` table.
* The system provides **Individual Permission Overrides** per user (stored in `users.permission_override` as a JSON array).
* If an override is `null`, the user inherits their role's default permissions; if specified, the override controls their exact permissions.
* The server prevents assigning administrative powers (`users.manage`, `roles.manage`, `siteProgress.manage`, `data.backup`) to non-admin roles through overrides.

---

## 8. DATA FLOW BETWEEN PAGES

```
[Purchase Orders] ──(Mark Ordered)──> [Inventory Items]
       │                                     │
       └──(Delivery Receipt Photo)──> [Available Stock]
                                             │
[Work Assignment] ──(Material Ratio)──> [DPR Proposals]
                                             │
[Daily DPR Submission] ──(Approved Qty)─> [Stock Movement] ──> [Project Material Cost]
                                                                        │
[Daily Site Expenses] ──(Deduction)──> [Cash/Bank Balance] ──> [Project Actual Cost]
                                                                        │
[Approved Variations] ──(Contract Revision)────────────────────> [Project Contract Value]
                                                                        │
                                                               [Live Recorded Profit]
                                                                        │
                                                               [Main Dashboard & Reports]
```

1. **Purchases to Inventory & Site Desk:**
   * Planning a purchase order in `PurchaseOrdersView` saves the vendor into the `suppliers` collection.
   * Marking the order as "Ordered" auto-provisions an inventory item in `InventoryView` with 0 stock.
   * Confirming delivery in `SiteDeskView` with a challan photo increments `currentStock` in `inventory` and writes a `purchase_in` entry in `stockMovements`.
2. **Work Assignment to DPR & Inventory:**
   * Material rules set during **Work Assignment** link an inventory SKU to a work item.
   * When the supervisor submits actual quantities in **Today's Assigned Work**, a material usage proposal is computed.
   * When the manager approves the material consumption in **DPR Approvals**, `currentStock` decreases, a `site_issue` record is logged, and the monetary value is added to `projectMaterialCost`.
3. **Expenses to Banking & Profitability:**
   * Entering rows in **Daily Site Expenses** reduces `currentBalance` in `accounts` and generates `transactions` rows.
   * The incurred expenses are rolled into `expensesCost` for the project, directly reducing `actualRecordedProfit` on the **Main Dashboard**.
4. **Daily Site Register to Autocomplete Masters:**
   * Typing custom materials, equipment names, or labour trades in **Daily Site Register** persists those names into `dailyRegisterMaster` records upon save.
   * On future dates, the autocomplete endpoint (`searchDailyRegisterMasters`) suggests those exact names.
   * Cement balances carry forward date-by-date across historical entries automatically.

---

## 9. EXISTING PROBLEMS AND DUPLICATE FEATURES

### 9.1 Duplicate Features & Code Redundancy
1. **Dual Purchase Order & Supplier Invoice Screens:**
   * The software contains two overlapping procurement screens: `PurchaseOrdersView` (focused on planning, party selection, and scheduled dates) and `SupplierInvoicesView` within `PurchasesView` (focused on uploaded tax invoice documents and GST).
   * Having both creates confusion regarding whether an order or a bill is the primary payable record.
2. **Dual Historical Data Importers:**
   * Both `NativeAdminTools.tsx` (in User Management) and `SaaSAccess.tsx` (`LegacyMigrationPanel`) contain code to import browser localStorage backups.
3. **Repeated Project Progress Bars:**
   * Project progress is tracked both via simple percentage inputs in `ProjectDetailView` and via approved quantities in `DailyDprView`. These two metrics do not synchronize automatically.

### 9.2 Non-Functional or Misleading UI Elements
1. **Financial Reports Fallback Display:**
   * 16 of the 20 financial reports in `FinancialReportsView.tsx` do not perform specific calculations; they display a placeholder of the first 15 transactions from `transactions`. The user receives no warning that the report is a placeholder.
2. **Platform Dashboard Revenue Metrics:**
   * The Platform Admin overview displays "MRR: Not aggregated". The dashboard displays cards for paid transactions and pending payments that do not reflect actual recurring revenue.
3. **Demo Persona Switcher in Header:**
   * The header dropdown presents a list of team personas and a "Reset Demo Data" option. In production mode, clicking them does nothing or displays an error because client-side persona switching is blocked.

### 9.3 UI/UX Problems & Workflow Confusion
1. **Icon Duplication in Navigation:**
   * Three sidebar items in the Projects section share the identical `ClipboardCheck` icon, making visual scanning difficult.
2. **Navigation Split Across Two Dashboards:**
   * Having both `Manager / Site Desk` and `Main Dashboard` is confusing. Users are unsure whether to look at the Site Desk for operational alerts or the Main Dashboard for financial KPIs.
3. **Invoice Upload vs Purchase Order Disconnect:**
   * Uploading a supplier invoice bill in `InvoiceUploadModal` does not automatically mark a planned purchase order as fulfilled; they exist as independent records in the database.

### 9.4 Technical & Test Environment Findings
1. **Test Runner Timeout Sensitivity:**
   * `tests/server-core.test.mjs` contains a test ("Hostinger listener responds promptly even with an unavailable database") that failed during the audit with an assertion timeout (2857ms vs 3000ms threshold). On slower CPU cycles or Windows cold starts, this test can intermittently fail.
2. **Orphaned Firebase Codebase:**
   * A complete Firebase backend remains in `functions/` and `src/components/auth/SaaSAccess.tsx`. While safely ignored by the active Express runtime, it adds bundle size overhead and code clutter.

---

## 10. FINAL SUMMARY WITH TOTAL COUNTS

### 10.1 Comprehensive Metrics Count

| Metric Category | Count | Details / Breakdown |
|---|---|---|
| **Active Application Pages & Modals** | **24** | 20 view tabs + 4 auth/onboarding/admin screens |
| **Preserved Marketing Website Pages** | **10** | Home, Features, Industries, Pricing, About, Contact, FAQ, Privacy, Terms, Refund |
| **Total System Pages Documented** | **34** | 24 Active ERP + 10 Preserved Marketing |
| **Sidebar Menu Sections** | **5** | Financial Cockpit, Projects & Contracts, Purchases & Expenses, Labour & Workforce, Reports & Controls |
| **Sidebar Menu Items** | **16** | 14 standard items + 2 conditionally filtered items |
| **Total Buttons Audited** | **128** | Across all active views, headers, forms, footers, and modals |
| **Total Input Forms & Modals** | **19** | Including project creation, invoice upload, expense grid, DPR submit, employee drawer |
| **Total Dropdown Selectors & Filters**| **38** | Project selectors, status filters, trade filters, account selectors, report pickers |
| **Total Database Tables (MySQL)** | **17** | `enterprises`, `roles`, `permissions`, `users`, `user_projects`, `project_sites`, `sessions`, `login_limits`, `erp_records`, `work_categories`, `allocated_work_items`, `work_assignments`, `daily_progress_reports`, `uploaded_files`, `progress_approvals`, `audit_logs`, `idempotency_keys` |
| **Total Automated Tests Executed** | **76** | 75 Passed, 1 Intermittent Timeout Failure |
| **Configured User Roles** | **7** | Platform Owner, Admin: Editor, Project Manager, Accounts, Purchase Manager, Admin: Reviewer, Site Supervisor |
| **Granular Permission Keys** | **32** | Covering projects, purchases, sales, expenses, inventory, workers, attendance, payroll, banking, siteProgress, users, roles |

### 10.2 Final Auditor Verdict & Assessment
The NirmanKhata ERP is a **robust, secure, and thoughtfully architected construction ERP**. Its transaction handling in MySQL, HttpOnly cookie authentication, scrypt password security, sharp image validation, and atomic inventory-deduction workflows are exceptionally well engineered and ready for real-world operations. 

The software's primary areas requiring attention are **UX consolidation** (unifying the dual purchase order/invoice flow, resolving icon duplication, and linking the 16 placeholder financial reports to real SQL aggregations) and **dead code elimination** (cleaning up the unrouted Firebase functions and marketing pages).

---
*End of Complete Software Audit Report.*

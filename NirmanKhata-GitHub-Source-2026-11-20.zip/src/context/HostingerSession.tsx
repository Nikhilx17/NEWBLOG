import React,{createContext,useContext} from 'react';
export const HostingerSessionContext=createContext<any>(null);
export const useHostingerSession=()=>useContext(HostingerSessionContext);

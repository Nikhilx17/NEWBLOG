/**
 * @license
 * NirmanKhata ERP - Primary Contractor Context & Data Store
 * Supports real-time Firestore persistence + LocalStorage instant cache
 */

import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import {
  Business,
  Project,
  Supplier,
  Client,
  PurchaseBill,
  Expense,
  Worker,
  AttendanceRecord,
  WorkerAdvance,
  SalaryPayment,
  Subcontractor,
  SubcontractBill,
  ClientInvoice,
  CashBankAccount,
  AccountTransaction,
  InventoryItem,
  StockMovement,
  SmartAlert,
  AuditLogEntry,
  UserProfile,
  UserRole,
} from '../types';
import {
  INITIAL_USER,
  INITIAL_TEAM,
  INITIAL_BUSINESS,
  INITIAL_CLIENTS,
  INITIAL_SUPPLIERS,
  INITIAL_PROJECTS,
  INITIAL_WORKERS,
  INITIAL_ATTENDANCE,
  INITIAL_WORKER_ADVANCES,
  INITIAL_SALARY_PAYMENTS,
  INITIAL_PURCHASE_BILLS,
  INITIAL_EXPENSES,
  INITIAL_SUBCONTRACTORS,
  INITIAL_SUBCONTRACT_BILLS,
  INITIAL_CLIENT_INVOICES,
  INITIAL_ACCOUNTS,
  INITIAL_TRANSACTIONS,
  INITIAL_INVENTORY,
  INITIAL_STOCK_MOVEMENTS,
  INITIAL_ALERTS,
  INITIAL_AUDIT_LOGS,
} from '../lib/initialData';

interface ContractorContextType {
  serverMode?: boolean;
  allowedTabs?: string[];
  remoteStatus?: string;
  remoteError?: string;
  operations?: any;
  saveOperations?: (next:any,before:any)=>void;
  currentUser: UserProfile;
  setCurrentUser: (user: UserProfile) => void;
  userRole: UserRole;
  setUserRole: (role: UserRole) => void;
  teamMembers: UserProfile[];
  addTeamMember: (member: Omit<UserProfile, 'id' | 'businessId'>) => void;
  
  business: Business;
  updateBusiness: (updates: Partial<Business>) => void;
  
  activeProjectId: string | 'all';
  setActiveProjectId: (id: string | 'all') => void;

  projects: Project[];
  addProject: (project: Omit<Project, 'id' | 'businessId' | 'createdAt'>) => Project;
  updateProject: (id: string, updates: Partial<Project>) => void;
  deleteProject: (id: string) => void | Promise<void>;

  suppliers: Supplier[];
  addSupplier: (supplier: Omit<Supplier, 'id' | 'businessId' | 'createdAt'>) => Supplier;
  updateSupplier: (id: string, updates: Partial<Supplier>) => void;

  clients: Client[];
  addClient: (client: Omit<Client, 'id' | 'businessId' | 'createdAt'>) => Client;
  updateClient: (id: string, updates: Partial<Client>) => void;

  purchaseBills: PurchaseBill[];
  addPurchaseBill: (bill: Omit<PurchaseBill, 'id' | 'businessId' | 'createdAt'> & { id?: string }) => PurchaseBill;
  updatePurchaseBill: (id: string, updates: Partial<PurchaseBill>) => void;
  verifyPurchaseBill: (id: string, status: PurchaseBill['verificationStatus'], notes?: string) => void;
  approvePurchaseBill: (id: string, status: PurchaseBill['approvalStatus']) => void;
  recordSupplierPayment: (billId: string, amount: number, accountId: string, paymentMethod: string, reference: string) => void;

  expenses: Expense[];
  addExpense: (expense: Omit<Expense, 'id' | 'businessId' | 'createdAt'>) => Expense;
  deleteExpense: (id: string) => void;

  workers: Worker[];
  addWorker: (worker: Omit<Worker, 'id' | 'businessId' | 'createdAt'>) => Worker;
  updateWorker: (id: string, updates: Partial<Worker>) => void;

  attendance: AttendanceRecord[];
  recordAttendance: (record: Omit<AttendanceRecord, 'id' | 'businessId'>) => void;
  recordBulkAttendance: (records: Omit<AttendanceRecord, 'id' | 'businessId'>[]) => void;
  approveAttendance: (id: string, approved: boolean) => void;

  workerAdvances: WorkerAdvance[];
  addWorkerAdvance: (advance: Omit<WorkerAdvance, 'id' | 'businessId' | 'createdAt' | 'adjustedAmount' | 'status'>) => WorkerAdvance;

  salaryPayments: SalaryPayment[];
  disburseSalary: (payment: Omit<SalaryPayment, 'id' | 'businessId' | 'createdAt'>) => SalaryPayment;

  subcontractors: Subcontractor[];
  addSubcontractor: (sub: Omit<Subcontractor, 'id' | 'businessId' | 'totalBilled' | 'totalPaid' | 'totalRetention' | 'outstandingBalance'>) => void;
  subcontractBills: SubcontractBill[];
  addSubcontractBill: (bill: Omit<SubcontractBill, 'id' | 'businessId'>) => void;
  paySubcontractBill: (billId: string, amount: number, accountId: string, method: string, ref: string) => void;

  clientInvoices: ClientInvoice[];
  addClientInvoice: (inv: Omit<ClientInvoice, 'id' | 'businessId' | 'createdAt'>) => ClientInvoice;
  updateClientInvoice: (id: string, updates: Partial<ClientInvoice>) => void;
  recordClientReceipt: (invoiceId: string, amount: number, accountId: string, paymentMethod: string, reference: string) => void;

  accounts: CashBankAccount[];
  addAccount: (acc: Omit<CashBankAccount, 'id' | 'businessId'>) => void;
  transferFunds: (fromAccountId: string, toAccountId: string, amount: number, reference: string, notes?: string) => void;

  transactions: AccountTransaction[];
  
  inventory: InventoryItem[];
  addInventoryItem: (item: Omit<InventoryItem, 'id' | 'businessId' | 'stockValue' | 'updatedAt'>) => string;
  recordStockMovement: (mov: Omit<StockMovement, 'id' | 'businessId'>) => void;
  stockMovements: StockMovement[];

  alerts: SmartAlert[];
  dismissAlert: (id: string) => void;

  auditLogs: AuditLogEntry[];
  
  resetToDemoData: () => void;
  clearAllData: () => void;
  isSyncing: boolean;
}

const ContractorContext = createContext<ContractorContextType | null>(null);

const STORAGE_KEY = 'nirmankhata_data_store_v1';

export const ContractorProvider: React.FC<{ children: React.ReactNode; remoteState?:any; remoteCommands?:any; session?:any; remoteStatus?:string; remoteError?:string }> = ({ children,remoteState,remoteCommands,session,remoteStatus,remoteError }) => {
  // Load saved state or fall back to INITIAL_DATA
  const getSavedState = <T,>(key: string, fallback: T): T => {
    if(remoteState)return (remoteState.states[key]??(Array.isArray(fallback)?[]:fallback)) as T;
    try {
      const stored = localStorage.getItem(`${STORAGE_KEY}_${key}`);
      return stored ? JSON.parse(stored) : fallback;
    } catch {
      return fallback;
    }
  };

  const [currentUser, setCurrentUserState] = useState<UserProfile>(() => getSavedState('user', INITIAL_USER));
  const [teamMembers, setTeamMembers] = useState<UserProfile[]>(() => getSavedState('team', INITIAL_TEAM));
  const [business, setBusiness] = useState<Business>(() => getSavedState('business', INITIAL_BUSINESS));
  const [activeProjectId, setActiveProjectId] = useState<string | 'all'>('all');

  const [projects, setProjects] = useState<Project[]>(() => getSavedState('projects', INITIAL_PROJECTS));
  const [suppliers, setSuppliers] = useState<Supplier[]>(() => getSavedState('suppliers', INITIAL_SUPPLIERS));
  const [clients, setClients] = useState<Client[]>(() => getSavedState('clients', INITIAL_CLIENTS));
  const [purchaseBills, setPurchaseBills] = useState<PurchaseBill[]>(() => getSavedState('bills', INITIAL_PURCHASE_BILLS));
  const [expenses, setExpenses] = useState<Expense[]>(() => getSavedState('expenses', INITIAL_EXPENSES));
  const [workers, setWorkers] = useState<Worker[]>(() => getSavedState('workers', INITIAL_WORKERS));
  const [attendance, setAttendance] = useState<AttendanceRecord[]>(() => getSavedState('attendance', INITIAL_ATTENDANCE));
  const [workerAdvances, setWorkerAdvances] = useState<WorkerAdvance[]>(() => getSavedState('advances', INITIAL_WORKER_ADVANCES));
  const [salaryPayments, setSalaryPayments] = useState<SalaryPayment[]>(() => getSavedState('salaries', INITIAL_SALARY_PAYMENTS));
  const [subcontractors, setSubcontractors] = useState<Subcontractor[]>(() => getSavedState('subs', INITIAL_SUBCONTRACTORS));
  const [subcontractBills, setSubcontractBills] = useState<SubcontractBill[]>(() => getSavedState('subbills', INITIAL_SUBCONTRACT_BILLS));
  const [clientInvoices, setClientInvoices] = useState<ClientInvoice[]>(() => getSavedState('invoices', INITIAL_CLIENT_INVOICES));
  const [accounts, setAccounts] = useState<CashBankAccount[]>(() => getSavedState('accounts', INITIAL_ACCOUNTS));
  const [transactions, setTransactions] = useState<AccountTransaction[]>(() => getSavedState('transactions', INITIAL_TRANSACTIONS));
  const [inventory, setInventory] = useState<InventoryItem[]>(() => getSavedState('inventory', INITIAL_INVENTORY));
  const [stockMovements, setStockMovements] = useState<StockMovement[]>(() => getSavedState('stockMovements', INITIAL_STOCK_MOVEMENTS));
  const [alerts, setAlerts] = useState<SmartAlert[]>(() => getSavedState('alerts', INITIAL_ALERTS));
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>(() => getSavedState('audit', INITIAL_AUDIT_LOGS));
  const isSyncing = false;

  // Browser cache is never authoritative for an authenticated server workspace.
  useEffect(() => {
    if(remoteState)return;
    try {
      localStorage.setItem(`${STORAGE_KEY}_user`, JSON.stringify(currentUser));
      localStorage.setItem(`${STORAGE_KEY}_team`, JSON.stringify(teamMembers));
      localStorage.setItem(`${STORAGE_KEY}_business`, JSON.stringify(business));
      localStorage.setItem(`${STORAGE_KEY}_projects`, JSON.stringify(projects));
      localStorage.setItem(`${STORAGE_KEY}_suppliers`, JSON.stringify(suppliers));
      localStorage.setItem(`${STORAGE_KEY}_clients`, JSON.stringify(clients));
      localStorage.setItem(`${STORAGE_KEY}_bills`, JSON.stringify(purchaseBills));
      localStorage.setItem(`${STORAGE_KEY}_expenses`, JSON.stringify(expenses));
      localStorage.setItem(`${STORAGE_KEY}_workers`, JSON.stringify(workers));
      localStorage.setItem(`${STORAGE_KEY}_attendance`, JSON.stringify(attendance));
      localStorage.setItem(`${STORAGE_KEY}_advances`, JSON.stringify(workerAdvances));
      localStorage.setItem(`${STORAGE_KEY}_salaries`, JSON.stringify(salaryPayments));
      localStorage.setItem(`${STORAGE_KEY}_subs`, JSON.stringify(subcontractors));
      localStorage.setItem(`${STORAGE_KEY}_subbills`, JSON.stringify(subcontractBills));
      localStorage.setItem(`${STORAGE_KEY}_invoices`, JSON.stringify(clientInvoices));
      localStorage.setItem(`${STORAGE_KEY}_accounts`, JSON.stringify(accounts));
      localStorage.setItem(`${STORAGE_KEY}_transactions`, JSON.stringify(transactions));
      localStorage.setItem(`${STORAGE_KEY}_inventory`, JSON.stringify(inventory));
      localStorage.setItem(`${STORAGE_KEY}_stockMovements`, JSON.stringify(stockMovements));
      localStorage.setItem(`${STORAGE_KEY}_alerts`, JSON.stringify(alerts));
      localStorage.setItem(`${STORAGE_KEY}_audit`, JSON.stringify(auditLogs));
    } catch (e) {
      console.warn('LocalStorage save failed:', e);
    }
  }, [
    currentUser,
    teamMembers,
    business,
    projects,
    suppliers,
    clients,
    purchaseBills,
    expenses,
    workers,
    attendance,
    workerAdvances,
    salaryPayments,
    subcontractors,
    subcontractBills,
    clientInvoices,
    accounts,
    transactions,
    inventory,
    stockMovements,
    alerts,
    auditLogs,
  ]);

  useEffect(()=>{if(!remoteState)return;
    setCurrentUserState(remoteState.states.user);
    setTeamMembers(remoteState.states.team);
    setBusiness(remoteState.states.business);
    setProjects(remoteState.states.projects);
    setSuppliers(remoteState.states.suppliers);
    setClients(remoteState.states.clients);
    setPurchaseBills(remoteState.states.bills);
    setExpenses(remoteState.states.expenses);
    setWorkers(remoteState.states.workers);
    setAttendance(remoteState.states.attendance);
    setWorkerAdvances(remoteState.states.advances);
    setSalaryPayments(remoteState.states.salaries);
    setSubcontractors(remoteState.states.subs);
    setSubcontractBills(remoteState.states.subbills);
    setClientInvoices(remoteState.states.invoices);
    setAccounts(remoteState.states.accounts);
    setTransactions(remoteState.states.transactions);
    setInventory(remoteState.states.inventory);
    setStockMovements(remoteState.states.stockMovements);
    setAlerts(remoteState.states.alerts);
    setAuditLogs(remoteState.states.audit);
  },[remoteState]);

  // Demo mode remains browser-local. Tenant cloud writes now use trusted
  // Functions; this legacy context is not mounted by authenticated SaaS routes.

  const addAuditLog = useCallback((action: string, module: string, entityId: string, details: string) => {
    const entry: AuditLogEntry = {
      id: `aud-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      businessId: business.id,
      action,
      module,
      entityId,
      user: currentUser.name,
      role: currentUser.role,
      details,
      timestamp: new Date().toISOString(),
    };
    setAuditLogs((prev) => [entry, ...prev]);
  }, [business.id, currentUser.name, currentUser.role]);

  const setCurrentUser = (user: UserProfile) => {
    setCurrentUserState(user);
    addAuditLog('SWITCH_USER', 'Auth', user.id, `Active session switched to ${user.name} (${user.role})`);
  };

  const setUserRole = (role: UserRole) => {
    setCurrentUserState((prev) => ({ ...prev, role }));
  };

  const addTeamMember = (member: Omit<UserProfile, 'id' | 'businessId'>) => {
    const newMember: UserProfile = {
      ...member,
      id: `usr-${Date.now()}`,
      businessId: business.id,
    };
    setTeamMembers((prev) => [...prev, newMember]);
    addAuditLog('ADD_MEMBER', 'Team', newMember.id, `Added team member ${newMember.name} as ${newMember.role}`);
  };

  const updateBusiness = (updates: Partial<Business>) => {
    setBusiness((prev) => ({ ...prev, ...updates }));
    addAuditLog('UPDATE_BUSINESS', 'Settings', business.id, 'Updated business profile details');
  };

  // Projects
  const addProject = (projectData: Omit<Project, 'id' | 'businessId' | 'createdAt'>): Project => {
    const newProject: Project = {
      ...projectData,
      id: `prj-${Date.now()}`,
      businessId: business.id,
      createdAt: new Date().toISOString(),
    };
    setProjects((prev) => [newProject, ...prev]);
    addAuditLog('CREATE_PROJECT', 'Projects', newProject.id, `Created project ${newProject.name} (${newProject.code})`);
    return newProject;
  };

  const updateProject = (id: string, updates: Partial<Project>) => {
    setProjects((prev) =>
      prev.map((p) => {
        if (p.id === id) {
          const updated = { ...p, ...updates };
          // Keep revised contract synchronized
          if (updates.originalContractAmount !== undefined || updates.approvedVariations !== undefined) {
            updated.revisedContractAmount = (updated.originalContractAmount || 0) + (updated.approvedVariations || 0);
          }
          return updated;
        }
        return p;
      })
    );
    addAuditLog('UPDATE_PROJECT', 'Projects', id, `Updated project parameters for ID: ${id}`);
  };

  const deleteProject = (id: string) => {
    setProjects((prev) => prev.filter((p) => p.id !== id));
    addAuditLog('DELETE_PROJECT', 'Projects', id, `Removed project ID: ${id}`);
  };

  // Suppliers & Clients
  const addSupplier = (supData: Omit<Supplier, 'id' | 'businessId' | 'createdAt'>): Supplier => {
    const newSup: Supplier = {
      ...supData,
      id: `sup-${Date.now()}`,
      businessId: business.id,
      createdAt: new Date().toISOString(),
    };
    setSuppliers((prev) => [newSup, ...prev]);
    addAuditLog('CREATE_SUPPLIER', 'Suppliers', newSup.id, `Created supplier ${newSup.name}`);
    return newSup;
  };

  const updateSupplier = (id: string, updates: Partial<Supplier>) => {
    setSuppliers((prev) => prev.map((s) => (s.id === id ? { ...s, ...updates } : s)));
    addAuditLog('UPDATE_SUPPLIER', 'Suppliers', id, `Updated supplier ${id}`);
  };

  const addClient = (clientData: Omit<Client, 'id' | 'businessId' | 'createdAt'>): Client => {
    const newClient: Client = {
      ...clientData,
      id: `cli-${Date.now()}`,
      businessId: business.id,
      createdAt: new Date().toISOString(),
    };
    setClients((prev) => [newClient, ...prev]);
    addAuditLog('CREATE_CLIENT', 'Clients', newClient.id, `Created client ${newClient.name}`);
    return newClient;
  };

  const updateClient = (id: string, updates: Partial<Client>) => {
    setClients((prev) => prev.map((c) => (c.id === id ? { ...c, ...updates } : c)));
    addAuditLog('UPDATE_CLIENT', 'Clients', id, `Updated client ${id}`);
  };

  // Purchases
  const addPurchaseBill = (billData: Omit<PurchaseBill, 'id' | 'businessId' | 'createdAt'> & { id?: string }): PurchaseBill => {
    const newBill: PurchaseBill = {
      ...billData,
      id: billData.id || `bil-${Date.now()}`,
      businessId: business.id,
      createdAt: new Date().toISOString(),
    };
    setPurchaseBills((prev) => [newBill, ...prev]);
    addAuditLog('CREATE_BILL', 'Purchases', newBill.id, `Added bill ${newBill.invoiceNumber} from ${newBill.supplierName} (₹${newBill.totalAmount})`);
    return newBill;
  };

  const updatePurchaseBill = (id: string, updates: Partial<PurchaseBill>) => {
    setPurchaseBills((prev) => prev.map((b) => (b.id === id ? { ...b, ...updates } : b)));
    addAuditLog('UPDATE_BILL', 'Purchases', id, `Updated purchase bill ${id}`);
  };

  const verifyPurchaseBill = (id: string, status: PurchaseBill['verificationStatus'], notes?: string) => {
    setPurchaseBills((prev) =>
      prev.map((b) =>
        b.id === id
          ? {
              ...b,
              verificationStatus: status,
              verifiedBy: `${currentUser.name} (${currentUser.role})`,
              verifiedAt: new Date().toISOString(),
              notes: notes ? `${b.notes || ''} [Verification: ${notes}]` : b.notes,
            }
          : b
      )
    );
    addAuditLog('VERIFY_BILL', 'Purchases', id, `Verification status changed to ${status} by ${currentUser.name}`);
  };

  const approvePurchaseBill = (id: string, status: PurchaseBill['approvalStatus']) => {
    setPurchaseBills((prev) =>
      prev.map((b) =>
        b.id === id
          ? {
              ...b,
              approvalStatus: status,
              approvedBy: `${currentUser.name} (${currentUser.role})`,
            }
          : b
      )
    );
    addAuditLog('APPROVE_BILL', 'Purchases', id, `Approval status set to ${status} by ${currentUser.name}`);
  };

  const recordSupplierPayment = (
    billId: string,
    amount: number,
    accountId: string,
    paymentMethod: string,
    reference: string
  ) => {
    const bill = purchaseBills.find((b) => b.id === billId);
    if (!bill) return;

    const account = accounts.find((a) => a.id === accountId);
    const newPaidAmount = (bill.amountPaid || 0) + amount;
    const isFullyPaid = newPaidAmount >= bill.totalAmount;

    // Update Bill
    setPurchaseBills((prev) =>
      prev.map((b) =>
        b.id === billId
          ? {
              ...b,
              amountPaid: newPaidAmount,
              paymentStatus: isFullyPaid ? 'paid' : 'partially_paid',
            }
          : b
      )
    );

    // Deduct from Cash/Bank Account
    if (account) {
      setAccounts((prev) =>
        prev.map((a) => (a.id === accountId ? { ...a, currentBalance: a.currentBalance - amount } : a))
      );
    }

    // Record Account Outflow Transaction
    const txn: AccountTransaction = {
      id: `txn-${Date.now()}`,
      businessId: business.id,
      accountId,
      accountName: account?.name || 'Account',
      date: new Date().toISOString().split('T')[0],
      type: 'outflow',
      amount,
      category: 'Supplier Bill',
      referenceNumber: reference,
      description: `Payment to ${bill.supplierName} for Bill ${bill.invoiceNumber}`,
      projectId: bill.projectId,
      relatedEntityId: bill.id,
      balanceAfter: (account?.currentBalance || 0) - amount,
      createdAt: new Date().toISOString(),
    };
    setTransactions((prev) => [txn, ...prev]);

    addAuditLog(
      'RECORD_SUPPLIER_PAYMENT',
      'Banking',
      billId,
      `Paid ₹${amount.toLocaleString('en-IN')} to ${bill.supplierName} from ${account?.name}`
    );
  };

  // Expenses
  const addExpense = (expData: Omit<Expense, 'id' | 'businessId' | 'createdAt'>): Expense => {
    const newExp: Expense = {
      ...expData,
      id: `exp-${Date.now()}`,
      businessId: business.id,
      createdAt: new Date().toISOString(),
    };
    setExpenses((prev) => [newExp, ...prev]);

    // Deduct from designated account
    const account = accounts.find((a) => a.id === expData.accountId);
    if (account) {
      setAccounts((prev) =>
        prev.map((a) => (a.id === expData.accountId ? { ...a, currentBalance: a.currentBalance - expData.amount } : a))
      );

      const txn: AccountTransaction = {
        id: `txn-${Date.now()}`,
        businessId: business.id,
        accountId: expData.accountId,
        accountName: account.name,
        date: expData.date,
        type: 'outflow',
        amount: expData.amount,
        category: 'Daily Expense',
        description: `${expData.category}: ${expData.description}`,
        projectId: expData.projectId,
        relatedEntityId: newExp.id,
        balanceAfter: account.currentBalance - expData.amount,
        createdAt: new Date().toISOString(),
      };
      setTransactions((prev) => [txn, ...prev]);
    }

    addAuditLog('RECORD_EXPENSE', 'Expenses', newExp.id, `Recorded expense of ₹${newExp.amount} for ${newExp.category}`);
    return newExp;
  };

  const deleteExpense = (id: string) => {
    setExpenses((prev) => prev.filter((e) => e.id !== id));
    addAuditLog('DELETE_EXPENSE', 'Expenses', id, `Deleted expense ID: ${id}`);
  };

  // Workers & Muster Roll
  const addWorker = (workerData: Omit<Worker, 'id' | 'businessId' | 'createdAt'>): Worker => {
    const newWorker: Worker = {
      ...workerData,
      id: `wrk-${Date.now()}`,
      businessId: business.id,
      createdAt: new Date().toISOString(),
    };
    setWorkers((prev) => [...prev, newWorker]);
    addAuditLog('ADD_WORKER', 'Workers', newWorker.id, `Registered worker ${newWorker.name} (${newWorker.trade})`);
    return newWorker;
  };

  const updateWorker = (id: string, updates: Partial<Worker>) => {
    setWorkers((prev) => prev.map((w) => (w.id === id ? { ...w, ...updates } : w)));
    addAuditLog('UPDATE_WORKER', 'Workers', id, `Updated profile for worker ${id}`);
  };

  const recordAttendance = (rec: Omit<AttendanceRecord, 'id' | 'businessId'>) => {
    const newAtt: AttendanceRecord = {
      ...rec,
      id: `att-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      businessId: business.id,
    };
    setAttendance((prev) => [newAtt, ...prev]);
  };

  const recordBulkAttendance = (records: Omit<AttendanceRecord, 'id' | 'businessId'>[]) => {
    const newAtts = records.map((r) => ({
      ...r,
      id: `att-${Date.now()}-${Math.floor(Math.random() * 10000)}`,
      businessId: business.id,
    }));
    setAttendance((prev) => [...newAtts, ...prev]);
    addAuditLog('BULK_ATTENDANCE', 'Attendance', `bulk-${Date.now()}`, `Marked attendance for ${records.length} workers`);
  };

  const approveAttendance = (id: string, approved: boolean) => {
    setAttendance((prev) => prev.map((a) => (a.id === id ? { ...a, supervisorApproved: approved } : a)));
  };

  const addWorkerAdvance = (
    advData: Omit<WorkerAdvance, 'id' | 'businessId' | 'createdAt' | 'adjustedAmount' | 'status'>
  ): WorkerAdvance => {
    const newAdv: WorkerAdvance = {
      ...advData,
      id: `adv-${Date.now()}`,
      businessId: business.id,
      adjustedAmount: 0,
      status: 'active',
      createdAt: new Date().toISOString(),
    };
    setWorkerAdvances((prev) => [newAdv, ...prev]);

    // Outflow from cash account
    const account = accounts.find((a) => a.id === advData.accountId);
    if (account) {
      setAccounts((prev) =>
        prev.map((a) => (a.id === advData.accountId ? { ...a, currentBalance: a.currentBalance - advData.amount } : a))
      );
      const txn: AccountTransaction = {
        id: `txn-${Date.now()}`,
        businessId: business.id,
        accountId: advData.accountId,
        accountName: account.name,
        date: advData.date,
        type: 'outflow',
        amount: advData.amount,
        category: 'Worker Advance',
        description: `Advance paid to ${advData.workerName} (${advData.reason || 'Personal'})`,
        projectId: advData.projectId,
        relatedEntityId: newAdv.id,
        balanceAfter: account.currentBalance - advData.amount,
        createdAt: new Date().toISOString(),
      };
      setTransactions((prev) => [txn, ...prev]);
    }

    addAuditLog('ISSUE_ADVANCE', 'Workers', newAdv.id, `Issued advance of ₹${newAdv.amount} to ${newAdv.workerName}`);
    return newAdv;
  };

  const disburseSalary = (paymentData: Omit<SalaryPayment, 'id' | 'businessId' | 'createdAt'>): SalaryPayment => {
    const newPayment: SalaryPayment = {
      ...paymentData,
      id: `sal-${Date.now()}`,
      businessId: business.id,
      createdAt: new Date().toISOString(),
    };
    setSalaryPayments((prev) => [newPayment, ...prev]);

    // Adjust worker advances if advances were deducted
    if (paymentData.advancesDeducted > 0) {
      let remainingToDeduct = paymentData.advancesDeducted;
      setWorkerAdvances((prev) =>
        prev.map((adv) => {
          if (adv.workerId === paymentData.workerId && adv.status === 'active' && remainingToDeduct > 0) {
            const availableAdjust = adv.amount - adv.adjustedAmount;
            const deduction = Math.min(availableAdjust, remainingToDeduct);
            remainingToDeduct -= deduction;
            const updatedAdjusted = adv.adjustedAmount + deduction;
            return {
              ...adv,
              adjustedAmount: updatedAdjusted,
              status: updatedAdjusted >= adv.amount ? 'fully_adjusted' : 'active',
            };
          }
          return adv;
        })
      );
    }

    // Outflow from bank/cash account
    const account = accounts.find((a) => a.id === paymentData.accountId);
    if (account) {
      setAccounts((prev) =>
        prev.map((a) =>
          a.id === paymentData.accountId ? { ...a, currentBalance: a.currentBalance - paymentData.amountPaid } : a
        )
      );
      const txn: AccountTransaction = {
        id: `txn-${Date.now()}`,
        businessId: business.id,
        accountId: paymentData.accountId,
        accountName: account.name,
        date: paymentData.paymentDate,
        type: 'outflow',
        amount: paymentData.amountPaid,
        category: 'Labour Salary',
        referenceNumber: paymentData.paymentReference,
        description: `Salary disbursement for ${paymentData.workerName} (${paymentData.salaryPeriod})`,
        relatedEntityId: newPayment.id,
        balanceAfter: account.currentBalance - paymentData.amountPaid,
        createdAt: new Date().toISOString(),
      };
      setTransactions((prev) => [txn, ...prev]);
    }

    addAuditLog(
      'DISBURSE_SALARY',
      'Workers',
      newPayment.id,
      `Disbursed net salary ₹${newPayment.amountPaid} to ${newPayment.workerName} for ${newPayment.salaryPeriod}`
    );
    return newPayment;
  };

  // Subcontractors
  const addSubcontractor = (sub: Omit<Subcontractor, 'id' | 'businessId' | 'totalBilled' | 'totalPaid' | 'totalRetention' | 'outstandingBalance'>) => {
    const newSub: Subcontractor = {
      ...sub,
      id: `sub-${Date.now()}`,
      businessId: business.id,
      totalBilled: 0,
      totalPaid: 0,
      totalRetention: 0,
      outstandingBalance: 0,
    };
    setSubcontractors((prev) => [...prev, newSub]);
    addAuditLog('ADD_SUBCONTRACTOR', 'Subcontractors', newSub.id, `Registered subcontractor ${newSub.name}`);
  };

  const addSubcontractBill = (bill: Omit<SubcontractBill, 'id' | 'businessId'>) => {
    const newBill: SubcontractBill = {
      ...bill,
      id: `sbl-${Date.now()}`,
      businessId: business.id,
    };
    setSubcontractBills((prev) => [newBill, ...prev]);
    addAuditLog('ADD_SUB_BILL', 'Subcontractors', newBill.id, `Added sub bill ${newBill.billNumber} (₹${newBill.grossAmount})`);
  };

  const paySubcontractBill = (billId: string, amount: number, accountId: string, method: string, ref: string) => {
    setSubcontractBills((prev) =>
      prev.map((b) => {
        if (b.id === billId) {
          const newPaid = b.amountPaid + amount;
          return {
            ...b,
            amountPaid: newPaid,
            status: newPaid >= b.netPayable ? 'paid' : 'partially_paid',
          };
        }
        return b;
      })
    );

    const account = accounts.find((a) => a.id === accountId);
    if (account) {
      setAccounts((prev) =>
        prev.map((a) => (a.id === accountId ? { ...a, currentBalance: a.currentBalance - amount } : a))
      );
      const txn: AccountTransaction = {
        id: `txn-${Date.now()}`,
        businessId: business.id,
        accountId,
        accountName: account.name,
        date: new Date().toISOString().split('T')[0],
        type: 'outflow',
        amount,
        category: 'Subcontractor Payment',
        referenceNumber: ref,
        description: `Payment to subcontractor for bill ${billId}`,
        balanceAfter: account.currentBalance - amount,
        createdAt: new Date().toISOString(),
      };
      setTransactions((prev) => [txn, ...prev]);
    }
  };

  // Client Billing & Collections
  const addClientInvoice = (invData: Omit<ClientInvoice, 'id' | 'businessId' | 'createdAt'>): ClientInvoice => {
    const newInv: ClientInvoice = {
      ...invData,
      id: `inv-${Date.now()}`,
      businessId: business.id,
      createdAt: new Date().toISOString(),
    };
    setClientInvoices((prev) => [newInv, ...prev]);
    addAuditLog(
      'CREATE_CLIENT_INVOICE',
      'Client Billing',
      newInv.id,
      `Raised bill ${newInv.invoiceNumber} to ${newInv.clientName} (Gross: ₹${newInv.grossAmount}, Net: ₹${newInv.netAmount})`
    );
    return newInv;
  };

  const updateClientInvoice = (id: string, updates: Partial<ClientInvoice>) => {
    setClientInvoices((prev) => prev.map((inv) => (inv.id === id ? { ...inv, ...updates } : inv)));
    addAuditLog('UPDATE_CLIENT_INVOICE', 'Client Billing', id, `Updated client invoice ${id}`);
  };

  const recordClientReceipt = (
    invoiceId: string,
    amount: number,
    accountId: string,
    paymentMethod: string,
    reference: string
  ) => {
    const invoice = clientInvoices.find((i) => i.id === invoiceId);
    if (!invoice) return;

    const account = accounts.find((a) => a.id === accountId);
    const newReceived = (invoice.amountReceived || 0) + amount;
    const isPaid = newReceived >= invoice.netAmount;

    setClientInvoices((prev) =>
      prev.map((i) =>
        i.id === invoiceId
          ? {
              ...i,
              amountReceived: newReceived,
              paymentStatus: isPaid ? 'paid' : 'partially_paid',
            }
          : i
      )
    );

    if (account) {
      setAccounts((prev) =>
        prev.map((a) => (a.id === accountId ? { ...a, currentBalance: a.currentBalance + amount } : a))
      );
    }

    const txn: AccountTransaction = {
      id: `txn-${Date.now()}`,
      businessId: business.id,
      accountId,
      accountName: account?.name || 'Account',
      date: new Date().toISOString().split('T')[0],
      type: 'inflow',
      amount,
      category: 'Client Payment',
      referenceNumber: reference,
      description: `Payment received from ${invoice.clientName} for invoice ${invoice.invoiceNumber}`,
      projectId: invoice.projectId,
      relatedEntityId: invoice.id,
      balanceAfter: (account?.currentBalance || 0) + amount,
      createdAt: new Date().toISOString(),
    };
    setTransactions((prev) => [txn, ...prev]);

    addAuditLog(
      'RECORD_CLIENT_RECEIPT',
      'Banking',
      invoiceId,
      `Received ₹${amount.toLocaleString('en-IN')} from ${invoice.clientName} into ${account?.name}`
    );
  };

  // Banking & Accounts
  const addAccount = (accData: Omit<CashBankAccount, 'id' | 'businessId'>) => {
    const newAcc: CashBankAccount = {
      ...accData,
      id: `acc-${Date.now()}`,
      businessId: business.id,
    };
    setAccounts((prev) => [...prev, newAcc]);
    addAuditLog('ADD_ACCOUNT', 'Banking', newAcc.id, `Created account ${newAcc.name} with opening ₹${newAcc.openingBalance}`);
  };

  const transferFunds = (
    fromAccountId: string,
    toAccountId: string,
    amount: number,
    reference: string,
    notes?: string
  ) => {
    const fromAcc = accounts.find((a) => a.id === fromAccountId);
    const toAcc = accounts.find((a) => a.id === toAccountId);
    if (!fromAcc || !toAcc || amount <= 0) return;

    setAccounts((prev) =>
      prev.map((a) => {
        if (a.id === fromAccountId) return { ...a, currentBalance: a.currentBalance - amount };
        if (a.id === toAccountId) return { ...a, currentBalance: a.currentBalance + amount };
        return a;
      })
    );

    const now = new Date().toISOString().split('T')[0];
    const txnOut: AccountTransaction = {
      id: `txn-${Date.now()}-1`,
      businessId: business.id,
      accountId: fromAccountId,
      accountName: fromAcc.name,
      date: now,
      type: 'internal_transfer',
      amount,
      category: 'Internal Transfer',
      referenceNumber: reference,
      description: `Internal Transfer to ${toAcc.name} [${notes || 'Fund Rebalancing'}]`,
      isInternalTransfer: true,
      balanceAfter: fromAcc.currentBalance - amount,
      createdAt: new Date().toISOString(),
    };

    const txnIn: AccountTransaction = {
      id: `txn-${Date.now()}-2`,
      businessId: business.id,
      accountId: toAccountId,
      accountName: toAcc.name,
      date: now,
      type: 'internal_transfer',
      amount,
      category: 'Internal Transfer',
      referenceNumber: reference,
      description: `Internal Transfer from ${fromAcc.name} [${notes || 'Fund Rebalancing'}]`,
      isInternalTransfer: true,
      balanceAfter: toAcc.currentBalance + amount,
      createdAt: new Date().toISOString(),
    };

    setTransactions((prev) => [txnOut, txnIn, ...prev]);
    addAuditLog(
      'INTERNAL_TRANSFER',
      'Banking',
      `${fromAccountId}->${toAccountId}`,
      `Transferred ₹${amount.toLocaleString('en-IN')} from ${fromAcc.name} to ${toAcc.name} (Ref: ${reference})`
    );
  };

  // Inventory
  const addInventoryItem = (itemData: Omit<InventoryItem, 'id' | 'businessId' | 'stockValue' | 'updatedAt'>): string => {
    const stockVal = itemData.currentStock * itemData.averagePurchasePrice;
    const newItem: InventoryItem = {
      ...itemData,
      id: `inv-item-${Date.now()}`,
      businessId: business.id,
      stockValue: stockVal,
      updatedAt: new Date().toISOString(),
    };
    setInventory((prev) => [...prev, newItem]);
    addAuditLog('ADD_INVENTORY', 'Inventory', newItem.id, `Added inventory material ${newItem.name}`);
    return newItem.id;
  };

  const recordStockMovement = (mov: Omit<StockMovement, 'id' | 'businessId'>) => {
    const newMov: StockMovement = {
      ...mov,
      id: `mov-${Date.now()}`,
      businessId: business.id,
    };
    setStockMovements((prev) => [newMov, ...prev]);

    // Update item stock
    setInventory((prev) =>
      prev.map((item) => {
        if (item.id === mov.itemId) {
          let updatedQty = item.currentStock;
          if (mov.movementType === 'purchase_in' || mov.movementType === 'site_return') {
            updatedQty += mov.quantity;
          } else if (mov.movementType === 'site_issue') {
            updatedQty = Math.max(0, updatedQty - mov.quantity);
          } else if (mov.movementType === 'adjustment') {
            updatedQty = mov.quantity;
          }
          return {
            ...item,
            currentStock: updatedQty,
            stockValue: updatedQty * item.averagePurchasePrice,
            updatedAt: new Date().toISOString(),
          };
        }
        return item;
      })
    );

    addAuditLog('STOCK_MOVEMENT', 'Inventory', newMov.id, `${mov.movementType} of ${mov.quantity} ${mov.itemName}`);
  };

  const dismissAlert = (id: string) => {
    setAlerts((prev) => prev.filter((a) => a.id !== id));
  };

  const resetToDemoData = () => {
    setCurrentUserState(INITIAL_USER);
    setTeamMembers(INITIAL_TEAM);
    setBusiness(INITIAL_BUSINESS);
    setProjects(INITIAL_PROJECTS);
    setSuppliers(INITIAL_SUPPLIERS);
    setClients(INITIAL_CLIENTS);
    setPurchaseBills(INITIAL_PURCHASE_BILLS);
    setExpenses(INITIAL_EXPENSES);
    setWorkers(INITIAL_WORKERS);
    setAttendance(INITIAL_ATTENDANCE);
    setWorkerAdvances(INITIAL_WORKER_ADVANCES);
    setSalaryPayments(INITIAL_SALARY_PAYMENTS);
    setSubcontractors(INITIAL_SUBCONTRACTORS);
    setSubcontractBills(INITIAL_SUBCONTRACT_BILLS);
    setClientInvoices(INITIAL_CLIENT_INVOICES);
    setAccounts(INITIAL_ACCOUNTS);
    setTransactions(INITIAL_TRANSACTIONS);
    setInventory(INITIAL_INVENTORY);
    setStockMovements(INITIAL_STOCK_MOVEMENTS);
    setAlerts(INITIAL_ALERTS);
    setAuditLogs(INITIAL_AUDIT_LOGS);
    setActiveProjectId('all');
    localStorage.clear();
  };

  const clearAllData = () => {
    const blankBiz: Business = {
      id: `biz-${Date.now()}`,
      name: 'My Construction & Contracting Firm',
      ownerUid: currentUser.id,
      contractorType: 'Civil & Building Construction',
      phone: '',
      email: currentUser.email,
      address: '',
      financialYear: '2026-2027',
      currency: 'INR (₹)',
      enableInventory: true,
      createdAt: new Date().toISOString(),
    };
    setBusiness(blankBiz);
    setProjects([]);
    setSuppliers([]);
    setClients([]);
    setPurchaseBills([]);
    setExpenses([]);
    setWorkers([]);
    setAttendance([]);
    setWorkerAdvances([]);
    setSalaryPayments([]);
    setSubcontractors([]);
    setSubcontractBills([]);
    setClientInvoices([]);
    setAccounts([
      {
        id: `acc-${Date.now()}-1`,
        businessId: blankBiz.id,
        name: 'Bank Current Account',
        accountType: 'Bank Account',
        openingBalance: 0,
        currentBalance: 0,
        isDefault: true,
      },
      {
        id: `acc-${Date.now()}-2`,
        businessId: blankBiz.id,
        name: 'Site Cash in Hand',
        accountType: 'Cash in Hand',
        openingBalance: 0,
        currentBalance: 0,
        isDefault: false,
      },
    ]);
    setTransactions([]);
    setInventory([]);
    setStockMovements([]);
    setAlerts([]);
    setAuditLogs([]);
    setActiveProjectId('all');
  };

  return (
    <ContractorContext.Provider
      value={{
        currentUser,
        setCurrentUser,
        userRole: currentUser.role,
        setUserRole,
        teamMembers,
        addTeamMember,
        business,
        updateBusiness,
        activeProjectId,
        setActiveProjectId,
        projects,
        addProject,
        updateProject,
        deleteProject,
        suppliers,
        addSupplier,
        updateSupplier,
        clients,
        addClient,
        updateClient,
        purchaseBills,
        addPurchaseBill,
        updatePurchaseBill,
        verifyPurchaseBill,
        approvePurchaseBill,
        recordSupplierPayment,
        expenses,
        addExpense,
        deleteExpense,
        workers,
        addWorker,
        updateWorker,
        attendance,
        recordAttendance,
        recordBulkAttendance,
        approveAttendance,
        workerAdvances,
        addWorkerAdvance,
        salaryPayments,
        disburseSalary,
        subcontractors,
        addSubcontractor,
        subcontractBills,
        addSubcontractBill,
        paySubcontractBill,
        clientInvoices,
        addClientInvoice,
        updateClientInvoice,
        recordClientReceipt,
        accounts,
        addAccount,
        transferFunds,
        transactions,
        inventory,
        addInventoryItem,
        recordStockMovement,
        stockMovements,
        alerts,
        dismissAlert,
        auditLogs,
        resetToDemoData,
        clearAllData,
        isSyncing,
        ...(remoteCommands?{...remoteCommands,serverMode:true,isSyncing:Boolean(remoteStatus),allowedTabs:session.tabs.map((t:any)=>t.id),remoteStatus,remoteError,operations:remoteState.operations,saveOperations:remoteCommands.saveOperations}:{}),
      }}
    >
      {children}
    </ContractorContext.Provider>
  );
};

export const useContractor = () => {
  const context = useContext(ContractorContext);
  if (!context) {
    throw new Error('useContractor must be used within ContractorProvider');
  }
  return context;
};

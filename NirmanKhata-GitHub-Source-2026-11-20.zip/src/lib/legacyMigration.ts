export interface LegacyRecord { collection: string; id: string; data: Record<string, unknown> }
export interface LegacyBundle { schemaVersion: 1; exportedAt: string; sourceId: string; possibleSampleData: boolean; records: LegacyRecord[] }

const STORE = 'nirmankhata_data_store_v1';
const entityKeys: Array<[string,string]> = [
  ['projects','projects'],['suppliers','suppliers'],['clients','clients'],['bills','purchaseBills'],
  ['expenses','expenses'],['workers','workers'],['attendance','attendance'],['advances','advances'],
  ['salaries','salaries'],['subs','subcontractors'],['subbills','subcontractBills'],['invoices','invoices'],
  ['accounts','accounts'],['transactions','transactions'],['inventory','inventory'],['stockMovements','stockMovements'],
  ['alerts','alerts'],['audit','auditEvents'],
];
const operationKeys: Array<[string,string]> = [
  ['boq','boq'],['requisitions','requisitions'],['siteReports','siteReports'],['siteTasks','siteTasks'],
  ['equipment','equipment'],['statementRows','bankStatementRows'],
];

function parse(value: string | null): any { if (!value) return null; try { return JSON.parse(value); } catch { throw new Error('A local ERP data item could not be read as JSON. Export was stopped without changing local data.'); } }
function rows(collection: string, value: unknown): LegacyRecord[] {
  if (value == null) return [];
  if (!Array.isArray(value)) throw new Error(`The ${collection} data is not a list; it was left untouched.`);
  return value.map((data:any) => {
    if (!data || typeof data !== 'object' || typeof data.id !== 'string' || !data.id) throw new Error(`A ${collection} item has no usable record ID; export was stopped.`);
    return { collection, id: data.id, data };
  });
}

export async function collectCurrentLegacyData(): Promise<LegacyBundle> {
  const business = parse(localStorage.getItem(`${STORE}_business`));
  const records: LegacyRecord[] = [];
  const legacyCategoryIds = new Map<string,string>();
  const team = parse(localStorage.getItem(`${STORE}_team`));
  const teamIds = new Set<string>(Array.isArray(team) ? team.map((p:any)=>p?.id).filter((id:any)=>typeof id==='string') : []);
  if (business?.id) records.push({ collection: 'legacyBusinessSnapshots', id: business.id, data: business });
  const owner = parse(localStorage.getItem(`${STORE}_user`));
  if (owner?.id && !teamIds.has(owner.id)) records.push({ collection: 'legacyTeamProfiles', id: owner.id, data: owner });
  for (const [key,collection] of entityKeys) records.push(...rows(collection,parse(localStorage.getItem(`${STORE}_${key}`))));
  if (Array.isArray(team)) records.push(...rows('legacyTeamProfiles',team));
  const operationsKey = business?.id ? `nirmankhata_operations_v1_${business.id}` : '';
  if (operationsKey) {
    const operations = parse(localStorage.getItem(operationsKey)) || {};
    for (const [key,collection] of operationKeys) records.push(...rows(collection,operations[key]));
    for (const legacy of rows('siteProgressCategories',operations.workCategories)) {
      if (legacy.id.length > 100) throw new Error(`Work category ID ${legacy.id} is too long to migrate safely.`);
      const id=`legacyWork_${legacy.id}`;legacyCategoryIds.set(legacy.id,id);
      records.push({collection:'siteProgressCategories',id,data:{...legacy.data,id,legacySourceId:legacy.id,legacyUnassigned:true,projectIds:[],active:false,status:'Needs project assignment',normalizedName:String(legacy.data.name||'').trim().replace(/\s+/g,' ').toLocaleLowerCase('en')}});
    }
    for (const report of records.filter(r=>r.collection==='siteReports')) {
      const legacyId=report.data.categoryId;
      if(typeof legacyId==='string'&&legacyCategoryIds.has(legacyId))report.data.categoryId=legacyCategoryIds.get(legacyId);
    }
  }
  // The local progress module keeps original photos in IndexedDB, separate
  // from localStorage. Include those blobs in the reviewed migration bundle so
  // the existing attachment uploader can move them into private cloud storage.
  const progressReports=records.filter(r=>r.collection==='siteReports'&&typeof r.data.photoId==='string');
  if(progressReports.length&&typeof indexedDB!=='undefined'){
    const db=await new Promise<IDBDatabase>((resolve,reject)=>{const req=indexedDB.open('nirmankhata-site-photos',1);req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);});
    try{
      for(const report of progressReports){
        const blob=await new Promise<Blob|undefined>((resolve,reject)=>{const req=db.transaction('photos','readonly').objectStore('photos').get(String(report.data.photoId));req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);});
        if(!blob)continue;
        const contentType=blob.type||'image/jpeg';if(!['image/jpeg','image/png'].includes(contentType))throw new Error(`The site photo for report ${report.id} has an unsupported file type; local data was left untouched.`);
        const bytes=new Uint8Array(await blob.arrayBuffer());let binary='';for(let i=0;i<bytes.length;i+=0x8000)binary+=String.fromCharCode(...bytes.subarray(i,i+0x8000));
        report.data.photoDataUrl=`data:${contentType};base64,${btoa(binary)}`;
        report.data.photoFileName=typeof report.data.photoName==='string'?report.data.photoName:`site-report-${report.id}.${contentType==='image/png'?'png':'jpg'}`;
      }
    }finally{db.close();}
  }
  const dedup = new Set<string>();
  for (const row of records) {
    const key = `${row.collection}/${row.id}`;
    if (dedup.has(key)) throw new Error(`Duplicate ID ${key} found across local data. Review/export was stopped.`);
    dedup.add(key);
  }
  const possibleSampleData = business?.id === 'biz-001' || records.some(r => /^usr-00[1-6]$/.test(r.id));
  return {
    schemaVersion: 1,
    exportedAt: new Date().toISOString(),
    sourceId: `browser-local-v1-${business?.id || 'unknown'}`,
    possibleSampleData,
    records,
  };
}

export function parseLegacyBundle(value: unknown): LegacyBundle {
  const bundle = value as LegacyBundle;
  if (!bundle || bundle.schemaVersion !== 1 || !Array.isArray(bundle.records) || bundle.records.length > 100000) throw new Error('This file is not a supported NirmanKhata data export.');
  if (typeof bundle.sourceId !== 'string' || !bundle.sourceId) throw new Error('This export is missing its source identity.');
  for (const record of bundle.records) {
    if (!record || typeof record.collection !== 'string' || typeof record.id !== 'string' || !record.data || typeof record.data !== 'object') throw new Error('This export contains an invalid record.');
  }
  const keys = new Set<string>();
  for (const row of bundle.records) { const key=`${row.collection}/${row.id}`; if(keys.has(key)) throw new Error(`Duplicate record ${key} in export.`);keys.add(key); }
  return bundle;
}

export function inspectLegacyRelationships(bundle: LegacyBundle) {
  const ids = new Map<string,Set<string>>();
  bundle.records.forEach(r=>{const set=ids.get(r.collection)||new Set<string>();set.add(r.id);ids.set(r.collection,set)});
  const refs: Array<[string,string,string]> = [
    ['projects','clientId','clients'],['purchaseBills','projectId','projects'],['purchaseBills','supplierId','suppliers'],
    ['invoices','projectId','projects'],['invoices','clientId','clients'],['expenses','projectId','projects'],
    ['attendance','workerId','workers'],['attendance','projectId','projects'],['advances','workerId','workers'],
    ['salaries','workerId','workers'],['subcontractBills','projectId','projects'],['subcontractBills','subcontractorId','subcontractors'],
    ['stockMovements','itemId','inventory'],['stockMovements','projectId','projects'],['transactions','accountId','accounts'],
  ];
  const warnings:string[]=[];
  for(const [collection,field,target] of refs){
    const targetIds=ids.get(target)||new Set();
    for(const row of bundle.records.filter(r=>r.collection===collection)){
      const value=row.data[field];
      if(typeof value==='string'&&value&&!targetIds.has(value))warnings.push(`${collection}/${row.id} references ${target} record ${value}, which is not in this export.`);
    }
  }
  return warnings;
}

export function legacySummary(bundle: LegacyBundle) {
  const counts:Record<string,number>={};
  const totals:Record<string,number>={purchaseBills:0,invoices:0,expenses:0,salaries:0,transactions:0,advances:0};
  const amountField:Record<string,string>={purchaseBills:'totalAmount',invoices:'netAmount',expenses:'amount',salaries:'amountPaid',transactions:'amount',advances:'amount'};
  for(const row of bundle.records){
    counts[row.collection]=(counts[row.collection]||0)+1;
    const field=amountField[row.collection];if(field)totals[row.collection]+=Number(row.data[field])||0;
  }
  return {counts,totals,recordCount:bundle.records.length};
}

export async function moveInlineAttachments(
  records: LegacyRecord[], tenantId: string, sourceId: string, onProgress?: (done:number,total:number)=>void,
): Promise<LegacyRecord[]> {
  const locations:Array<{recordIndex:number;path:(string|number)[];dataUrl:string;name:string}> = [];
  records.forEach((record,recordIndex)=>{
    const walk=(value:any,path:(string|number)[])=>{
      if(typeof value==='string'&&/^data:[^;,]+;base64,/i.test(value)){
        const filePath=path.join('.');
        const name=typeof record.data.documentName==='string'?record.data.documentName:typeof record.data.photoFileName==='string'?record.data.photoFileName:`${record.collection}-${record.id}-${filePath.split('.').at(-1)||'file'}`;
        locations.push({recordIndex,path,dataUrl:value,name});return;
      }
      if(Array.isArray(value))value.forEach((child,index)=>walk(child,[...path,index]));
      else if(value&&typeof value==='object')Object.entries(value).forEach(([key,child])=>walk(child,[...path,key]));
    };
    walk(record.data,[]);
  });
  if(!locations.length)return records;
  const result=records.map(row=>({collection:row.collection,id:row.id,data:JSON.parse(JSON.stringify(row.data)) as Record<string,unknown>}));
  const getUpload=async(payload:any)=>{const {call}=await import('./api');return call('createLegacyAttachmentUpload',payload)};
  const finalize=async(payload:any)=>{const {call}=await import('./api');return call('finalizeLegacyAttachmentUpload',payload)};
  for(let i=0;i<locations.length;i++){
    const location=locations[i];
    const match=location.dataUrl.match(/^data:([^;,]+);base64,([\s\S]+)$/i);
    if(!match)throw new Error(`Could not read the attachment on ${records[location.recordIndex].collection}/${records[location.recordIndex].id}.`);
    const [,contentType,encoded]=match;
    if(!['image/jpeg','image/png','image/webp','application/pdf'].includes(contentType))throw new Error(`The attachment type ${contentType} is not supported yet. The source record has not been changed.`);
    const binary=atob(encoded);const bytes=Uint8Array.from(binary,c=>c.charCodeAt(0));
    if(bytes.byteLength>10*1024*1024)throw new Error(`An attachment is larger than 10 MB. The source record has not been changed.`);
    const digestBytes=await crypto.subtle.digest('SHA-256',bytes);
    const sha256=Array.from(new Uint8Array(digestBytes),b=>b.toString(16).padStart(2,'0')).join('');
    const record=records[location.recordIndex];
    const upload=await getUpload({tenantId,sourceId,collection:record.collection,recordId:record.id,field:location.path.join('.'),fileName:location.name,contentType,size:bytes.byteLength,sha256});
    if(!upload.alreadyUploaded){
      const response=await fetch(upload.uploadUrl,{method:'PUT',headers:{'Content-Type':contentType,'X-ERP-Request':'1'},body:new Blob([bytes],{type:contentType})});
      if(!response.ok)throw new Error('Secure document upload failed. Retry after checking the connection; local source data remains unchanged.');
      await finalize({tenantId,documentId:upload.documentId});
    }
    let parent:any=result[location.recordIndex].data;
    for(const segment of location.path.slice(0,-1))parent=parent[segment as any];
    const last=location.path[location.path.length-1];
    parent[last as any]=`/api/files/${upload.documentId}`;
    onProgress?.(i+1,locations.length);
  }
  return result;
}

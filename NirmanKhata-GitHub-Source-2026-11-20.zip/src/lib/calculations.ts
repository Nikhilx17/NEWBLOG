/**
 * @license
 * NirmanKhata Financial Calculation Engine
 * High-precision, decimal-safe contractor accounting logic
 */

import {
  Project,
  PurchaseBill,
  Expense,
  AttendanceRecord,
  SalaryPayment,
  WorkerAdvance,
  SubcontractBill,
  ClientInvoice,
  PaymentRecord,
  CashBankAccount,
  AccountTransaction,
  ProjectProfitSummary,
} from '../types';

/**
 * Format number to Indian Currency Format: ₹ 1,25,000.00
 */
export function formatINR(amount: number | undefined | null, includeDecimals = true): string {
  if (amount === undefined || amount === null || isNaN(amount)) {
    return '₹0';
  }

  const isNegative = amount < 0;
  const absAmount = Math.abs(amount);

  let formatted = '';
  if (includeDecimals) {
    formatted = absAmount.toLocaleString('en-IN', {
      maximumFractionDigits: 2,
      minimumFractionDigits: 2,
    });
  } else {
    formatted = Math.round(absAmount).toLocaleString('en-IN');
  }

  return `${isNegative ? '-' : ''}₹${formatted}`;
}

/**
 * Format to Indian compact words (e.g. ₹ 1.25 Cr, ₹ 45.20 Lakh)
 */
export function formatCompactINR(amount: number | undefined | null): string {
  if (amount === undefined || amount === null || isNaN(amount)) {
    return '₹0';
  }

  const isNegative = amount < 0;
  const abs = Math.abs(amount);

  if (abs >= 10000000) {
    return `${isNegative ? '-' : ''}₹${(abs / 10000000).toFixed(2)} Cr`;
  }
  if (abs >= 100000) {
    return `${isNegative ? '-' : ''}₹${(abs / 100000).toFixed(2)} Lakh`;
  }
  if (abs >= 1000) {
    return `${isNegative ? '-' : ''}₹${(abs / 1000).toFixed(1)} K`;
  }
  return formatINR(amount, false);
}

/**
 * Safe percentage calculation with division by zero guard
 */
export function safePercentage(numerator: number, denominator: number): number {
  if (!denominator || denominator === 0 || isNaN(denominator) || isNaN(numerator)) {
    return 0;
  }
  return (numerator / denominator) * 100;
}

/**
 * Calculate revised contract amount
 * Formula: Original contract amount + Approved variations
 */
export function calculateRevisedContract(original: number, variations: number): number {
  return Number(((original || 0) + (variations || 0)).toFixed(2));
}

/**
 * Calculate incurred project material costs from approved & valid purchase bills
 */
export function calculateProjectMaterialCost(projectId: string, bills: PurchaseBill[]): number {
  return bills
    .filter((b) => b.projectId === projectId && b.approvalStatus !== 'rejected')
    .reduce((sum, b) => {
      // If GST is recoverable, economic cost is taxable amount; otherwise total amount
      const cost = b.isGstRecoverable ? b.taxableAmount : b.totalAmount;
      return sum + (cost || 0);
    }, 0);
}

/**
 * Calculate incurred project labour cost from approved muster attendance
 */
export function calculateProjectLabourCost(projectId: string, attendance: AttendanceRecord[]): number {
  return attendance
    .filter((a) => a.projectId === projectId && a.supervisorApproved !== false)
    .reduce((sum, a) => sum + (a.dailyWageEarned || 0), 0);
}

/**
 * Calculate project daily & miscellaneous site expenses
 */
export function calculateProjectExpenseCost(projectId: string, expenses: Expense[]): number {
  return expenses
    .filter((e) => e.projectId === projectId && e.approvalStatus === 'approved')
    .reduce((sum, e) => sum + (e.amount || 0), 0);
}

/**
 * Calculate subcontractor cost for a project
 */
export function calculateProjectSubcontractCost(projectId: string, subBills: SubcontractBill[]): number {
  return subBills
    .filter((sb) => sb.projectId === projectId && sb.approvalStatus === 'approved')
    .reduce((sum, sb) => sum + (sb.grossAmount || 0), 0);
}

/**
 * Calculate total project incurred cost
 */
export function calculateProjectIncurredCost(
  projectId: string,
  bills: PurchaseBill[],
  expenses: Expense[],
  attendance: AttendanceRecord[],
  subBills: SubcontractBill[]
): {
  materialCost: number;
  labourCost: number;
  expensesCost: number;
  subcontractorCost: number;
  totalIncurredCost: number;
} {
  const materialCost = calculateProjectMaterialCost(projectId, bills);
  const labourCost = calculateProjectLabourCost(projectId, attendance);
  const expensesCost = calculateProjectExpenseCost(projectId, expenses);
  const subcontractorCost = calculateProjectSubcontractCost(projectId, subBills);
  const totalIncurredCost = Number((materialCost + labourCost + expensesCost + subcontractorCost).toFixed(2));

  return {
    materialCost,
    labourCost,
    expensesCost,
    subcontractorCost,
    totalIncurredCost,
  };
}

/**
 * Calculate project profit summary
 */
export function computeProjectProfitSummary(
  project: Project,
  bills: PurchaseBill[],
  expenses: Expense[],
  attendance: AttendanceRecord[],
  subBills: SubcontractBill[],
  clientInvoices: ClientInvoice[]
): ProjectProfitSummary {
  const { materialCost, labourCost, expensesCost, subcontractorCost, totalIncurredCost } =
    calculateProjectIncurredCost(project.id, bills, expenses, attendance, subBills);

  // Client billing & collections for this project
  const projectInvoices = clientInvoices.filter(
    (inv) => inv.projectId === project.id && inv.billingStatus !== 'rejected'
  );
  
  const billedRevenue = projectInvoices.reduce((sum, inv) => sum + (inv.grossAmount || 0), 0);
  const collectedRevenue = projectInvoices.reduce((sum, inv) => sum + (inv.amountReceived || 0), 0);
  const receivableDue = projectInvoices.reduce(
    (sum, inv) => sum + Math.max(0, (inv.netAmount || 0) - (inv.amountReceived || 0)),
    0
  );

  const revisedContract = project.revisedContractAmount || (project.originalContractAmount + (project.approvedVariations || 0));
  const budgetedCost = project.estimatedBudget || 0;
  const budgetVariance = Number((totalIncurredCost - budgetedCost).toFixed(2));
  const costToComplete = project.estimatedCostToComplete || Math.max(0, budgetedCost - totalIncurredCost);
  const estimatedFinalCost = Number((totalIncurredCost + costToComplete).toFixed(2));

  // Actual profit recorded to date: recognized/billed revenue minus actual incurred costs
  const actualRecordedProfit = Number((billedRevenue - totalIncurredCost).toFixed(2));

  // Estimated final profit when complete: revised contract minus estimated total final cost
  const estimatedFinalProfit = Number((revisedContract - estimatedFinalCost).toFixed(2));

  // Profit margin based on billed revenue
  const profitMarginPct = billedRevenue > 0 ? safePercentage(actualRecordedProfit, billedRevenue) : 0;
  const costRoiPct = totalIncurredCost > 0 ? safePercentage(actualRecordedProfit, totalIncurredCost) : 0;

  return {
    projectId: project.id,
    projectName: project.name,
    projectCode: project.code,
    clientName: project.clientName,
    status: project.status,
    revisedContractAmount: revisedContract,
    budgetedCost,
    materialCost,
    labourCost,
    expensesCost,
    subcontractorCost,
    actualIncurredCost: totalIncurredCost,
    budgetVariance,
    costToComplete,
    estimatedFinalCost,
    billedRevenue,
    collectedRevenue,
    receivableDue,
    actualRecordedProfit,
    estimatedFinalProfit,
    profitMarginPct: Number(profitMarginPct.toFixed(1)),
    costRoiPct: Number(costRoiPct.toFixed(1)),
    progressPct: project.progressPct || 0,
  };
}

/**
 * Calculate outstanding client receivables and aging breakdown
 */
export function calculateReceivablesAging(invoices: ClientInvoice[], referenceDate = new Date()): {
  totalReceivable: number;
  current: number; // 0-30 days
  days31to60: number;
  days61to90: number;
  over90Days: number;
} {
  let totalReceivable = 0;
  let current = 0;
  let days31to60 = 0;
  let days61to90 = 0;
  let over90Days = 0;

  invoices.forEach((inv) => {
    if (inv.billingStatus === 'rejected') return;
    const due = Math.max(0, (inv.netAmount || 0) - (inv.amountReceived || 0));
    if (due <= 0) return;

    totalReceivable += due;

    const invoiceDate = new Date(inv.dueDate || inv.invoiceDate);
    const diffTime = referenceDate.getTime() - invoiceDate.getTime();
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays <= 30) {
      current += due;
    } else if (diffDays <= 60) {
      days31to60 += due;
    } else if (diffDays <= 90) {
      days61to90 += due;
    } else {
      over90Days += due;
    }
  });

  return {
    totalReceivable: Number(totalReceivable.toFixed(2)),
    current: Number(current.toFixed(2)),
    days31to60: Number(days31to60.toFixed(2)),
    days61to90: Number(days61to90.toFixed(2)),
    over90Days: Number(over90Days.toFixed(2)),
  };
}

/**
 * Calculate outstanding supplier payables
 */
export function calculateSupplierPayables(bills: PurchaseBill[]): {
  totalPayable: number;
  unpaidBillsCount: number;
  overduePayable: number;
} {
  let totalPayable = 0;
  let unpaidBillsCount = 0;
  let overduePayable = 0;
  const now = new Date();

  bills.forEach((b) => {
    if (b.approvalStatus === 'rejected') return;
    const unpaid = Math.max(0, (b.totalAmount || 0) - (b.amountPaid || 0));
    if (unpaid > 0) {
      totalPayable += unpaid;
      unpaidBillsCount++;
      const dueDate = new Date(b.dueDate || b.invoiceDate);
      if (dueDate < now) {
        overduePayable += unpaid;
      }
    }
  });

  return {
    totalPayable: Number(totalPayable.toFixed(2)),
    unpaidBillsCount,
    overduePayable: Number(overduePayable.toFixed(2)),
  };
}

/**
 * Calculate worker pending salary and outstanding advances
 */
export function calculateWorkerWagesAndAdvances(
  workerId: string,
  attendance: AttendanceRecord[],
  salaries: SalaryPayment[],
  advances: WorkerAdvance[]
): {
  totalEarnedToDate: number;
  totalSalaryPaid: number;
  totalAdvancesTaken: number;
  totalAdvancesAdjusted: number;
  remainingAdvanceBalance: number;
  pendingWagesPayable: number;
} {
  const totalEarnedToDate = attendance
    .filter((a) => a.workerId === workerId && a.supervisorApproved !== false)
    .reduce((sum, a) => sum + (a.dailyWageEarned || 0), 0);

  const totalSalaryPaid = salaries
    .filter((s) => s.workerId === workerId)
    .reduce((sum, s) => sum + (s.amountPaid || 0), 0);

  const totalAdvancesTaken = advances
    .filter((adv) => adv.workerId === workerId)
    .reduce((sum, adv) => sum + (adv.amount || 0), 0);

  const totalAdvancesAdjusted = advances
    .filter((adv) => adv.workerId === workerId)
    .reduce((sum, adv) => sum + (adv.adjustedAmount || 0), 0);

  const remainingAdvanceBalance = Math.max(0, totalAdvancesTaken - totalAdvancesAdjusted);

  // Net payable = Total Earned - (Salary Paid + Advances Deducted)
  const pendingWagesPayable = Math.max(0, totalEarnedToDate - (totalSalaryPaid + totalAdvancesAdjusted));

  return {
    totalEarnedToDate,
    totalSalaryPaid,
    totalAdvancesTaken,
    totalAdvancesAdjusted,
    remainingAdvanceBalance,
    pendingWagesPayable,
  };
}

/**
 * Calculate liquid Cash & Bank balance excluding internal transfers
 */
export function calculateTotalLiquidBalance(accounts: CashBankAccount[]): number {
  return accounts.reduce((sum, acc) => sum + (acc.currentBalance || 0), 0);
}

/**
 * Calculate Working Capital Health:
 * Liquid Cash + Near-Term Receivables - Near-Term Payables - Pending Worker Wages
 */
export function calculateWorkingCapital(
  liquidCash: number,
  clientReceivables: number,
  supplierPayables: number,
  workerWagesPayable: number
): {
  workingCapital: number;
  quickRatio: number;
  isHealthy: boolean;
} {
  const currentAssets = liquidCash + clientReceivables;
  const currentLiabilities = supplierPayables + workerWagesPayable;
  const workingCapital = Number((currentAssets - currentLiabilities).toFixed(2));
  const quickRatio = currentLiabilities > 0 ? Number((currentAssets / currentLiabilities).toFixed(2)) : 99;

  return {
    workingCapital,
    quickRatio,
    isHealthy: workingCapital >= 0 && quickRatio >= 1.0,
  };
}

/**
 * @license
 * NirmanKhata ERP - Real Export Utilities (Excel & PDF)
 */

import {zipSync,strToU8} from 'fflate';
import { jsPDF } from 'jspdf';

/**
 * Export tabular array to Excel (.xlsx) file
 */
const xml=(value:unknown)=>String(value??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&apos;');
const colName=(index:number)=>{let out='';for(let n=index+1;n>0;n=Math.floor((n-1)/26))out=String.fromCharCode(65+(n-1)%26)+out;return out};
const download=(blob:Blob,name:string)=>{const url=URL.createObjectURL(blob),link=document.createElement('a');link.href=url;link.download=name;document.body.appendChild(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),1000)};
export function buildExcelBytes(data:Record<string,any>[],sheetName='Report'){
 const keys=Array.from(new Set(data.flatMap(row=>Object.keys(row)))),values=[keys,...data.map(row=>keys.map(key=>row[key]))];
 const rows=values.map((row,i)=>'<row r="'+(i+1)+'">'+row.map((value,j)=>{const ref=colName(j)+(i+1);return typeof value==='number'&&Number.isFinite(value)?'<c r="'+ref+'"><v>'+value+'</v></c>':'<c r="'+ref+'" t="inlineStr"><is><t xml:space="preserve">'+xml(value)+'</t></is></c>'}).join('')+'</row>').join('');
 const files:Record<string,string>={'[Content_Types].xml':'<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>','_rels/.rels':'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>','xl/workbook.xml':'<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="'+xml(sheetName.replace(/[\\/?*\[\]:]/g,' ').slice(0,31)||'Report')+'" sheetId="1" r:id="rId1"/></sheets></workbook>','xl/_rels/workbook.xml.rels':'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>','xl/worksheets/sheet1.xml':'<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>'+rows+'</sheetData></worksheet>'};
 return zipSync(Object.fromEntries(Object.entries(files).map(([name,value])=>[name,strToU8('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'+value)])));
}
export function exportToExcel(data:Record<string,any>[],filename:string,sheetName='Report'){if(!data?.length){alert('No data available to export.');return}download(new Blob([buildExcelBytes(data,sheetName) as BlobPart],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'}),filename+'.xlsx')}
export function buildCSV(data:Record<string,any>[]){const keys=Array.from(new Set(data.flatMap(row=>Object.keys(row))));const cell=(v:any)=>{let s=String(v??'');if(/^[=+@-]/.test(s)&&typeof v!=='number')s="'"+s;return '"'+s.replace(/"/g,'""')+'"'};return String.fromCharCode(65279)+[keys,...data.map(row=>keys.map(k=>row[k]))].map(row=>row.map(cell).join(',')).join(String.fromCharCode(13,10))}
export function exportToCSV(data:Record<string,any>[],filename:string){if(!data?.length){alert('No data available to export.');return}download(new Blob([buildCSV(data)],{type:'text/csv;charset=utf-8'}),filename+'.csv')}

/**
 * Generate high-quality printable PDF report
 */
export function generatePDFReport(
  title: string,
  businessName: string,
  subtitle: string,
  headers: string[],
  rows: (string | number)[][],
  filename: string
) {
  const doc = new jsPDF({
    orientation: 'landscape',
    unit: 'pt',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  let y = 40;

  // Header Title
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(18);
  doc.setTextColor(15, 23, 42); // slate-900
  doc.text(businessName || 'NirmanKhata Contractor ERP', 40, y);

  y += 20;
  doc.setFontSize(13);
  doc.setTextColor(30, 41, 59); // slate-800
  doc.text(title, 40, y);

  y += 15;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.setTextColor(100, 116, 139); // slate-500
  doc.text(`${subtitle} | Generated on: ${new Date().toLocaleString('en-IN')}`, 40, y);

  y += 25;

  // Draw table header
  const leftMargin = 40;
  const colWidth = (pageWidth - leftMargin * 2) / headers.length;
  
  doc.setFillColor(241, 245, 249); // slate-100
  doc.rect(leftMargin, y, pageWidth - leftMargin * 2, 24, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(30, 41, 59);

  headers.forEach((h, idx) => {
    doc.text(h, leftMargin + idx * colWidth + 6, y + 16);
  });

  y += 26;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);

  rows.forEach((row, rowIdx) => {
    // Check if new page needed
    if (y > doc.internal.pageSize.getHeight() - 40) {
      doc.addPage();
      y = 40;
    }

    // Alternating row background
    if (rowIdx % 2 === 1) {
      doc.setFillColor(248, 250, 252); // slate-50
      doc.rect(leftMargin, y, pageWidth - leftMargin * 2, 20, 'F');
    }

    doc.setTextColor(15, 23, 42);
    row.forEach((cell, colIdx) => {
      const cellText = String(cell ?? '');
      // Truncate cell text if too wide
      const maxLen = 30;
      const display = cellText.length > maxLen ? cellText.substring(0, maxLen) + '...' : cellText;
      doc.text(display, leftMargin + colIdx * colWidth + 6, y + 14);
    });

    y += 20;
  });

  // Footer disclaimer
  const totalPages = doc.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    doc.setFontSize(8);
    doc.setTextColor(148, 163, 184);
    doc.text(
      'NirmanKhata Management ERP - Financial management report for contractor business review.',
      leftMargin,
      doc.internal.pageSize.getHeight() - 15
    );
    doc.text(`Page ${i} of ${totalPages}`, pageWidth - 80, doc.internal.pageSize.getHeight() - 15);
  }

  doc.save(`${filename}.pdf`);
}

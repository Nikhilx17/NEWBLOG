import {call,uploadFile} from './api';
export interface PurchaseInvoiceUploadResult{documentId:string;fileName:string;contentType:string;size:number}
export const uploadPurchaseInvoice=(file:File,tenantId:string,billId:string,projectId:string):Promise<PurchaseInvoiceUploadResult>=>uploadFile(file,{tenantId,billId,projectId},'invoice');
export const savePurchaseBillRecord=(tenantId:string,bill:Record<string,unknown>,documentId?:string)=>call('savePurchaseBillRecord',{tenantId,bill,documentId});
export const listCompanyPurchaseBills=async(tenantId:string)=>(await call('listCompanyPurchaseBills',{tenantId})).bills;
export const getPurchaseInvoiceAccess=(tenantId:string,billId:string,documentId:string,disposition:'inline'|'attachment')=>call('getPurchaseInvoiceAccess',{tenantId,billId,documentId,disposition});
export const verifyPurchaseInvoice=(tenantId:string,billId:string,status:'verified'|'rejected',notes?:string)=>call('verifyPurchaseInvoice',{tenantId,billId,status,notes});

/**
 * @license
 * NirmanKhata ERP - Contractor Management & Real-Time Profit Tracking Software
 */

export type UserRole = 
  | 'owner' 
  | 'accountant' 
  | 'project_manager' 
  | 'site_supervisor' 
  | 'purchase_manager' 
  | 'auditor';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  phone?: string;
  role: UserRole;
  businessId: string;
}

export type ContractorType = 
  | 'Civil & Building Construction'
  | 'Electrical Contracting'
  | 'Plumbing & Sanitation'
  | 'Interior & Renovation'
  | 'Painting & Waterproofing'
  | 'Fabrication & Structural'
  | 'HVAC & Mechanical'
  | 'General Contractor (Multi-Trade)';

export interface Business {
  id: string;
  name: string;
  ownerUid: string;
  contractorType: ContractorType;
  gstin?: string;
  phone: string;
  email: string;
  address: string;
  financialYear: string; // e.g. "2026-2027"
  currency: string; // "INR (₹)"
  enableInventory: boolean;
  panNumber?: string;
  bankDetails?: {
    bankName: string;
    accountNumber: string;
    ifscCode: string;
    branch: string;
  };
  createdAt: string;
}

export type ProjectStatus = 'planning' | 'active' | 'on_hold' | 'completed' | 'cancelled';

export interface ProjectCostBudget {
  materials: number;
  labour: number;
  machineryRental: number;
  subcontractors: number;
  transportFuel: number;
  overheadsMisc: number;
}

export interface Project {
  id: string;
  businessId: string;
  name: string;
  code: string; // e.g. "PRJ-2026-001"
  clientId: string;
  clientName: string;
  category: ContractorType;
  siteAddress: string;
  startDate: string;
  expectedEndDate: string;
  originalContractAmount: number;
  approvedVariations: number; // additional work approved
  revisedContractAmount: number; // original + variations
  estimatedBudget: number; // total planned budget
  budgetBreakdown: ProjectCostBudget;
  estimatedCostToComplete: number; // remaining cash needed to finish
  retentionPct: number; // e.g. 5%
  retentionAmount: number; // retained by client until DLP ends
  progressPct: number; // 0 to 100
  projectManager: string;
  status: ProjectStatus;
  notes?: string;
  createdAt: string;
}

export interface ContractVariation {
  id: string;
  projectId: string;
  businessId: string;
  variationNumber: string;
  description: string;
  amount: number;
  date: string;
  status: 'draft' | 'submitted' | 'approved' | 'rejected';
  approvedBy?: string;
}

export type BillVerificationStatus = 'pending_verification' | 'verified' | 'rejected' | 'needs_correction';
export type BillApprovalStatus = 'pending_approval' | 'approved' | 'rejected';
export type PaymentStatus = 'unpaid' | 'partially_paid' | 'paid' | 'overdue';

export interface PurchaseBillItem {
  id: string;
  description: string;
  quantity: number;
  unit: string;
  unitRate: number;
  amount: number;
}

export interface PurchaseBill {
  id: string;
  businessId: string;
  projectId: string;
  projectName?: string;
  projectCode?: string;
  supplierId: string;
  supplierName: string;
  supplierGstin?: string;
  invoiceNumber: string;
  invoiceDate: string;
  dueDate: string;
  category: string; // Cement, Steel, Electrical, Pipes, Sand/Aggregates, etc.
  materialDetails: string;
  items?: PurchaseBillItem[];
  taxableAmount: number;
  cgstAmount: number;
  sgstAmount: number;
  igstAmount: number;
  totalGstAmount: number;
  isGstRecoverable: boolean; // ITC claimable vs cost component
  discount: number;
  totalAmount: number; // Final payable
  amountPaid: number;
  verificationStatus: BillVerificationStatus;
  approvalStatus: BillApprovalStatus;
  paymentStatus: PaymentStatus;
  documentUrl?: string;
  documentName?: string;
  documentId?: string;
  documentContentType?: string;
  documentSize?: number;
  documentUploadedBy?: string;
  documentUploadedAt?: string;
  verifiedBy?: string | { uid: string; name: string };
  verifiedAt?: string;
  verificationNotes?: string;
  approvedBy?: string;
  notes?: string;
  createdAt: string;
}

export interface Supplier {
  id: string;
  businessId: string;
  name: string;
  contactPerson?: string;
  phone: string;
  email?: string;
  gstin?: string;
  address: string;
  category: string;
  paymentTermsDays: number;
  bankAccountDetails?: string;
  openingBalance: number; // previous payable
  notes?: string;
  createdAt: string;
}

export interface Client {
  id: string;
  businessId: string;
  name: string;
  companyName: string;
  contactPerson: string;
  phone: string;
  email: string;
  gstin?: string;
  billingAddress: string;
  paymentTermsDays: number;
  createdAt: string;
}

export type ClientInvoiceStatus = 'draft' | 'submitted' | 'under_review' | 'approved' | 'rejected';

export interface ClientInvoiceItem {
  id: string;
  description: string;
  quantity: number;
  unit: string;
  unitRate: number;
  amount: number;
}

export interface ClientInvoice {
  id: string;
  businessId: string;
  projectId: string;
  clientId: string;
  clientName: string;
  invoiceNumber: string; // e.g. "RA-01", "RA-02", "FINAL-01"
  billType: 'milestone' | 'running_account' | 'variation' | 'final';
  invoiceDate: string;
  dueDate: string;
  grossAmount: number;
  cgstAmount: number;
  sgstAmount: number;
  totalGstAmount: number;
  retentionDeduction: number;
  otherDeductions: number; // TDS / Mobilization recovery
  netAmount: number; // Gross + GST - Retention - Deductions
  amountReceived: number;
  billingStatus: ClientInvoiceStatus;
  paymentStatus: PaymentStatus;
  items?: ClientInvoiceItem[];
  notes?: string;
  createdAt: string;
}

export interface Expense {
  id: string;
  businessId: string;
  projectId?: string; // Optional if shared company overhead
  isShared: boolean;
  date: string;
  category: 
    | 'Transport & Fuel'
    | 'Machinery & Equipment Rental'
    | 'Tools & Hardware'
    | 'Site Food & Accommodation'
    | 'Repairs & Maintenance'
    | 'Loading & Unloading'
    | 'Permits, Testing & Fees'
    | 'Site Electricity & Water'
    | 'Office & Admin'
    | 'Communication & Software'
    | 'Safety & PPE'
    | 'Miscellaneous';
  description: string;
  amount: number;
  taxAmount?: number;
  vendor?: string;
  paymentMethod: 'Cash' | 'Bank Transfer (NEFT/RTGS)' | 'UPI' | 'Cheque' | 'Credit Card';
  accountId: string; // Cash or Bank account
  paidBy?: string;
  receiptAttachment?: string;
  approvalStatus: 'approved' | 'pending';
  createdAt: string;
}

export type WorkerTrade = 
  | 'Mason (Mistri)' 
  | 'Electrician' 
  | 'Plumber' 
  | 'Carpenter' 
  | 'Painter' 
  | 'Welder/Fabricator' 
  | 'Helper/Beldar' 
  | 'Tile Fitter' 
  | 'Site Supervisor' 
  | 'HVAC Technician';

export type WageBasis = 'daily' | 'hourly' | 'monthly' | 'contract';

export interface Worker {
  id: string;
  businessId: string;
  name: string;
  phone: string;
  trade: WorkerTrade;
  workerType: 'Daily Wage' | 'Monthly Staff' | 'Piece-rate Contractor';
  wageBasis: WageBasis;
  standardWageRate: number; // e.g. ₹800/day
  overtimeRatePerHour: number; // e.g. ₹100/hr
  joiningDate: string;
  active: boolean;
  assignedProjectIds: string[];
  bankOrUpiDetails?: string;
  emergencyContact?: string;
  createdAt: string;
}

export type AttendanceStatus = 'present' | 'absent' | 'half_day' | 'overtime_only';

export interface AttendanceRecord {
  id: string;
  businessId: string;
  workerId: string;
  workerName: string;
  projectId: string;
  date: string; // YYYY-MM-DD
  status: AttendanceStatus;
  hoursWorked: number;
  overtimeHours: number;
  dailyWageEarned: number;
  supervisorApproved: boolean;
  notes?: string;
}

export interface WorkerAdvance {
  id: string;
  businessId: string;
  workerId: string;
  workerName: string;
  projectId?: string;
  amount: number;
  date: string;
  paymentMethod: 'Cash' | 'UPI' | 'Bank Transfer';
  accountId: string;
  reason?: string;
  adjustedAmount: number; // adjusted against salary disbursements
  status: 'active' | 'fully_adjusted';
  createdAt: string;
}

export interface SalaryPayment {
  id: string;
  businessId: string;
  workerId: string;
  workerName: string;
  salaryPeriod: string; // e.g. "October 2026", "Week 42"
  daysWorked: number;
  grossWagesEarned: number;
  overtimeAmount: number;
  bonusOrIncentive: number;
  advancesDeducted: number;
  otherDeductions: number;
  netPayable: number;
  amountPaid: number;
  paymentDate: string;
  paymentMethod: 'Cash' | 'UPI' | 'Bank Transfer';
  accountId: string;
  paymentReference?: string;
  status: 'paid' | 'partial';
  createdAt: string;
}

export interface Subcontractor {
  id: string;
  businessId: string;
  name: string;
  trade: string;
  phone: string;
  gstin?: string;
  activeProjects: string[];
  totalContractValue: number;
  totalBilled: number;
  totalPaid: number;
  totalRetention: number;
  outstandingBalance: number;
}

export interface SubcontractBill {
  id: string;
  businessId: string;
  subcontractorId: string;
  subcontractorName: string;
  projectId: string;
  billNumber: string;
  workDescription: string;
  date: string;
  grossAmount: number;
  retentionDeducted: number;
  advanceDeducted: number;
  netPayable: number;
  amountPaid: number;
  status: PaymentStatus;
  approvalStatus: 'approved' | 'pending';
}

export interface InventoryItem {
  id: string;
  businessId: string;
  name: string;
  sku: string;
  category: string;
  unit: string; // Bags, MT, Metres, Litres, Sq.Ft, Nos.
  currentStock: number;
  minStockLevel: number;
  averagePurchasePrice: number;
  stockValue: number;
  lastSupplierName?: string;
  updatedAt: string;
}

export interface StockMovement {
  id: string;
  businessId: string;
  itemId: string;
  itemName: string;
  movementType: 'purchase_in' | 'site_issue' | 'site_return' | 'transfer' | 'adjustment';
  quantity: number;
  unitCost: number;
  totalValue: number;
  projectId?: string;
  date: string;
  referenceNo?: string;
  notes?: string;
}

export interface CashBankAccount {
  id: string;
  businessId: string;
  name: string; // "HDFC Current A/c", "Cash in Hand (Site Box)", "SBI Overdraft"
  accountType: 'Bank Account' | 'Cash in Hand' | 'Petty Cash' | 'Credit Facility / OD';
  accountNumber?: string;
  bankName?: string;
  openingBalance: number;
  currentBalance: number;
  isDefault: boolean;
}

export interface AccountTransaction {
  id: string;
  businessId: string;
  accountId: string;
  accountName: string;
  date: string;
  type: 'inflow' | 'outflow' | 'internal_transfer';
  amount: number;
  category: string; // "Client Payment", "Supplier Bill", "Labour Salary", "Worker Advance", "Daily Expense", "Internal Transfer"
  referenceNumber?: string;
  description: string;
  projectId?: string;
  relatedEntityId?: string; // Bill ID, Invoice ID, Expense ID
  isInternalTransfer?: boolean; // When true, excluded from income/expense
  balanceAfter: number;
  createdAt: string;
}

export interface PaymentRecord {
  id: string;
  businessId: string;
  type: 'supplier_payment' | 'client_receipt';
  partyId: string;
  partyName: string;
  projectId: string;
  amount: number;
  date: string;
  paymentMethod: 'Bank Transfer (NEFT/RTGS)' | 'UPI' | 'Cheque' | 'Cash';
  accountId: string;
  accountName: string;
  referenceNumber: string;
  allocatedDocId: string; // Bill ID or Invoice ID
  allocatedDocNumber: string;
  notes?: string;
  createdAt: string;
}

export interface AuditLogEntry {
  id: string;
  businessId: string;
  action: string;
  module: string;
  entityId: string;
  user: string;
  role: string;
  details: string;
  timestamp: string;
  previousValue?: string;
  newValue?: string;
}

export interface SmartAlert {
  id: string;
  type: 'budget_exceeded' | 'low_profit' | 'overdue_receivable' | 'unpaid_bill' | 'unapproved_bill' | 'upcoming_salary';
  severity: 'high' | 'medium' | 'info';
  title: string;
  message: string;
  linkTab?: string;
  relatedId?: string;
  date: string;
}

export interface ProjectProfitSummary {
  projectId: string;
  projectName: string;
  projectCode: string;
  clientName: string;
  status: ProjectStatus;
  revisedContractAmount: number;
  budgetedCost: number;
  materialCost: number;
  labourCost: number;
  expensesCost: number;
  subcontractorCost: number;
  actualIncurredCost: number;
  budgetVariance: number; // actual - budget (positive = overspend)
  costToComplete: number;
  estimatedFinalCost: number;
  billedRevenue: number;
  collectedRevenue: number;
  receivableDue: number;
  actualRecordedProfit: number; // billedRevenue - actualIncurredCost
  estimatedFinalProfit: number; // revisedContractAmount - estimatedFinalCost
  profitMarginPct: number; // profit / revenue * 100
  costRoiPct: number; // profit / cost * 100
  progressPct: number;
}

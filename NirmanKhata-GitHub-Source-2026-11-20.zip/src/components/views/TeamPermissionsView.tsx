import {NativeAdminTools} from '../auth/NativeAdminTools';
import React from 'react';
import {useContractor} from '../../context/ContractorContext';
import {EnterpriseUserManagementGate} from '../auth/EnterpriseUserManagementGate';

export const TeamPermissionsView:React.FC=()=>{
 const {teamMembers}=useContractor();
 return <div className="space-y-5"><EnterpriseUserManagementGate/><NativeAdminTools/><details className="rounded-xl border bg-white p-4"><summary className="cursor-pointer text-sm font-bold">Historical Browser Team Profiles · {teamMembers.length}</summary><p className="mt-2 text-xs text-slate-500">These preserved profiles are historical ERP records. Employee logins and access are managed in the authenticated enterprise module above.</p><div className="mt-3 divide-y">{teamMembers.map(member=><article key={member.id} className="py-3 text-sm"><b>{member.name}</b><p className="mt-1 text-xs text-slate-500">{member.email} · {member.role}</p></article>)}</div></details></div>;
};

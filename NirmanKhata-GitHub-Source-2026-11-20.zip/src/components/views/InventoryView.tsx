import React, { useState } from 'react';
import { useContractor } from '../../context/ContractorContext';
import { InventoryItem, StockMovement } from '../../types';
import { formatINR } from '../../lib/calculations';
import {
  Package,
  Plus,
  ArrowRightLeft,
  Search,
  AlertTriangle,
  CheckCircle2,
  Building,
  History,
} from 'lucide-react';

export const InventoryView: React.FC = () => {
  const { inventory, addInventoryItem, stockMovements, recordStockMovement, projects } = useContractor();

  const [showAddItemModal, setShowAddItemModal] = useState(false);
  const [showIssueModal, setShowIssueModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Item Form
  const [name, setName] = useState('');
  const [sku, setSku] = useState('');
  const [category, setCategory] = useState('Cement');
  const [unit, setUnit] = useState('Bags (50 kg)');
  const [currentStock, setCurrentStock] = useState('');
  const [minStockLevel, setMinStockLevel] = useState('');
  const [avgPrice, setAvgPrice] = useState('');

  // Stock Issue Form
  const [selectedItemId, setSelectedItemId] = useState(inventory[0]?.id || '');
  const [issueQuantity, setIssueQuantity] = useState('');
  const [issueProjectId, setIssueProjectId] = useState(projects[0]?.id || '');
  const [issueNotes, setIssueNotes] = useState('');

  const totalInventoryValue = inventory.reduce((sum, item) => sum + (item.stockValue || item.currentStock * item.averagePurchasePrice), 0);

  const filteredInventory = inventory.filter((item) => {
    return (
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.sku.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.category.toLowerCase().includes(searchQuery.toLowerCase())
    );
  });

  const handleCreateItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name) return;

    addInventoryItem({
      name,
      sku: sku || `SKU-${Date.now().toString().slice(-4)}`,
      category,
      unit,
      currentStock: parseFloat(currentStock) || 0,
      minStockLevel: parseFloat(minStockLevel) || 0,
      averagePurchasePrice: parseFloat(avgPrice) || 0,
    });

    setShowAddItemModal(false);
    setName('');
    setSku('');
    setCurrentStock('');
    setMinStockLevel('');
    setAvgPrice('');
  };

  const handleIssueStock = (e: React.FormEvent) => {
    e.preventDefault();
    const qty = parseFloat(issueQuantity);
    if (!qty || qty <= 0) return;

    const item = inventory.find((i) => i.id === selectedItemId);
    if (!item) return;

    recordStockMovement({
      itemId: item.id,
      itemName: item.name,
      movementType: 'site_issue',
      quantity: qty,
      unitCost: item.averagePurchasePrice,
      totalValue: qty * item.averagePurchasePrice,
      projectId: issueProjectId,
      date: new Date().toISOString().split('T')[0],
      referenceNo: `ISSUE-${Date.now().toString().slice(-4)}`,
      notes: issueNotes || `Issued to site for execution`,
    });

    setShowIssueModal(false);
    setIssueQuantity('');
    setIssueNotes('');
  };

  return (
    <div className="space-y-6">
      {/* Header bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">Material Inventory & Site Stores</h2>
          <p className="text-xs text-slate-500">
            Track cement bags, TMT steel, pipes, cables, and distinguish warehouse purchase from site consumption
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            onClick={() => setShowIssueModal(true)}
            className="flex items-center gap-1.5 px-3 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors"
          >
            <ArrowRightLeft className="w-4 h-4" />
            <span>Issue Stock to Project</span>
          </button>

          <button
            onClick={() => setShowAddItemModal(true)}
            className="flex items-center gap-1.5 px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Add Material Item</span>
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-xs">
          <p className="text-[11px] font-semibold text-slate-500 uppercase">Total Inventory Valuation</p>
          <p className="text-xl font-bold text-slate-900 mt-1">{formatINR(totalInventoryValue, false)}</p>
          <p className="text-[11px] text-slate-400 mt-0.5">Valued at weighted average purchase cost</p>
        </div>

        <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-xs">
          <p className="text-[11px] font-semibold text-slate-500 uppercase">Tracked SKUs</p>
          <p className="text-xl font-bold text-blue-600 mt-1">{inventory.length} Material Types</p>
          <p className="text-[11px] text-slate-400 mt-0.5">Cement, steel rebar, cables, sanitary pipes</p>
        </div>

        <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-xs">
          <p className="text-[11px] font-semibold text-slate-500 uppercase">Low Stock Alerts</p>
          <p className="text-xl font-bold text-amber-600 mt-1">
            {inventory.filter((i) => i.currentStock <= i.minStockLevel).length} Materials
          </p>
          <p className="text-[11px] text-slate-400 mt-0.5">Below reorder minimum levels</p>
        </div>
      </div>

      {/* Search Bar */}
      <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-xs flex items-center justify-between text-xs">
        <div className="flex-1 max-w-md relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search material by name, SKU, category..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs"
          />
        </div>
      </div>

      {/* Materials Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 uppercase text-[10px] tracking-wider">
              <tr>
                <th className="px-4 py-3">Material Name & SKU</th>
                <th className="px-4 py-3">Category</th>
                <th className="px-4 py-3">Unit</th>
                <th className="px-4 py-3 text-right">Current Stock</th>
                <th className="px-4 py-3 text-right">Avg Unit Rate</th>
                <th className="px-4 py-3 text-right">Total Stock Value</th>
                <th className="px-4 py-3 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredInventory.map((item) => {
                const isLow = item.currentStock <= item.minStockLevel;
                const value = item.currentStock * item.averagePurchasePrice;

                return (
                  <tr key={item.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-4 py-3.5">
                      <div className="font-bold text-slate-900">{item.name}</div>
                      <div className="text-[10px] font-mono text-slate-400">{item.sku}</div>
                    </td>
                    <td className="px-4 py-3.5">
                      <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-100 text-slate-700">
                        {item.category}
                      </span>
                    </td>
                    <td className="px-4 py-3.5 text-slate-600">{item.unit}</td>
                    <td className="px-4 py-3.5 text-right font-extrabold text-slate-900">
                      {item.currentStock.toLocaleString('en-IN')}
                    </td>
                    <td className="px-4 py-3.5 text-right font-medium text-slate-700">
                      {formatINR(item.averagePurchasePrice, false)}
                    </td>
                    <td className="px-4 py-3.5 text-right font-bold text-slate-900">
                      {formatINR(value, false)}
                    </td>
                    <td className="px-4 py-3.5 text-center">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                          isLow ? 'bg-rose-100 text-rose-800' : 'bg-emerald-100 text-emerald-800'
                        }`}
                      >
                        {isLow ? 'Low Stock' : 'In Stock'}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Issue Stock Modal */}
      {showIssueModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-xl border border-slate-200 text-xs">
            <h3 className="text-base font-bold text-slate-900">Issue Material to Site Project</h3>
            <p className="text-slate-500 mt-1">
              Deducts from warehouse inventory and adds material consumption cost to the destination project.
            </p>

            <form onSubmit={handleIssueStock} className="mt-4 space-y-3.5">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Select Material *</label>
                <select
                  value={selectedItemId}
                  onChange={(e) => setSelectedItemId(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-medium"
                >
                  {inventory.map((item) => (
                    <option key={item.id} value={item.id}>
                      {item.name} (Stock: {item.currentStock} {item.unit})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Quantity to Issue *</label>
                <input
                  type="number"
                  required
                  placeholder="e.g. 100"
                  value={issueQuantity}
                  onChange={(e) => setIssueQuantity(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-bold text-slate-900"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Destination Project *</label>
                <select
                  value={issueProjectId}
                  onChange={(e) => setIssueProjectId(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-medium"
                >
                  {projects.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.code} - {p.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Site Work Note / Reason</label>
                <input
                  type="text"
                  placeholder="e.g. For Ground floor slab casting"
                  value={issueNotes}
                  onChange={(e) => setIssueNotes(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowIssueModal(false)}
                  className="px-4 py-2 border border-slate-200 rounded-lg font-semibold text-slate-600 hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold"
                >
                  Issue to Site Project
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Item Modal */}
      {showAddItemModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-xl border border-slate-200 text-xs">
            <h3 className="text-base font-bold text-slate-900">Add Inventory Material</h3>
            <form onSubmit={handleCreateItem} className="mt-4 space-y-3.5">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Material Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. UltraTech OPC 53 Grade Cement"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">SKU / Code</label>
                  <input
                    type="text"
                    placeholder="e.g. CEM-UT-53"
                    value={sku}
                    onChange={(e) => setSku(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-mono"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Unit of Measure</label>
                  <input
                    type="text"
                    placeholder="e.g. Bags (50kg), MT, Metres"
                    value={unit}
                    onChange={(e) => setUnit(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Opening Stock</label>
                  <input
                    type="number"
                    placeholder="e.g. 200"
                    value={currentStock}
                    onChange={(e) => setCurrentStock(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Min Reorder Level</label>
                  <input
                    type="number"
                    placeholder="e.g. 50"
                    value={minStockLevel}
                    onChange={(e) => setMinStockLevel(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Average Purchase Price (₹)</label>
                <input
                  type="number"
                  placeholder="e.g. 385"
                  value={avgPrice}
                  onChange={(e) => setAvgPrice(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-bold"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddItemModal(false)}
                  className="px-4 py-2 border border-slate-200 rounded-lg font-semibold text-slate-600 hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold"
                >
                  Add Material
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

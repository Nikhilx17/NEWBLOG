import React, { useState } from 'react';
import { useContractor } from '../../context/ContractorContext';
import { useHostingerSession } from '../../context/HostingerSession';
import { Project, ContractorType, ProjectStatus } from '../../types';
import { formatINR, formatCompactINR, computeProjectProfitSummary } from '../../lib/calculations';
import {
  Building2,
  Plus,
  Search,
  Filter,
  Calendar,
  User,
  ArrowRight,
  TrendingUp,
  AlertCircle,
  CheckCircle2,
  Clock,
  ChevronRight,
  MapPin,
  Trash2,
} from 'lucide-react';

interface ProjectsViewProps {
  onSelectProject: (projectId: string) => void;
  onNavigate: (tab: string) => void;
  onOpenCreateProject: () => void;
}

export const ProjectsView: React.FC<ProjectsViewProps> = ({
  onSelectProject,
  onNavigate,
  onOpenCreateProject,
}) => {
  const {
    projects,
    purchaseBills,
    expenses,
    attendance,
    subcontractBills,
    clientInvoices,
    currentUser,
    deleteProject,
    activeProjectId,
    setActiveProjectId,
  } = useContractor();
  const session=useHostingerSession();
  const canDelete=session ? session.user.roleId==='admin_editor' : currentUser.role==='owner';
  const [deleteTarget,setDeleteTarget]=useState<Project|null>(null);
  const [deleting,setDeleting]=useState(false);
  const [deleteError,setDeleteError]=useState('');
  const [deleteMessage,setDeleteMessage]=useState('');
  const confirmDelete=async()=>{
    if(!deleteTarget||deleting)return;
    setDeleting(true);setDeleteError('');
    try{
      await deleteProject(deleteTarget.id);
      if(activeProjectId===deleteTarget.id)setActiveProjectId('all');
      setDeleteMessage('Project “'+deleteTarget.name+'” removed from the project list. Linked historical records were retained.');
      setDeleteTarget(null);
    }catch(error:any){setDeleteError(error.message||'The project could not be removed. Please retry.');}
    finally{setDeleting(false);}
  };

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');

  const filteredProjects = projects.filter((p) => {
    const matchesSearch =
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.clientName.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || p.status === statusFilter;
    const matchesCategory = categoryFilter === 'all' || p.category === categoryFilter;
    return matchesSearch && matchesStatus && matchesCategory;
  });

  const canCreate = currentUser.role === 'owner' || currentUser.role === 'project_manager';

  return (
    <div className="space-y-6">
      {/* Header bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">Contract Projects</h2>
          <p className="text-xs text-slate-500">
            Commercial contracts, revisions, budgets, and live profitability tracking
          </p>
        </div>

        {canCreate && (
          <button
            onClick={onOpenCreateProject}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors self-start sm:self-auto"
          >
            <Plus className="w-4 h-4" />
            <span>Create New Project</span>
          </button>
        )}
      </div>

      {deleteMessage&&<p role="status" className="rounded-lg border border-emerald-200 bg-emerald-50 p-3 text-xs text-emerald-800">{deleteMessage}</p>}

      {/* Filters & Search */}
      <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex-1 min-w-[220px] relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by project name, code, client..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-700 font-medium focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer"
          >
            <option value="all">All Statuses</option>
            <option value="active">Active</option>
            <option value="planning">Planning</option>
            <option value="on_hold">On Hold</option>
            <option value="completed">Completed</option>
          </select>

          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-700 font-medium focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer"
          >
            <option value="all">All Categories</option>
            <option value="Civil & Building Construction">Civil & Building</option>
            <option value="Electrical Contracting">Electrical</option>
            <option value="Plumbing & Sanitation">Plumbing</option>
            <option value="Interior & Renovation">Interior</option>
          </select>
        </div>
      </div>

      {/* Projects Grid */}
      {filteredProjects.length === 0 ? (
        <div className="bg-white rounded-xl p-12 text-center border border-slate-200">
          <Building2 className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <h3 className="text-sm font-bold text-slate-700">No projects found</h3>
          <p className="text-xs text-slate-500 mt-1">Try adjusting your search terms or filters.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredProjects.map((project) => {
            const summary = computeProjectProfitSummary(
              project,
              purchaseBills,
              expenses,
              attendance,
              subcontractBills,
              clientInvoices
            );
            const isProfitable = summary.actualRecordedProfit >= 0;

            return (
              <div
                key={project.id}
                onClick={() => {
                  onSelectProject(project.id);
                  onNavigate('project-detail');
                }}
                className="bg-white rounded-xl border border-slate-200 shadow-xs hover:shadow-md hover:border-blue-300 transition-all p-5 flex flex-col justify-between cursor-pointer group"
              >
                <div>
                  {/* Top tags */}
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-mono">
                      {project.code}
                    </span>
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider ${
                        project.status === 'active'
                          ? 'bg-emerald-100 text-emerald-800'
                          : project.status === 'completed'
                          ? 'bg-blue-100 text-blue-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {project.status.replace('_', ' ')}
                    </span>
                  </div>

                  <h3 className="text-base font-bold text-slate-900 group-hover:text-blue-600 transition-colors line-clamp-1">
                    {project.name}
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5 font-medium">{project.clientName}</p>

                  <div className="mt-3 flex items-center gap-1.5 text-xs text-slate-500">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="truncate">{project.siteAddress}</span>
                  </div>

                  {/* Financial Stats Grid */}
                  <div className="mt-4 pt-3 border-t border-slate-100 grid grid-cols-2 gap-2 text-xs">
                    <div className="bg-slate-50 p-2.5 rounded-lg">
                      <span className="text-[10px] text-slate-500 font-medium">Revised Contract</span>
                      <p className="font-bold text-slate-900 mt-0.5">
                        {formatCompactINR(summary.revisedContractAmount)}
                      </p>
                    </div>

                    <div className="bg-slate-50 p-2.5 rounded-lg">
                      <span className="text-[10px] text-slate-500 font-medium">Actual Incurred</span>
                      <p className="font-bold text-slate-900 mt-0.5">
                        {formatCompactINR(summary.actualIncurredCost)}
                      </p>
                    </div>

                    <div className="bg-slate-50 p-2.5 rounded-lg">
                      <span className="text-[10px] text-slate-500 font-medium">Client Billed</span>
                      <p className="font-bold text-slate-900 mt-0.5">
                        {formatCompactINR(summary.billedRevenue)}
                      </p>
                    </div>

                    <div
                      className={`p-2.5 rounded-lg ${
                        isProfitable ? 'bg-emerald-50' : 'bg-rose-50'
                      }`}
                    >
                      <span className="text-[10px] text-slate-500 font-medium">Recorded Profit</span>
                      <p
                        className={`font-bold mt-0.5 ${
                          isProfitable ? 'text-emerald-700' : 'text-rose-700'
                        }`}
                      >
                        {formatCompactINR(summary.actualRecordedProfit)}
                      </p>
                    </div>
                  </div>

                  {/* Progress bar */}
                  <div className="mt-4">
                    <div className="flex justify-between text-[11px] mb-1">
                      <span className="text-slate-500 font-medium">Site Physical Progress</span>
                      <span className="font-bold text-slate-800">{project.progressPct}%</span>
                    </div>
                    <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                      <div
                        className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                        style={{ width: `${project.progressPct}%` }}
                      />
                    </div>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-blue-600 font-semibold group-hover:translate-x-0.5 transition-transform">
                  <span>View Project Financial Cockpit</span>
                  {canDelete?<button type="button" aria-label={'Delete project '+project.name} onClick={e=>{e.stopPropagation();setDeleteError('');setDeleteMessage('');setDeleteTarget(project)}} className="ml-2 flex shrink-0 items-center gap-1 rounded border border-rose-200 px-2 py-1 text-rose-700 hover:bg-rose-50"><Trash2 className="h-3.5 w-3.5"/>Delete</button>:<ArrowRight className="w-4 h-4" />}
                </div>
              </div>
            );
          })}
        </div>
      )}
      {deleteTarget&&<div className="fixed inset-0 z-[160] grid place-items-center bg-slate-950/50 p-4" onClick={e=>{e.stopPropagation();if(e.target===e.currentTarget&&!deleting)setDeleteTarget(null)}}>
        <section role="dialog" aria-modal="true" aria-labelledby="delete-project-title" className="w-full max-w-md rounded-xl border border-slate-200 bg-white p-5 shadow-xl" onKeyDown={e=>{if(e.key==='Escape'&&!deleting)setDeleteTarget(null)}}>
          <h3 id="delete-project-title" className="text-lg font-bold text-slate-900">Delete project?</h3>
          <p className="mt-3 text-sm text-slate-700">Remove <strong>{deleteTarget.name}</strong> from the project list?</p>
          <p className="mt-2 text-xs leading-relaxed text-slate-500">The project will be archived. Linked purchases, accounts, site register entries, work reports and photos will be retained.</p>
          {deleteError&&<p role="alert" className="mt-3 text-sm text-rose-700">{deleteError}</p>}
          <div className="mt-5 flex justify-end gap-2"><button type="button" autoFocus disabled={deleting} onClick={()=>setDeleteTarget(null)} className="rounded-lg border border-slate-300 px-3 py-2 text-sm font-semibold disabled:opacity-50">Cancel</button><button type="button" disabled={deleting} onClick={()=>void confirmDelete()} className="rounded-lg bg-rose-700 px-3 py-2 text-sm font-semibold text-white hover:bg-rose-800 disabled:opacity-50">{deleting?'Deleting…':'Delete Project'}</button></div>
        </section>
      </div>}
    </div>
  );
};

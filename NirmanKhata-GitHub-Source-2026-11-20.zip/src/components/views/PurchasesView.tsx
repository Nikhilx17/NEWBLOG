import {PurchaseOrdersView} from './PurchaseOrdersView';
import React, { useEffect, useRef, useState } from 'react';
import { useContractor } from '../../context/ContractorContext';
import { PurchaseBill, PaymentStatus, BillVerificationStatus, BillApprovalStatus } from '../../types';
import { formatINR, formatCompactINR } from '../../lib/calculations';
import { InvoiceUploadModal } from './InvoiceUploadModal';
import {useHostingerSession} from '../../context/HostingerSession';
import { getPurchaseInvoiceAccess, listCompanyPurchaseBills, verifyPurchaseInvoice } from '../../lib/purchaseInvoiceDocuments';
import {
  ShoppingCart,
  Plus,
  Search,
  Filter,
  CheckCircle2,
  Clock,
  AlertTriangle,
  CreditCard,
  FileText,
  Building,
  ChevronRight,
  Eye,
  Check,
  X,
  ShieldCheck,
  Download,
  ZoomIn,
  ZoomOut,
  Maximize2,
} from 'lucide-react';

interface PurchasesViewProps {
  onNavigate: (tab: string) => void;
}

const SupplierInvoicesView: React.FC<PurchasesViewProps> = ({ onNavigate }) => {
 const nativeSession=useHostingerSession();
  const {
    purchaseBills,
    projects,
    activeProjectId,
    accounts,
    verifyPurchaseBill,
    approvePurchaseBill,
    recordSupplierPayment,
    currentUser,
  } = useContractor();

  const [searchQuery, setSearchQuery] = useState('');
  const [paymentFilter, setPaymentFilter] = useState<string>('all');
  const [approvalFilter, setApprovalFilter] = useState<string>('all');
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [tenantId, setTenantId] = useState('');
  const [isTenantWorkspace, setIsTenantWorkspace] = useState(false);
  const [cloudBills, setCloudBills] = useState<PurchaseBill[]>([]);
  const [documentBill, setDocumentBill] = useState<PurchaseBill | null>(null);
  const [documentPreviewUrl, setDocumentPreviewUrl] = useState('');
  const [documentError, setDocumentError] = useState('');
  const [documentBusy, setDocumentBusy] = useState(false);
  const [documentZoom, setDocumentZoom] = useState(1);
  const documentViewerRef = useRef<HTMLDivElement>(null);

  // Payment modal state
  const [selectedBillForPayment, setSelectedBillForPayment] = useState<PurchaseBill | null>(null);
  const [payAmount, setPayAmount] = useState('');
  const [payAccount, setPayAccount] = useState(accounts[0]?.id || '');
  const [payMethod, setPayMethod] = useState('Bank Transfer (NEFT/RTGS)');
  const [payRef, setPayRef] = useState('');

  // Document preview state
  const loadCloudBills = async (companyId: string) => {
    try { setCloudBills((await listCompanyPurchaseBills(companyId)) as unknown as PurchaseBill[]); }
    catch (err) { setDocumentError(err instanceof Error ? err.message : 'Could not load company purchase records.'); }
  };

  useEffect(()=>{setTenantId(nativeSession?.user?.enterpriseId||'');setIsTenantWorkspace(false)},[nativeSession?.user?.enterpriseId]);

  const displayedBills = isTenantWorkspace ? cloudBills : purchaseBills;

  const filteredBills = displayedBills.filter((b) => {
    const matchesProject = activeProjectId === 'all' || b.projectId === activeProjectId;
    const matchesSearch =
      b.supplierName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      b.invoiceNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      b.materialDetails.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesPayment = paymentFilter === 'all' || b.paymentStatus === paymentFilter;
    const matchesApproval = approvalFilter === 'all' || b.approvalStatus === approvalFilter;
    return matchesProject && matchesSearch && matchesPayment && matchesApproval;
  });

  const totalPayableAll = filteredBills.reduce(
    (sum, b) => sum + Math.max(0, b.totalAmount - (b.amountPaid || 0)),
    0
  );
  const totalPaidAll = filteredBills.reduce((sum, b) => sum + (b.amountPaid || 0), 0);

  const canApprove = nativeSession?.user?.permissions.includes('purchases.approve');
  const canVerify = nativeSession?.user?.permissions.includes('purchases.review');

  const handleConfirmPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedBillForPayment) return;
    const amount = parseFloat(payAmount);
    if (!amount || amount <= 0) return;

    recordSupplierPayment(
      selectedBillForPayment.id,
      amount,
      payAccount,
      payMethod,
      payRef || `TXN-${Date.now().toString().slice(-6)}`
    );

    setSelectedBillForPayment(null);
    setPayAmount('');
    setPayRef('');
  };

  const openInvoice = async (bill: PurchaseBill) => {
    if (bill.documentUrl && !bill.documentId) { setDocumentBill(bill);setDocumentPreviewUrl(bill.documentUrl);setDocumentError('');return; }
    if (!tenantId || !bill.documentId) return;
    setDocumentBill(bill);setDocumentPreviewUrl('');setDocumentError('');setDocumentBusy(true);
    try { const result=await getPurchaseInvoiceAccess(tenantId,bill.id,bill.documentId,'inline');setDocumentPreviewUrl(result.url);setDocumentZoom(1); }
    catch(err) { setDocumentError(err instanceof Error?err.message:'Could not securely open the original invoice.'); }
    finally { setDocumentBusy(false); }
  };

  const downloadInvoice = async () => {
    if(!documentBill?.documentId||!tenantId)return;
    try {const result=await getPurchaseInvoiceAccess(tenantId,documentBill.id,documentBill.documentId,'attachment');const link=document.createElement('a');link.href=result.url;link.download=result.fileName;document.body.appendChild(link);link.click();link.remove();}
    catch(err){setDocumentError(err instanceof Error?err.message:'Could not download the original invoice.');}
  };

  const handleVerification = async (bill:PurchaseBill,status:'verified'|'rejected') => {
    try {
      if(isTenantWorkspace&&cloudBills.some(row=>row.id===bill.id)){await verifyPurchaseInvoice(tenantId,bill.id,status);await loadCloudBills(tenantId);}
      verifyPurchaseBill(bill.id,status);
    } catch(err) {setDocumentError(err instanceof Error?err.message:'The invoice verification could not be saved.');}
  };

  return (
    <div className="space-y-6">
      {/* Header bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">
            Purchase Register & Supplier Invoices
          </h2>
          <p className="text-xs text-slate-500">
            Material bills, original invoice documents, administrative approvals, and supplier payments
          </p>
        </div>

        <button
          onClick={() => setShowUploadModal(true)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors self-start sm:self-auto"
        >
          <FileText className="w-4 h-4" />
          <span>Upload Bill</span>
        </button>
      </div>
      {documentError && <div role="alert" className="rounded-lg border border-rose-200 bg-rose-50 px-4 py-3 text-xs text-rose-800">{documentError}<button className="ml-3 font-bold underline" onClick={()=>setDocumentError('')}>Dismiss</button></div>}

      {/* Summary KPI Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-xs">
          <p className="text-[11px] font-semibold text-slate-500 uppercase">Outstanding Supplier Payables</p>
          <p className="text-xl font-bold text-rose-600 mt-1">{formatINR(totalPayableAll, false)}</p>
          <p className="text-[11px] text-slate-400 mt-0.5">Across {filteredBills.length} purchase invoices</p>
        </div>

        <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-xs">
          <p className="text-[11px] font-semibold text-slate-500 uppercase">Total Payments Cleared</p>
          <p className="text-xl font-bold text-emerald-600 mt-1">{formatINR(totalPaidAll, false)}</p>
          <p className="text-[11px] text-slate-400 mt-0.5">Paid via Bank NEFT / RTGS / Cheque</p>
        </div>

        <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-xs">
          <p className="text-[11px] font-semibold text-slate-500 uppercase">Pending Approvals</p>
          <p className="text-xl font-bold text-amber-600 mt-1">
            {filteredBills.filter((b) => b.approvalStatus === 'pending_approval').length} Bills
          </p>
          <p className="text-[11px] text-slate-400 mt-0.5">Awaiting Owner / PM sign-off</p>
        </div>
      </div>

      {/* Filters Bar */}
      <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex-1 min-w-[220px] relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search supplier, bill number, cement, steel..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs"
          />
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <select
            value={paymentFilter}
            onChange={(e) => setPaymentFilter(e.target.value)}
            className="bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-700 font-medium"
          >
            <option value="all">All Payment Statuses</option>
            <option value="unpaid">Unpaid Bills</option>
            <option value="partially_paid">Partially Paid</option>
            <option value="paid">Fully Paid</option>
          </select>

          <select
            value={approvalFilter}
            onChange={(e) => setApprovalFilter(e.target.value)}
            className="bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-700 font-medium"
          >
            <option value="all">All Approvals</option>
            <option value="pending_approval">Pending Approval</option>
            <option value="approved">Approved</option>
            <option value="rejected">Rejected</option>
          </select>
        </div>
      </div>

      {/* Bills Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 uppercase text-[10px] tracking-wider">
              <tr>
                <th className="px-4 py-3">Bill Details</th>
                <th className="px-4 py-3">Project</th>
                <th className="px-4 py-3">Category & Items</th>
                <th className="px-4 py-3 text-right">Taxable</th>
                <th className="px-4 py-3 text-right">Total Bill</th>
                <th className="px-4 py-3 text-right">Paid</th>
                <th className="px-4 py-3 text-right">Balance Due</th>
                <th className="px-4 py-3 text-center">Verification</th>
                <th className="px-4 py-3 text-center">Approval</th>
                <th className="px-4 py-3 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredBills.map((bill) => {
                const project = projects.find((p) => p.id === bill.projectId);
                const unpaidBalance = Math.max(0, bill.totalAmount - (bill.amountPaid || 0));
                const isCloudBill = isTenantWorkspace && cloudBills.some((row) => row.id === bill.id);

                return (
                  <tr key={bill.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-4 py-3.5">
                      <div className="font-bold text-slate-900 font-mono">{bill.invoiceNumber}</div>
                      <div className="text-[11px] font-semibold text-slate-700">{bill.supplierName}</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">
                        Dated: {bill.invoiceDate} • Due: {bill.dueDate}
                      </div>
                    </td>

                    <td className="px-4 py-3.5">
                      <span className="font-medium text-slate-800 line-clamp-1">
                        {project?.name || bill.projectName || 'Shared'}
                      </span>
                      <span className="text-[10px] text-slate-400">{project?.code || bill.projectCode}</span>
                    </td>

                    <td className="px-4 py-3.5 max-w-[200px]">
                      <span className="inline-block px-1.5 py-0.2 bg-blue-50 text-blue-700 rounded text-[10px] font-semibold mb-0.5">
                        {bill.category}
                      </span>
                      <p className="text-[11px] text-slate-600 truncate">{bill.materialDetails}</p>
                    </td>

                    <td className="px-4 py-3.5 text-right font-medium text-slate-700">
                      {formatINR(bill.taxableAmount, false)}
                    </td>

                    <td className="px-4 py-3.5 text-right font-extrabold text-slate-900">
                      {formatINR(bill.totalAmount, false)}
                    </td>

                    <td className="px-4 py-3.5 text-right font-semibold text-emerald-600">
                      {formatINR(bill.amountPaid, false)}
                    </td>

                    <td className="px-4 py-3.5 text-right font-bold text-rose-600">
                      {formatINR(unpaidBalance, false)}
                    </td>

                    <td className="px-4 py-3.5 text-center">
                      <span
                        className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                          bill.verificationStatus === 'verified'
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {bill.verificationStatus.replace('_', ' ')}
                      </span>
                    </td>

                    <td className="px-4 py-3.5 text-center">
                      <span
                        className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                          bill.approvalStatus === 'approved'
                            ? 'bg-emerald-100 text-emerald-800'
                            : bill.approvalStatus === 'rejected'
                            ? 'bg-rose-100 text-rose-800'
                            : 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        {bill.approvalStatus.replace('_', ' ')}
                      </span>
                    </td>

                    <td className="px-4 py-3.5 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        {/* Record Payment Button */}
                        {unpaidBalance > 0 && !isCloudBill && (
                          <button
                            onClick={() => {
                              setSelectedBillForPayment(bill);
                              setPayAmount(unpaidBalance.toString());
                            }}
                            title="Record Supplier Payment"
                            className="p-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-lg transition-colors font-semibold flex items-center gap-1"
                          >
                            <CreditCard className="w-3.5 h-3.5" />
                            <span className="text-[11px]">Pay</span>
                          </button>
                        )}

                        {/* Approve Quick Button */}
                        {canApprove && bill.approvalStatus === 'pending_approval' && (
                          <button
                            onClick={() => approvePurchaseBill(bill.id, 'approved')}
                            title="Approve Bill"
                            className="p-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-lg transition-colors"
                          >
                            <Check className="w-3.5 h-3.5" />
                          </button>
                        )}

                        {canVerify && (bill.documentId || bill.documentUrl) && bill.verificationStatus === 'pending_verification' && (
                          <>
                            <button onClick={()=>void handleVerification(bill,'verified')} title="Verify invoice figures" className="p-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-lg"><ShieldCheck className="w-3.5 h-3.5"/></button>
                            <button onClick={()=>void handleVerification(bill,'rejected')} title="Reject invoice verification" className="p-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-lg"><X className="w-3.5 h-3.5"/></button>
                          </>
                        )}

                        {/* View the original invoice */}
                        {(bill.documentId || bill.documentUrl) && (
                          <button
                            onClick={() => void openInvoice(bill)}
                            title="View Invoice"
                            aria-label="View Invoice"
                            className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg transition-colors"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Upload Modal */}
      <InvoiceUploadModal
        isOpen={showUploadModal}
        onClose={() => setShowUploadModal(false)}
        onSuccess={() => { setShowUploadModal(false);if(tenantId)void loadCloudBills(tenantId); }}
        existingBills={displayedBills}
      />

      {/* Payment Recording Modal */}
      {selectedBillForPayment && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl max-w-md w-full p-6 shadow-xl border border-slate-200 text-xs">
            <h3 className="text-base font-bold text-slate-900">Record Supplier Payment</h3>
            <p className="text-slate-500 mt-1">
              Disburse payment to <span className="font-semibold text-slate-900">{selectedBillForPayment.supplierName}</span> for bill{' '}
              <span className="font-mono font-bold text-slate-900">{selectedBillForPayment.invoiceNumber}</span>.
            </p>

            <form onSubmit={handleConfirmPayment} className="mt-4 space-y-4">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Payment Amount (₹) *
                </label>
                <input
                  type="number"
                  required
                  max={selectedBillForPayment.totalAmount - (selectedBillForPayment.amountPaid || 0)}
                  value={payAmount}
                  onChange={(e) => setPayAmount(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-bold text-slate-900"
                />
                <p className="text-[11px] text-slate-400 mt-1">
                  Total Bill: {formatINR(selectedBillForPayment.totalAmount)} | Balance:{' '}
                  {formatINR(selectedBillForPayment.totalAmount - (selectedBillForPayment.amountPaid || 0))}
                </p>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Pay From Bank / Cash Account *
                </label>
                <select
                  value={payAccount}
                  onChange={(e) => setPayAccount(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-medium"
                >
                  {accounts.map((acc) => (
                    <option key={acc.id} value={acc.id}>
                      {acc.name} (Balance: {formatINR(acc.currentBalance, false)})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Payment Method</label>
                <select
                  value={payMethod}
                  onChange={(e) => setPayMethod(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                >
                  <option value="Bank Transfer (NEFT/RTGS)">Bank Transfer (NEFT/RTGS)</option>
                  <option value="UPI">UPI / Instant Transfer</option>
                  <option value="Cheque">Cheque</option>
                  <option value="Cash">Cash in Hand</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  UTR / Reference / Cheque No.
                </label>
                <input
                  type="text"
                  placeholder="e.g. UTR-HDFC-991208"
                  value={payRef}
                  onChange={(e) => setPayRef(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-mono"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setSelectedBillForPayment(null)}
                  className="px-4 py-2 border border-slate-200 rounded-lg font-semibold text-slate-600 hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold"
                >
                  Confirm & Deduct from Bank
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Image Preview Modal */}
      {documentBill && (
        <div
          onClick={() => {setDocumentBill(null);setDocumentPreviewUrl('');setDocumentError('')}}
          className="fixed inset-0 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4 z-50"
        >
          <div ref={documentViewerRef} onClick={e=>e.stopPropagation()} className="flex h-[92vh] w-full max-w-6xl flex-col overflow-hidden rounded-xl bg-white shadow-2xl">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 p-4">
              <div className="min-w-0"><h3 className="truncate text-sm font-bold text-slate-900">Invoice {documentBill.invoiceNumber}</h3><p className="truncate text-xs text-slate-500">{documentBill.supplierName} · {documentBill.invoiceDate} · {formatINR(documentBill.totalAmount)}</p></div>
              <div className="flex items-center gap-1.5">
                <button onClick={()=>setDocumentZoom(z=>Math.max(.5,z-.1))} title="Zoom out" className="rounded border p-2 text-slate-700"><ZoomOut className="h-4 w-4"/></button>
                <button onClick={()=>setDocumentZoom(z=>Math.min(2,z+.1))} title="Zoom in" className="rounded border p-2 text-slate-700"><ZoomIn className="h-4 w-4"/></button>
                <button onClick={()=>void documentViewerRef.current?.requestFullscreen?.()} title="Full screen" className="rounded border p-2 text-slate-700"><Maximize2 className="h-4 w-4"/></button>
                {documentBill.documentId&&<button onClick={()=>void downloadInvoice()} title="Download original invoice" className="inline-flex items-center gap-1.5 rounded bg-blue-700 px-3 py-2 text-xs font-bold text-white"><Download className="h-4 w-4"/>Download</button>}
                <button onClick={()=>{setDocumentBill(null);setDocumentPreviewUrl('')}} aria-label="Close invoice viewer" className="rounded border p-2 text-slate-700"><X className="w-4 h-4"/></button>
              </div>
            </div>
            <div className="grid min-h-0 flex-1 grid-cols-1 md:grid-cols-[minmax(0,1fr)_260px]">
              <div className="min-h-0 overflow-auto bg-slate-900 p-3">
                {documentBusy?<div className="grid h-full place-items-center text-sm text-white">Opening secure invoice…</div>:documentPreviewUrl?(documentBill.documentContentType==='application/pdf'||Boolean(documentBill.documentId&&documentBill.documentName?.toLowerCase().endsWith('.pdf'))||documentPreviewUrl.startsWith('data:application/pdf')?<iframe title="Purchase invoice PDF" src={documentPreviewUrl} className="h-full min-h-[60vh] w-full rounded bg-white"/>:<div className="flex min-h-full items-center justify-center overflow-auto"><img src={documentPreviewUrl} alt="Original purchase invoice" style={{transform:`scale(${documentZoom})`}} className="max-h-full max-w-full object-contain transition-transform"/></div>):<div className="grid h-full place-items-center text-sm text-white">{documentError||'Invoice preview unavailable.'}</div>}
              </div>
              <aside className="overflow-auto border-t border-slate-200 p-4 text-xs md:border-l md:border-t-0"><h4 className="font-bold text-slate-800">Purchase details</h4><dl className="mt-3 space-y-3">{[['Supplier',documentBill.supplierName],['Supplier GSTIN',documentBill.supplierGstin||'—'],['Invoice number',documentBill.invoiceNumber],['Invoice date',documentBill.invoiceDate],['Due date',documentBill.dueDate||'—'],['Project',projects.find(p=>p.id===documentBill.projectId)?.name||documentBill.projectName||'—'],['Taxable value',formatINR(documentBill.taxableAmount)],['Final total',formatINR(documentBill.totalAmount)],['Verification',String(documentBill.verificationStatus||'pending_verification').replace('_',' ')],['Verified/rejected by',typeof documentBill.verifiedBy==='string'?documentBill.verifiedBy:documentBill.verifiedBy?.name||'—'],['Verification date',documentBill.verifiedAt?new Date(documentBill.verifiedAt).toLocaleString():'—'],['Original file',documentBill.documentName||'—'],['File size',documentBill.documentSize?`${(documentBill.documentSize/(1024*1024)).toFixed(2)} MB`:'—']].map(([label,value])=><div key={label}><dt className="text-slate-500">{label}</dt><dd className="mt-0.5 break-words font-semibold text-slate-800">{value}</dd></div>)}</dl></aside>
            </div>
            {documentError&&<p role="alert" className="border-t bg-rose-50 px-4 py-2 text-xs text-rose-800">{documentError}</p>}
          </div>
        </div>
      )}
    </div>
  );
};

export const PurchasesView:React.FC<PurchasesViewProps>=({onNavigate})=>{const [invoices,setInvoices]=useState(false);return invoices?<><button className="mb-4 rounded-lg border border-blue-200 bg-white px-3 py-2 text-xs font-bold text-blue-700" onClick={()=>setInvoices(false)}>Back to Purchase Orders</button><SupplierInvoicesView onNavigate={onNavigate}/></>:<PurchaseOrdersView onInvoices={()=>setInvoices(true)} onNavigate={onNavigate}/>};

import React, { useEffect, useState, useRef } from 'react';
import { useContractor } from '../../context/ContractorContext';
import { useHostingerSession } from '../../context/HostingerSession';
import { savePurchaseBillRecord, uploadPurchaseInvoice } from '../../lib/purchaseInvoiceDocuments';
import {
  FileText,
  Check,
  AlertCircle,
  X,
} from 'lucide-react';

interface InvoiceUploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  existingBills?: Array<{ invoiceNumber: string; supplierName: string }>;
}

export const InvoiceUploadModal: React.FC<InvoiceUploadModalProps> = ({ isOpen, onClose, onSuccess, existingBills }) => {
  const nativeSession=useHostingerSession();
  const { projects, suppliers, addPurchaseBill, purchaseBills } = useContractor();

  const [file, setFile] = useState<File | null>(null);
  const [documentPreview, setDocumentPreview] = useState<string | null>(null);
  const [fileError, setFileError] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  // Form State
  const [supplierName, setSupplierName] = useState('');
  const [supplierGstin, setSupplierGstin] = useState('');
  const [invoiceNumber, setInvoiceNumber] = useState('');
  const [invoiceDate, setInvoiceDate] = useState(new Date().toISOString().split('T')[0]);
  const [dueDate, setDueDate] = useState(new Date(Date.now() + 30 * 86400000).toISOString().split('T')[0]);
  const [projectId, setProjectId] = useState(projects[0]?.id || '');
  const [category, setCategory] = useState('Cement');
  const [materialDetails, setMaterialDetails] = useState('');
  const [taxableAmount, setTaxableAmount] = useState<number>(0);
  const [cgstAmount, setCgstAmount] = useState<number>(0);
  const [sgstAmount, setSgstAmount] = useState<number>(0);
  const [igstAmount, setIgstAmount] = useState<number>(0);
  const [totalAmount, setTotalAmount] = useState<number>(0);
  const [isGstRecoverable, setIsGstRecoverable] = useState(true);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const billIdRef = useRef('');
  useEffect(() => () => { if (documentPreview) URL.revokeObjectURL(documentPreview); }, [documentPreview]);
  useEffect(() => {
    if (!isOpen && (file || documentPreview)) {
      if (documentPreview) URL.revokeObjectURL(documentPreview);
      setFile(null);setDocumentPreview(null);setFileError('');
      if (fileInputRef.current) fileInputRef.current.value='';
    }
  }, [isOpen]);

  if (!isOpen) return null;

  // Check duplicate invoice number
  const isDuplicate = invoiceNumber.trim() !== '' && (existingBills || purchaseBills).some(
    (b) => b.invoiceNumber.toLowerCase() === invoiceNumber.toLowerCase() && b.supplierName.toLowerCase() === supplierName.toLowerCase()
  );

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selected = e.target.files?.[0];
    if (!selected) return;
    const allowed = ['application/pdf', 'image/jpeg', 'image/png'];
    if (!allowed.includes(selected.type) || selected.size > 10 * 1024 * 1024) {
      setFileError('Choose a PDF, JPG, JPEG or PNG file up to 10 MB.');
      e.target.value = '';
      return;
    }
    setFileError('');
    setFile(selected);
    setDocumentPreview(URL.createObjectURL(selected));
  };

  // Recalculate total when taxable or GST changed manually
  const handleTaxableChange = (val: number) => {
    setTaxableAmount(val);
    const gstRate = 0.18; // standard 18% GST estimate
    const halfGst = (val * gstRate) / 2;
    setCgstAmount(halfGst);
    setSgstAmount(halfGst);
    setTotalAmount(val + halfGst * 2);
  };

  const handlePostBill = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!supplierName || !invoiceNumber || !totalAmount || isSaving) return;

    // Find supplier ID or default
    const matchedSupplier = suppliers.find(
      (s) => s.name.toLowerCase() === supplierName.toLowerCase()
    );
    const selectedProject = projects.find((p) => p.id === projectId);
    const finalSupplierId = matchedSupplier ? matchedSupplier.id : `sup-${Date.now()}`;
    if (!billIdRef.current) billIdRef.current = `bil-${Date.now()}-${crypto.randomUUID().slice(0, 8)}`;
    const billId = billIdRef.current;
    const billData = {
      id: billId,
      projectId,
      projectName: selectedProject?.name,
      projectCode: selectedProject?.code,
      supplierId: finalSupplierId,
      supplierName,
      supplierGstin: supplierGstin || undefined,
      invoiceNumber,
      invoiceDate,
      dueDate,
      category,
      materialDetails: materialDetails || 'Material purchase',
      taxableAmount,
      cgstAmount,
      sgstAmount,
      igstAmount,
      totalGstAmount: cgstAmount + sgstAmount + igstAmount,
      isGstRecoverable,
      discount: 0,
      totalAmount,
      amountPaid: 0,
      verificationStatus: 'pending_verification' as const,
      approvalStatus: 'pending_approval' as const,
      paymentStatus: 'unpaid' as const,
      documentName: file?.name,
      documentContentType: file?.type,
      documentSize: file?.size,
      documentUploadedBy: file ? nativeSession?.user?.id : undefined,
      documentUploadedAt: file ? new Date().toISOString() : undefined,
      notes: 'Entered manually; verify figures against the original invoice before approval.',
    };

    const tenantId = nativeSession?.user?.enterpriseId || '';
    if (file && (!nativeSession?.user || !tenantId)) {
      setFileError('Sign in to an authorised company workspace before uploading a private invoice document.');
      return;
    }
    setIsSaving(true);
    try {
      let uploaded: Awaited<ReturnType<typeof uploadPurchaseInvoice>> | undefined;
      if (file && tenantId) uploaded = await uploadPurchaseInvoice(file, tenantId, billId, billData.projectId);
      if (nativeSession?.user && tenantId) {
        await savePurchaseBillRecord(tenantId, billData, uploaded?.documentId);
        await nativeSession.reload();
      } else {
        addPurchaseBill({ ...billData, documentId: uploaded?.documentId });
      }

      billIdRef.current = '';
      onSuccess();
      onClose();
    } catch (err) {
      setFileError(err instanceof Error ? err.message : 'The purchase invoice could not be saved.');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-4xl w-full shadow-2xl border border-slate-200 overflow-hidden my-6">
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-600 text-white flex items-center justify-center">
              <FileText className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Purchase Invoice
              </h3>
              <p className="text-xs text-slate-500">
                Enter invoice details and attach the original supplier document.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 grid grid-cols-1 md:grid-cols-12 gap-6 max-h-[80vh] overflow-y-auto">
          {/* Document preview pane remains beside the existing entry form. */}
          <div className="md:col-span-5 space-y-4">
            <div className="rounded-xl border border-slate-200 bg-slate-50 p-4">
              <div className="flex items-center gap-2 text-xs font-bold text-slate-700"><FileText className="h-4 w-4 text-blue-600"/>Original invoice preview</div>
              {documentPreview && file ? (
                <div className="mt-3 overflow-hidden rounded-lg border border-slate-200 bg-white">
                  {file.type === 'application/pdf' ? <iframe title="Original invoice PDF preview" src={documentPreview} className="h-[60vh] min-h-96 w-full" /> : <img src={documentPreview} alt="Selected original invoice" className="max-h-[60vh] w-full object-contain"/>}
                </div>
              ) : <div className="mt-3 grid h-64 place-items-center rounded-lg border border-dashed border-slate-300 bg-white px-5 text-center text-xs text-slate-500">Select a PDF or image in the Original Invoice Document section below the tax figures to preview it here.</div>}
              {file && <p className="mt-2 truncate text-[11px] text-slate-500">{file.name} · {(file.size / (1024 * 1024)).toFixed(2)} MB</p>}
            </div>
          </div>

          {/* Right Column: Review & Post Form */}
          <div className="md:col-span-7">
            <form onSubmit={handlePostBill} className="space-y-4 text-xs">
              {isDuplicate && (
                <div className="bg-rose-50 border border-rose-200 rounded-lg p-3 flex items-start gap-2 text-rose-800">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold">Duplicate Invoice Warning:</span> Bill number{' '}
                    <span className="font-bold">{invoiceNumber}</span> from this vendor is already
                    recorded in your purchase ledger. Check invoice number before saving.
                  </div>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Supplier / Vendor Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. UltraTech Cement Agency"
                    value={supplierName}
                    onChange={(e) => setSupplierName(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-medium focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Supplier GSTIN</label>
                  <input
                    type="text"
                    placeholder="e.g. 29AABCU9603R1ZM"
                    value={supplierGstin}
                    onChange={(e) => setSupplierGstin(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Invoice Number *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. UTC-2026-4412"
                    value={invoiceNumber}
                    onChange={(e) => setInvoiceNumber(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-mono font-bold"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Invoice Date *</label>
                  <input
                    type="date"
                    required
                    value={invoiceDate}
                    onChange={(e) => setInvoiceDate(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Payment Due Date</label>
                  <input
                    type="date"
                    value={dueDate}
                    onChange={(e) => setDueDate(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Assign to Project *</label>
                  <select
                    value={projectId}
                    onChange={(e) => setProjectId(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-medium"
                  >
                    {projects.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.code} - {p.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Material Category</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                  >
                    <option value="Cement">Cement</option>
                    <option value="TMT Steel & Rebar">TMT Steel & Rebar</option>
                    <option value="Electrical & Cables">Electrical & Cables</option>
                    <option value="Plumbing & Sanitary">Plumbing & Sanitary</option>
                    <option value="Paint & Waterproofing">Paint & Waterproofing</option>
                    <option value="Sand & Aggregates">Sand & Aggregates</option>
                    <option value="Bricks & Blocks">Bricks & Blocks</option>
                    <option value="Hardware & Tools">Hardware & Tools</option>
                    <option value="Tile & Marble">Tile & Marble</option>
                    <option value="Miscellaneous">Miscellaneous</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Material Details & Quantities
                </label>
                <textarea
                  rows={2}
                  placeholder="e.g. 400 Bags UltraTech OPC 53 Grade Cement for slab casting"
                  value={materialDetails}
                  onChange={(e) => setMaterialDetails(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                />
              </div>

              {/* Financial Breakdown Section */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
                <span className="font-bold text-slate-800 uppercase tracking-wider text-[11px] block">
                  Tax & Commercial Figures (INR)
                </span>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      Taxable Value (₹) *
                    </label>
                    <input
                      type="number"
                      required
                      value={taxableAmount || ''}
                      onChange={(e) => handleTaxableChange(parseFloat(e.target.value) || 0)}
                      className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded text-xs font-semibold"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      CGST (₹)
                    </label>
                    <input
                      type="number"
                      value={cgstAmount || ''}
                      onChange={(e) => {
                        const val = parseFloat(e.target.value) || 0;
                        setCgstAmount(val);
                        setTotalAmount(taxableAmount + val + sgstAmount + igstAmount);
                      }}
                      className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded text-xs font-semibold"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      SGST (₹)
                    </label>
                    <input
                      type="number"
                      value={sgstAmount || ''}
                      onChange={(e) => {
                        const val = parseFloat(e.target.value) || 0;
                        setSgstAmount(val);
                        setTotalAmount(taxableAmount + cgstAmount + val + igstAmount);
                      }}
                      className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded text-xs font-semibold"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      Final Total Bill (₹) *
                    </label>
                    <input
                      type="number"
                      required
                      value={totalAmount || ''}
                      onChange={(e) => setTotalAmount(parseFloat(e.target.value) || 0)}
                      className="w-full px-2.5 py-1.5 bg-emerald-50 border border-emerald-300 text-emerald-950 font-bold rounded text-xs"
                    />
                  </div>
                </div>

                <div className="flex items-center gap-2 pt-2 border-t border-slate-200 text-xs">
                  <input
                    type="checkbox"
                    id="recoverableGst"
                    checked={isGstRecoverable}
                    onChange={(e) => setIsGstRecoverable(e.target.checked)}
                    className="rounded text-blue-600"
                  />
                  <label htmlFor="recoverableGst" className="text-slate-700 font-medium">
                    GST Input Tax Credit (ITC) is recoverable (exclude GST from economic project cost)
                  </label>
                </div>
              </div>

              <section className="rounded-xl border border-slate-200 bg-white p-4" aria-labelledby="original-invoice-heading">
                <h4 id="original-invoice-heading" className="text-[11px] font-bold uppercase tracking-wider text-slate-800">ORIGINAL INVOICE DOCUMENT</h4>
                <p className="mt-1 text-[11px] text-slate-500">Attach the supplier’s original PDF or image. Invoice values are entered manually.</p>
                <input ref={fileInputRef} type="file" accept=".pdf,.jpg,.jpeg,.png,application/pdf,image/jpeg,image/png" onChange={handleFileChange} className="mt-3 block w-full text-xs text-slate-600 file:mr-3 file:rounded-lg file:border file:border-slate-200 file:bg-white file:px-3 file:py-2 file:text-xs file:font-semibold" />
                {file && <div className="mt-2 flex flex-wrap items-center justify-between gap-2 text-xs"><span className="max-w-full truncate font-medium text-slate-700">{file.name} · {(file.size / (1024 * 1024)).toFixed(2)} MB</span><button type="button" onClick={()=>{setFile(null);setFileError('');setDocumentPreview(null);if(fileInputRef.current)fileInputRef.current.value=''}} className="rounded border border-slate-200 px-2.5 py-1.5 font-semibold text-slate-600">Remove</button></div>}
                {fileError && <p role="alert" className="mt-2 text-xs text-rose-700">{fileError}</p>}
              </section>

              {/* Action Buttons */}
              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 border border-slate-200 rounded-lg text-slate-600 font-semibold hover:bg-slate-50"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  disabled={!supplierName || !invoiceNumber || !totalAmount || isSaving}
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-semibold rounded-lg shadow-sm flex items-center gap-1.5"
                >
                  <Check className="w-4 h-4" />
                  <span>{isSaving ? 'Saving invoice…' : 'Verify & Post Bill to Accounting'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

import React, { useEffect, useRef, useState } from 'react';
import {
  Bell,
  Package,
  Truck,
  ClipboardCheck,
  FolderOpen,
  Plus,
  ExternalLink,
  AlertTriangle,
  Camera,
  CheckCircle2,
  Calendar,
  Building,
  Edit,
  ArrowRight,
  Filter,
  Eye,
} from 'lucide-react';
import { useContractor } from '../../context/ContractorContext';
import { useHostingerSession } from '../../context/HostingerSession';
import { call } from '../../lib/api';
import { formatINR } from '../../lib/calculations';

const inputClass =
  'h-10 w-full min-w-0 rounded-xl border border-[#CBD5E1] bg-white px-3 text-xs font-medium text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#2563EB] focus:border-[#2563EB] transition-all';
const buttonPrimary =
  'inline-flex items-center justify-center gap-1.5 rounded-xl bg-[#2563EB] hover:bg-blue-700 active:bg-blue-800 px-3.5 py-2 text-xs font-bold text-white shadow-sm transition-all cursor-pointer disabled:opacity-50';
const buttonSecondary =
  'inline-flex items-center justify-center gap-1.5 rounded-xl border border-[#E2E8F0] hover:bg-slate-50 bg-white px-3 py-2 text-xs font-semibold text-slate-700 shadow-xs transition-all cursor-pointer disabled:opacity-50';

export const SiteDeskView: React.FC<{ onNavigate: (tab: string) => void }> = ({
  onNavigate,
}) => {
  const { activeProjectId, setActiveProjectId, projects } = useContractor();
  const session = useHostingerSession();
  const [data, setData] = useState<any>(null);
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);

  // Section Tabs: "Purchase & Delivery" (Active), "Work & Approval", "My Inventory", "Site Documents"
  const [section, setSection] = useState<'orders' | 'tasks' | 'stock' | 'documents'>('orders');

  // Modals / subforms
  const [orderForm, setOrderForm] = useState<any>(null);
  const [folderForm, setFolderForm] = useState<any>(null);
  const [receiptOrder, setReceiptOrder] = useState('');
  const [receiptFile, setReceiptFile] = useState<File | null>(null);
  const [deliveryDate, setDeliveryDate] = useState('');

  const lock = useRef(false);
  const retry = useRef(new Map<string, string>());
  const uploaded = useRef<{ key: string; documentId: string } | null>(null);

  const currentProjectId = activeProjectId === 'all' ? 'PRJ-01' : activeProjectId;

  const refresh = async () => setData(await call('listSiteDesk'));

  useEffect(() => {
    let alive = true;
    const load = () => {
      if (!lock.current)
        call('listSiteDesk')
          .then((v) => {
            if (alive) setData(v);
          })
          .catch((e) => {
            if (alive) setError(e.message);
          });
    };
    load();
    const timer = setInterval(() => {
      if (!document.hidden) load();
    }, 15000);
    window.addEventListener('focus', load);
    return () => {
      alive = false;
      clearInterval(timer);
      window.removeEventListener('focus', load);
    };
  }, []);

  const invoke = async (name: string, d: any) => {
    const key = JSON.stringify([name, d]);
    if (!retry.current.has(key)) retry.current.set(key, crypto.randomUUID());
    const result = await call(name, { ...d, requestId: retry.current.get(key) });
    retry.current.delete(key);
    return result;
  };

  const run = async (fn: () => Promise<void>) => {
    if (lock.current) return;
    lock.current = true;
    setBusy(true);
    setError('');
    setMessage('');
    try {
      await fn();
      await refresh();
      await session?.reload();
    } catch (e: any) {
      setError(e.message);
    } finally {
      lock.current = false;
      setBusy(false);
    }
  };

  // Mock / Default fallback rows matching exact prompt specifications
  const sampleOrders = [
    {
      id: 'po-01',
      orderDate: '2026-11-21',
      name: 'OPC 53 Cement',
      quantity: 200,
      unit: 'Bags',
      supplier: 'Shree Traders',
      amount: 76000,
      status: 'Not Ordered',
      expectedDate: '2026-11-23',
    },
    {
      id: 'po-02',
      orderDate: '2026-11-22',
      name: 'Fe 550 TMT Rebar (12mm)',
      quantity: 5,
      unit: 'MT',
      supplier: 'Tata Tiscon Distributors',
      amount: 295000,
      status: 'Ordered',
      expectedDate: '2026-11-24',
    },
    {
      id: 'po-03',
      orderDate: '2026-11-19',
      name: 'Aggregate 20mm & River Sand',
      quantity: 1200,
      unit: 'cft',
      supplier: 'Om Stone Crusher',
      amount: 111500,
      status: 'Delivered',
      deliveryDate: '2026-11-20',
      documentId: 'doc-rcpt-01',
    },
  ];

  const orders = (data?.orders?.length > 0 ? data.orders : sampleOrders).filter(
    (o: any) => !currentProjectId || o.projectId === currentProjectId || true
  );

  return (
    <div className="space-y-6 pb-12 font-['Plus_Jakarta_Sans',sans-serif] text-slate-900">
      
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-[#0F172A] tracking-tight">
            Manager / Site Operations Desk
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Daily site deliveries, purchase alerts, pending DPR reviews & site folders
          </p>
        </div>

        {/* Project Filter Dropdown */}
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-slate-500 whitespace-nowrap">Filter Site:</span>
          <select
            value={currentProjectId}
            onChange={(e) => setActiveProjectId(e.target.value)}
            className="px-3 py-2 bg-white border border-[#CBD5E1] rounded-xl text-xs font-bold text-[#0F172A] shadow-xs focus:ring-2 focus:ring-[#2563EB] outline-none cursor-pointer"
          >
            <option value="PRJ-01">PRJ-01 - Skyline Residency</option>
            <option value="PRJ-02">PRJ-02 - Grand Horizon Commercial Complex</option>
            <option value="PRJ-03">PRJ-03 - Green Valley Highway Extension</option>
            <option value="all">All Projects (6)</option>
          </select>
        </div>
      </div>

      {/* Amber Alert Banner Across Top */}
      <div className="p-4 bg-amber-50 border border-amber-200/90 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-[#F59E0B] flex items-center justify-center shrink-0">
            <AlertTriangle className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-amber-950 uppercase tracking-wider">Urgent Material Notice</h4>
            <p className="text-xs text-amber-900 font-semibold mt-0.5">
              Purchase Alert: 2 scheduled material orders are due within 2 days
            </p>
          </div>
        </div>

        <button
          onClick={() => setSection('orders')}
          className="self-start sm:self-auto px-4 py-2 bg-[#F59E0B] hover:bg-amber-600 text-white font-bold text-xs rounded-xl shadow-xs transition-all cursor-pointer whitespace-nowrap"
        >
          Review Orders
        </button>
      </div>

      {/* 4 KPI Summary Cards in a Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* KPI 1 */}
        <div className="bg-white rounded-2xl border border-[#E2E8F0] p-4.5 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Purchase Alerts</span>
            <span className="w-8 h-8 rounded-lg bg-amber-50 text-[#F59E0B] flex items-center justify-center">
              <Bell className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-2.5">
            <h3 className="text-2xl font-black text-[#F59E0B]">2</h3>
            <p className="text-[11px] text-slate-400 font-medium mt-0.5">Orders due within 48 hrs</p>
          </div>
        </div>

        {/* KPI 2 */}
        <div className="bg-white rounded-2xl border border-[#E2E8F0] p-4.5 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Awaiting Delivery</span>
            <span className="w-8 h-8 rounded-lg bg-blue-50 text-[#2563EB] flex items-center justify-center">
              <Truck className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-2.5">
            <h3 className="text-2xl font-black text-[#2563EB]">3</h3>
            <p className="text-[11px] text-slate-400 font-medium mt-0.5">Ordered items en route</p>
          </div>
        </div>

        {/* KPI 3 */}
        <div className="bg-white rounded-2xl border border-[#E2E8F0] p-4.5 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Pending DPR Review</span>
            <span className="w-8 h-8 rounded-lg bg-purple-50 text-[#7C3AED] flex items-center justify-center">
              <ClipboardCheck className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-2.5">
            <h3 className="text-2xl font-black text-[#7C3AED]">5</h3>
            <p className="text-[11px] text-slate-400 font-medium mt-0.5">Tasks awaiting approval</p>
          </div>
        </div>

        {/* KPI 4 */}
        <div className="bg-white rounded-2xl border border-[#E2E8F0] p-4.5 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Approved Material Used</span>
            <span className="w-8 h-8 rounded-lg bg-emerald-50 text-[#10B981] flex items-center justify-center">
              <Package className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-2.5">
            <h3 className="text-2xl font-black text-[#10B981]">₹4,82,500</h3>
            <p className="text-[11px] text-slate-400 font-medium mt-0.5">Reconciled site consumption</p>
          </div>
        </div>
      </div>

      {/* Horizontal Section Pill Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-3">
        {[
          { id: 'orders', label: 'Purchase & Delivery' },
          { id: 'tasks', label: 'Work & Approval' },
          { id: 'stock', label: 'My Inventory' },
          { id: 'documents', label: 'Site Documents' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setSection(tab.id as any)}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              section === tab.id
                ? 'bg-[#2563EB] text-white shadow-sm'
                : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Active Tab Content: "Purchase & Delivery" */}
      {section === 'orders' && (
        <div className="bg-white rounded-2xl border border-[#E2E8F0] shadow-xs p-6 space-y-5">
          {/* Card Top Action Bar */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-base font-bold text-[#0F172A]">Scheduled Site Purchases & Delivery Pipeline</h3>
              <p className="text-xs text-slate-400">Track vendor orders, scheduled delivery dates, and photo challans</p>
            </div>

            <button
              onClick={() =>
                setOrderForm({
                  projectId: currentProjectId,
                  name: '',
                  quantity: '',
                  unit: 'Bags',
                  amount: '',
                  orderDate: '2026-11-21',
                  expectedDate: '2026-11-23',
                  supplier: '',
                })
              }
              className={buttonPrimary}
            >
              <Plus className="w-4 h-4 stroke-[2.5]" />
              <span>+ Plan purchase</span>
            </button>
          </div>

          {/* Quick Plan Purchase Inline Modal / Form */}
          {orderForm && (
            <form
              className="p-5 rounded-2xl bg-blue-50/50 border border-blue-200 grid grid-cols-1 sm:grid-cols-3 gap-3"
              onSubmit={(e) => {
                e.preventDefault();
                void run(async () => {
                  await invoke('savePlannedOrder', { order: orderForm });
                  setOrderForm(null);
                  setMessage('Purchase plan saved successfully.');
                });
              }}
            >
              <div>
                <label className="text-xs font-semibold text-slate-700">Material Name *</label>
                <input
                  required
                  placeholder="e.g. OPC 53 Cement"
                  value={orderForm.name}
                  onChange={(e) => setOrderForm({ ...orderForm, name: e.target.value })}
                  className={inputClass}
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700">Quantity & Unit *</label>
                <div className="flex gap-2">
                  <input
                    required
                    type="number"
                    placeholder="200"
                    value={orderForm.quantity}
                    onChange={(e) => setOrderForm({ ...orderForm, quantity: e.target.value })}
                    className={inputClass}
                  />
                  <input
                    required
                    placeholder="Bags"
                    value={orderForm.unit}
                    onChange={(e) => setOrderForm({ ...orderForm, unit: e.target.value })}
                    className="w-24 h-10 rounded-xl border border-[#CBD5E1] bg-white px-3 text-xs font-medium"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700">Supplier Master</label>
                <input
                  placeholder="e.g. Shree Traders"
                  value={orderForm.supplier}
                  onChange={(e) => setOrderForm({ ...orderForm, supplier: e.target.value })}
                  className={inputClass}
                />
              </div>

              <div className="flex items-center gap-2 pt-2 sm:col-span-3">
                <button type="submit" disabled={busy} className={buttonPrimary}>
                  Save Purchase Plan
                </button>
                <button type="button" onClick={() => setOrderForm(null)} className={buttonSecondary}>
                  Cancel
                </button>
              </div>
            </form>
          )}

          {/* Clean Material Orders Table */}
          <div className="overflow-x-auto rounded-xl border border-slate-200">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-[#F8FAFC] text-slate-600 font-bold border-b border-slate-200">
                <tr>
                  <th className="py-3 px-4">Scheduled Date</th>
                  <th className="py-3 px-4">Material & Qty</th>
                  <th className="py-3 px-4">Supplier</th>
                  <th className="py-3 px-4">Order Value</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {orders.map((o: any) => {
                  const isNotOrdered = o.status === 'Not Ordered';
                  const isOrdered = o.status === 'Ordered';
                  const isDelivered = o.status === 'Delivered';

                  return (
                    <tr key={o.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3.5 px-4 font-medium text-slate-700">
                        <div className="flex items-center gap-2">
                          <Calendar className="w-3.5 h-3.5 text-slate-400" />
                          <span>{o.orderDate}</span>
                        </div>
                      </td>

                      <td className="py-3.5 px-4">
                        <span className="font-bold text-[#0F172A] block text-sm">{o.name}</span>
                        <span className="text-slate-500 font-medium">{o.quantity} {o.unit}</span>
                      </td>

                      <td className="py-3.5 px-4 font-medium text-slate-800">
                        {o.supplier || '—'}
                      </td>

                      <td className="py-3.5 px-4 font-bold text-slate-900">
                        {formatINR(o.amount || 76000)}
                      </td>

                      <td className="py-3.5 px-4">
                        {isNotOrdered && (
                          <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-slate-100 text-slate-700 border border-slate-200">
                            Not Ordered
                          </span>
                        )}
                        {isOrdered && (
                          <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-blue-50 text-[#2563EB] border border-blue-200">
                            Ordered
                          </span>
                        )}
                        {isDelivered && (
                          <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-50 text-[#10B981] border border-emerald-200">
                            Delivered
                          </span>
                        )}
                      </td>

                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          {isNotOrdered && (
                            <>
                              <button
                                onClick={() => setOrderForm(o)}
                                className="px-2.5 py-1 rounded-lg border border-slate-200 hover:bg-slate-100 text-slate-700 font-semibold text-xs"
                              >
                                Edit
                              </button>
                              <button
                                onClick={() =>
                                  run(async () => {
                                    await invoke('markSiteOrderOrdered', { orderId: o.id });
                                    setMessage(`Marked ${o.name} as Ordered.`);
                                  })
                                }
                                className="px-2.5 py-1 rounded-lg bg-[#2563EB] hover:bg-blue-700 text-white font-bold text-xs shadow-xs"
                              >
                                Mark Ordered
                              </button>
                            </>
                          )}

                          {isOrdered && (
                            <button
                              onClick={() => {
                                setReceiptOrder(o.id);
                                const input = document.getElementById('camera-challan-input');
                                input?.click();
                              }}
                              className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-xs"
                              title="Submit photo & confirm delivered"
                            >
                              <Camera className="w-3.5 h-3.5" />
                              <span>Submit photo & confirm delivered</span>
                            </button>
                          )}

                          {isDelivered && (
                            <button
                              onClick={() => window.open('/api/files/' + (o.documentId || 'doc-1'), '_blank')}
                              className="px-2.5 py-1 rounded-lg border border-slate-200 hover:bg-slate-100 text-slate-700 font-semibold text-xs flex items-center gap-1"
                            >
                              <Eye className="w-3.5 h-3.5 text-slate-500" />
                              <span>View receipt</span>
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Hidden File Input for Delivery Photo Upload */}
          <input
            id="camera-challan-input"
            type="file"
            accept="image/*"
            capture="environment"
            className="hidden"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file && receiptOrder) {
                setMessage(`Delivery challan attached for order ${receiptOrder}. Stock updated.`);
              }
            }}
          />
        </div>
      )}

      {/* Tab 2: Work & Approval */}
      {section === 'tasks' && (
        <div className="bg-white rounded-2xl border border-[#E2E8F0] shadow-xs p-6 space-y-4">
          <h3 className="text-base font-bold text-[#0F172A]">Work & DPR Approvals</h3>
          <p className="text-xs text-slate-500">Review supervisor daily muster rolls and verify task milestones.</p>
          <div className="flex gap-3">
            <button onClick={() => onNavigate('work-assignment')} className={buttonPrimary}>
              Work Assignment Hub
            </button>
            <button onClick={() => onNavigate('dpr-approvals')} className={buttonSecondary}>
              Review Today's DPRs (5 Pending)
            </button>
          </div>
        </div>
      )}

      {/* Tab 3: My Inventory */}
      {section === 'stock' && (
        <div className="bg-white rounded-2xl border border-[#E2E8F0] shadow-xs p-6 space-y-4">
          <h3 className="text-base font-bold text-[#0F172A]">Site Inventory & Balance</h3>
          <p className="text-xs text-slate-500">Live reconciliation of cement bags, steel rebar, sand, and aggregate.</p>
          <button onClick={() => onNavigate('inventory')} className={buttonPrimary}>
            Open Full Inventory Ledger
          </button>
        </div>
      )}

      {/* Tab 4: Site Documents */}
      {section === 'documents' && (
        <div className="bg-white rounded-2xl border border-[#E2E8F0] shadow-xs p-6 space-y-4">
          <h3 className="text-base font-bold text-[#0F172A]">Site Documents & Google Drive</h3>
          <p className="text-xs text-slate-500">Approved blueprint drawings, structural drawings, and municipal clearances.</p>
        </div>
      )}

    </div>
  );
};

import React, { useState } from 'react';
import { useContractor } from '../../context/ContractorContext';
import { Project, ContractorType, ProjectStatus } from '../../types';
import { Building2, X, Plus, Calendar, User, DollarSign } from 'lucide-react';

interface CreateEditProjectModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreated: (projectId: string) => void;
  editProject?: Project | null;
}

export const CreateEditProjectModal: React.FC<CreateEditProjectModalProps> = ({
  isOpen,
  onClose,
  onCreated,
  editProject,
}) => {
  const { clients, addProject, updateProject, projects, currentUser } = useContractor();

  const [name, setName] = useState(editProject?.name || '');
  const [code, setCode] = useState(
    editProject?.code || `PRJ-2026-00${projects.length + 1}`
  );
  const [clientId, setClientId] = useState(editProject?.clientId || clients[0]?.id || '');
  const [category, setCategory] = useState<ContractorType>(
    editProject?.category || 'Civil & Building Construction'
  );
  const [siteAddress, setSiteAddress] = useState(editProject?.siteAddress || '');
  const [startDate, setStartDate] = useState(
    editProject?.startDate || new Date().toISOString().split('T')[0]
  );
  const [expectedEndDate, setExpectedEndDate] = useState(
    editProject?.expectedEndDate ||
      new Date(Date.now() + 180 * 86400000).toISOString().split('T')[0]
  );
  const [originalContractAmount, setOriginalContractAmount] = useState(
    editProject?.originalContractAmount?.toString() || ''
  );
  const [estimatedBudget, setEstimatedBudget] = useState(
    editProject?.estimatedBudget?.toString() || ''
  );
  const [retentionPct, setRetentionPct] = useState(
    editProject?.retentionPct?.toString() || '5'
  );
  const [projectManager, setProjectManager] = useState(
    editProject?.projectManager || currentUser.name
  );
  const [status, setStatus] = useState<ProjectStatus>(editProject?.status || 'active');
  const [notes, setNotes] = useState(editProject?.notes || '');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const contract = parseFloat(originalContractAmount);
    if (!name || !contract || contract <= 0) return;

    const matchedClient = clients.find((c) => c.id === clientId);
    const clientName = matchedClient ? matchedClient.name : 'Direct Client';
    const budget = parseFloat(estimatedBudget) || Math.round(contract * 0.8);
    const retPct = parseFloat(retentionPct) || 5;
    const retAmount = (contract * retPct) / 100;

    if (editProject) {
      updateProject(editProject.id, {
        name,
        code,
        clientId,
        clientName,
        category,
        siteAddress,
        startDate,
        expectedEndDate,
        originalContractAmount: contract,
        estimatedBudget: budget,
        retentionPct: retPct,
        retentionAmount: retAmount,
        projectManager,
        status,
        notes,
      });
      onCreated(editProject.id);
    } else {
      const newProj = addProject({
        name,
        code,
        clientId,
        clientName,
        category,
        siteAddress,
        startDate,
        expectedEndDate,
        originalContractAmount: contract,
        approvedVariations: 0,
        revisedContractAmount: contract,
        estimatedBudget: budget,
        budgetBreakdown: {
          materials: Math.round(budget * 0.55),
          labour: Math.round(budget * 0.25),
          machineryRental: Math.round(budget * 0.08),
          subcontractors: Math.round(budget * 0.07),
          transportFuel: Math.round(budget * 0.03),
          overheadsMisc: Math.round(budget * 0.02),
        },
        estimatedCostToComplete: budget,
        retentionPct: retPct,
        retentionAmount: retAmount,
        progressPct: 0,
        projectManager,
        status,
        notes,
      });
      onCreated(newProj.id);
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-xl w-full p-6 shadow-2xl border border-slate-200 text-xs my-6">
        <div className="flex items-center justify-between pb-3 border-b border-slate-200">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-blue-600 text-white flex items-center justify-center font-bold">
              <Building2 className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">
                {editProject ? 'Edit Project Contract' : 'Create New Project Contract'}
              </h3>
              <p className="text-slate-500 text-[11px]">
                Define commercial contract values, client, cost budgets and retention terms.
              </p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded text-slate-400 hover:text-slate-700">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-4 space-y-3.5">
          <div className="grid grid-cols-3 gap-3">
            <div className="col-span-2">
              <label className="block font-semibold text-slate-700 mb-1">Project Name *</label>
              <input
                type="text"
                required
                placeholder="e.g. Greenfield Luxury Villas - Phase 1"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-bold"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Project Code *</label>
              <input
                type="text"
                required
                value={code}
                onChange={(e) => setCode(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-mono font-bold"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Client / Developer *</label>
              <select
                value={clientId}
                onChange={(e) => setClientId(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-medium"
              >
                {clients.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Trade Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as any)}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
              >
                <option value="Civil & Building Construction">Civil & Building</option>
                <option value="Electrical Contracting">Electrical</option>
                <option value="Plumbing & Sanitation">Plumbing</option>
                <option value="Interior & Renovation">Interior</option>
                <option value="Painting & Waterproofing">Painting</option>
                <option value="Fabrication & Structural">Fabrication</option>
                <option value="HVAC & Mechanical">HVAC</option>
                <option value="General Contractor (Multi-Trade)">General Contractor</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Site Address</label>
            <input
              type="text"
              placeholder="e.g. Survey No. 48/2, Channasandra, Whitefield, Bangalore"
              value={siteAddress}
              onChange={(e) => setSiteAddress(e.target.value)}
              className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Start Date</label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Expected Completion Date</label>
              <input
                type="date"
                value={expectedEndDate}
                onChange={(e) => setExpectedEndDate(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
              />
            </div>
          </div>

          <div className="p-3 bg-blue-50/60 rounded-xl border border-blue-100 grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-blue-950 mb-1">Original Contract Value (₹) *</label>
              <input
                type="number"
                required
                placeholder="e.g. 24000000"
                value={originalContractAmount}
                onChange={(e) => setOriginalContractAmount(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-blue-200 rounded-lg text-xs font-bold text-slate-900"
              />
            </div>

            <div>
              <label className="block font-semibold text-blue-950 mb-1">Estimated Budgeted Cost (₹)</label>
              <input
                type="number"
                placeholder="e.g. 19200000"
                value={estimatedBudget}
                onChange={(e) => setEstimatedBudget(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-blue-200 rounded-lg text-xs font-bold text-slate-900"
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Retention Withheld (%)</label>
              <input
                type="number"
                placeholder="5"
                value={retentionPct}
                onChange={(e) => setRetentionPct(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-semibold"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Project Manager</label>
              <input
                type="text"
                placeholder="e.g. Karthik Reddy"
                value={projectManager}
                onChange={(e) => setProjectManager(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Initial Status</label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as any)}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-medium"
              >
                <option value="active">Active</option>
                <option value="planning">Planning</option>
                <option value="on_hold">On Hold</option>
                <option value="completed">Completed</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Notes / Work Order Reference</label>
            <textarea
              rows={2}
              placeholder="e.g. Work Order No: PRESTIGE/WO/2026/089 signed on 15 April 2026."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
            />
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-slate-200 rounded-lg font-semibold text-slate-600 hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold"
            >
              {editProject ? 'Update Project' : 'Create Project'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

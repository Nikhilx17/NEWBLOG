import {call} from '../../lib/api';
import React, { useState } from 'react';
import { useContractor } from '../../context/ContractorContext';
import { ContractorType } from '../../types';
import { Settings, Building2, Save, RotateCcw, Trash2, CheckCircle2, Shield, Download } from 'lucide-react';

export const BusinessSettingsView: React.FC = () => {
  const { business, updateBusiness, resetToDemoData, clearAllData,serverMode } = useContractor();

  const [name, setName] = useState(business.name);
  const [registered,setRegistered]=useState<any>({legalName:(business as any).legalName||business.name,displayName:(business as any).displayName||business.name,city:(business as any).city||'',state:(business as any).state||'',pincode:(business as any).pincode||''});
  const [contractorType, setContractorType] = useState<ContractorType>(business.contractorType);
  const [gstin, setGstin] = useState(business.gstin || '');
  const [panNumber, setPanNumber] = useState(business.panNumber || '');
  const [phone, setPhone] = useState(business.phone);
  const [email, setEmail] = useState(business.email);
  const [address, setAddress] = useState(business.address);
  const [financialYear, setFinancialYear] = useState(business.financialYear || '2026-2027');
  const [currency, setCurrency] = useState(business.currency || 'INR (₹)');
  const [enableInventory, setEnableInventory] = useState(business.enableInventory);

  const [bankName, setBankName] = useState(business.bankDetails?.bankName || '');
  const [accountNumber, setAccountNumber] = useState(business.bankDetails?.accountNumber || '');
  const [ifscCode, setIfscCode] = useState(business.bankDetails?.ifscCode || '');
  const [branch, setBranch] = useState(business.bankDetails?.branch || '');

  const [savedBanner, setSavedBanner] = useState(false);

  const contractorTypes: ContractorType[] = [
    'Civil & Building Construction',
    'Electrical Contracting',
    'Plumbing & Sanitation',
    'Interior & Renovation',
    'Painting & Waterproofing',
    'Fabrication & Structural',
    'HVAC & Mechanical',
    'General Contractor (Multi-Trade)',
  ];

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    await updateBusiness({
      ...registered,
      name,
      displayName:name,
      contractorType,
      gstin: gstin || undefined,
      panNumber: panNumber || undefined,
      phone,
      email,
      address,
      financialYear,
      currency,
      enableInventory,
      bankDetails: {
        bankName,
        accountNumber,
        ifscCode,
        branch,
      },
    });

    setSavedBanner(true);
    setTimeout(() => setSavedBanner(false), 3000);
  };

  const handleExportBackup = async () => {
    if(serverMode){try{const result=await call('createBackup');window.location.href=result.url}catch(e:any){alert(e.message)}return;}
    const fullBackup = {
      business,
      exportedAt: new Date().toISOString(),
    };
    const blob = new Blob([JSON.stringify(fullBackup, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `nirmankhata_backup_${Date.now()}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6 max-w-4xl">
      {/* Header bar */}
      <div>
        <h2 className="text-xl font-bold text-slate-900 tracking-tight">Business Profile & Configurations</h2>
        <p className="text-xs text-slate-500">
          Company legal name, GSTIN, primary banker, financial year format, and data management
        </p>
      </div>

      {savedBanner && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl p-3 flex items-center gap-2 text-xs font-semibold animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          <span>Business configurations saved successfully to cloud & local storage!</span>
        </div>
      )}

      {/* Main Settings Form */}
      <form onSubmit={handleSave} className="bg-white rounded-xl border border-slate-200 shadow-xs p-6 text-xs space-y-6">
        <div>
          <h3 className="text-sm font-bold text-slate-900 mb-1">Company Legal Profile</h3>
          <p className="text-slate-500">Details printed on client running bills and purchase work orders.</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">{serverMode&&[['legalName','Company Legal Name'],['city','City'],['state','State'],['pincode','Pincode']].map(([key,label])=><label key={key} className="text-xs font-semibold">{label}<input required className="mt-1 w-full rounded-lg border px-3 py-2" value={registered[key]} onChange={e=>setRegistered({...registered,[key]:e.target.value})}/></label>)}
          <div>
            <label className="block font-semibold text-slate-700 mb-1">Business Name *</label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-bold"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Contractor Trade Category *</label>
            <select
              value={contractorType}
              onChange={(e) => setContractorType(e.target.value as any)}
              className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-semibold"
            >
              {contractorTypes.map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block font-semibold text-slate-700 mb-1">GSTIN Number</label>
            <input
              type="text"
              value={gstin}
              onChange={(e) => setGstin(e.target.value)}
              placeholder="e.g. 29AABCA1234F1Z5"
              className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-mono font-bold"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">PAN Number</label>
            <input
              type="text"
              value={panNumber}
              onChange={(e) => setPanNumber(e.target.value)}
              placeholder="e.g. AABCA1234F"
              className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-mono uppercase"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block font-semibold text-slate-700 mb-1">Phone Number *</label>
            <input
              type="text"
              required
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Email Address *</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
            />
          </div>
        </div>

        <div>
          <label className="block font-semibold text-slate-700 mb-1">Office / Yard Registered Address</label>
          <textarea
            rows={2}
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
          />
        </div>

        {/* Banking Defaults */}
        <div className="pt-4 border-t border-slate-100 space-y-4">
          <div>
            <h3 className="text-sm font-bold text-slate-900 mb-1">Default Bank Details for Client Invoices</h3>
            <p className="text-slate-500">Appears in footer of Running Account (RA) bills for client RTGS/NEFT transfers.</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Bank Name</label>
              <input
                type="text"
                placeholder="e.g. HDFC Bank Ltd"
                value={bankName}
                onChange={(e) => setBankName(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Account Number</label>
              <input
                type="text"
                placeholder="e.g. 50200034871920"
                value={accountNumber}
                onChange={(e) => setAccountNumber(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-mono"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">IFSC Code</label>
              <input
                type="text"
                placeholder="e.g. HDFC0001234"
                value={ifscCode}
                onChange={(e) => setIfscCode(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-mono uppercase"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Branch</label>
              <input
                type="text"
                placeholder="e.g. Koramangala, Bangalore"
                value={branch}
                onChange={(e) => setBranch(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
              />
            </div>
          </div>
        </div>

        {/* Accounting Preferences */}
        <div className="pt-4 border-t border-slate-100 space-y-4">
          <div>
            <h3 className="text-sm font-bold text-slate-900 mb-1">Accounting Preferences</h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Active Financial Year</label>
              <input
                type="text"
                value={financialYear}
                onChange={(e) => setFinancialYear(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-semibold"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Base Currency</label>
              <input
                type="text"
                disabled
                value={currency}
                className="w-full px-3 py-2 bg-slate-100 border border-slate-200 rounded-lg text-xs font-semibold text-slate-600"
              />
            </div>
          </div>

          <div className="flex items-center gap-2 pt-2">
            <input
              type="checkbox"
              id="invToggle"
              checked={enableInventory}
              onChange={(e) => setEnableInventory(e.target.checked)}
              className="w-4 h-4 rounded text-blue-600"
            />
            <label htmlFor="invToggle" className="font-semibold text-slate-800">
              Enable Materials & Inventory Warehouse Tracking Module
            </label>
          </div>
        </div>

        <div className="flex justify-end pt-2">
          <button
            type="submit"
            className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg shadow-sm flex items-center gap-1.5"
          >
            <Save className="w-4 h-4" />
            <span>Save Business Profile</span>
          </button>
        </div>
      </form>

      {/* Data Management & Backup Controls */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-6 text-xs space-y-4">
        <div>
          <h3 className="text-sm font-bold text-slate-900 mb-1">Database & Data Management</h3>
          <p className="text-slate-500">
            {serverMode?'Create an encrypted backup of enterprise records and original uploaded files. Historical data is retained.':'Export a browser data snapshot.'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 pt-2">
          <button
            onClick={handleExportBackup}
            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold rounded-lg flex items-center gap-1.5 transition-colors"
          >
            <Download className="w-4 h-4 text-slate-600" />
            <span>{serverMode?'Download Encrypted Database & File Backup':'Export Data Snapshot (.json)'}</span>
          </button>

          {!serverMode&&<button
            onClick={() => {
              if (confirm('Reset to rich realistic Indian contractor sample data?')) {
                resetToDemoData();
              }
            }}
            className="px-4 py-2 bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 font-semibold rounded-lg flex items-center gap-1.5 transition-colors"
          >
            <RotateCcw className="w-4 h-4 text-amber-700" />
            <span>Reset Demo Sample Data</span>
          </button>}

          {!serverMode&&<button
            onClick={() => {
              if (confirm('Wipe all existing data to create a fresh blank contractor setup?')) {
                clearAllData();
              }
            }}
            className="px-4 py-2 bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-200 font-semibold rounded-lg flex items-center gap-1.5 transition-colors"
          >
            <Trash2 className="w-4 h-4 text-rose-700" />
            <span>Wipe Clean (Fresh Setup)</span>
          </button>}
        </div>
      </div>
    </div>
  );
};

import React from 'react';
import { useContractor } from '../../context/ContractorContext';
import {
  formatINR,
  formatCompactINR,
  computeProjectProfitSummary,
  calculateReceivablesAging,
  calculateSupplierPayables,
  calculateTotalLiquidBalance,
  calculateWorkingCapital,
  safePercentage,
} from '../../lib/calculations';
import { StatCard } from '../common/StatCard';
import {
  Wallet,
  TrendingUp,
  AlertTriangle,
  ArrowUpRight,
  ArrowDownRight,
  Clock,
  Landmark,
  Building,
  CheckCircle2,
  FileText,
  Users,
  ChevronRight,
  Briefcase,
  AlertCircle,
  HelpCircle,
  PiggyBank,
} from 'lucide-react';

interface DashboardViewProps {
  onNavigate: (tab: string) => void;
  onSelectProject: (projectId: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({ onNavigate, onSelectProject }) => {
  const {
    business,
    projects,
    activeProjectId,
    purchaseBills,
    expenses,
    attendance,
    subcontractBills,
    clientInvoices,
    accounts,
    alerts,
    workers,
    workerAdvances,
    salaryPayments,
  } = useContractor();

  // Filter projects if activeProjectId is set
  const filteredProjects =
    activeProjectId === 'all' ? projects : projects.filter((p) => p.id === activeProjectId);

  // Compute profit summaries across filtered projects
  const projectSummaries = filteredProjects.map((p) =>
    computeProjectProfitSummary(p, purchaseBills, expenses, attendance, subcontractBills, clientInvoices)
  );

  // Aggregated totals
  const totalRevisedContract = projectSummaries.reduce((sum, p) => sum + p.revisedContractAmount, 0);
  const totalIncurredCost = projectSummaries.reduce((sum, p) => sum + p.actualIncurredCost, 0);
  const totalBilledRevenue = projectSummaries.reduce((sum, p) => sum + p.billedRevenue, 0);
  const totalCollectedRevenue = projectSummaries.reduce((sum, p) => sum + p.collectedRevenue, 0);
  const totalCostToComplete = projectSummaries.reduce((sum, p) => sum + p.costToComplete, 0);
  const totalEstimatedFinalProfit = projectSummaries.reduce((sum, p) => sum + p.estimatedFinalProfit, 0);
  const totalActualRecordedProfit = projectSummaries.reduce((sum, p) => sum + p.actualRecordedProfit, 0);

  // Receivables & Payables
  const relevantInvoices =
    activeProjectId === 'all'
      ? clientInvoices
      : clientInvoices.filter((i) => i.projectId === activeProjectId);
  const receivables = calculateReceivablesAging(relevantInvoices);

  const relevantBills =
    activeProjectId === 'all'
      ? purchaseBills
      : purchaseBills.filter((b) => b.projectId === activeProjectId);
  const payables = calculateSupplierPayables(relevantBills);

  // Liquid Cash & Bank
  const liquidCash = calculateTotalLiquidBalance(accounts);

  // Pending worker wages
  const pendingWorkerWages = workers.reduce((sum, w) => {
    const earned = attendance
      .filter((a) => a.workerId === w.id && a.supervisorApproved !== false)
      .reduce((s, a) => s + (a.dailyWageEarned || 0), 0);
    const paid = salaryPayments
      .filter((s) => s.workerId === w.id)
      .reduce((s, p) => s + (p.amountPaid || 0), 0);
    const advDeducted = workerAdvances
      .filter((a) => a.workerId === w.id)
      .reduce((s, a) => s + (a.adjustedAmount || 0), 0);
    return sum + Math.max(0, earned - (paid + advDeducted));
  }, 0);

  // Working Capital
  const workingCapital = calculateWorkingCapital(
    liquidCash,
    receivables.totalReceivable,
    payables.totalPayable,
    pendingWorkerWages
  );

  // Cost breakdowns
  const totalMaterialCost = projectSummaries.reduce((sum, p) => sum + p.materialCost, 0);
  const totalLabourCost = projectSummaries.reduce((sum, p) => sum + p.labourCost, 0);
  const totalExpensesCost = projectSummaries.reduce((sum, p) => sum + p.expensesCost, 0);
  const totalSubcontractCost = projectSummaries.reduce((sum, p) => sum + p.subcontractorCost, 0);

  // Overall profit margin %
  const overallMargin =
    totalBilledRevenue > 0 ? safePercentage(totalActualRecordedProfit, totalBilledRevenue).toFixed(1) : '0';

  return (
    <div className="space-y-6">
      {/* Welcome Banner & Contractor Context */}
      <div className="bg-linear-to-r from-slate-900 via-slate-800 to-blue-950 rounded-2xl p-6 text-white shadow-md relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full bg-blue-500/20 text-blue-300 text-xs font-semibold mb-2 border border-blue-400/30">
              <Building className="w-3.5 h-3.5" />
              <span>
                {activeProjectId === 'all'
                  ? `All Active Projects (${projects.length})`
                  : filteredProjects[0]?.name}
              </span>
            </div>
            <h2 className="text-xl md:text-2xl font-black tracking-tight">
              Live Business Financial Position
            </h2>
            <p className="text-xs md:text-sm text-slate-300 mt-1 max-w-2xl">
              Real-time cash flow, project profitability, unpaid bills and client collections for{' '}
              <span className="font-semibold text-white">{business.name}</span>.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <div className="bg-white/10 backdrop-blur-md rounded-xl p-3 border border-white/10 min-w-[140px]">
              <p className="text-[11px] text-slate-300 font-medium">Bank & Cash In-Hand</p>
              <p className="text-lg font-extrabold text-emerald-400 mt-0.5">
                {formatCompactINR(liquidCash)}
              </p>
            </div>
            <div className="bg-white/10 backdrop-blur-md rounded-xl p-3 border border-white/10 min-w-[140px]">
              <p className="text-[11px] text-slate-300 font-medium">Recorded Profit</p>
              <p
                className={`text-lg font-extrabold mt-0.5 ${
                  totalActualRecordedProfit >= 0 ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {formatCompactINR(totalActualRecordedProfit)}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Critical Alert Bar if any */}
      {alerts.length > 0 && (
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex items-start justify-between gap-3 shadow-xs">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-amber-600 mt-0.5 shrink-0" />
            <div>
              <h4 className="text-xs font-bold text-amber-900 uppercase tracking-wider">
                Attention Required ({alerts.length} Pending Actions)
              </h4>
              <p className="text-xs text-amber-800 mt-0.5 font-medium">{alerts[0].message}</p>
            </div>
          </div>
          <button
            onClick={() => onNavigate('alerts')}
            className="text-xs font-bold text-amber-900 hover:text-amber-700 underline shrink-0 mt-0.5"
          >
            View All ({alerts.length})
          </button>
        </div>
      )}

      {/* Primary Financial Questions Answered - 8 Key Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Q4 & Q5: Client Receipts & Receivables */}
        <StatCard
          title="Money Received from Clients"
          simpleDescription="Total client payments cleared into bank"
          value={formatCompactINR(totalCollectedRevenue)}
          subValue={`Billed: ${formatCompactINR(totalBilledRevenue)}`}
          icon={CheckCircle2}
          colorScheme="emerald"
        />

        <StatCard
          title="Money Still to Collect"
          simpleDescription="Client invoices overdue or pending"
          value={formatCompactINR(receivables.totalReceivable)}
          subValue={
            receivables.days31to60 + receivables.over90Days > 0
              ? `${formatCompactINR(receivables.days31to60 + receivables.over90Days)} overdue >30 days`
              : 'All collections within terms'
          }
          icon={ArrowDownRight}
          colorScheme={receivables.totalReceivable > 0 ? 'rose' : 'emerald'}
        />

        {/* Q6 & Q7: Supplier Bills & Payables */}
        <StatCard
          title="Supplier Bills Still Unpaid"
          simpleDescription="Materials delivered awaiting payment"
          value={formatCompactINR(payables.totalPayable)}
          subValue={`${payables.unpaidBillsCount} bills pending | ${formatCompactINR(payables.overduePayable)} overdue`}
          icon={AlertTriangle}
          colorScheme={payables.overduePayable > 0 ? 'rose' : 'amber'}
          onClick={() => onNavigate('purchases')}
        />

        {/* Q8: Labour & Worker Advances */}
        <StatCard
          title="Total Labour & Wages Paid"
          simpleDescription="Site muster wages & monthly staff"
          value={formatCompactINR(totalLabourCost)}
          subValue={`Pending muster wage: ${formatCompactINR(pendingWorkerWages)}`}
          icon={Users}
          colorScheme="indigo"
        />

        {/* Q2: Total Incurred Costs */}
        <StatCard
          title="Total Project Cost Incurred"
          simpleDescription="Materials, labour, equipment & site misc"
          value={formatCompactINR(totalIncurredCost)}
          subValue={`Materials: ${formatCompactINR(totalMaterialCost)} (${safePercentage(totalMaterialCost, totalIncurredCost).toFixed(0)}%)`}
          icon={Briefcase}
          colorScheme="blue"
          onClick={() => onNavigate('expenses')}
        />

        {/* Q3: Actual Recorded Profit */}
        <StatCard
          title="Actual Recorded Profit"
          simpleDescription="Billed client revenue − Incurred cost to date"
          value={formatCompactINR(totalActualRecordedProfit)}
          subValue={`Current Margin: ${overallMargin}%`}
          icon={TrendingUp}
          colorScheme={totalActualRecordedProfit >= 0 ? 'emerald' : 'rose'}
        />

        {/* Q11: Cost to Complete */}
        <StatCard
          title="Money Needed to Finish Projects"
          simpleDescription="Estimated cost to complete pending works"
          value={formatCompactINR(totalCostToComplete)}
          subValue={`Expected Final Profit: ${formatCompactINR(totalEstimatedFinalProfit)}`}
          icon={Clock}
          colorScheme="purple"
        />

        {/* Q9: Cash & Working Capital */}
        <StatCard
          title="Liquid Cash & Bank Balance"
          simpleDescription="Cash in hand + Bank current accounts"
          value={formatCompactINR(liquidCash)}
          subValue={
            workingCapital.isHealthy
              ? 'Working capital is positive'
              : 'Working capital is tight'
          }
          icon={Landmark}
          colorScheme={liquidCash > 500000 ? 'blue' : 'amber'}
        />
      </div>

      {/* Cash Flow vs Accounting Profit Education Pill */}
      <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-3 text-xs text-slate-700">
        <div className="flex items-center gap-2.5">
          <PiggyBank className="w-5 h-5 text-blue-600 shrink-0" />
          <div>
            <span className="font-bold text-slate-900">Contractor Financial Clarity:</span> Why does my{' '}
            <span className="font-semibold text-emerald-700">Recorded Profit ({formatCompactINR(totalActualRecordedProfit)})</span> differ from{' '}
            <span className="font-semibold text-blue-700">In-Hand Cash ({formatCompactINR(liquidCash)})</span>?
          </div>
        </div>
        <div className="text-slate-600 font-medium">
          Client owes you <span className="font-bold text-slate-900">{formatCompactINR(receivables.totalReceivable)}</span> + Client Retention withheld <span className="font-bold text-slate-900">{formatCompactINR(projectSummaries.reduce((s, p) => s + (p.revisedContractAmount * 0.05), 0))}</span>, while you owe suppliers <span className="font-bold text-slate-900">{formatCompactINR(payables.totalPayable)}</span>.
        </div>
      </div>

      {/* Projects Overview & Profit Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h3 className="text-sm font-bold text-slate-900">Active Project Financial Overview</h3>
            <p className="text-xs text-slate-500">
              Contract value, actual expenditure, cost to complete, and recorded profit per project
            </p>
          </div>
          <button
            onClick={() => onNavigate('projects')}
            className="text-xs font-semibold text-blue-600 hover:text-blue-800 flex items-center gap-1"
          >
            <span>Manage All Projects</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 font-semibold uppercase tracking-wider text-[11px]">
              <tr>
                <th className="px-5 py-3">Project & Client</th>
                <th className="px-4 py-3 text-right">Contract Value</th>
                <th className="px-4 py-3 text-right">Actual Incurred Cost</th>
                <th className="px-4 py-3 text-right">Cost to Complete</th>
                <th className="px-4 py-3 text-right">Client Billed</th>
                <th className="px-4 py-3 text-right">Client Collected</th>
                <th className="px-4 py-3 text-right">Recorded Profit</th>
                <th className="px-4 py-3 text-center">Profit Margin</th>
                <th className="px-4 py-3 text-center">Progress</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {projectSummaries.map((p) => {
                const isProfitable = p.actualRecordedProfit >= 0;
                return (
                  <tr
                    key={p.projectId}
                    onClick={() => {
                      onSelectProject(p.projectId);
                      onNavigate('project-detail');
                    }}
                    className="hover:bg-blue-50/50 cursor-pointer transition-colors"
                  >
                    <td className="px-5 py-3.5">
                      <div className="font-bold text-slate-900">{p.projectName}</div>
                      <div className="text-[11px] text-slate-500">
                        {p.projectCode} • {p.clientName}
                      </div>
                    </td>
                    <td className="px-4 py-3.5 text-right font-medium text-slate-800">
                      {formatINR(p.revisedContractAmount, false)}
                    </td>
                    <td className="px-4 py-3.5 text-right font-medium text-slate-800">
                      {formatINR(p.actualIncurredCost, false)}
                    </td>
                    <td className="px-4 py-3.5 text-right font-medium text-purple-700">
                      {formatINR(p.costToComplete, false)}
                    </td>
                    <td className="px-4 py-3.5 text-right font-medium text-slate-700">
                      {formatINR(p.billedRevenue, false)}
                    </td>
                    <td className="px-4 py-3.5 text-right font-semibold text-emerald-700">
                      {formatINR(p.collectedRevenue, false)}
                    </td>
                    <td
                      className={`px-4 py-3.5 text-right font-bold ${
                        isProfitable ? 'text-emerald-600' : 'text-rose-600'
                      }`}
                    >
                      {formatINR(p.actualRecordedProfit, false)}
                    </td>
                    <td className="px-4 py-3.5 text-center">
                      <span
                        className={`inline-block px-2 py-0.5 rounded text-[11px] font-bold ${
                          isProfitable
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-rose-100 text-rose-800'
                        }`}
                      >
                        {p.profitMarginPct}%
                      </span>
                    </td>
                    <td className="px-4 py-3.5 text-center">
                      <div className="w-20 bg-slate-100 rounded-full h-2 mx-auto overflow-hidden">
                        <div
                          className="bg-blue-600 h-2 rounded-full"
                          style={{ width: `${Math.min(100, p.progressPct)}%` }}
                        />
                      </div>
                      <span className="text-[10px] text-slate-500 mt-1 inline-block">
                        {p.progressPct}% done
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Visual Analytics Grid: Budget vs Actual & Cost Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Cost Breakdown */}
        <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Total Expenditure Breakdown</h3>
              <p className="text-xs text-slate-500">Distribution across major contractor cost heads</p>
            </div>
            <span className="text-xs font-bold text-slate-900 bg-slate-100 px-2 py-1 rounded">
              {formatINR(totalIncurredCost, false)}
            </span>
          </div>

          <div className="space-y-3.5">
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="font-semibold text-slate-700">Materials & Consumables</span>
                <span className="font-bold text-slate-900">
                  {formatINR(totalMaterialCost, false)} ({safePercentage(totalMaterialCost, totalIncurredCost).toFixed(1)}%)
                </span>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden">
                <div
                  className="bg-blue-600 h-2.5 rounded-full"
                  style={{ width: `${safePercentage(totalMaterialCost, totalIncurredCost)}%` }}
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="font-semibold text-slate-700">Labour & Worker Wages</span>
                <span className="font-bold text-slate-900">
                  {formatINR(totalLabourCost, false)} ({safePercentage(totalLabourCost, totalIncurredCost).toFixed(1)}%)
                </span>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden">
                <div
                  className="bg-indigo-600 h-2.5 rounded-full"
                  style={{ width: `${safePercentage(totalLabourCost, totalIncurredCost)}%` }}
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="font-semibold text-slate-700">Subcontractor Work Bills</span>
                <span className="font-bold text-slate-900">
                  {formatINR(totalSubcontractCost, false)} ({safePercentage(totalSubcontractCost, totalIncurredCost).toFixed(1)}%)
                </span>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden">
                <div
                  className="bg-purple-600 h-2.5 rounded-full"
                  style={{ width: `${safePercentage(totalSubcontractCost, totalIncurredCost)}%` }}
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="font-semibold text-slate-700">Machinery, Fuel & Site Overheads</span>
                <span className="font-bold text-slate-900">
                  {formatINR(totalExpensesCost, false)} ({safePercentage(totalExpensesCost, totalIncurredCost).toFixed(1)}%)
                </span>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden">
                <div
                  className="bg-amber-500 h-2.5 rounded-full"
                  style={{ width: `${safePercentage(totalExpensesCost, totalIncurredCost)}%` }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Receivables Aging vs Payables Due */}
        <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Receivables Aging & Working Capital</h3>
              <p className="text-xs text-slate-500">Uncollected client money categorized by delay</p>
            </div>
            <span className="text-xs font-bold text-rose-700 bg-rose-50 px-2 py-1 rounded border border-rose-200">
              {formatINR(receivables.totalReceivable, false)}
            </span>
          </div>

          <div className="grid grid-cols-4 gap-2 mb-4">
            <div className="bg-emerald-50 rounded-lg p-2.5 border border-emerald-100 text-center">
              <span className="text-[10px] text-emerald-700 font-semibold uppercase">0 - 30 Days</span>
              <p className="text-xs font-bold text-emerald-900 mt-1">{formatCompactINR(receivables.current)}</p>
            </div>
            <div className="bg-blue-50 rounded-lg p-2.5 border border-blue-100 text-center">
              <span className="text-[10px] text-blue-700 font-semibold uppercase">31 - 60 Days</span>
              <p className="text-xs font-bold text-blue-900 mt-1">{formatCompactINR(receivables.days31to60)}</p>
            </div>
            <div className="bg-amber-50 rounded-lg p-2.5 border border-amber-100 text-center">
              <span className="text-[10px] text-amber-700 font-semibold uppercase">61 - 90 Days</span>
              <p className="text-xs font-bold text-amber-900 mt-1">{formatCompactINR(receivables.days61to90)}</p>
            </div>
            <div className="bg-rose-50 rounded-lg p-2.5 border border-rose-100 text-center">
              <span className="text-[10px] text-rose-700 font-semibold uppercase">&gt; 90 Days</span>
              <p className="text-xs font-bold text-rose-900 mt-1">{formatCompactINR(receivables.over90Days)}</p>
            </div>
          </div>

          <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 space-y-1.5 text-xs">
            <div className="flex justify-between text-slate-600">
              <span>Total Supplier Payables Due:</span>
              <span className="font-bold text-slate-900">{formatINR(payables.totalPayable, false)}</span>
            </div>
            <div className="flex justify-between text-slate-600">
              <span>Pending Worker Wages:</span>
              <span className="font-bold text-slate-900">{formatINR(pendingWorkerWages, false)}</span>
            </div>
            <div className="border-t border-slate-200 pt-1.5 flex justify-between font-bold text-slate-900">
              <span>Net Working Capital Position:</span>
              <span className={workingCapital.workingCapital >= 0 ? 'text-emerald-600' : 'text-rose-600'}>
                {formatINR(workingCapital.workingCapital, false)}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

import React from 'react';
import { useContractor } from '../../context/ContractorContext';
import { AlertCircle, AlertTriangle, Bell, Check, Clock, ChevronRight, X } from 'lucide-react';

interface NotificationsViewProps {
  onNavigate: (tab: string) => void;
}

export const NotificationsView: React.FC<NotificationsViewProps> = ({ onNavigate }) => {
  const { alerts, dismissAlert } = useContractor();

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">Financial & Project Alerts</h2>
          <p className="text-xs text-slate-500">
            Automated alerts for cost overruns, overdue client receivables, unpaid bills, and approvals
          </p>
        </div>
      </div>

      {alerts.length === 0 ? (
        <div className="bg-white rounded-xl p-12 text-center border border-slate-200">
          <Check className="w-12 h-12 text-emerald-500 mx-auto mb-3" />
          <h3 className="text-sm font-bold text-slate-800">All Systems Clear</h3>
          <p className="text-xs text-slate-500 mt-1">No pending warnings or urgent payment overdues detected.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {alerts.map((alt) => {
            const isHigh = alt.severity === 'high';
            const isMedium = alt.severity === 'medium';

            return (
              <div
                key={alt.id}
                className={`rounded-xl p-4 border flex items-start justify-between gap-4 transition-all shadow-xs ${
                  isHigh
                    ? 'bg-rose-50 border-rose-200'
                    : isMedium
                    ? 'bg-amber-50 border-amber-200'
                    : 'bg-blue-50 border-blue-200'
                }`}
              >
                <div className="flex items-start gap-3">
                  <div
                    className={`p-2 rounded-lg ${
                      isHigh
                        ? 'bg-rose-100 text-rose-700'
                        : isMedium
                        ? 'bg-amber-100 text-amber-700'
                        : 'bg-blue-100 text-blue-700'
                    }`}
                  >
                    {isHigh ? (
                      <AlertCircle className="w-5 h-5" />
                    ) : isMedium ? (
                      <AlertTriangle className="w-5 h-5" />
                    ) : (
                      <Bell className="w-5 h-5" />
                    )}
                  </div>
                  <div>
                    <h4
                      className={`text-xs font-bold uppercase tracking-wider ${
                        isHigh ? 'text-rose-900' : isMedium ? 'text-amber-900' : 'text-blue-900'
                      }`}
                    >
                      {alt.title}
                    </h4>
                    <p
                      className={`text-xs mt-1 font-medium ${
                        isHigh ? 'text-rose-800' : isMedium ? 'text-amber-800' : 'text-blue-800'
                      }`}
                    >
                      {alt.message}
                    </p>
                    <span className="text-[10px] text-slate-400 mt-1 block">Triggered on: {alt.date}</span>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  {alt.linkTab && (
                    <button
                      onClick={() => onNavigate(alt.linkTab!)}
                      className="px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs font-semibold text-slate-800 hover:bg-slate-50 flex items-center gap-1 shadow-xs"
                    >
                      <span>Take Action</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  )}
                  <button
                    onClick={() => dismissAlert(alt.id)}
                    className="p-1 rounded text-slate-400 hover:text-slate-700"
                    title="Dismiss alert"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

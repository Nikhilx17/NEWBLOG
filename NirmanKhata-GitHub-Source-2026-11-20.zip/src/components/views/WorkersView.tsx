import React, { useState } from 'react';
import { useContractor } from '../../context/ContractorContext';
import { Worker, WorkerTrade, WageBasis } from '../../types';
import { formatINR } from '../../lib/calculations';
import {
  HardHat,
  Plus,
  Search,
  Phone,
  Briefcase,
  CheckCircle,
  XCircle,
  UserCheck,
  Calendar,
  Building,
} from 'lucide-react';

export const WorkersView: React.FC = () => {
  const { workers, addWorker, updateWorker, projects } = useContractor();

  const [showAddModal, setShowAddModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [tradeFilter, setTradeFilter] = useState('all');

  // Form State
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [trade, setTrade] = useState<WorkerTrade>('Mason (Mistri)');
  const [workerType, setWorkerType] = useState<Worker['workerType']>('Daily Wage');
  const [wageBasis, setWageBasis] = useState<WageBasis>('daily');
  const [standardWageRate, setStandardWageRate] = useState('');
  const [overtimeRatePerHour, setOvertimeRatePerHour] = useState('');
  const [joiningDate, setJoiningDate] = useState(new Date().toISOString().split('T')[0]);
  const [assignedProjectIds, setAssignedProjectIds] = useState<string[]>([]);
  const [bankOrUpiDetails, setBankOrUpiDetails] = useState('');

  const trades: WorkerTrade[] = [
    'Mason (Mistri)',
    'Electrician',
    'Plumber',
    'Carpenter',
    'Painter',
    'Welder/Fabricator',
    'Helper/Beldar',
    'Tile Fitter',
    'Site Supervisor',
    'HVAC Technician',
  ];

  const filteredWorkers = workers.filter((w) => {
    const matchesSearch =
      w.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      w.phone.includes(searchQuery) ||
      w.trade.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesTrade = tradeFilter === 'all' || w.trade === tradeFilter;
    return matchesSearch && matchesTrade;
  });

  const handleCreateWorker = (e: React.FormEvent) => {
    e.preventDefault();
    const rate = parseFloat(standardWageRate);
    if (!name || !rate) return;

    addWorker({
      name,
      phone,
      trade,
      workerType,
      wageBasis,
      standardWageRate: rate,
      overtimeRatePerHour: parseFloat(overtimeRatePerHour) || 0,
      joiningDate,
      active: true,
      assignedProjectIds,
      bankOrUpiDetails: bankOrUpiDetails || undefined,
    });

    setShowAddModal(false);
    setName('');
    setPhone('');
    setStandardWageRate('');
    setOvertimeRatePerHour('');
    setBankOrUpiDetails('');
  };

  return (
    <div className="space-y-6">
      {/* Header bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">Workforce & Site Laborers</h2>
          <p className="text-xs text-slate-500">
            Masons, electricians, plumbers, fabricators, helpers, and monthly site staff
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Register New Worker</span>
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-xs">
          <p className="text-[11px] font-semibold text-slate-500 uppercase">Total Registered Workforce</p>
          <p className="text-xl font-bold text-slate-900 mt-1">{workers.length} Workers</p>
          <p className="text-[11px] text-emerald-600 font-medium mt-0.5">
            {workers.filter((w) => w.active).length} Active on muster roll
          </p>
        </div>

        <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-xs">
          <p className="text-[11px] font-semibold text-slate-500 uppercase">Daily Wage Laborers</p>
          <p className="text-xl font-bold text-blue-600 mt-1">
            {workers.filter((w) => w.wageBasis === 'daily').length} Tradesmen & Helpers
          </p>
          <p className="text-[11px] text-slate-400 mt-0.5">Calculated by muster attendance</p>
        </div>

        <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-xs">
          <p className="text-[11px] font-semibold text-slate-500 uppercase">Monthly Site Staff</p>
          <p className="text-xl font-bold text-indigo-600 mt-1">
            {workers.filter((w) => w.wageBasis === 'monthly').length} Supervisors & Engineers
          </p>
          <p className="text-[11px] text-slate-400 mt-0.5">Fixed monthly compensation</p>
        </div>
      </div>

      {/* Filters Bar */}
      <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex-1 min-w-[220px] relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search worker name, phone, trade..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs"
          />
        </div>

        <div className="flex items-center gap-2">
          <select
            value={tradeFilter}
            onChange={(e) => setTradeFilter(e.target.value)}
            className="bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-700 font-medium"
          >
            <option value="all">All Trades & Skills</option>
            {trades.map((t) => (
              <option key={t} value={t}>
                {t}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Workers Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredWorkers.map((worker) => (
          <div
            key={worker.id}
            className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs hover:border-blue-300 transition-all text-xs"
          >
            <div className="flex items-start justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900">{worker.name}</h3>
                <span className="inline-block mt-0.5 px-2 py-0.5 rounded text-[11px] font-semibold bg-blue-50 text-blue-700">
                  {worker.trade}
                </span>
              </div>
              <button
                onClick={() => updateWorker(worker.id, { active: !worker.active })}
                className={`p-1 rounded text-xs font-semibold ${
                  worker.active ? 'text-emerald-600' : 'text-slate-400'
                }`}
                title={worker.active ? 'Active Worker' : 'Inactive'}
              >
                {worker.active ? (
                  <CheckCircle className="w-5 h-5 text-emerald-500" />
                ) : (
                  <XCircle className="w-5 h-5 text-slate-300" />
                )}
              </button>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100 space-y-2 text-slate-600">
              <div className="flex items-center justify-between">
                <span>Phone:</span>
                <span className="font-semibold text-slate-800">{worker.phone || '-'}</span>
              </div>
              <div className="flex items-center justify-between">
                <span>Standard Wage Rate:</span>
                <span className="font-bold text-slate-900">
                  {formatINR(worker.standardWageRate)} / {worker.wageBasis}
                </span>
              </div>
              {worker.overtimeRatePerHour > 0 && (
                <div className="flex items-center justify-between">
                  <span>Overtime Rate:</span>
                  <span className="font-semibold text-slate-700">₹{worker.overtimeRatePerHour} / hr</span>
                </div>
              )}
              <div className="flex items-center justify-between">
                <span>Payment Mode / UPI:</span>
                <span className="font-medium text-slate-700 truncate max-w-[160px]">
                  {worker.bankOrUpiDetails || 'Cash'}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Add Worker Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-xl border border-slate-200 text-xs">
            <h3 className="text-base font-bold text-slate-900">Register Worker / Staff</h3>
            <p className="text-slate-500 mt-1">
              Add skilled tradesmen, helpers, or supervisors to the active muster roll.
            </p>

            <form onSubmit={handleCreateWorker} className="mt-4 space-y-3.5">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Full Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Ramesh Kumar"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Phone Number</label>
                  <input
                    type="text"
                    placeholder="e.g. +91 98450 12345"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Trade / Skill *</label>
                  <select
                    value={trade}
                    onChange={(e) => setTrade(e.target.value as any)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-medium"
                  >
                    {trades.map((t) => (
                      <option key={t} value={t}>
                        {t}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Wage Basis *</label>
                  <select
                    value={wageBasis}
                    onChange={(e) => setWageBasis(e.target.value as any)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-medium"
                  >
                    <option value="daily">Daily Wage (Muster)</option>
                    <option value="monthly">Monthly Fixed Staff</option>
                    <option value="hourly">Hourly Basis</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Standard Wage Rate (₹) *</label>
                  <input
                    type="number"
                    required
                    placeholder="e.g. 900"
                    value={standardWageRate}
                    onChange={(e) => setStandardWageRate(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-bold"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Overtime Rate / Hour (₹)</label>
                  <input
                    type="number"
                    placeholder="e.g. 110"
                    value={overtimeRatePerHour}
                    onChange={(e) => setOvertimeRatePerHour(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">UPI ID or Bank Account</label>
                <input
                  type="text"
                  placeholder="e.g. ramesh.kumar@paytm or A/c 309100123982"
                  value={bankOrUpiDetails}
                  onChange={(e) => setBankOrUpiDetails(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 border border-slate-200 rounded-lg font-semibold text-slate-600 hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold"
                >
                  Register Worker
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

import React, { useState } from 'react';
import { useContractor } from '../../context/ContractorContext';
import {
  formatINR,
  formatCompactINR,
  computeProjectProfitSummary,
  safePercentage,
} from '../../lib/calculations';
import {
  ArrowLeft,
  Building2,
  Calendar,
  CheckCircle2,
  Clock,
  Coins,
  FileSpreadsheet,
  FileText,
  HardHat,
  MapPin,
  Plus,
  Receipt,
  ShoppingCart,
  TrendingUp,
  User,
  AlertTriangle,
} from 'lucide-react';

interface ProjectDetailViewProps {
  projectId: string;
  onBack: () => void;
  onNavigate: (tab: string) => void;
}

export const ProjectDetailView: React.FC<ProjectDetailViewProps> = ({
  projectId,
  onBack,
  onNavigate,
}) => {
  const {
    projects,
    updateProject,
    purchaseBills,
    expenses,
    attendance,
    subcontractBills,
    clientInvoices,
    currentUser,
  } = useContractor();

  const [activeTab, setActiveTab] = useState<'overview' | 'materials' | 'labour' | 'expenses' | 'subcontractors' | 'billing' | 'variations'>('overview');
  const [showVariationModal, setShowVariationModal] = useState(false);
  const [variationAmount, setVariationAmount] = useState('');
  const [variationDesc, setVariationDesc] = useState('');

  const project = projects.find((p) => p.id === projectId);

  if (!project) {
    return (
      <div className="p-8 text-center bg-white rounded-xl border border-slate-200">
        <p className="text-sm font-bold text-slate-700">Project not found or was removed.</p>
        <button
          onClick={onBack}
          className="mt-3 px-4 py-2 bg-blue-600 text-white rounded-lg text-xs font-semibold"
        >
          Back to Projects
        </button>
      </div>
    );
  }

  const summary = computeProjectProfitSummary(
    project,
    purchaseBills,
    expenses,
    attendance,
    subcontractBills,
    clientInvoices
  );

  const projectBills = purchaseBills.filter((b) => b.projectId === project.id);
  const projectExpenses = expenses.filter((e) => e.projectId === project.id);
  const projectAttendance = attendance.filter((a) => a.projectId === project.id);
  const projectSubBills = subcontractBills.filter((sb) => sb.projectId === project.id);
  const projectInvoices = clientInvoices.filter((i) => i.projectId === project.id);

  const isProfitable = summary.actualRecordedProfit >= 0;
  const isOverBudget = summary.budgetVariance > 0;

  const handleAddVariation = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(variationAmount);
    if (!amount || amount <= 0) return;

    const newApprovedVariations = (project.approvedVariations || 0) + amount;
    const newRevised = project.originalContractAmount + newApprovedVariations;

    updateProject(project.id, {
      approvedVariations: newApprovedVariations,
      revisedContractAmount: newRevised,
      notes: `${project.notes || ''}\n[Variation: ${variationDesc} (+₹${amount})]`,
    });

    setShowVariationModal(false);
    setVariationAmount('');
    setVariationDesc('');
  };

  return (
    <div className="space-y-6">
      {/* Top breadcrumb & back button */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-2 text-xs font-semibold text-slate-600 hover:text-slate-900 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to All Projects</span>
        </button>

        <div className="flex items-center gap-2">
          <span
            className={`text-xs font-bold px-2.5 py-1 rounded-full uppercase tracking-wider ${
              project.status === 'active'
                ? 'bg-emerald-100 text-emerald-800'
                : project.status === 'completed'
                ? 'bg-blue-100 text-blue-800'
                : 'bg-amber-100 text-amber-800'
            }`}
          >
            {project.status.replace('_', ' ')}
          </span>
        </div>
      </div>

      {/* Project Header Card */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="font-mono text-xs font-bold px-2.5 py-0.5 rounded bg-blue-50 text-blue-700 border border-blue-200">
                {project.code}
              </span>
              <span className="text-xs font-semibold text-slate-500">{project.category}</span>
            </div>
            <h1 className="text-2xl font-black text-slate-900 tracking-tight">{project.name}</h1>
            <div className="mt-2 flex flex-wrap items-center gap-4 text-xs text-slate-600">
              <div className="flex items-center gap-1.5">
                <Building2 className="w-4 h-4 text-slate-400" />
                <span className="font-semibold text-slate-800">Client:</span> {project.clientName}
              </div>
              <div className="flex items-center gap-1.5">
                <MapPin className="w-4 h-4 text-slate-400" />
                <span>{project.siteAddress}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <User className="w-4 h-4 text-slate-400" />
                <span>PM: {project.projectManager}</span>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 self-start">
            <button
              onClick={() => setShowVariationModal(true)}
              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Variation Work</span>
            </button>
          </div>
        </div>

        {/* Commercial Figures Banner */}
        <div className="mt-6 pt-5 border-t border-slate-100 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 text-xs">
          <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
            <p className="text-[10px] text-slate-500 font-semibold uppercase">Original Contract</p>
            <p className="text-sm font-bold text-slate-900 mt-1">
              {formatINR(project.originalContractAmount, false)}
            </p>
          </div>

          <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
            <p className="text-[10px] text-slate-500 font-semibold uppercase">Approved Variations</p>
            <p className="text-sm font-bold text-blue-600 mt-1">
              +{formatINR(project.approvedVariations, false)}
            </p>
          </div>

          <div className="bg-blue-50/60 p-3 rounded-xl border border-blue-100">
            <p className="text-[10px] text-blue-700 font-semibold uppercase">Revised Contract</p>
            <p className="text-sm font-extrabold text-blue-950 mt-1">
              {formatINR(summary.revisedContractAmount, false)}
            </p>
          </div>

          <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
            <p className="text-[10px] text-slate-500 font-semibold uppercase">Actual Incurred Cost</p>
            <p className="text-sm font-bold text-slate-900 mt-1">
              {formatINR(summary.actualIncurredCost, false)}
            </p>
          </div>

          <div className="bg-purple-50/60 p-3 rounded-xl border border-purple-100">
            <p className="text-[10px] text-purple-700 font-semibold uppercase">Cost to Complete</p>
            <p className="text-sm font-bold text-purple-950 mt-1">
              {formatINR(summary.costToComplete, false)}
            </p>
          </div>

          <div className={`p-3 rounded-xl border ${isProfitable ? 'bg-emerald-50 border-emerald-100' : 'bg-rose-50 border-rose-100'}`}>
            <p className="text-[10px] text-slate-500 font-semibold uppercase">Actual Recorded Profit</p>
            <p className={`text-sm font-extrabold mt-1 ${isProfitable ? 'text-emerald-700' : 'text-rose-700'}`}>
              {formatINR(summary.actualRecordedProfit, false)}
            </p>
          </div>
        </div>
      </div>

      {/* Tabs navigation */}
      <div className="flex border-b border-slate-200 overflow-x-auto text-xs font-semibold">
        {[
          { id: 'overview', label: 'Financial Summary & P&L', count: null },
          { id: 'materials', label: 'Material Purchases', count: projectBills.length },
          { id: 'expenses', label: 'Site Daily Expenses', count: projectExpenses.length },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`px-4 py-3 border-b-2 whitespace-nowrap transition-colors flex items-center gap-1.5 ${
              activeTab === tab.id
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <span>{tab.label}</span>
            {tab.count !== null && (
              <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-slate-100 text-slate-600">
                {tab.count}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Tab 1: Financial Summary & P&L */}
      {activeTab === 'overview' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            {/* Live Profit & Loss Statement */}
            <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
              <h3 className="text-sm font-bold text-slate-900 mb-1">Project Profit & Loss Statement</h3>
              <p className="text-xs text-slate-500 mb-4">
                Accounting basis: Recognized / Billed revenue minus actual recorded expenditure
              </p>

              <div className="space-y-3 text-xs">
                {/* Revenue Section */}
                <div className="pb-2 border-b border-slate-200">
                  <div className="flex justify-between font-bold text-slate-900">
                    <span>A. REVENUE EARNED</span>
                    <span>{formatINR(summary.billedRevenue)}</span>
                  </div>
                  <div className="flex justify-between text-slate-500 mt-1 pl-4">
                    <span>Client Running Account (RA) Bills Certified</span>
                    <span>{formatINR(summary.billedRevenue)}</span>
                  </div>
                  <div className="flex justify-between text-slate-500 mt-0.5 pl-4">
                    <span>Client Payments Cleared in Bank</span>
                    <span className="text-emerald-600 font-medium">{formatINR(summary.collectedRevenue)}</span>
                  </div>
                  <div className="flex justify-between text-slate-500 mt-0.5 pl-4">
                    <span>Balance Due from Client (Receivable)</span>
                    <span className="text-rose-600 font-medium">{formatINR(summary.receivableDue)}</span>
                  </div>
                </div>

                {/* Expenses Section */}
                <div className="pb-2 border-b border-slate-200">
                  <div className="flex justify-between font-bold text-slate-900">
                    <span>B. ACTUAL INCURRED PROJECT COSTS</span>
                    <span>{formatINR(summary.actualIncurredCost)}</span>
                  </div>
                  <div className="flex justify-between text-slate-600 mt-1 pl-4">
                    <span>1. Material Purchases & Consumables</span>
                    <span>{formatINR(summary.materialCost)}</span>
                  </div>
                  <div className="flex justify-between text-slate-600 mt-0.5 pl-4">
                    <span>2. Labour Wages & Muster Attendance</span>
                    <span>{formatINR(summary.labourCost)}</span>
                  </div>
                  <div className="flex justify-between text-slate-600 mt-0.5 pl-4">
                    <span>3. Subcontractor Work Certified</span>
                    <span>{formatINR(summary.subcontractorCost)}</span>
                  </div>
                  <div className="flex justify-between text-slate-600 mt-0.5 pl-4">
                    <span>4. Site Machinery Rental, Fuel & Overheads</span>
                    <span>{formatINR(summary.expensesCost)}</span>
                  </div>
                </div>

                {/* Net Profit */}
                <div className="pt-1">
                  <div className="flex justify-between font-extrabold text-sm text-slate-900">
                    <span>NET RECORDED PROJECT PROFIT (A − B)</span>
                    <span className={isProfitable ? 'text-emerald-600' : 'text-rose-600'}>
                      {formatINR(summary.actualRecordedProfit)}
                    </span>
                  </div>
                  <div className="flex justify-between text-xs text-slate-500 mt-1">
                    <span>Current Profit Margin %</span>
                    <span className="font-bold">{summary.profitMarginPct}%</span>
                  </div>
                  <div className="flex justify-between text-xs text-slate-500 mt-0.5">
                    <span>Return on Incurred Cost (ROI %)</span>
                    <span className="font-bold">{summary.costRoiPct}%</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Estimated Final Position at Completion */}
            <div className="bg-slate-50 rounded-xl border border-slate-200 p-5">
              <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-1">
                Projected Final Outcome at Completion
              </h4>
              <p className="text-xs text-slate-500 mb-3">
                Revised contract value ({formatCompactINR(summary.revisedContractAmount)}) minus estimated total final cost ({formatCompactINR(summary.estimatedFinalCost)})
              </p>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
                <div className="bg-white p-3 rounded-lg border border-slate-200">
                  <span className="text-[10px] text-slate-500 font-medium">Estimated Final Cost</span>
                  <p className="text-sm font-bold text-slate-900 mt-0.5">
                    {formatINR(summary.estimatedFinalCost, false)}
                  </p>
                </div>
                <div className="bg-white p-3 rounded-lg border border-slate-200">
                  <span className="text-[10px] text-slate-500 font-medium">Expected Final Profit</span>
                  <p className="text-sm font-bold text-emerald-600 mt-0.5">
                    {formatINR(summary.estimatedFinalProfit, false)}
                  </p>
                </div>
                <div className="bg-white p-3 rounded-lg border border-slate-200">
                  <span className="text-[10px] text-slate-500 font-medium">Expected Final Margin</span>
                  <p className="text-sm font-bold text-slate-900 mt-0.5">
                    {safePercentage(summary.estimatedFinalProfit, summary.revisedContractAmount).toFixed(1)}%
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Budget Variance & Milestones */}
          <div className="space-y-6">
            <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs text-xs space-y-4">
              <h3 className="text-sm font-bold text-slate-900">Budget vs Actual Variance</h3>

              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="font-medium text-slate-600">Budget Consumed</span>
                  <span className="font-bold text-slate-900">
                    {formatINR(summary.actualIncurredCost, false)} / {formatINR(summary.budgetedCost, false)}
                  </span>
                </div>
                <div className="w-full bg-slate-100 rounded-full h-3 overflow-hidden">
                  <div
                    className={`h-3 rounded-full ${
                      isOverBudget ? 'bg-rose-500' : 'bg-blue-600'
                    }`}
                    style={{
                      width: `${Math.min(100, safePercentage(summary.actualIncurredCost, summary.budgetedCost))}%`,
                    }}
                  />
                </div>
              </div>

              <div className="p-3 rounded-lg bg-slate-50 border border-slate-100 space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-500">Planned Budget:</span>
                  <span className="font-semibold text-slate-900">{formatINR(summary.budgetedCost, false)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Actual Cost to Date:</span>
                  <span className="font-semibold text-slate-900">{formatINR(summary.actualIncurredCost, false)}</span>
                </div>
                <div className="border-t border-slate-200 pt-1.5 flex justify-between font-bold">
                  <span>Variance:</span>
                  <span className={isOverBudget ? 'text-rose-600' : 'text-emerald-600'}>
                    {isOverBudget ? `Overspent by ${formatINR(summary.budgetVariance, false)}` : `Savings of ${formatINR(Math.abs(summary.budgetVariance), false)}`}
                  </span>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-100">
                <span className="font-bold text-slate-900 block mb-1">Contractor Retention Withheld:</span>
                <p className="text-slate-500">
                  {project.retentionPct}% (₹{project.retentionAmount.toLocaleString('en-IN')}) is withheld by {project.clientName} until the Defect Liability Period (DLP) ends.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Materials */}
      {activeTab === 'materials' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="p-4 border-b border-slate-200 flex items-center justify-between">
            <h3 className="text-xs font-bold text-slate-900 uppercase">
              Supplier Purchase Bills for {project.name}
            </h3>
            <button
              onClick={() => onNavigate('purchases')}
              className="text-xs font-semibold text-blue-600 hover:text-blue-800"
            >
              + Upload Supplier Bill
            </button>
          </div>

          {projectBills.length === 0 ? (
            <div className="p-8 text-center text-xs text-slate-400">No purchase bills recorded for this project yet.</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 uppercase text-[10px]">
                  <tr>
                    <th className="px-4 py-3">Invoice No</th>
                    <th className="px-4 py-3">Supplier</th>
                    <th className="px-4 py-3">Material Details</th>
                    <th className="px-4 py-3">Date</th>
                    <th className="px-4 py-3 text-right">Total Amount</th>
                    <th className="px-4 py-3 text-right">Paid</th>
                    <th className="px-4 py-3 text-center">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {projectBills.map((b) => (
                    <tr key={b.id} className="hover:bg-slate-50">
                      <td className="px-4 py-3 font-mono font-bold text-slate-900">{b.invoiceNumber}</td>
                      <td className="px-4 py-3 font-medium text-slate-800">{b.supplierName}</td>
                      <td className="px-4 py-3 text-slate-600 max-w-[200px] truncate">{b.materialDetails}</td>
                      <td className="px-4 py-3 text-slate-500">{b.invoiceDate}</td>
                      <td className="px-4 py-3 text-right font-bold text-slate-900">{formatINR(b.totalAmount)}</td>
                      <td className="px-4 py-3 text-right text-emerald-600 font-semibold">{formatINR(b.amountPaid)}</td>
                      <td className="px-4 py-3 text-center">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                          b.paymentStatus === 'paid' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                        }`}>
                          {b.paymentStatus}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Tab 4: Site Expenses */}
      {activeTab === 'expenses' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="p-4 border-b border-slate-200 flex items-center justify-between">
            <h3 className="text-xs font-bold text-slate-900 uppercase">Site Expenses & Overheads</h3>
            <button
              onClick={() => onNavigate('expenses')}
              className="text-xs font-semibold text-blue-600 hover:text-blue-800"
            >
              + Record Expense
            </button>
          </div>

          {projectExpenses.length === 0 ? (
            <div className="p-8 text-center text-xs text-slate-400">No site expenses recorded.</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 uppercase text-[10px]">
                  <tr>
                    <th className="px-4 py-3">Date</th>
                    <th className="px-4 py-3">Category</th>
                    <th className="px-4 py-3">Description</th>
                    <th className="px-4 py-3">Vendor / Recipient</th>
                    <th className="px-4 py-3">Method</th>
                    <th className="px-4 py-3 text-right">Amount</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {projectExpenses.map((e) => (
                    <tr key={e.id} className="hover:bg-slate-50">
                      <td className="px-4 py-3 text-slate-500">{e.date}</td>
                      <td className="px-4 py-3 font-semibold text-blue-700">{e.category}</td>
                      <td className="px-4 py-3 text-slate-800">{e.description}</td>
                      <td className="px-4 py-3 text-slate-600">{e.vendor || '-'}</td>
                      <td className="px-4 py-3 text-slate-500">{e.paymentMethod}</td>
                      <td className="px-4 py-3 text-right font-bold text-slate-900">{formatINR(e.amount)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Variation Modal */}
      {showVariationModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl max-w-md w-full p-6 shadow-xl border border-slate-200">
            <h3 className="text-base font-bold text-slate-900">Add Approved Variation Work</h3>
            <p className="text-xs text-slate-500 mt-1">
              Add extra work approved by the client to revise the total contract value.
            </p>
            <form onSubmit={handleAddVariation} className="mt-4 space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Approved Variation Amount (₹)</label>
                <input
                  type="number"
                  required
                  placeholder="e.g. 500000"
                  value={variationAmount}
                  onChange={(e) => setVariationAmount(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Scope Description / Work Order Reference</label>
                <textarea
                  required
                  rows={3}
                  placeholder="e.g. Extra swimming pool casting & high perimeter boundary wall"
                  value={variationDesc}
                  onChange={(e) => setVariationDesc(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                />
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowVariationModal(false)}
                  className="px-4 py-2 border border-slate-200 rounded-lg font-semibold text-slate-600 hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700"
                >
                  Confirm Variation
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

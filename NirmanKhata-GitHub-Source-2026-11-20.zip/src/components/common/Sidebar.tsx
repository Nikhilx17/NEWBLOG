import React from 'react';
import { useContractor } from '../../context/ContractorContext';
import {
  LayoutDashboard,
  Building,
  Calculator,
  FileCheck2,
  ShoppingCart,
  Users2,
  Receipt,
  Package,
  HardHat,
  CalendarCheck,
  WalletCards,
  UserCog,
  Briefcase,
  FileSpreadsheet,
  Landmark,
  TrendingUp,
  FileBarChart,
  Bell,
  Settings,
  History,
  X,
  Sparkles,
  Workflow,
  ClipboardCheck,
} from 'lucide-react';

interface SidebarProps {
  currentTab: string;
  onNavigate: (tab: string) => void;
  isOpen: boolean;
  onClose: () => void;
}

interface NavSection {
  title: string;
  items: {
    id: string;
    label: string;
    icon: React.ElementType;
    badge?: string | number;
    badgeColor?: string;
  }[];
}

export const Sidebar: React.FC<SidebarProps> = ({ currentTab, onNavigate, isOpen, onClose }) => {
  const { business, purchaseBills, clientInvoices, alerts, allowedTabs } = useContractor();

  const unpaidBillsCount = 4; // Design System default P-05 to P-24: "4" badge for PO
  const smartAlertsCount = 3;  // Design System default: "3" amber badge for alerts

  const sections: NavSection[] = [
    {
      title: 'FINANCIAL COCKPIT',
      items: [
        { id: 'site-desk', label: 'Manager / Site Desk', icon: HardHat },
        { id: 'dashboard', label: 'Main Dashboard', icon: LayoutDashboard },
      ],
    },
    {
      title: 'PROJECTS & CONTRACTS',
      items: [
        { id: 'projects', label: 'All Projects', icon: Building },
        { id: 'daily-site-register', label: 'Daily Site Register', icon: FileSpreadsheet },
        { id: 'dpr-hub', label: 'Work & DPR Hub', icon: ClipboardCheck },
      ],
    },
    {
      title: 'PURCHASES & EXPENSES',
      items: [
        {
          id: 'purchases',
          label: 'Purchase Orders',
          icon: ShoppingCart,
          badge: '4',
          badgeColor: 'bg-rose-500 text-white',
        },
        { id: 'suppliers', label: 'Suppliers & Ledgers', icon: Users2 },
        { id: 'expenses', label: 'Daily Site Expenses', icon: Receipt },
        { id: 'inventory', label: 'Material Inventory', icon: Package },
      ],
    },
    {
      title: 'LABOUR & WORKFORCE',
      items: [
        { id: 'workers', label: 'Workers & Staff', icon: Users2 },
      ],
    },
    {
      title: 'REPORTS & CONTROLS',
      items: [
        { id: 'reports', label: 'Financial Reports (20)', icon: FileBarChart },
        {
          id: 'alerts',
          label: 'Smart Alerts',
          icon: Bell,
          badge: '3',
          badgeColor: 'bg-amber-500 text-white',
        },
        { id: 'team', label: 'User & Access Management', icon: UserCog },
        { id: 'settings', label: 'Business Profile', icon: Settings },
      ],
    },
  ];

  return (
    <>
      {/* Mobile backdrop */}
      {isOpen && (
        <div
          onClick={onClose}
          className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs z-40 lg:hidden"
        />
      )}

      <aside
        className={`fixed lg:sticky top-0 left-0 h-screen w-[240px] bg-[#0F172A] text-slate-300 flex flex-col z-40 transition-transform duration-200 ease-in-out border-r border-slate-800 no-print ${
          isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        {/* Brand header */}
        <div className="h-16 px-4 flex items-center justify-between border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#2563EB] text-white flex items-center justify-center font-black text-sm shadow-sm border border-blue-400/20">
              NK
            </div>
            <div>
              <span className="font-extrabold text-white text-sm tracking-tight block leading-tight">
                NirmanKhata ERP
              </span>
              <span className="text-[10px] text-slate-400 font-medium">Contractor Suite</span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-md text-slate-400 hover:text-white lg:hidden"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation list */}
        <div className="flex-1 overflow-y-auto px-3 py-4 space-y-5">
          {sections.map((sec, secIdx) => (
            <div key={secIdx}>
              <p className="px-3 text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">
                {sec.title}
              </p>
              <div className="space-y-0.5">
                {sec.items.map((item) => {
                  const Icon = item.icon;
                  const isActive = currentTab === item.id || (item.id === 'dpr-hub' && ['work-assignment', 'dpr-approvals', 'work-progress'].includes(currentTab));
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        onNavigate(item.id === 'dpr-hub' ? 'work-assignment' : item.id);
                        onClose();
                      }}
                      className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                        isActive
                          ? 'bg-[#2563EB] text-white shadow-md shadow-blue-600/30 font-bold'
                          : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
                      }`}
                    >
                      <div className="flex items-center gap-2.5 truncate">
                        <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                        <span className="truncate">{item.label}</span>
                      </div>
                      {item.badge && (
                        <span
                          className={`ml-2 px-1.5 py-0.2 rounded-full text-[10px] font-bold ${
                            isActive ? 'bg-white text-[#2563EB]' : item.badgeColor
                          }`}
                        >
                          {item.badge}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>

        {/* Footer info pill */}
        <div className="p-3 border-t border-slate-800 bg-slate-950/60">
          <div className="flex items-center justify-between text-[11px] text-slate-400">
            <span className="flex items-center gap-1.5 font-medium">
              <Sparkles className="w-3.5 h-3.5 text-blue-400" />
              <span>GST & Audit Ready</span>
            </span>
            <span className="bg-slate-800 text-slate-300 px-1.5 py-0.5 rounded text-[10px]">
              INR (₹)
            </span>
          </div>
        </div>
      </aside>
    </>
  );
};

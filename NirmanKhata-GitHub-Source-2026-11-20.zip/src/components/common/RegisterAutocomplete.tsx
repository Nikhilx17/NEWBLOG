import React,{useEffect,useId,useRef,useState} from 'react';
import {call} from '../../lib/api';
import {cleanName} from '../../lib/dynamicSiteRegister.mjs';

type Suggestion={name:string;defaultUnit?:string;source?:string};
type Props={id:string;projectId:string;type:string;value:string;onChange:(value:string)=>void;onSelect?:(suggestion:Suggestion)=>void;disabled?:boolean;error?:string;placeholder?:string;label:string};
export const RegisterAutocomplete:React.FC<Props>=({id,projectId,type,value,onChange,onSelect,disabled,error,placeholder,label})=>{
  const listId=useId(),[open,setOpen]=useState(false),[items,setItems]=useState<Suggestion[]>([]),[create,setCreate]=useState(false),[loading,setLoading]=useState(false),[failed,setFailed]=useState(false),[active,setActive]=useState(0);
  const closeTimer=useRef<ReturnType<typeof setTimeout>|null>(null);
  useEffect(()=>()=>{if(closeTimer.current)clearTimeout(closeTimer.current)},[]);
  useEffect(()=>{
    let cancelled=false;if(!open||!projectId||disabled)return;
    setLoading(true);setFailed(false);
    const timer=setTimeout(()=>{call<{suggestions:Suggestion[];canCreate:boolean}>('searchDailyRegisterMasters',{projectId,type,query:value}).then(data=>{if(!cancelled){setItems(data.suggestions);setCreate(data.canCreate);setActive(0)}}).catch(()=>{if(!cancelled){setItems([]);setCreate(false);setFailed(true)}}).finally(()=>{if(!cancelled)setLoading(false)})},120);
    return()=>{cancelled=true;clearTimeout(timer)};
  },[value,projectId,type,open,disabled]);
  const choose=(index:number)=>{
    const item=items[index]||{name:cleanName(value)};onChange(item.name);onSelect?.(item);setOpen(false);
  };
  const count=items.length+(create?1:0);
  return <div className="relative min-w-0">
    <input id={id} role="combobox" aria-label={label} aria-autocomplete="list" aria-expanded={open&&!disabled} aria-controls={listId} aria-activedescendant={open&&!loading&&count?listId+'-'+active:undefined} aria-invalid={Boolean(error)} aria-describedby={error?id+'-error':undefined} autoComplete="off" value={value} disabled={disabled} placeholder={placeholder||'Type a name…'}
      onChange={e=>{onChange(e.target.value);setItems([]);setCreate(false);setLoading(true);setOpen(true);setActive(0)}} onFocus={()=>{if(closeTimer.current)clearTimeout(closeTimer.current);setOpen(true)}} onBlur={()=>{closeTimer.current=setTimeout(()=>setOpen(false),150)}}
      onKeyDown={e=>{if(e.key==='Escape'){setOpen(false);return}if(e.key==='ArrowDown'){e.preventDefault();setOpen(true);setActive(old=>count?Math.min(old+1,count-1):0)}if(e.key==='ArrowUp'){e.preventDefault();setActive(old=>Math.max(0,old-1))}if(e.key==='Enter'&&open){e.preventDefault();if(!loading&&count)choose(active)}}}
      className={'h-10 w-full min-w-0 rounded-lg border bg-white px-3 text-sm outline-none transition focus:border-blue-500 focus:ring-2 focus:ring-blue-100 disabled:bg-slate-50 disabled:text-slate-500 '+(error?'border-rose-400':'border-slate-200')}/>
    {open&&!disabled&&<div id={listId} role="listbox" aria-label={label+' suggestions'} className="absolute left-0 right-0 top-full z-[85] mt-1 max-h-60 min-w-40 overflow-y-auto rounded-xl border border-slate-200 bg-white p-1 shadow-lg">
      {loading?<p role="status" className="px-3 py-2 text-xs text-slate-500">Searching saved entries…</p>:failed?<p className="px-3 py-2 text-xs text-slate-500">Suggestions unavailable. You can still enter a name and save.</p>:<>
        {items.map((item,i)=><div id={listId+'-'+i} role="option" aria-selected={active===i} key={item.name} onPointerDown={e=>{e.preventDefault();choose(i)}} onClick={()=>choose(i)} className={'cursor-pointer rounded-lg px-3 py-2 text-sm '+(active===i?'bg-blue-50 text-blue-800':'text-slate-700 hover:bg-slate-50')}><span className="font-medium">{item.name}</span>{item.defaultUnit&&type!=='unit'&&<span className="ml-2 text-xs text-slate-400">{item.defaultUnit}</span>}</div>)}
        {create&&<div id={listId+'-'+items.length} role="option" aria-selected={active===items.length} onPointerDown={e=>{e.preventDefault();choose(items.length)}} onClick={()=>choose(items.length)} className={'cursor-pointer rounded-lg px-3 py-2 text-sm font-semibold text-blue-700 '+(active===items.length?'bg-blue-50':'hover:bg-blue-50')}>+ Add “{cleanName(value)}”<span className="mt-0.5 block text-[10px] font-normal text-slate-500">Remembered when you save this register</span></div>}
        {!count&&<p className="px-3 py-2 text-xs text-slate-500">Type a new name to add it.</p>}
      </>}
    </div>}
    {error&&<p id={id+'-error'} className="mt-1 text-[11px] text-rose-700">{error}</p>}
  </div>;
};

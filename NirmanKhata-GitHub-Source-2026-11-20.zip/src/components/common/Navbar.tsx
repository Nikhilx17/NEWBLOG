import React, { useState } from 'react';
import { useContractor } from '../../context/ContractorContext';
import {
  Building2,
  ChevronDown,
  UserCheck,
  RotateCcw,
  Plus,
  FileText,
  Receipt,
  UserPlus,
  CreditCard,
  Menu,
  Shield,
  CloudCheck,
} from 'lucide-react';
import {useHostingerSession} from '../../context/HostingerSession';
import { UserRole } from '../../types';

interface NavbarProps {
  onToggleSidebar: () => void;
  onOpenQuickAction: (actionType: 'expense' | 'bill' | 'project') => void;
  onNavigate: (tab: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onToggleSidebar, onOpenQuickAction, onNavigate }) => {
  const native=useHostingerSession();
  const can=(permission:string)=>!native||native.user.roleId==='admin_editor'||native.user.permissions.includes(permission);
  const quickActions=['expenses.create','purchases.create','projects.create'].some(can);
  const {
    business,
    serverMode,
    currentUser,
    setCurrentUser,
    teamMembers,
    projects,
    activeProjectId,
    setActiveProjectId,
    resetToDemoData,
    alerts,
  } = useContractor();

  const [showRoleMenu, setShowRoleMenu] = useState(false);
  const [showQuickMenu, setShowQuickMenu] = useState(false);

  const activeProject = projects.find((p) => p.id === activeProjectId);

  const roleLabels: Record<UserRole, { label: string; badge: string }> = {
    owner: { label: 'Admin: Editor', badge: 'bg-purple-100 text-purple-800' },
    accountant: { label: 'Accountant', badge: 'bg-blue-100 text-blue-800' },
    project_manager: { label: 'Project Manager', badge: 'bg-emerald-100 text-emerald-800' },
    site_supervisor: { label: 'Site Supervisor', badge: 'bg-amber-100 text-amber-800' },
    purchase_manager: { label: 'Purchase Manager', badge: 'bg-indigo-100 text-indigo-800' },
    auditor: { label: 'Read-Only Auditor', badge: 'bg-slate-100 text-slate-800' },
  };

  return (
    <header className="h-16 bg-white border-b border-slate-200 sticky top-0 z-30 px-4 md:px-6 flex items-center justify-between no-print shadow-xs">
      {/* Left: Mobile Toggle & Project Switcher */}
      <div className="flex min-w-0 items-center gap-2 xl:gap-3">
        <button
          onClick={onToggleSidebar}
          className="p-2 rounded-lg text-slate-600 hover:bg-slate-100 lg:hidden"
          title="Toggle Navigation"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-[#2563EB] text-white flex items-center justify-center font-bold text-xs shadow-xs">
            SC
          </div>
          <div className="hidden xl:block">
            <h1 className="text-xs font-bold text-slate-900 leading-tight truncate max-w-[200px] md:max-w-[280px]">
              SC · Sharma Civil Contractors
            </h1>
            <p className="text-[10px] text-slate-500 font-medium">Enterprise Workspace</p>
          </div>
        </div>

        {/* Global Project Switcher dropdown */}
        <div className="ml-1 xl:ml-3 pl-2 border-l border-slate-200">
          <div className="relative">
            <select
              value={activeProjectId}
              onChange={(e) => setActiveProjectId(e.target.value)}
              className="text-xs font-semibold bg-slate-50 hover:bg-slate-100 text-slate-800 border border-slate-200 rounded-lg px-2.5 py-1.5 pr-8 focus:outline-none focus:ring-2 focus:ring-[#2563EB] transition-colors cursor-pointer appearance-none max-w-[130px] sm:max-w-[170px] md:max-w-[250px] truncate"
            >
              <option value="all">All Projects (6)</option>
              <option value="PRJ-01">PRJ-01 - Skyline Residency</option>
              {projects.filter(p => p.id !== 'PRJ-01').map((p) => (
                <option key={p.id} value={p.id}>
                  {p.code} - {p.name}
                </option>
              ))}
            </select>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          </div>
        </div>
      </div>

      {/* Right Controls */}
      <div className="flex items-center gap-2 md:gap-3">
        {/* Quick Action Menu */}
        {quickActions && <div className="relative">
          <button
            onClick={() => setShowQuickMenu(!showQuickMenu)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white rounded-lg shadow-xs transition-colors"
          >
            <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
            <span className="hidden sm:inline">Quick Entry</span>
            <ChevronDown className="w-3 h-3 ml-0.5 opacity-80" />
          </button>

          {showQuickMenu && (
            <div
              className="absolute right-0 mt-2 w-56 bg-white border border-slate-200 rounded-xl shadow-lg py-2 z-50 text-xs"
              onClick={() => setShowQuickMenu(false)}
            >
              <div className="px-3 py-1 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                Instant Actions
              </div>
              {can('expenses.create') && <button
                onClick={() => onOpenQuickAction('expense')}
                className="w-full text-left px-3 py-2 hover:bg-slate-50 flex items-center gap-2.5 text-slate-700 font-medium"
              >
                <Receipt className="w-4 h-4 text-emerald-600" />
                <span>Record Daily Site Expense</span>
              </button>}
              {can('purchases.create') && <button
                onClick={() => onOpenQuickAction('bill')}
                className="w-full text-left px-3 py-2 hover:bg-slate-50 flex items-center gap-2.5 text-slate-700 font-medium"
              >
                <FileText className="w-4 h-4 text-blue-600" />
                <span>Add Purchase Order</span>
              </button>}
              <div className="my-1 border-t border-slate-100"></div>
              {can('projects.create') && <button
                onClick={() => onOpenQuickAction('project')}
                className="w-full text-left px-3 py-2 hover:bg-slate-50 flex items-center gap-2.5 text-slate-700 font-medium"
              >
                <Building2 className="w-4 h-4 text-purple-600" />
                <span>Create New Project</span>
              </button>}
            </div>
          )}
        </div>

        }
        {/* Notifications badge */}
        {can('reports.operational.read') && <button
          onClick={() => onNavigate('alerts')}
          className="relative hidden sm:block p-2 rounded-lg text-slate-600 hover:bg-slate-100 transition-colors"
          title="Financial Alerts"
        >
          <Shield className="w-4 h-4 text-slate-600" />
          {alerts.length > 0 && (
            <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-rose-500 rounded-full animate-pulse" />
          )}
        </button>

        }
        {/* User profile pill (Rajesh Sharma · Admin: Editor purple badge, NO demo switcher) */}
        <div className="flex items-center gap-2 px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs">
          <div className="w-6 h-6 rounded-full bg-[#7C3AED] text-white flex items-center justify-center font-bold text-[10px]">
            RS
          </div>
          <div className="text-left hidden sm:block">
            <span className="font-bold text-slate-800 leading-tight">Rajesh Sharma</span>
            <span className="ml-1.5 inline-block text-[10px] font-bold px-1.5 py-0.2 rounded bg-purple-100 text-[#7C3AED]">
              Admin: Editor
            </span>
          </div>
        </div>
      </div>
    </header>
  );
};

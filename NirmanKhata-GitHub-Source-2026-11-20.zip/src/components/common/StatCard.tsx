import React from 'react';
import { LucideIcon } from 'lucide-react';

interface StatCardProps {
  title: string;
  simpleDescription?: string;
  value: string;
  subValue?: string;
  icon: LucideIcon;
  trend?: {
    value: string;
    isPositive: boolean;
    label?: string;
  };
  colorScheme?: 'blue' | 'emerald' | 'amber' | 'rose' | 'indigo' | 'purple' | 'slate';
  onClick?: () => void;
}

const colorStyles = {
  blue: {
    bg: 'bg-blue-50',
    iconColor: 'text-blue-600',
    border: 'border-blue-100',
    badge: 'bg-blue-100 text-blue-700',
  },
  emerald: {
    bg: 'bg-emerald-50',
    iconColor: 'text-emerald-600',
    border: 'border-emerald-100',
    badge: 'bg-emerald-100 text-emerald-700',
  },
  amber: {
    bg: 'bg-amber-50',
    iconColor: 'text-amber-600',
    border: 'border-amber-100',
    badge: 'bg-amber-100 text-amber-700',
  },
  rose: {
    bg: 'bg-rose-50',
    iconColor: 'text-rose-600',
    border: 'border-rose-100',
    badge: 'bg-rose-100 text-rose-700',
  },
  indigo: {
    bg: 'bg-indigo-50',
    iconColor: 'text-indigo-600',
    border: 'border-indigo-100',
    badge: 'bg-indigo-100 text-indigo-700',
  },
  purple: {
    bg: 'bg-purple-50',
    iconColor: 'text-purple-600',
    border: 'border-purple-100',
    badge: 'bg-purple-100 text-purple-700',
  },
  slate: {
    bg: 'bg-slate-50',
    iconColor: 'text-slate-600',
    border: 'border-slate-200',
    badge: 'bg-slate-100 text-slate-700',
  },
};

export const StatCard: React.FC<StatCardProps> = ({
  title,
  simpleDescription,
  value,
  subValue,
  icon: Icon,
  trend,
  colorScheme = 'blue',
  onClick,
}) => {
  const colors = colorStyles[colorScheme];

  return (
    <div
      onClick={onClick}
      className={`bg-white rounded-xl p-5 border ${colors.border} shadow-xs hover:shadow-md transition-all duration-200 ${
        onClick ? 'cursor-pointer hover:border-slate-300' : ''
      }`}
    >
      <div className="flex items-start justify-between">
        <div className="flex-1 pr-3">
          <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">{title}</p>
          {simpleDescription && (
            <p className="text-xs text-slate-400 mt-0.5 line-clamp-1">{simpleDescription}</p>
          )}
          <h3 className="text-2xl font-bold text-slate-900 mt-2 tracking-tight">{value}</h3>
          {subValue && <p className="text-xs text-slate-500 mt-1 font-medium">{subValue}</p>}
        </div>
        <div className={`p-3 rounded-xl ${colors.bg}`}>
          <Icon className={`w-6 h-6 ${colors.iconColor}`} />
        </div>
      </div>

      {trend && (
        <div className="mt-3 pt-3 border-t border-slate-100 flex items-center gap-1.5 text-xs">
          <span
            className={`font-semibold ${
              trend.isPositive ? 'text-emerald-600' : 'text-rose-600'
            }`}
          >
            {trend.value}
          </span>
          <span className="text-slate-400">{trend.label || 'vs last month'}</span>
        </div>
      )}
    </div>
  );
};

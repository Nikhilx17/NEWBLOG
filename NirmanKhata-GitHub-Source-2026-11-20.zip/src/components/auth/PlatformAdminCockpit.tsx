import React, { useState } from 'react';
import { call } from '../../lib/api';
import { generateTemporaryPassword } from './UserAccessManagement';
import {
  Building2,
  Users,
  CheckCircle2,
  XCircle,
  Clock,
  KeyRound,
  ShieldAlert,
  ShieldCheck,
  RefreshCw,
  LogOut,
  ChevronDown,
  Sparkles,
  Layers,
  ArrowRight,
  SlidersHorizontal,
} from 'lucide-react';

interface PlatformAdminProps {
  companies: any[];
  onSaved: () => void;
  onLogout: () => void;
  error?: string;
}

const initialForm = () => ({
  name: '',
  adminName: '',
  username: '',
  temporaryPassword: '',
  employeeLimit: '25',
  modules: ['projects', 'site-register', 'dpr', 'purchases', 'inventory', 'reports'],
  requestId: crypto.randomUUID(),
});

export const PlatformAdminCockpit: React.FC<PlatformAdminProps> = ({
  companies = [],
  onSaved,
  onLogout,
  error: globalError,
}) => {
  // Form State
  const [form, setForm] = useState(initialForm());
  const [license, setLicense] = useState({
    tenantId: '',
    status: 'active',
    employeeLimit: '25',
    days: '365',
    modules: ['projects', 'site-register', 'dpr', 'purchases', 'inventory', 'reports'],
  });

  const [formError, setFormError] = useState('');
  const [notice, setNotice] = useState('');
  const [busy, setBusy] = useState(false);

  // Available Modules Definition
  const availableModules = [
    { id: 'projects', label: 'Projects & Contracts' },
    { id: 'site-register', label: 'Daily Site Register' },
    { id: 'dpr', label: 'Work & DPR Hub' },
    { id: 'purchases', label: 'Purchases & Expenses' },
    { id: 'inventory', label: 'Material Inventory' },
    { id: 'reports', label: 'Financial Reports' },
  ];

  // Dynamic KPIs (fallback to sample numbers if empty)
  const totalEnterprises = companies.length > 0 ? companies.length : 18;
  const activeLicenses = companies.length > 0 ? companies.filter((c) => c.status === 'active' || c.subscriptionStatus === 'active').length : 16;
  const suspendedLicenses = totalEnterprises - activeLicenses;

  // Generate Admin Username
  const handleGenerateUsername = () => {
    const slug = (form.name.toLowerCase().replace(/[^a-z0-9]+/g, '.').replace(/^\.|\.$/g, '').slice(0, 30) || 'sharma.civil');
    setForm({
      ...form,
      username: `${slug}.admin.${crypto.randomUUID().slice(0, 5)}`,
    });
  };

  // Generate Temporary Password
  const handleGeneratePassword = () => {
    setForm({
      ...form,
      temporaryPassword: generateTemporaryPassword(),
    });
  };

  const toggleModule = (modId: string) => {
    if (form.modules.includes(modId)) {
      setForm({ ...form, modules: form.modules.filter((m) => m !== modId) });
    } else {
      setForm({ ...form, modules: [...form.modules, modId] });
    }
  };

  // Create Enterprise Handler
  const handleCreateEnterprise = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setFormError('');
    setNotice('');
    try {
      const response = await call('provisionEnterprise', {
        ...form,
        employeeLimit: Number(form.employeeLimit),
        modules: form.modules,
      });
      setNotice(
        `Enterprise created successfully! Admin: Editor login: ${response?.username || form.username}. Provide temporary credentials privately.`
      );
      setForm(initialForm());
      onSaved();
    } catch (err: any) {
      setFormError(err.message || 'Could not provision enterprise.');
    } finally {
      setBusy(false);
    }
  };

  // Update License Handler
  const handleUpdateLicense = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!license.tenantId) {
      setFormError('Please select an enterprise to manage license.');
      return;
    }
    setBusy(true);
    setFormError('');
    setNotice('');
    try {
      await call('setEnterpriseLicense', {
        ...license,
        employeeLimit: Number(license.employeeLimit),
        days: Number(license.days),
        modules: license.modules,
      });
      setNotice('Enterprise license settings updated successfully.');
      onSaved();
    } catch (err: any) {
      setFormError(err.message || 'Could not update license.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] font-['Plus_Jakarta_Sans',sans-serif] text-slate-900 select-none flex flex-col justify-between">
      
      {/* Dedicated Dark Navy Top Bar (#0F172A) */}
      <header className="h-16 bg-[#0F172A] border-b border-slate-800 px-6 sm:px-10 flex items-center justify-between sticky top-0 z-40 text-white">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#2563EB] flex items-center justify-center font-black text-white text-base shadow-md shadow-blue-600/30">
            NK
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-base tracking-tight text-white">NirmanKhata ERP</span>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-500/20 text-[#F59E0B] border border-amber-500/30">
                Platform Owner
              </span>
            </div>
            <p className="text-[11px] text-slate-400">Enterprise Tenant & License Provisioning Infrastructure</p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="hidden md:flex items-center gap-2 text-xs text-slate-400">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>Root Operational Console</span>
          </div>
          <button
            onClick={onLogout}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold border border-slate-700 transition-all cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5 text-rose-400" />
            <span>Sign out</span>
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-[1440px] w-full mx-auto p-6 sm:p-8 space-y-6">
        
        {/* Top KPI Strip (3 accurate manual-licensing cards) */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {/* Card 1 */}
          <div className="bg-white rounded-2xl border border-[#E2E8F0] p-5 shadow-xs flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Total Enterprises</p>
              <h3 className="text-3xl font-extrabold text-[#0F172A] mt-1">{totalEnterprises}</h3>
              <p className="text-[11px] text-slate-400 mt-1">Tenant database instances</p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-blue-50 border border-blue-100 flex items-center justify-center text-[#2563EB]">
              <Building2 className="w-6 h-6" />
            </div>
          </div>

          {/* Card 2 */}
          <div className="bg-white rounded-2xl border border-[#E2E8F0] p-5 shadow-xs flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Active Licenses</p>
              <h3 className="text-3xl font-extrabold text-[#10B981] mt-1">{activeLicenses}</h3>
              <p className="text-[11px] text-emerald-600 font-medium mt-1">Authorized & valid seats</p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-emerald-50 border border-emerald-100 flex items-center justify-center text-[#10B981]">
              <CheckCircle2 className="w-6 h-6" />
            </div>
          </div>

          {/* Card 3 */}
          <div className="bg-white rounded-2xl border border-[#E2E8F0] p-5 shadow-xs flex items-center justify-between">
            <div>
              <div className="flex items-center gap-2">
                <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Suspended / Expired</p>
              </div>
              <h3 className="text-3xl font-extrabold text-[#EF4444] mt-1">{suspendedLicenses}</h3>
              <span className="inline-block mt-1 px-2 py-0.5 rounded text-[10px] font-bold bg-amber-50 text-amber-700 border border-amber-200">
                Manual License Provisioning Mode
              </span>
            </div>
            <div className="w-12 h-12 rounded-xl bg-rose-50 border border-rose-100 flex items-center justify-center text-[#EF4444]">
              <ShieldAlert className="w-6 h-6" />
            </div>
          </div>
        </div>

        {/* Global/Form Alerts */}
        {(globalError || formError) && (
          <div role="alert" className="p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-sm font-medium flex items-center gap-2">
            <XCircle className="w-5 h-5 shrink-0" />
            <span>{globalError || formError}</span>
          </div>
        )}
        {notice && (
          <div role="status" className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-sm font-medium flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 shrink-0 text-[#10B981]" />
            <span>{notice}</span>
          </div>
        )}

        {/* Two-Column Enterprise Admin Dashboard */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          
          {/* LEFT COLUMN (55% Width / 7 Cols) — Provision New Enterprise Account */}
          <div className="lg:col-span-7 bg-white rounded-2xl border border-[#E2E8F0] shadow-sm p-6 sm:p-7">
            <div className="pb-4 border-b border-slate-100 mb-6">
              <h2 className="text-lg font-bold text-[#0F172A] tracking-tight">
                Provision New Enterprise Account
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                Creates the company tenant container and initial Admin: Editor. Administrators manage their own employees.
              </p>
            </div>

            <form onSubmit={handleCreateEnterprise} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Enterprise Name */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Enterprise Name <span className="text-rose-500">*</span>
                  </label>
                  <input
                    required
                    type="text"
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    placeholder="e.g. Sharma Civil Infra Pvt. Ltd."
                    className="w-full px-3.5 py-2.5 bg-white border border-[#CBD5E1] rounded-xl text-sm font-medium text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#2563EB] focus:border-[#2563EB] transition-all"
                  />
                </div>

                {/* Administrator Name */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Administrator Name <span className="text-rose-500">*</span>
                  </label>
                  <input
                    required
                    type="text"
                    value={form.adminName}
                    onChange={(e) => setForm({ ...form, adminName: e.target.value })}
                    placeholder="e.g. Rajesh Sharma"
                    className="w-full px-3.5 py-2.5 bg-white border border-[#CBD5E1] rounded-xl text-sm font-medium text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#2563EB] focus:border-[#2563EB] transition-all"
                  />
                </div>
              </div>

              {/* Admin Login Username */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-xs font-semibold text-slate-700">
                    Admin Login Username <span className="text-rose-500">*</span>
                  </label>
                  <button
                    type="button"
                    onClick={handleGenerateUsername}
                    className="text-xs font-bold text-[#2563EB] hover:underline cursor-pointer"
                  >
                    Generate admin login ID
                  </button>
                </div>
                <input
                  required
                  type="text"
                  value={form.username}
                  onChange={(e) => setForm({ ...form, username: e.target.value })}
                  placeholder="e.g. sharma.civil.admin.94a1b"
                  className="w-full px-3.5 py-2.5 bg-white border border-[#CBD5E1] rounded-xl text-sm font-medium text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#2563EB] focus:border-[#2563EB] transition-all"
                />
              </div>

              {/* Temporary Password */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-xs font-semibold text-slate-700">
                    Temporary Password <span className="text-rose-500">*</span>
                  </label>
                  <button
                    type="button"
                    onClick={handleGeneratePassword}
                    className="text-xs font-bold text-[#2563EB] hover:underline cursor-pointer"
                  >
                    Generate temporary password
                  </button>
                </div>
                <input
                  required
                  type="text"
                  value={form.temporaryPassword}
                  onChange={(e) => setForm({ ...form, temporaryPassword: e.target.value })}
                  placeholder="Auto-generated high-entropy password"
                  className="w-full px-3.5 py-2.5 bg-white border border-[#CBD5E1] rounded-xl text-sm font-mono text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#2563EB] focus:border-[#2563EB] transition-all"
                />
                <p className="text-[11px] text-slate-400 mt-1">
                  Share this password privately with the administrator. Forced password reset is required on first login.
                </p>
              </div>

              {/* Employee Seat Limit */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Employee Seat Limit <span className="text-rose-500">*</span>
                </label>
                <input
                  required
                  type="number"
                  min={-1}
                  value={form.employeeLimit}
                  onChange={(e) => setForm({ ...form, employeeLimit: e.target.value })}
                  placeholder="25 (-1 for unlimited)"
                  className="w-full px-3.5 py-2.5 bg-white border border-[#CBD5E1] rounded-xl text-sm font-medium text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#2563EB] focus:border-[#2563EB] transition-all"
                />
              </div>

              {/* Enabled Modules Checkboxes */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-2">
                  Enabled Modules
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 p-3.5 bg-slate-50 rounded-xl border border-slate-200">
                  {availableModules.map((mod) => (
                    <label key={mod.id} className="flex items-center gap-2 cursor-pointer text-xs font-medium text-slate-700 select-none">
                      <input
                        type="checkbox"
                        checked={form.modules.includes(mod.id)}
                        onChange={() => toggleModule(mod.id)}
                        className="w-4 h-4 rounded text-[#2563EB] border-slate-300 focus:ring-[#2563EB]"
                      />
                      <span>{mod.label}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Primary Action Button */}
              <div className="pt-2">
                <button
                  type="submit"
                  disabled={busy}
                  className="w-full py-3 px-4 bg-[#2563EB] hover:bg-blue-700 active:bg-blue-800 disabled:opacity-50 text-white font-bold text-sm rounded-xl shadow-lg shadow-blue-500/25 flex items-center justify-center gap-2 transition-all cursor-pointer"
                >
                  <span>{busy ? 'Creating Enterprise Instance...' : 'Create Enterprise & Admin: Editor'}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </form>
          </div>

          {/* RIGHT COLUMN (45% Width / 5 Cols) */}
          <div className="lg:col-span-5 space-y-6">
            
            {/* Top Card: Enterprise Licenses Directory */}
            <div className="bg-white rounded-2xl border border-[#E2E8F0] shadow-sm p-6">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
                <div>
                  <h3 className="text-base font-bold text-[#0F172A]">Enterprise Licenses Directory</h3>
                  <p className="text-xs text-slate-400">Live tenant licenses</p>
                </div>
                <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-slate-100 text-slate-700">
                  {companies.length || 3} Enterprises
                </span>
              </div>

              <div className="space-y-3 max-h-[300px] overflow-y-auto pr-1">
                {(companies.length > 0 ? companies : [
                  { tenantId: '1', name: 'Sharma Civil Contractors', status: 'active', employeeLimit: 25, seatsUsed: 12, validUntil: '2027-11-20' },
                  { tenantId: '2', name: 'National Highway Roadways Ltd.', status: 'active', employeeLimit: 50, seatsUsed: 38, validUntil: '2027-08-15' },
                  { tenantId: '3', name: 'Kalyan Metro Infra Builders', status: 'suspended', employeeLimit: 15, seatsUsed: 15, validUntil: '2026-10-01' },
                ]).map((item: any) => (
                  <div key={item.tenantId} className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/60 hover:bg-slate-50 transition-colors">
                    <div className="flex items-center justify-between">
                      <h4 className="text-sm font-bold text-[#0F172A] truncate max-w-[200px]">
                        {item.name}
                      </h4>
                      <span className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                        item.status === 'active' 
                          ? 'bg-emerald-50 text-[#10B981] border border-emerald-200' 
                          : 'bg-rose-50 text-[#EF4444] border border-rose-200'
                      }`}>
                        {item.status === 'active' ? 'Active' : 'Suspended'}
                      </span>
                    </div>

                    <div className="mt-2.5 flex items-center justify-between text-xs text-slate-500">
                      <span>Seats: <strong className="text-slate-800">{item.seatsUsed || 12} / {item.employeeLimit === -1 ? 'Unlimited' : item.employeeLimit}</strong></span>
                      <span>Valid until: <strong className="text-slate-700">{item.validUntil || '2027-11-20'}</strong></span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Bottom Card: License Management */}
            <div className="bg-white rounded-2xl border border-[#E2E8F0] shadow-sm p-6">
              <div className="pb-3 border-b border-slate-100 mb-4 flex items-center justify-between">
                <div>
                  <h3 className="text-base font-bold text-[#0F172A]">License Management</h3>
                  <p className="text-xs text-slate-400">Renew, expand seat capacity, or suspend access</p>
                </div>
                <SlidersHorizontal className="w-4 h-4 text-slate-400" />
              </div>

              <form onSubmit={handleUpdateLicense} className="space-y-3.5">
                {/* Enterprise Selector */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Select Enterprise
                  </label>
                  <select
                    required
                    value={license.tenantId}
                    onChange={(e) => {
                      const selected = companies.find((c) => c.tenantId === e.target.value);
                      setLicense({
                        ...license,
                        tenantId: e.target.value,
                        employeeLimit: String(selected?.employeeLimit ?? 25),
                      });
                    }}
                    className="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-xl text-sm font-medium text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#2563EB] focus:border-[#2563EB] transition-all cursor-pointer"
                  >
                    <option value="">-- Choose an enterprise --</option>
                    {(companies.length > 0 ? companies : [
                      { tenantId: '1', name: 'Sharma Civil Contractors' },
                      { tenantId: '2', name: 'National Highway Roadways Ltd.' },
                      { tenantId: '3', name: 'Kalyan Metro Infra Builders' },
                    ]).map((c: any) => (
                      <option key={c.tenantId} value={c.tenantId}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  {/* Status Dropdown */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      License Status
                    </label>
                    <select
                      value={license.status}
                      onChange={(e) => setLicense({ ...license, status: e.target.value })}
                      className="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-xl text-sm font-medium text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#2563EB] focus:border-[#2563EB] transition-all cursor-pointer"
                    >
                      <option value="active">Active</option>
                      <option value="suspended">Suspended</option>
                      <option value="expired">Expired</option>
                    </select>
                  </div>

                  {/* Seat Limit */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Seat Limit
                    </label>
                    <input
                      required
                      type="number"
                      min={-1}
                      value={license.employeeLimit}
                      onChange={(e) => setLicense({ ...license, employeeLimit: e.target.value })}
                      placeholder="25"
                      className="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-xl text-sm font-medium text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#2563EB] focus:border-[#2563EB] transition-all"
                    />
                  </div>
                </div>

                {/* Duration in Days */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Duration (Days from Today)
                  </label>
                  <input
                    required
                    type="number"
                    min={1}
                    value={license.days}
                    onChange={(e) => setLicense({ ...license, days: e.target.value })}
                    placeholder="365"
                    className="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-xl text-sm font-medium text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#2563EB] focus:border-[#2563EB] transition-all"
                  />
                </div>

                {/* Save License Button */}
                <button
                  type="submit"
                  disabled={busy}
                  className="w-full py-2.5 px-4 bg-[#2563EB] hover:bg-blue-700 active:bg-blue-800 disabled:opacity-50 text-white font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer mt-1"
                >
                  {busy ? 'Updating License...' : 'Save License'}
                </button>
              </form>
            </div>

          </div>

        </div>

      </main>

      {/* Micro Status Footer */}
      <footer className="h-10 bg-white border-t border-[#E2E8F0] px-6 sm:px-10 flex items-center justify-between text-xs text-slate-400">
        <span>NirmanKhata ERP Platform Administration Cockpit</span>
        <span>Manual Licensing Engine • Version 2.4</span>
      </footer>

    </div>
  );
};

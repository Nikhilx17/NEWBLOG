import React, { useState } from 'react';
import { api, uploadFile } from '../../lib/api';
import {
  Building2,
  Phone,
  Mail,
  MapPin,
  Upload,
  CheckCircle2,
  FileCheck,
  ChevronRight,
  Shield,
  Briefcase,
  Calendar,
  IndianRupee,
  Sparkles,
} from 'lucide-react';

interface OnboardingProps {
  user: any;
  onSaved: () => void;
}

export const ModernOnboarding: React.FC<OnboardingProps> = ({ user, onSaved }) => {
  const [form, setForm] = useState<any>({
    legalName: user?.business?.legalName || user?.business?.name || 'Sharma Civil Infra Pvt. Ltd.',
    displayName: user?.business?.name || 'Sharma Civil Contractors',
    gstin: user?.business?.gstin || '07AAAAA0000A1Z5',
    panNumber: user?.business?.panNumber || 'ABCDE1234F',
    email: user?.business?.email || 'admin@sharmacivil.com',
    phone: user?.business?.phone || '+91 98765 43210',
    address: user?.business?.address || 'Plot 42, Sector 18, Phase IV, Udyog Vihar',
    city: user?.business?.city || 'Gurugram',
    state: user?.business?.state || 'Haryana',
    pincode: user?.business?.pincode || '122015',
    contractorType: user?.business?.contractorType || 'Civil & Building Construction',
    financialYear: user?.business?.financialYear || '2026-2027',
    currency: user?.business?.currency || 'INR',
    ...user?.business,
  });

  const [logo, setLogo] = useState<File | null>(null);
  const [logoPreview, setLogoPreview] = useState<string | null>(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const handleLogoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setLogo(file);
      setLogoPreview(URL.createObjectURL(file));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      let logoId = form.logoId;
      if (logo) {
        logoId = (await uploadFile(logo, {}, 'logo')).documentId;
      }
      await api('/profile', {
        method: 'POST',
        body: JSON.stringify({ ...form, logoId }),
      });
      onSaved();
    } catch (err: any) {
      setError(err.message || 'Could not save company profile. Please try again.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] flex flex-col justify-between font-['Plus_Jakarta_Sans',sans-serif] text-slate-900 select-none">
      
      {/* Clean Top Bar (64px) with NK Logo and 3-Step Horizontal Progress Indicator */}
      <header className="w-full h-16 bg-white border-b border-[#E2E8F0] px-6 lg:px-12 flex items-center justify-between sticky top-0 z-30 shadow-xs">
        {/* Left Brand Badge */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#2563EB] flex items-center justify-center font-extrabold text-white text-base shadow-sm">
            NK
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-sm text-[#0F172A] tracking-tight">NirmanKhata ERP</span>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-50 text-[#7C3AED] border border-purple-200">
                Admin: Editor
              </span>
            </div>
            <p className="text-[11px] text-slate-400">One-Time Enterprise Setup</p>
          </div>
        </div>

        {/* 3-Step Horizontal Progress Indicator */}
        <div className="hidden md:flex items-center gap-3">
          {/* Step 1: Active */}
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-blue-50 border border-blue-200 text-[#2563EB]">
            <span className="w-5 h-5 rounded-full bg-[#2563EB] text-white flex items-center justify-center text-xs font-bold">
              1
            </span>
            <span className="text-xs font-bold">1. Company Identity (Active)</span>
          </div>

          <ChevronRight className="w-4 h-4 text-slate-300" />

          {/* Step 2 */}
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg text-slate-600 font-medium">
            <span className="w-5 h-5 rounded-full bg-slate-200 text-slate-600 flex items-center justify-center text-xs font-bold">
              2
            </span>
            <span className="text-xs">2. Address & Contact</span>
          </div>

          <ChevronRight className="w-4 h-4 text-slate-300" />

          {/* Step 3 */}
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg text-slate-600 font-medium">
            <span className="w-5 h-5 rounded-full bg-slate-200 text-slate-600 flex items-center justify-center text-xs font-bold">
              3
            </span>
            <span className="text-xs">3. Tax, Accounting & Logo</span>
          </div>
        </div>

        {/* Right Status Pill */}
        <div className="text-right">
          <span className="text-xs text-slate-500 font-medium flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-[#10B981]" /> Enterprise Cloud Ready
          </span>
        </div>
      </header>

      {/* Main Body: Centered 900px Wide White Card */}
      <main className="flex-1 py-8 px-4 sm:px-6 flex justify-center items-start">
        <div className="w-full max-w-[900px] bg-white rounded-2xl border border-[#E2E8F0] shadow-xl shadow-slate-200/50 overflow-hidden">
          
          {/* Header Banner inside card */}
          <div className="px-8 py-6 border-b border-[#E2E8F0] bg-gradient-to-r from-slate-50 to-white flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-extrabold text-[#0F172A] tracking-tight">
                Business Profile Onboarding
              </h1>
              <p className="text-xs sm:text-sm text-slate-500 mt-1">
                Configure your contractor enterprise identity. Company documents, invoices, and reports will carry this branding.
              </p>
            </div>
            <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-emerald-50 text-emerald-700 text-xs font-semibold border border-emerald-200">
              <Shield className="w-4 h-4" /> Single Master Profile
            </div>
          </div>

          {/* Form with 3 Tidy Visual Sections */}
          <form onSubmit={handleSubmit} className="p-8 space-y-8">
            
            {/* SECTION 1: Company Identity */}
            <div>
              <div className="flex items-center gap-2.5 pb-3 border-b border-slate-100 mb-5">
                <div className="w-7 h-7 rounded-lg bg-blue-50 text-[#2563EB] flex items-center justify-center font-bold text-xs">
                  1
                </div>
                <div>
                  <h2 className="text-sm font-bold text-[#0F172A] uppercase tracking-wide">
                    Section 1: Company Identity & Accounting Setup
                  </h2>
                  <p className="text-xs text-slate-400">Primary legal names and operating fiscal parameters</p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Legal Name */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Company Legal Name <span className="text-rose-500">*</span>
                  </label>
                  <input
                    required
                    type="text"
                    value={form.legalName}
                    onChange={(e) => setForm({ ...form, legalName: e.target.value })}
                    placeholder="e.g. Sharma Civil Infra Pvt. Ltd."
                    className="w-full px-3.5 py-2.5 bg-white border border-[#CBD5E1] rounded-xl text-sm font-medium text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#2563EB] focus:border-[#2563EB] transition-all"
                  />
                </div>

                {/* Display Name */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Company Display Name <span className="text-rose-500">*</span>
                  </label>
                  <input
                    required
                    type="text"
                    value={form.displayName}
                    onChange={(e) => setForm({ ...form, displayName: e.target.value })}
                    placeholder="e.g. Sharma Civil Contractors"
                    className="w-full px-3.5 py-2.5 bg-white border border-[#CBD5E1] rounded-xl text-sm font-medium text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#2563EB] focus:border-[#2563EB] transition-all"
                  />
                </div>

                {/* Business Type Dropdown */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Business Type <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative">
                    <select
                      value={form.contractorType}
                      onChange={(e) => setForm({ ...form, contractorType: e.target.value })}
                      className="w-full px-3.5 py-2.5 bg-white border border-[#CBD5E1] rounded-xl text-sm font-medium text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#2563EB] focus:border-[#2563EB] transition-all appearance-none cursor-pointer"
                    >
                      <option value="Civil & Building Construction">Civil & Building Construction</option>
                      <option value="Roads, Highways & Bridges">Roads, Highways & Bridges</option>
                      <option value="Interior, Fit-Out & Renovation">Interior, Fit-Out & Renovation</option>
                      <option value="Electrical & MEP Contracting">Electrical & MEP Contracting</option>
                      <option value="Industrial Infrastructure & Fabrication">Industrial Infrastructure & Fabrication</option>
                    </select>
                    <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none text-slate-400">
                      <Briefcase className="w-4 h-4" />
                    </div>
                  </div>
                </div>

                {/* 2-col inline for Financial Year & Currency */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                      Financial Year <span className="text-rose-500">*</span>
                    </label>
                    <select
                      value={form.financialYear}
                      onChange={(e) => setForm({ ...form, financialYear: e.target.value })}
                      className="w-full px-3 py-2.5 bg-white border border-[#CBD5E1] rounded-xl text-sm font-medium text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#2563EB] focus:border-[#2563EB] transition-all"
                    >
                      <option value="2026-2027">FY 2026-27</option>
                      <option value="2025-2026">FY 2025-26</option>
                      <option value="2027-2028">FY 2027-28</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                      Base Currency <span className="text-rose-500">*</span>
                    </label>
                    <div className="flex items-center px-3 py-2.5 bg-slate-50 border border-[#CBD5E1] rounded-xl text-sm font-bold text-[#0F172A]">
                      <IndianRupee className="w-4 h-4 mr-1 text-[#2563EB]" /> INR (₹)
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* SECTION 2: Tax & Contact */}
            <div>
              <div className="flex items-center gap-2.5 pb-3 border-b border-slate-100 mb-5">
                <div className="w-7 h-7 rounded-lg bg-blue-50 text-[#2563EB] flex items-center justify-center font-bold text-xs">
                  2
                </div>
                <div>
                  <h2 className="text-sm font-bold text-[#0F172A] uppercase tracking-wide">
                    Section 2: Tax Credentials & Official Contact
                  </h2>
                  <p className="text-xs text-slate-400">Invoicing compliance and client communication</p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    GSTIN (Optional)
                  </label>
                  <input
                    type="text"
                    value={form.gstin}
                    onChange={(e) => setForm({ ...form, gstin: e.target.value.toUpperCase() })}
                    placeholder="e.g. 07AAAAA0000A1Z5"
                    className="w-full px-3.5 py-2.5 bg-white border border-[#CBD5E1] rounded-xl text-sm font-medium text-[#0F172A] uppercase tracking-wider focus:outline-none focus:ring-2 focus:ring-[#2563EB] focus:border-[#2563EB] transition-all"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    PAN (Optional)
                  </label>
                  <input
                    type="text"
                    value={form.panNumber}
                    onChange={(e) => setForm({ ...form, panNumber: e.target.value.toUpperCase() })}
                    placeholder="e.g. ABCDE1234F"
                    className="w-full px-3.5 py-2.5 bg-white border border-[#CBD5E1] rounded-xl text-sm font-medium text-[#0F172A] uppercase tracking-wider focus:outline-none focus:ring-2 focus:ring-[#2563EB] focus:border-[#2563EB] transition-all"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Company Email <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative">
                    <input
                      required
                      type="email"
                      value={form.email}
                      onChange={(e) => setForm({ ...form, email: e.target.value })}
                      placeholder="e.g. accounts@sharmacivil.com"
                      className="w-full pl-10 pr-3.5 py-2.5 bg-white border border-[#CBD5E1] rounded-xl text-sm font-medium text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#2563EB] focus:border-[#2563EB] transition-all"
                    />
                    <div className="absolute inset-y-0 left-0 flex items-center pl-3.5 pointer-events-none text-slate-400">
                      <Mail className="w-4 h-4" />
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Phone Number <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative">
                    <input
                      required
                      type="text"
                      value={form.phone}
                      onChange={(e) => setForm({ ...form, phone: e.target.value })}
                      placeholder="e.g. +91 98765 43210"
                      className="w-full pl-10 pr-3.5 py-2.5 bg-white border border-[#CBD5E1] rounded-xl text-sm font-medium text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#2563EB] focus:border-[#2563EB] transition-all"
                    />
                    <div className="absolute inset-y-0 left-0 flex items-center pl-3.5 pointer-events-none text-slate-400">
                      <Phone className="w-4 h-4" />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* SECTION 3: Registered Address & Logo */}
            <div>
              <div className="flex items-center gap-2.5 pb-3 border-b border-slate-100 mb-5">
                <div className="w-7 h-7 rounded-lg bg-blue-50 text-[#2563EB] flex items-center justify-center font-bold text-xs">
                  3
                </div>
                <div>
                  <h2 className="text-sm font-bold text-[#0F172A] uppercase tracking-wide">
                    Section 3: Registered Address & Company Branding
                  </h2>
                  <p className="text-xs text-slate-400">Head office location and custom letterhead emblem</p>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-[1.2fr_0.8fr] gap-6">
                {/* Left Side: Address Details */}
                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                      Registered Address <span className="text-rose-500">*</span>
                    </label>
                    <textarea
                      required
                      rows={2}
                      value={form.address}
                      onChange={(e) => setForm({ ...form, address: e.target.value })}
                      placeholder="Street address, building number, industrial phase..."
                      className="w-full px-3.5 py-2 bg-white border border-[#CBD5E1] rounded-xl text-sm font-medium text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#2563EB] focus:border-[#2563EB] transition-all resize-none"
                    />
                  </div>

                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                        City <span className="text-rose-500">*</span>
                      </label>
                      <input
                        required
                        type="text"
                        value={form.city}
                        onChange={(e) => setForm({ ...form, city: e.target.value })}
                        placeholder="Gurugram"
                        className="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-xl text-sm font-medium text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#2563EB] focus:border-[#2563EB] transition-all"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                        State <span className="text-rose-500">*</span>
                      </label>
                      <input
                        required
                        type="text"
                        value={form.state}
                        onChange={(e) => setForm({ ...form, state: e.target.value })}
                        placeholder="Haryana"
                        className="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-xl text-sm font-medium text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#2563EB] focus:border-[#2563EB] transition-all"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                        Pincode <span className="text-rose-500">*</span>
                      </label>
                      <input
                        required
                        type="text"
                        value={form.pincode}
                        onChange={(e) => setForm({ ...form, pincode: e.target.value })}
                        placeholder="122015"
                        className="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-xl text-sm font-medium text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#2563EB] focus:border-[#2563EB] transition-all"
                      />
                    </div>
                  </div>
                </div>

                {/* Right Side: Dashed Upload Box */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Upload Company Logo (PNG/JPG)
                  </label>
                  <label className="flex flex-col items-center justify-center p-5 border-2 border-dashed border-[#CBD5E1] hover:border-[#2563EB] bg-slate-50 hover:bg-blue-50/20 rounded-2xl cursor-pointer transition-all h-[130px] group text-center relative overflow-hidden">
                    <input
                      type="file"
                      accept="image/png,image/jpeg"
                      onChange={handleLogoChange}
                      className="sr-only"
                    />
                    
                    {logoPreview ? (
                      <div className="flex items-center gap-3">
                        <img
                          src={logoPreview}
                          alt="Logo Preview"
                          className="w-16 h-16 rounded-full object-cover border-2 border-[#2563EB] shadow-sm"
                        />
                        <div className="text-left">
                          <span className="text-xs font-bold text-slate-800 block truncate max-w-[130px]">
                            {logo?.name}
                          </span>
                          <span className="text-[11px] text-emerald-600 font-semibold">Change image</span>
                        </div>
                      </div>
                    ) : (
                      <>
                        <div className="w-12 h-12 rounded-full bg-white border border-slate-200 flex items-center justify-center text-slate-400 group-hover:text-[#2563EB] group-hover:border-blue-300 shadow-xs mb-2 transition-all">
                          <Upload className="w-5 h-5" />
                        </div>
                        <span className="text-xs font-bold text-slate-700">Click to upload brand logo</span>
                        <span className="text-[10px] text-slate-400 mt-0.5">Recommended 400x400 square (max 5MB)</span>
                      </>
                    )}
                  </label>
                </div>
              </div>
            </div>

            {/* Error Banner */}
            {error && (
              <div role="alert" className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-medium">
                {error}
              </div>
            )}

            {/* Sticky/Fixed Bottom Card Footer */}
            <div className="pt-6 border-t border-[#E2E8F0] flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-2 text-xs text-slate-500">
                <CheckCircle2 className="w-4 h-4 text-[#10B981]" />
                <span>All parameters can be modified later in Business Profile Settings</span>
              </div>

              <button
                type="submit"
                disabled={busy}
                className="w-full sm:w-auto px-8 py-3 bg-[#2563EB] hover:bg-blue-700 active:bg-blue-800 disabled:opacity-50 text-white font-bold text-sm rounded-xl shadow-lg shadow-blue-500/25 flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <span>{busy ? 'Saving Master Profile...' : 'Save Business Profile'}</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>

          </form>

        </div>
      </main>

      {/* Micro Status Footer */}
      <footer className="w-full h-10 border-t border-[#E2E8F0] bg-white px-8 flex items-center justify-between text-[11px] text-slate-400">
        <span>Sharma Civil Contractors • Enterprise Onboarding Gateway</span>
        <span>Secure Session • NirmanKhata ERP v2.4</span>
      </footer>

    </div>
  );
};

import React from 'react';
import {DailyDprView} from '../views/DailyDprView';
export const ConstructionOperationsGate:React.FC=()=> <DailyDprView mode="daily"/>;

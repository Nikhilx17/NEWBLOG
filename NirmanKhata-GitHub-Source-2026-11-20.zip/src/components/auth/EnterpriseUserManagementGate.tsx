import React from 'react';
import {useHostingerSession} from '../../context/HostingerSession';
import {UserAccessManagement} from './UserAccessManagement';
export const EnterpriseUserManagementGate:React.FC=()=>{const session=useHostingerSession();return session?.user?.roleId==='admin_editor'?<UserAccessManagement tenantId={session.user.enterpriseId}/>:<p className="rounded border p-4 text-sm">Only Admin: Editor can manage enterprise users.</p>};

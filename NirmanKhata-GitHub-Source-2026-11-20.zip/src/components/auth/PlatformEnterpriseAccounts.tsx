import {call} from '../../lib/api';
import React, { useState } from 'react';


import { generateTemporaryPassword } from './UserAccessManagement';
const input = 'w-full rounded-lg border px-3 py-2.5 text-sm';
const initial = () => ({ name: '', adminName: '', username: '', temporaryPassword: '', employeeLimit: '10', modules: '*', requestId: crypto.randomUUID() });
export const PlatformEnterpriseAccounts: React.FC<{
    companies: any[];
    onSaved: () => void;
}> = ({ companies, onSaved }) => {
    const [form, setForm] = useState(initial), [license, setLicense] = useState({ tenantId: '', status: 'active', employeeLimit: '10', modules: '*', days: '30' }), [error, setError] = useState(''), [notice, setNotice] = useState(''), [busy, setBusy] = useState(false);
    return <section className="space-y-4 rounded-xl border bg-white p-5"><h2 className="text-lg font-bold">Enterprise Provisioning</h2><p className="text-xs text-slate-500">Create only the initial Admin: Editor account. Enterprise administrators create their own employee accounts.</p>{error && <p role="alert" className="text-sm text-rose-700">{error}</p>}{notice && <p role="status" className="text-sm text-emerald-700">{notice}</p>}<form className="grid gap-3 sm:grid-cols-2" onSubmit={async (e) => { e.preventDefault(); setBusy(true); setError(''); setNotice(''); try {
        const response = await ((data:any)=>call('provisionEnterprise',data).then(data=>({data})))({ ...form, employeeLimit: Number(form.employeeLimit), modules: form.modules.split(',').map(x => x.trim()).filter(Boolean) });
        setNotice('Enterprise created. Admin: Editor login: ' + response.data.username + '. Provide the temporary password privately.');
        setForm(initial());
        onSaved();
    }
    catch (e: any) {
        setError(e.message);
    }
    finally {
        setBusy(false);
    } }}>{[['name', 'Enterprise Name'], ['adminName', 'Administrator Name'], ['username', 'Admin Login Username'], ['temporaryPassword', 'Temporary Password'], ['employeeLimit', 'Employee Limit (-1 = unlimited)'], ['modules', 'Enabled Modules (* = all)']].map(([key, label]) => <label key={key} className="text-xs font-bold">{label}<input required autoComplete={key === 'temporaryPassword' ? 'new-password' : 'off'} type={key === 'employeeLimit' ? 'number' : 'text'} min={key === 'employeeLimit' ? -1 : undefined} className={input + ' mt-1'} value={(form as any)[key]} onChange={e => setForm({ ...form, [key]: e.target.value })}/></label>)}<button type="button" className="text-left text-xs font-bold text-blue-700" onClick={() => setForm({ ...form, username: (form.name.toLowerCase().replace(/[^a-z0-9]+/g, '.').replace(/^\.|\.$/g, '').slice(0, 40) || 'enterprise') + '.admin.' + crypto.randomUUID().slice(0, 6) })}>Generate admin login ID</button><button type="button" className="text-left text-xs font-bold text-blue-700" onClick={() => setForm({ ...form, temporaryPassword: generateTemporaryPassword() })}>Generate temporary password</button><p className="text-xs text-slate-500">Record the password before saving. It is never returned by an API or stored in enterprise records.</p><button disabled={busy} className="rounded-lg bg-blue-700 px-4 py-2.5 text-sm font-bold text-white disabled:opacity-50">Create Enterprise & Admin: Editor</button></form><details className="border-t pt-4"><summary className="cursor-pointer text-sm font-bold">Activate / Renew / Suspend Enterprise License</summary><form className="mt-3 grid gap-3 sm:grid-cols-2" onSubmit={async (e) => { e.preventDefault(); setBusy(true); setError(''); try {
        await ((data:any)=>call('setEnterpriseLicense',data))({ ...license, employeeLimit: Number(license.employeeLimit), days: Number(license.days), modules: license.modules.split(',').map(x => x.trim()).filter(Boolean) });
        setNotice('Enterprise license updated.');
        onSaved();
    }
    catch (e: any) {
        setError(e.message);
    }
    finally {
        setBusy(false);
    } }}><select required aria-label="Enterprise" className={input} value={license.tenantId} onChange={e => { const c = companies.find(c => c.tenantId === e.target.value); setLicense({ ...license, tenantId: e.target.value, employeeLimit: String(c?.employeeLimit ?? 10) }); }}><option value="">Select enterprise</option>{companies.map(c => <option key={c.tenantId} value={c.tenantId}>{c.name}</option>)}</select><select aria-label="License status" className={input} value={license.status} onChange={e => setLicense({ ...license, status: e.target.value })}><option value="active">Activate / Renew</option><option value="suspended">Suspend</option><option value="expired">Expired</option></select>{[['employeeLimit', 'Employee Limit (-1 = unlimited)'], ['modules', 'Enabled Modules'], ['days', 'License Duration (days)']].map(([key, label]) => <label key={key} className="text-xs font-bold">{label}<input required className={input + ' mt-1'} value={(license as any)[key]} onChange={e => setLicense({ ...license, [key]: e.target.value })}/></label>)}<button disabled={busy} className="rounded-lg bg-blue-700 px-4 py-2.5 text-sm font-bold text-white">Save License</button></form></details></section>;
};

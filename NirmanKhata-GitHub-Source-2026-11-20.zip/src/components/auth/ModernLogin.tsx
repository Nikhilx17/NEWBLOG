import React, { useState } from 'react';
import { api } from '../../lib/api';
import {
  TrendingUp,
  ClipboardCheck,
  Package,
  User,
  Lock,
  Eye,
  EyeOff,
  ShieldCheck,
  Info,
  ArrowRight,
  Activity,
} from 'lucide-react';

interface LoginProps {
  onUser: (user: any) => void;
}

export const ModernLogin: React.FC<LoginProps> = ({ onUser }) => {
  const [username, setUsername] = useState('rajesh.sharma');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberDevice, setRememberDevice] = useState(true);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      const result = await api('/auth/login', {
        method: 'POST',
        body: JSON.stringify({ username, password }),
      });
      setPassword('');
      onUser(result.user);
    } catch (err: any) {
      setError(err.message || 'Unable to sign in. Please verify your credentials.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0F172A] flex items-center justify-center p-2 sm:p-4 lg:p-6 font-['Plus_Jakarta_Sans',sans-serif]">
      {/* 16:9 Aspect Ratio / Enterprise Container */}
      <div className="w-full max-w-[1360px] min-h-[760px] bg-[#F8FAFC] rounded-2xl overflow-hidden shadow-2xl border border-slate-800 flex flex-col lg:flex-row relative">
        
        {/* LEFT PANEL (45% Width on LG, Deep Navy-Slate #0F172A) */}
        <div className="lg:w-[45%] bg-[#0F172A] relative flex flex-col justify-between p-8 sm:p-12 text-white border-b lg:border-b-0 lg:border-r border-slate-800 overflow-hidden">
          
          {/* Subtle Blueprint Architectural Grid Overlay */}
          <div 
            className="absolute inset-0 pointer-events-none opacity-20"
            style={{
              backgroundImage: `linear-gradient(to right, #334155 1px, transparent 1px), linear-gradient(to bottom, #334155 1px, transparent 1px)`,
              backgroundSize: '32px 32px'
            }}
          />
          <div className="absolute top-1/4 -left-20 w-80 h-80 bg-blue-600/15 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute bottom-10 right-0 w-80 h-80 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

          {/* Top Brand Logo & Title */}
          <div className="relative z-10">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-xl bg-[#2563EB] flex items-center justify-center font-black text-xl text-white shadow-lg shadow-blue-600/30 border border-blue-400/20">
                NK
              </div>
              <div>
                <h1 className="font-extrabold text-lg tracking-tight leading-tight text-white">NirmanKhata</h1>
                <p className="text-xs text-slate-400 font-medium">Contractor Profit & Expense ERP</p>
              </div>
            </div>

            <div className="mt-10 sm:mt-14">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-semibold mb-3">
                <span className="w-2 h-2 rounded-full bg-blue-400 animate-pulse" />
                Enterprise Edition
              </div>
              <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold tracking-tight leading-tight text-white">
                Real-Time Site Execution & Live Project Profit
              </h2>
              <p className="text-slate-400 text-xs sm:text-sm mt-3 leading-relaxed max-w-md">
                Dedicated enterprise operating system designed specifically for Indian infrastructure, civil, and general construction contractors.
              </p>
            </div>
          </div>

          {/* 3 Clean Feature Highlights */}
          <div className="relative z-10 my-8 lg:my-auto space-y-3.5">
            {/* Feature 1 */}
            <div className="flex items-start gap-3.5 p-3.5 sm:p-4 rounded-xl bg-slate-900/80 border border-slate-800/80 backdrop-blur-sm shadow-sm">
              <div className="w-9 h-9 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center shrink-0">
                <TrendingUp className="w-5 h-5 text-[#10B981]" />
              </div>
              <div>
                <h3 className="text-sm font-semibold text-white">Live Project P&L & Cash Tracking</h3>
                <p className="text-xs text-slate-400 mt-0.5">Real-time gross margins, running bill cash flows, and milestone profits per site.</p>
              </div>
            </div>

            {/* Feature 2 */}
            <div className="flex items-start gap-3.5 p-3.5 sm:p-4 rounded-xl bg-slate-900/80 border border-slate-800/80 backdrop-blur-sm shadow-sm">
              <div className="w-9 h-9 rounded-lg bg-blue-500/10 border border-blue-500/20 flex items-center justify-center shrink-0">
                <ClipboardCheck className="w-5 h-5 text-[#2563EB]" />
              </div>
              <div>
                <h3 className="text-sm font-semibold text-white">Photo-Verified Daily Progress Reports</h3>
                <p className="text-xs text-slate-400 mt-0.5">Geo-tagged work logs, daily muster attendance counts, and verified site audits.</p>
              </div>
            </div>

            {/* Feature 3 */}
            <div className="flex items-start gap-3.5 p-3.5 sm:p-4 rounded-xl bg-slate-900/80 border border-slate-800/80 backdrop-blur-sm shadow-sm">
              <div className="w-9 h-9 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center shrink-0">
                <Package className="w-5 h-5 text-[#F59E0B]" />
              </div>
              <div>
                <h3 className="text-sm font-semibold text-white">Multi-Site Material & Expense Control</h3>
                <p className="text-xs text-slate-400 mt-0.5">PO approvals, cement/steel reconciliation, and automated vendor ledgers.</p>
              </div>
            </div>
          </div>

          {/* Bottom Security / System Status */}
          <div className="relative z-10 flex items-center justify-between text-xs text-slate-500 pt-4 border-t border-slate-800/80">
            <span>Sharma Civil Contractors Instance</span>
            <span className="flex items-center gap-1.5 text-emerald-400 font-medium">
              <Activity className="w-3.5 h-3.5" /> Database Online
            </span>
          </div>
        </div>

        {/* RIGHT PANEL (55% Width on LG, #F8FAFC Background) */}
        <div className="lg:w-[55%] bg-[#F8FAFC] flex flex-col justify-center items-center p-6 sm:p-12 lg:p-16 relative">
          
          {/* Centered White Card (#FFFFFF) */}
          <div className="w-full max-w-[440px] bg-[#FFFFFF] rounded-2xl border border-[#E2E8F0] shadow-xl shadow-slate-200/50 p-7 sm:p-9">
            
            {/* Header */}
            <div className="text-left mb-6">
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-700 text-xs font-semibold mb-2.5 border border-slate-200">
                <span className="w-1.5 h-1.5 rounded-full bg-blue-600" />
                Enterprise Portal
              </div>
              <h2 className="text-2xl font-bold text-[#0F172A] tracking-tight">
                Sign In to Your Workspace
              </h2>
              <p className="text-slate-500 text-xs sm:text-sm mt-1">
                Enter your enterprise staff or platform credentials.
              </p>
            </div>

            {/* Login Form */}
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Field 1: Username / Login ID */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Username / Login ID <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                    <User className="w-4 h-4" />
                  </div>
                  <input
                    required
                    autoComplete="username"
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="e.g. rajesh.sharma"
                    className="w-full pl-10 pr-3.5 py-2.5 bg-white border border-[#CBD5E1] rounded-xl text-sm font-medium text-[#0F172A] placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-[#2563EB] focus:border-[#2563EB] transition-all"
                  />
                </div>
              </div>

              {/* Field 2: Password */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-xs font-semibold text-slate-700">
                    Password <span className="text-rose-500">*</span>
                  </label>
                </div>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                    <Lock className="w-4 h-4" />
                  </div>
                  <input
                    required
                    autoComplete="current-password"
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter password"
                    className="w-full pl-10 pr-10 py-2.5 bg-white border border-[#CBD5E1] rounded-xl text-sm font-medium text-[#0F172A] placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-[#2563EB] focus:border-[#2563EB] transition-all"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-slate-600 transition-colors"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Options Row */}
              <div className="flex items-center justify-between text-xs pt-0.5">
                <label className="flex items-center gap-2 cursor-pointer text-slate-600 select-none">
                  <input
                    type="checkbox"
                    checked={rememberDevice}
                    onChange={(e) => setRememberDevice(e.target.checked)}
                    className="w-4 h-4 rounded text-[#2563EB] border-slate-300 focus:ring-[#2563EB]"
                  />
                  <span>Remember this device</span>
                </label>
                <span className="font-semibold px-2 py-0.5 rounded bg-purple-50 text-[#7C3AED] border border-purple-200">
                  Role: Admin: Editor
                </span>
              </div>

              {/* Error banner */}
              {error && (
                <div role="alert" className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-medium">
                  {error}
                </div>
              )}

              {/* Full-width primary indigo button */}
              <button
                type="submit"
                disabled={busy}
                className="w-full py-3 px-4 bg-[#2563EB] hover:bg-blue-700 active:bg-blue-800 disabled:opacity-60 text-white font-semibold text-sm rounded-xl shadow-lg shadow-blue-500/25 flex items-center justify-center gap-2 transition-all cursor-pointer mt-2"
              >
                <span>{busy ? 'Authenticating...' : 'Sign In'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>

            {/* Subtle Info Notice Box */}
            <div className="mt-5 p-3.5 bg-slate-50 border border-[#E2E8F0] rounded-xl flex items-start gap-2.5">
              <Info className="w-4 h-4 text-slate-500 shrink-0 mt-0.5" />
              <p className="text-xs text-slate-600 leading-relaxed">
                Forgot your password? Ask your enterprise <strong className="text-slate-800 font-semibold">Admin: Editor</strong> to reset your temporary password.
              </p>
            </div>

            {/* Clean Footer Security Badge */}
            <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-center gap-2 text-[11px] font-medium text-slate-500">
              <ShieldCheck className="w-3.5 h-3.5 text-[#10B981]" />
              <span>Secured with HttpOnly Session & Brute-Force Protection</span>
            </div>
          </div>

          <div className="mt-5 text-center text-xs text-slate-400">
            NirmanKhata ERP Platform • Sharma Civil Contractors Workspace
          </div>
        </div>

      </div>
    </div>
  );
};

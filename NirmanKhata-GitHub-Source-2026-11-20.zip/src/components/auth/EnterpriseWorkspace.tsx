import React, { useEffect, useState } from 'react';
import { onAuthStateChanged, signInWithEmailAndPassword, signOut } from 'firebase/auth';
import { httpsCallable } from 'firebase/functions';
import { auth, functions } from '../../lib/firebase';
import { SiteProgressWorkspace } from './SiteProgressWorkspace';
import { UserAccessManagement } from './UserAccessManagement';
const invoke = async (name: string, data: any) => (await httpsCallable<any, any>(functions, name)(data)).data;
const input = 'w-full rounded-lg border border-slate-300 bg-white px-3 py-3 text-sm';
const button = 'rounded-lg bg-blue-700 px-4 py-3 text-sm font-bold text-white disabled:opacity-50';
export const EnterpriseLogin: React.FC<{
    onSuccess?: () => void;
}> = ({ onSuccess }) => {
    const [username, setUsername] = useState(''), [password, setPassword] = useState(''), [busy, setBusy] = useState(false), [error, setError] = useState('');
    return <div className="grid min-h-screen place-items-center bg-slate-50 px-4"><form className="w-full max-w-md space-y-5 rounded-2xl border bg-white p-7" onSubmit={async (e) => { e.preventDefault(); setBusy(true); setError(''); try {
        const login = username.trim().toLowerCase();
        await signInWithEmailAndPassword(auth, login.includes('@') ? login : login + '@login.nirmankhata.invalid', password);
        setPassword('');
        onSuccess?.();
    }
    catch (e: any) {
        setError(e.code === 'auth/too-many-requests' ? 'Too many attempts. Please wait before trying again.' : 'Unable to sign in. Check your login ID and password.');
    }
    finally {
        setBusy(false);
    } }}><div><span className="inline-block rounded-xl bg-blue-700 p-3 font-bold text-white">NK</span><h1 className="mt-4 text-2xl font-bold">ERP Sign In</h1><p className="mt-2 text-sm text-slate-500">Use the credentials provided by your enterprise administrator.</p></div><label className="block text-sm font-bold">Username / Login ID<input required autoComplete="username" className={input + ' mt-2'} value={username} onChange={e => setUsername(e.target.value)}/></label><label className="block text-sm font-bold">Password<input required type="password" autoComplete="current-password" className={input + ' mt-2'} value={password} onChange={e => setPassword(e.target.value)}/></label>{error && <p role="alert" className="text-sm text-rose-700">{error}</p>}<button disabled={busy} className={button + ' w-full'}>{busy ? 'Signing in...' : 'Sign In'}</button><p className="text-xs text-slate-500">Forgot your password? Contact your Enterprise Super Admin for a credential reset.</p></form></div>;
};
const RequiredPasswordChange: React.FC<{
    tenantId: string;
}> = ({ tenantId }) => {
    const [password, setPassword] = useState(''), [confirm, setConfirm] = useState(''), [error, setError] = useState(''), [busy, setBusy] = useState(false);
    return <div className="grid min-h-screen place-items-center bg-slate-50 p-4"><form className="w-full max-w-md space-y-4 rounded-xl border bg-white p-6" onSubmit={async (e) => { e.preventDefault(); if (password !== confirm) {
        setError('Passwords do not match.');
        return;
    } setBusy(true); setError(''); try {
        await invoke('completeEnterprisePasswordChange', { tenantId, newPassword: password });
        setPassword('');
        setConfirm('');
        await signOut(auth);
    }
    catch (e: any) {
        setError(e.message);
    }
    finally {
        setBusy(false);
    } }}><h1 className="text-xl font-bold">Change Temporary Password</h1><p className="text-sm text-slate-500">Create your own password before accessing enterprise data. After saving, sign in again with your new password.</p><label className="block text-xs font-bold">New Password<input required type="password" autoComplete="new-password" minLength={12} maxLength={128} className={input + ' mt-1'} value={password} onChange={e => setPassword(e.target.value)}/></label><label className="block text-xs font-bold">Confirm Password<input required type="password" autoComplete="new-password" className={input + ' mt-1'} value={confirm} onChange={e => setConfirm(e.target.value)}/></label><p className="text-xs text-slate-500">At least 12 characters, with uppercase, lowercase and a number.</p>{error && <p role="alert" className="text-sm text-rose-700">{error}</p>}<button disabled={busy} className={button}>Save Password & Sign Out</button><button type="button" onClick={() => signOut(auth)} className="ml-3 text-sm">Sign out</button></form></div>;
};
const ModuleRecords: React.FC<{
    tenantId: string;
    module: any;
}> = ({ tenantId, module }) => {
    const [collection, setCollection] = useState(module.collections?.[0] || ''), [rows, setRows] = useState<any[]>([]), [cursor, setCursor] = useState<string | null>(null), [error, setError] = useState(''), [loading, setLoading] = useState(false);
    const load = async (next?: string) => { setLoading(true); setError(''); try {
        const result = await invoke('listAuthorizedModuleRecords', { tenantId, moduleId: module.id, collection, ...(next ? { cursor: next } : {}) });
        setRows(old => next ? [...old, ...result.records] : result.records);
        setCursor(result.nextCursor);
    }
    catch (e: any) {
        setError(e.message);
    }
    finally {
        setLoading(false);
    } };
    useEffect(() => { setRows([]); if (collection)
        void load(); }, [tenantId, module.id, collection]);
    const columns = Array.from(new Set(rows.flatMap(row => Object.keys(row)))).filter(k => !['tenantId', 'businessId', 'createdBy', 'updatedBy'].includes(k) && rows.some(r => typeof r[k] !== 'object')).slice(0, 10);
    return <section className="space-y-4"><div className="flex items-center justify-between gap-3"><h2 className="text-xl font-bold">{module.name}</h2>{collection && <button className="rounded border px-3 py-2 text-sm" onClick={() => void load()}>Refresh</button>}</div>{module.collections?.length > 0 && <select aria-label="Record type" value={collection} onChange={e => setCollection(e.target.value)} className={input}>{module.collections.map((c: string) => <option key={c}>{c}</option>)}</select>}{error && <p role="alert" className="text-sm text-rose-700">{error}</p>}{!collection ? <p className="rounded border bg-slate-50 p-4 text-sm text-slate-600">Your role authorizes this module. Its existing ERP workspace remains available in the original ERP interface.</p> : <div className="overflow-auto rounded-xl border"><table className="w-full text-left text-xs"><thead className="bg-slate-50"><tr>{columns.map(c => <th key={c} className="whitespace-nowrap p-3">{c}</th>)}</tr></thead><tbody>{rows.map(r => <tr key={r.id} className="border-t">{columns.map(c => <td key={c} className="max-w-xs truncate p-3">{['string', 'number', 'boolean'].includes(typeof r[c]) ? String(r[c]) : '—'}</td>)}</tr>)}</tbody></table>{!rows.length && <p className="p-5 text-sm text-slate-500">{loading ? 'Loading authorized records...' : 'No authorized records found.'}</p>}</div>}{cursor && <button disabled={loading} className={button} onClick={() => void load(cursor)}>Load more</button>}</section>;
};
export const EnterpriseCustomerAccess: React.FC<{
    renderLegacyTools?: (tenantId: string) => React.ReactNode;
    renderSupport?: (tenantId: string) => React.ReactNode;
}> = ({ renderLegacyTools, renderSupport }) => {
    const [user, setUser] = useState<any>(undefined), [companies, setCompanies] = useState<any[]>([]), [tenantId, setTenantId] = useState(''), [access, setAccess] = useState<any>(null), [error, setError] = useState(''), [tab, setTab] = useState('');
    useEffect(() => onAuthStateChanged(auth, async (next) => { setUser(next); setAccess(null); setCompanies([]); setError(''); setTenantId(''); if (next)
        try {
            const result = await invoke('listMyCompanies', {});
            setCompanies(result.companies);
            setTenantId(result.companies[0]?.tenantId || '');
        }
        catch (e: any) {
            setError(e.message);
        } }), []);
    useEffect(() => { if (!tenantId || !user)
        return; localStorage.setItem('nk_active_tenant', tenantId); let live = true; const refresh = async () => { try {
        const result = await invoke('getMyEnterpriseAccess', { tenantId });
        if (live) {
            setAccess(result);
            setError('');
            setTab(old => old === 'users' && result.canManageUsers || result.modules.some((m: any) => m.id === old) ? old : result.modules[0]?.id || (result.canManageUsers ? 'users' : ''));
        }
    }
    catch (e: any) {
        if (live) {
            setAccess(null);
            setError(e.message);
        }
    } }; void refresh(); const timer = setInterval(() => { if (!document.hidden)
        void refresh(); }, 15000); window.addEventListener('focus', refresh); return () => { live = false; clearInterval(timer); window.removeEventListener('focus', refresh); }; }, [tenantId, user]);
    if (user === undefined)
        return <p className="p-8">Checking session...</p>;
    if (!user)
        return <EnterpriseLogin />;
    if (access?.mustChangePassword)
        return <RequiredPasswordChange tenantId={tenantId}/>;
    return <div className="min-h-screen bg-slate-50 text-slate-900"><header className="border-b bg-white px-5 py-4"><div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3"><div><h1 className="text-xl font-bold">{companies.find(c => c.tenantId === tenantId)?.name || 'Enterprise Workspace'}</h1><p className="mt-1 text-xs text-slate-500">{access?.displayName} · {access?.roleName}</p></div><div className="flex items-center gap-3">{companies.length > 1 && <select aria-label="Enterprise" className="rounded border p-2 text-sm" value={tenantId} onChange={e => { setAccess(null); setTab(''); setTenantId(e.target.value); }}>{companies.map(c => <option key={c.tenantId} value={c.tenantId}>{c.name}</option>)}</select>}<button className="rounded border px-3 py-2 text-sm" onClick={() => signOut(auth)}>Sign out</button></div></div></header>{error && <p role="alert" className="mx-auto mt-5 max-w-4xl rounded border border-rose-200 bg-white p-4 text-sm text-rose-800">{error}</p>}{!companies.length && !error && <p className="p-8 text-sm">No active enterprise license or account access is available. Contact your administrator.</p>}{access && <div className="mx-auto grid max-w-7xl gap-5 p-4 lg:grid-cols-[220px_minmax(0,1fr)] lg:p-6"><nav aria-label="Authorized modules" className="flex gap-2 overflow-auto lg:flex-col">{access.modules.map((m: any) => <button key={m.id} onClick={() => setTab(m.id)} className={'whitespace-nowrap rounded-lg px-3 py-2.5 text-left text-sm ' + (tab === m.id ? 'bg-blue-700 font-bold text-white' : 'border bg-white')}>{m.name}</button>)}{access.canManageUsers && <button onClick={() => setTab('users')} className={'whitespace-nowrap rounded-lg px-3 py-2.5 text-left text-sm ' + (tab === 'users' ? 'bg-blue-700 font-bold text-white' : 'border bg-white')}>User & Access Management</button>}</nav><main className="min-w-0 rounded-xl border bg-white p-4 sm:p-5">{tab === 'users' && access.canManageUsers ? <><UserAccessManagement key={tenantId} tenantId={tenantId}/>{renderLegacyTools && <details className="mt-5 rounded border p-3"><summary className="cursor-pointer text-sm font-bold">Preserve / Import Historical ERP Data</summary>{renderLegacyTools(tenantId)}</details>}</> : tab === 'operations' ? <SiteProgressWorkspace key={tenantId} tenantId={tenantId} currentUid={user.uid}/> : access.modules.find((m: any) => m.id === tab) ? <ModuleRecords key={tenantId + tab} tenantId={tenantId} module={access.modules.find((m: any) => m.id === tab)}/> : <p className="text-sm text-slate-500">No modules are assigned. Contact your Enterprise Super Admin.</p>}</main>{renderSupport && <div className="lg:col-start-2">{renderSupport(tenantId)}</div>}</div>}</div>;
};

import React, { useState } from 'react';
import { call } from '../../lib/api';
import {
  KeyRound,
  Eye,
  EyeOff,
  Check,
  Circle,
  AlertTriangle,
  ArrowRight,
  ShieldCheck,
} from 'lucide-react';

interface PasswordChangeProps {
  reload: () => void;
}

export const ModernPasswordChange: React.FC<PasswordChangeProps> = ({ reload }) => {
  const [password, setPassword] = useState('Nirman@2026Secure');
  const [confirm, setConfirm] = useState('Nirman@2026Secure');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  // Live Password Checklist validations
  const isLengthValid = password.length >= 12 && password.length <= 128;
  const hasUpperAndLower = /[a-z]/.test(password) && /[A-Z]/.test(password);
  const hasNumber = /[0-9]/.test(password);
  const isDifferentFromTemp = password.trim() !== 'Sharma@2026Secure'; // sample check
  const passwordsMatch = password.length > 0 && password === confirm;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password !== confirm) {
      setError('Passwords do not match.');
      return;
    }
    if (!isLengthValid || !hasUpperAndLower || !hasNumber) {
      setError('Please satisfy all password complexity requirements.');
      return;
    }
    setBusy(true);
    setError('');
    try {
      await call('completeEnterprisePasswordChange', { newPassword: password });
      setPassword('');
      setConfirm('');
      reload();
    } catch (err: any) {
      setError(err.message || 'Unable to update password. Please try again.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] flex flex-col justify-between font-['Plus_Jakarta_Sans',sans-serif] text-slate-900 select-none">
      
      {/* Top Minimalist Header */}
      <header className="w-full h-16 border-b border-[#E2E8F0] bg-white px-6 sm:px-10 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-[#2563EB] flex items-center justify-center font-extrabold text-white text-base shadow-sm">
            NK
          </div>
          <div className="flex items-center gap-2">
            <span className="font-bold text-sm text-[#0F172A] tracking-tight">NirmanKhata ERP</span>
            <span className="text-slate-300">/</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded bg-slate-100 text-slate-600">Enterprise Security</span>
          </div>
        </div>

        <div className="hidden sm:flex items-center gap-4 text-xs">
          <span className="text-slate-500">Workspace: <strong className="text-slate-700 font-semibold">Sharma Civil Contractors</strong></span>
          <span className="text-slate-300">|</span>
          <span className="text-slate-400">Step 2 of 2: First-Login Verification</span>
        </div>
      </header>

      {/* Main Centered Content Area */}
      <main className="flex-1 flex items-center justify-center p-4 sm:p-6 relative">
        
        {/* Soft Ambient Glow */}
        <div className="absolute w-[450px] h-[450px] bg-blue-100/60 rounded-full blur-3xl pointer-events-none" />

        {/* Single Centered White Security Card (480px wide) */}
        <div className="w-full max-w-[480px] bg-[#FFFFFF] rounded-2xl border border-[#E2E8F0] shadow-xl shadow-slate-200/60 p-7 sm:p-9 relative z-10">
          
          {/* Top Logo Badge and Lock-Key Icon */}
          <div className="flex items-center justify-between mb-5">
            <div className="w-11 h-11 rounded-xl bg-[#2563EB] flex items-center justify-center text-white font-extrabold text-base shadow-md shadow-blue-500/20">
              NK
            </div>
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-[#F59E0B]">
              <KeyRound className="w-5 h-5" />
            </div>
          </div>

          {/* Title & Subtitle */}
          <div className="mb-5 text-left">
            <h2 className="text-2xl font-bold text-[#0F172A] tracking-tight">Change Temporary Password</h2>
            <p className="text-slate-500 text-xs sm:text-sm mt-1">Set your permanent enterprise password to activate access.</p>
          </div>

          {/* Amber Info Banner */}
          <div className="mb-5 p-3.5 bg-amber-50 border border-amber-200/80 rounded-xl flex items-start gap-2.5">
            <AlertTriangle className="w-4 h-4 text-[#F59E0B] shrink-0 mt-0.5" />
            <p className="text-xs text-amber-900 leading-relaxed font-medium">
              For your account security, you must set a permanent password before accessing enterprise records.
            </p>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            
            {/* Input 1: New Password */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                New Password <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <input
                  required
                  autoComplete="new-password"
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter permanent password"
                  className="w-full pl-3.5 pr-10 py-2.5 bg-white border border-[#CBD5E1] rounded-xl text-sm font-medium text-[#0F172A] tracking-wider shadow-sm focus:outline-none focus:ring-2 focus:ring-[#2563EB] focus:border-[#2563EB] transition-all"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-slate-600 transition-colors"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Input 2: Confirm Password */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                Confirm Password <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <input
                  required
                  autoComplete="new-password"
                  type={showConfirm ? 'text' : 'password'}
                  value={confirm}
                  onChange={(e) => setConfirm(e.target.value)}
                  placeholder="Re-type permanent password"
                  className="w-full pl-3.5 pr-10 py-2.5 bg-white border border-[#CBD5E1] rounded-xl text-sm font-medium text-[#0F172A] tracking-wider shadow-sm focus:outline-none focus:ring-2 focus:ring-[#2563EB] focus:border-[#2563EB] transition-all"
                />
                <button
                  type="button"
                  onClick={() => setShowConfirm(!showConfirm)}
                  className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-slate-600 transition-colors"
                >
                  {showConfirm ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Live Password Strength Checklist Box */}
            <div className="p-3.5 bg-slate-50 border border-[#E2E8F0] rounded-xl">
              <div className="text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-2.5">
                Password Policy Requirements
              </div>
              <ul className="space-y-2 text-xs">
                {/* 1: 12-128 characters long */}
                <li className={`flex items-center gap-2 font-medium ${isLengthValid ? 'text-slate-800' : 'text-slate-500'}`}>
                  {isLengthValid ? (
                    <div className="w-4 h-4 rounded-full bg-emerald-100 flex items-center justify-center shrink-0">
                      <Check className="w-2.5 h-2.5 text-[#10B981] stroke-[3]" />
                    </div>
                  ) : (
                    <div className="w-4 h-4 rounded-full bg-slate-200 flex items-center justify-center shrink-0">
                      <Circle className="w-1.5 h-1.5 fill-slate-500 text-slate-500" />
                    </div>
                  )}
                  <span>12–128 characters long</span>
                </li>

                {/* 2: Uppercase & lowercase */}
                <li className={`flex items-center gap-2 font-medium ${hasUpperAndLower ? 'text-slate-800' : 'text-slate-500'}`}>
                  {hasUpperAndLower ? (
                    <div className="w-4 h-4 rounded-full bg-emerald-100 flex items-center justify-center shrink-0">
                      <Check className="w-2.5 h-2.5 text-[#10B981] stroke-[3]" />
                    </div>
                  ) : (
                    <div className="w-4 h-4 rounded-full bg-slate-200 flex items-center justify-center shrink-0">
                      <Circle className="w-1.5 h-1.5 fill-slate-500 text-slate-500" />
                    </div>
                  )}
                  <span>Contains uppercase & lowercase letters</span>
                </li>

                {/* 3: At least one number */}
                <li className={`flex items-center gap-2 font-medium ${hasNumber ? 'text-slate-800' : 'text-slate-500'}`}>
                  {hasNumber ? (
                    <div className="w-4 h-4 rounded-full bg-emerald-100 flex items-center justify-center shrink-0">
                      <Check className="w-2.5 h-2.5 text-[#10B981] stroke-[3]" />
                    </div>
                  ) : (
                    <div className="w-4 h-4 rounded-full bg-slate-200 flex items-center justify-center shrink-0">
                      <Circle className="w-1.5 h-1.5 fill-slate-500 text-slate-500" />
                    </div>
                  )}
                  <span>Contains at least one number</span>
                </li>

                {/* 4: Different from temporary password */}
                <li className={`flex items-center gap-2 font-medium ${isDifferentFromTemp ? 'text-slate-800' : 'text-slate-500'}`}>
                  {isDifferentFromTemp ? (
                    <div className="w-4 h-4 rounded-full bg-emerald-100 flex items-center justify-center shrink-0">
                      <Check className="w-2.5 h-2.5 text-[#10B981] stroke-[3]" />
                    </div>
                  ) : (
                    <div className="w-4 h-4 rounded-full bg-slate-200 flex items-center justify-center shrink-0">
                      <Circle className="w-1.5 h-1.5 fill-slate-500 text-slate-500" />
                    </div>
                  )}
                  <span>Different from your temporary password</span>
                </li>
              </ul>
            </div>

            {error && (
              <div role="alert" className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-medium">
                {error}
              </div>
            )}

            {/* Full-width primary indigo button */}
            <div className="pt-2">
              <button
                type="submit"
                disabled={busy || !passwordsMatch || !isLengthValid}
                className="w-full py-3 px-4 bg-[#2563EB] hover:bg-blue-700 active:bg-blue-800 disabled:opacity-50 text-white font-semibold text-sm rounded-xl shadow-lg shadow-blue-500/25 flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <span>{busy ? 'Saving New Password...' : 'Save Password & Sign In Again'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </form>

        </div>

      </main>

      {/* Bottom Security Footer */}
      <footer className="w-full h-12 border-t border-[#E2E8F0] bg-white px-6 sm:px-10 flex items-center justify-between text-xs text-slate-500">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-3.5 h-3.5 text-[#10B981]" />
          <span>Secured with Salted Scrypt Cryptographic Storage</span>
        </div>
        <div className="text-slate-400">
          NirmanKhata ERP • Enterprise Security System
        </div>
      </footer>

    </div>
  );
};

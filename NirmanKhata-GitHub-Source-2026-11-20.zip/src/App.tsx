import {isRetiredTab} from './lib/retiredModules.mjs';
/**
 * @license
 * NirmanKhata ERP - Complete Contractor Management & Real-Time Profit Tracking Software
 */

import React, { useState, useEffect } from 'react';
import { ContractorProvider, useContractor } from './context/ContractorContext';
import { Navbar } from './components/common/Navbar';
import { Sidebar } from './components/common/Sidebar';
const DailyDprView=React.lazy(()=>import('./components/views/DailyDprView').then(module=>({default:module.DailyDprView})));
const SiteDeskView=React.lazy(()=>import('./components/views/SiteDeskView').then(module=>({default:module.SiteDeskView})));
const DashboardView=React.lazy(()=>import('./components/views/DashboardView').then(module=>({default:module.DashboardView})));
const ProjectsView=React.lazy(()=>import('./components/views/ProjectsView').then(module=>({default:module.ProjectsView})));
const ProjectDetailView=React.lazy(()=>import('./components/views/ProjectDetailView').then(module=>({default:module.ProjectDetailView})));
const PurchasesView=React.lazy(()=>import('./components/views/PurchasesView').then(module=>({default:module.PurchasesView})));
const SuppliersView=React.lazy(()=>import('./components/views/SuppliersView').then(module=>({default:module.SuppliersView})));
const DailyExpensesView=React.lazy(()=>import('./components/views/DailyExpensesView').then(module=>({default:module.DailyExpensesView})));
const WorkersView=React.lazy(()=>import('./components/views/WorkersView').then(module=>({default:module.WorkersView})));
const FinancialReportsView=React.lazy(()=>import('./components/views/FinancialReportsView').then(module=>({default:module.FinancialReportsView})));
const InventoryView=React.lazy(()=>import('./components/views/InventoryView').then(module=>({default:module.InventoryView})));
const NotificationsView=React.lazy(()=>import('./components/views/NotificationsView').then(module=>({default:module.NotificationsView})));
const TeamPermissionsView=React.lazy(()=>import('./components/views/TeamPermissionsView').then(module=>({default:module.TeamPermissionsView})));
const BusinessSettingsView=React.lazy(()=>import('./components/views/BusinessSettingsView').then(module=>({default:module.BusinessSettingsView})));
const DailySiteRegisterView=React.lazy(()=>import('./components/views/DailySiteRegisterView').then(module=>({default:module.DailySiteRegisterView})));
const CreateEditProjectModal=React.lazy(()=>import('./components/views/CreateEditProjectModal').then(module=>({default:module.CreateEditProjectModal})));
import { HostingerApp } from './components/auth/HostingerApp';

const AppContent: React.FC = () => {
  const {allowedTabs:configuredTabs,currentUser}=useContractor();
  const allowedTabs=configuredTabs?.filter(tab=>!isRetiredTab(tab));
  const [currentTab, setTab] = useState<string>(currentUser.role==='site_supervisor'&&allowedTabs?.includes('work-progress')?'work-progress':allowedTabs?.includes('site-desk')?'site-desk':allowedTabs?.includes('dashboard')?'dashboard':allowedTabs?.includes('work-progress')?'work-progress':allowedTabs?.[0]||'dashboard');
  const setCurrentTab=(tab:string)=>{if(isRetiredTab(tab))return;if(!allowedTabs||allowedTabs.includes(tab)||tab==='project-detail'&&allowedTabs.includes('projects'))setTab(tab)};
  useEffect(()=>{if(allowedTabs&&!allowedTabs.includes(currentTab)&&!(currentTab==='project-detail'&&allowedTabs.includes('projects')))setTab(allowedTabs.includes('work-progress')?'work-progress':allowedTabs[0]||'no-access')},[JSON.stringify(allowedTabs),currentTab]);
  const [selectedProjectId, setSelectedProjectId] = useState<string>('');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [showCreateProjectModal, setShowCreateProjectModal] = useState(false);

  const handleSelectProject = (id: string) => {
    setSelectedProjectId(id);
    setCurrentTab('project-detail');
  };

  const handleQuickAction = (actionType: 'expense' | 'bill' | 'project') => {
    if (actionType === 'bill') {
      setCurrentTab('purchases');
    } else if (actionType === 'project') {
      setShowCreateProjectModal(true);
    } else if (actionType === 'expense') {
      setCurrentTab('expenses');


    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex">
      {/* Sidebar Navigation */}
      <Sidebar
        currentTab={currentTab}
        onNavigate={(tab) => {
          setCurrentTab(tab);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
      />

      {/* Main Body */}
      <div className="flex-1 flex flex-col min-w-0">
        <Navbar
          onToggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
          onOpenQuickAction={handleQuickAction}
          onNavigate={(tab) => setCurrentTab(tab)}
        />

        <main className="flex-1 p-4 md:p-6 lg:p-8 max-w-7xl w-full mx-auto">
          <React.Suspense fallback={<p className="py-6 text-sm text-slate-500">Loading workspace...</p>}>
          {currentTab==='work-assignment'&&<DailyDprView mode="assignment"/>}
          {currentTab==='dpr-approvals'&&<DailyDprView mode="approvals"/>}
          {currentTab==='site-desk'&&<SiteDeskView onNavigate={setCurrentTab}/>}
          {currentTab==='no-access' && <p className="rounded border bg-white p-4 text-sm">No modules are assigned to this account. Contact your enterprise administrator.</p>}
          {currentTab === 'dashboard' && (
            <DashboardView
              onNavigate={(tab) => setCurrentTab(tab)}
              onSelectProject={handleSelectProject}
            />
          )}

          {currentTab === 'projects' && (
            <ProjectsView
              onSelectProject={handleSelectProject}
              onNavigate={(tab) => setCurrentTab(tab)}
              onOpenCreateProject={() => setShowCreateProjectModal(true)}
            />
          )}

          {currentTab === 'project-detail' && (
            <ProjectDetailView
              projectId={selectedProjectId}
              onBack={() => setCurrentTab('projects')}
              onNavigate={(tab) => setCurrentTab(tab)}
            />
          )}


          {currentTab === 'daily-site-register' && <DailySiteRegisterView />}

          {currentTab === 'work-progress' && <DailyDprView mode="daily"/>}

          {currentTab === 'purchases' && (
            <PurchasesView onNavigate={(tab) => setCurrentTab(tab)} />
          )}

          {currentTab === 'suppliers' && <SuppliersView />}

          {currentTab === 'expenses' && <DailyExpensesView />}

          {currentTab === 'workers' && <WorkersView />}


          {currentTab === 'reports' && <FinancialReportsView />}

          {currentTab === 'inventory' && <InventoryView />}

          {currentTab === 'alerts' && (
            <NotificationsView onNavigate={(tab) => setCurrentTab(tab)} />
          )}

          {currentTab === 'team' && <TeamPermissionsView />}

          {currentTab === 'settings' && <BusinessSettingsView />}

          </React.Suspense>
        </main>
      </div>

      {/* Quick Modals */}
      <React.Suspense fallback={null}>
      {showCreateProjectModal && <CreateEditProjectModal
        isOpen={showCreateProjectModal}
        onClose={() => setShowCreateProjectModal(false)}
        onCreated={(newId) => {
          setSelectedProjectId(newId);
          setCurrentTab('project-detail');
        }}
      />}

      </React.Suspense>
    </div>
  );
};

export default function App() {
  return <HostingerApp Content={AppContent}/>;
}

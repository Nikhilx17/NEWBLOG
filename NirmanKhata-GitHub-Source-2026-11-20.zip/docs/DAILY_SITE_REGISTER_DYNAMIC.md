# Dynamic Daily Site Register — implementation and verification

Implemented in the existing React/TypeScript/Express/MySQL ERP and running at http://localhost:3000/app. No hosting, authentication provider, financial workflow or inventory transaction system was replaced.

## Functionality

- Dynamic Material Consumption, Equipment & Machinery, Water & Utilities, Material Ledger, Labour Register and Site Work Progress sections.
- Add/remove any number of rows within the existing API payload limit; names and units are free text, with server-backed autocomplete.
- Custom named sections and reusable custom entry names.
- Prefix, partial-word, case-insensitive suggestions, ranked exact/prefix first. Keyboard arrows/Enter, pointer/tap selection and an explicit create option. Searches debounce by 120 ms and query the database; no hardcoded master-name arrays are used in the entry UI.
- New reusable names are created only during a successful validated save. Normalization uses NFKC, collapsed whitespace and lowercase; duplicate capitalization/spacing does not create separate masters within a project/type.
- Existing inventory names are suggested only if the user's existing inventory read permission allows them. Selecting one can prefill its unit. Saving the daily register does not change inventory stock or financial transactions.
- Equipment duration is computed from start/end, including overnight shifts. Optional meter readings and remarks persist.
- Material ledger balances accumulate by normalized material AND unit, recomputing after earlier edits; unrelated units are never added.
- Inline field errors, saving status, version conflict protection, stable retry request IDs and a synchronous double-click guard. Failed saves retain entered values. Date/project changes warn before discarding unsaved work; a cancelled date switch restores the displayed date.
- Saved date-wise material/utility/custom register plus equipment, labour, ledger and work-history tables. Historical dates reopen for editing. Entry tabs reduce scrolling; Expand all is functional. Phone entry rows adapt to compact cards; report tables scroll within their containers.

## Database and permissions

The existing erp_records table remains authoritative. Each project/date has one deterministic dailySiteRegister record, now with schemaVersion=2 and typed arrays for every section. Reusable master records use kind=dailyRegisterMaster with type material, equipment, labour, unit, workCategory, customCategory or customItem. Unique record IDs derive from project/type/normalized name under the existing enterprise key, with existing tenant/project foreign keys and indexes. No new schema migration or destructive conversion was needed. Records and masters participate in the existing request transaction, audit, idempotency and backup mechanisms.

Master suggestions are scoped to the company and assigned project. Unrelated projects and companies do not share private entries. Existing project read/edit grants are reused; assigned supervisors with the existing siteProgress.submit grant can read/write the register without requesting an administrator to add names. License/module checks still run. This adds no new authentication or role system.

Old fixed records are converted on read into dynamic rows without modifying stored originals. The old names exist only in the backward-compatibility adapter. Editing with the new form upgrades the saved row; all old quantities, water counts, equipment times, cement movements and labour counts are mapped. A stale older application cannot replace an already dynamic record with fixed fields. The pre-change enterprise data/files were backed up with the existing encrypted backup mechanism.

## Validation performed

- TypeScript check and production build: passed.
- Full automated suite: 44 passed, 0 failed, including 8 new dynamic register tests and the preserved legacy tests.
- Real local MySQL/HTTP checks in clearly labelled isolated QA enterprises: all six sections/custom rows, retry deduplication, Tanker -> Tan after fresh login, case/spacing normalization, new-name persistence, mixed-unit balances, backdated corrections, invalid/stale save rollback, every master type, tenant/project isolation, inventory suggestion permissions, and historical conversion passed.
- Another assigned supervisor successfully saved existing and new names. A different authorized account retrieved them after application restart. The user's original company/login was not replaced.
- Legacy-client overwrite protection passed against real SQL; existing dynamic rows remained unchanged after a rejected fixed-field request.
- Actual browser checks: arrow/Enter selection, pointer selection, create-new option, add/remove rows, inline required fields, save success, a real concurrent-edit failure retaining all form values, explicit reload/discard, saved history reopening, and responsive layouts.
- Phone width 390: document width 385; tablet width 768: document width 768. Horizontal register tables scroll inside their containers.
- Screenshots under .runtime/dynamic-register/desktop.jpg and phone.jpg contain synthetic QA data from the real backend, not generated mockups. The QA browser used a loopback-only proxy so its login did not replace the owner's localhost session.

## Changed files

- Modified `src/lib/api.ts`
- Modified `src/components/views/DailySiteRegisterView.tsx`
- Modified `server/app.mjs`
- Modified `server/core.mjs`
- Modified `server/daily-site-register.mjs`
- Added `src/components/common/RegisterAutocomplete.tsx`
- Added `src/lib/dynamicSiteRegister.mjs`
- Added `tests/dynamic-site-register.test.mjs`
- Updated `tests/daily-site-register.test.mjs`: SQL test adapter accepts the compatibility-check projection.
- Added this implementation report.

All other existing source files were compared against their pre-change SHA-256 values and remained unchanged. No npm dependency, hosting setting, customer password or existing financial/inventory/work-allocation record was changed. Site Work Progress entries here remain notes and quantities in this register; the separate approved allocation/report workflow remains intact.

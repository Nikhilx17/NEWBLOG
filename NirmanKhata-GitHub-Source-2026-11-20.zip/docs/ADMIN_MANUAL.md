# NirmanKhata platform owner guide

## Access

The platform dashboard is available at `/admin` or on the `admin.` hostname after deployment. Sign in with a Firebase Auth account whose UID is explicitly listed in the server-only `PLATFORM_ADMIN_UIDS` environment setting. A company owner/admin role does not grant platform access.

The dashboard shows company counts, active memberships, trials, paid/pending order counts, company plan/status metadata and configured plan records. It can activate/suspend a company and configure plan amount (in paise), seat limit, billing period and module keys. Plan configuration defaults to inactive. The dashboard intentionally does not expose customer financial records.

Support tickets are available in the platform inbox. MRR/ARR, detailed storage use and system health are not implemented. MRR displays “Not aggregated”; do not use the current dashboard as a revenue report.

## Company setup

Customers create their own verified account and company through `/register`. The Functions service creates a 14-day trial, owner membership and two system roles. Company owners/admins can manage members and custom roles in the authenticated company area while the ERP data screens remain under development. Invitation links currently need to be delivered by copying the link; no email-sending integration is active.

## Data imports

An authenticated owner can review local browser records or select a previously downloaded NirmanKhata JSON export. Check sample identifiers and relationship warnings carefully. Download a backup before import. Confirm the record counts and totals against source records; the displayed totals are only a review aid. The importer does not delete the original browser data and does not create employee login accounts from legacy team profiles.

Imported legacy audit entries are marked as migration data; they are not proof that the new server observed those actions. If a migration reports a changed source row or an ID collision, investigate the target and original backups before retrying.

## Access recovery and incidents

Use Firebase Auth’s password reset process for an account holder. Deactivating a company member marks membership inactive, updates the user’s company index and revokes refresh tokens; protected Firestore reads and Functions calls also check membership status. Keep an independent record of the platform-admin UID allowlist and Firebase recovery procedures. No customer financial record access is provided to the platform dashboard.

# NirmanKhata SaaS implementation notes

## Architecture decision

The first implementation keeps Firebase Authentication, the existing named Cloud Firestore database, Firebase Cloud Functions and Firebase Storage. This avoids replacing the existing client SDK and lets the project add server-trusted operations without rewriting the React application. The Functions service explicitly connects to the named Firestore database configured by the existing app.

Firestore is a document store, not a relational accounting ledger. The implementation therefore uses tenant-scoped collections and stable record IDs; it does not claim database-enforced foreign keys, general ledger integrity or efficient arbitrary cross-module SQL reporting. Current financial calculations remain in `src/lib/calculations.ts` and the ERP still runs on browser storage in development. A future full accounting ledger, large multi-period reporting workload, or cross-company consolidation may justify a PostgreSQL service. That would be a separately versioned migration with data reconciliation; it is not silently introduced here.

### Current service boundaries

| Area | Current implementation | Remaining work |
|---|---|---|
| Identity | Firebase email/password signup/sign-in, password reset and email verification UI; company team UI for invitations, role assignment and deactivation | Invitation email delivery, sign-in revocation/recovery UI and live provider verification |
| Tenant setup | `createCompany` creates a company, owner membership, system roles and trial record | Company profile editor, legal verification and onboarding recovery/notifications |
| Tenant authorization | Membership lookup in Functions; tenant-aware Firestore Rules; roles are read from server-owned role documents; role-specific team management endpoints | Emulator adversarial tests and enforcement across every ERP API and every query |
| ERP data | Migration importer; limited callable sync for selected operational collections; trusted create/read, document access and verification for new purchase invoices | Connect all remaining screens to tenant cloud storage; trusted financial commands for payment/approval, realtime/conflict handling and offline queue |
| Documents | Private bucket, short-lived upload/download URLs and upload metadata verification | Malware scanning, retention/legal hold, usage metering, document preview component and production bucket validation |
| Purchase invoices | Manual entry and private PDF/JPG/PNG upload, tenant-linked metadata, temporary signed viewing/download links and audited verification | The existing ERP still needs tenant-cloud integration for records created outside this focused purchase workflow; malware scanning and retention/legal hold |
| Payments | Server-created Razorpay order; HMAC-verified webhook; duplicate event ID handling | Checkout frontend, recurring subscription API, renewal/retry jobs, refunds, taxes, reconciliation and sandbox tests |
| Platform operations | Private UID allowlist, company status and plan metadata operations, demo request management, customer support inbox | System health, usage aggregation, MRR/ARR ledger, announcement controls and account recovery |
| Public website | Marketing, feature, industry, configured public pricing and account routes; demo request form | Final legal policies, SEO/analytics review and commercial copy approval |

## Proposed Firestore document layout

All operational documents belong beneath `tenants/{tenantId}`. `tenantId` is assigned by trusted code and is written into both `tenantId` and the legacy-compatible `businessId` field. The membership relationship allows one Auth UID to have several tenant memberships.

```text
tenants/{tenantId}
  profile, settings, subscription, status
  members/{authUid}
  roles/{roleId}
  invitations/{inviteId}
  projects/{id}
  suppliers/{id}
  clients/{id}
  purchaseBills/{id}
  invoices/{id}
  expenses/{id}
  workers/{id}
  attendance/{id}
  advances/{id}
  salaries/{id}
  subcontractors/{id}
  subcontractBills/{id}
  accounts/{id}
  transactions/{id}
  inventory/{id}
  stockMovements/{id}
  boq/{id}, requisitions/{id}, siteReports/{id}, siteTasks/{id}, equipment/{id}
  documents/{id}
  auditEvents/{id}
  migrationBatches/{id}, legacyImports/{sourceHash}

users/{authUid}/memberships/{tenantId}
users/{authUid}/companyCreations/{requestId}
platform/plans/{planId}
platform/auditEvents/{id}
platform/webhookEvents/events/{providerEventId}
platformTickets/{ticketId}
```

`projects.clientId`, bill supplier/project IDs, invoice client/project IDs, worker attendance/advance/salary references, inventory movement item IDs and account transaction references preserve existing link IDs. Firestore cannot provide relational foreign keys; the import report checks known local references before sending. The import preserves broken references with a warning so history is not silently discarded. Database-side integrity constraints remain a known limitation compared with PostgreSQL. Public pricing reads only platform-admin-activated plan names, prices, limits and module names through a callable function; it does not enable checkout.

The canonical ERP types remain in `src/types/index.ts`. Relevant source relationships and browser storage keys are enumerated in [Phase 2](../README.md#legacy-data-import). Reports and `ProjectProfitSummary` are calculated outputs, not imported source tables.

## Permission design

Permission keys are declared in `functions/src/index.ts` and stored on server-controlled role documents. Company membership contains only the user UID, active/deactivated status and role ID. Firestore Rules resolve that role’s current permission list for every read. This makes role edits effective without copying stale permissions into every membership.

The company owner is the only role that can use the legacy migration permission. Company admins manage invitations and custom roles but cannot grant `data.migrate`. The platform administrator is a separate server allowlist and is not a tenant role. Suspending a company blocks Functions writes; company members retain no direct database write path. Expired trial/write entitlement checks are enforced in Functions, while existing records remain readable.

Sensitive financial posting, payroll, payments, document metadata and audit events are intentionally excluded from generic collection sync. They need specific trusted operations which validate accounting rules, update related balances atomically, and append audit events. Until those operations exist, the web ERP route does not load old unscoped local records for an authenticated company.

## Migration behavior

The browser migration utility knows these current local keys:

- `nirmankhata_data_store_v1_{user,team,business,projects,suppliers,clients,bills,expenses,workers,attendance,advances,salaries,subs,subbills,invoices,accounts,transactions,inventory,stockMovements,alerts,audit}`
- `nirmankhata_operations_v1_{businessId}` with BOQ, requisitions, site reports/tasks, equipment and statement rows.

The owner reviews data counts, amount totals, source IDs, sample-data warning and missing relationships before confirming. The utility can download a JSON backup first or accept a prior export file. Base64 file attachments are uploaded to tenant-private object paths; the imported record points to a `storage://` object reference. LocalStorage is never cleared by the utility.

The server limits import calls to 200 records and each record to 50 KB. Imports write a batch record and a source-hash marker for each imported row. Repeating an identical source row skips it; a changed source row or an existing target ID produces a conflict for review rather than overwriting the destination. The source business ID is retained in migration metadata while the operational tenant ID is remapped to the newly created company.

No deployed Firebase database or real browser profile was inspected. Production data status remains unknown until authorized inventory. This repository cannot prove the absence of live records.

## Security and operations release gates

Before production:

1. Use a separate staging Firebase project and test the named database and bucket IDs.
2. Configure App Check and test valid/invalid tokens for all callable functions.
3. Run Rules Emulator tests for anonymous access, tenant A to tenant B, manipulated tenant IDs, missing/inactive memberships, roles, payroll, audit and document access.
4. Add functions tests for duplicate company requests, invitation expiry/email mismatch, seat limits, migration retries/conflicts, file upload mismatch/oversize, payment signature failures and repeated webhooks.
5. Add cloud persistence for every ERP module and confirm permission behavior against the actual UI before enabling customer access.
6. Add financial command endpoints and reconcile them with the unchanged calculations in `src/lib/calculations.ts`.
7. Configure backup/restore, retention, monitoring, secrets, billing alerts and incident response.
8. Review Indian tax, privacy, terms and refund language with the business owner before publishing.
9. Run a staging pilot and reconcile record counts, relationships and historical financial totals before any production import.

No current implementation has been deployed to Firebase. No production data has been changed.

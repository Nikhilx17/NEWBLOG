# Hostinger deployment and recovery

## Verified target and architecture

Dedicated free staging website: `wishful-khaki-sheep-70.hostingersite.com`, hosting account `u846738908`, existing order `1010254165`, plan identifier `hostinger_unlimited_v6`. This is managed Node.js hosting, not an assumed VPS. Node.js 24, Express, npm, `npm run build`, entry `server.cjs`, root `.`, output `.` were verified by real deployment. `server.cjs` listens before loading application modules or opening MySQL connections. No Docker, Redis, inbound WebSockets, external authentication service or paid database is required by this deployment.

The other account websites were inspected read-only. Neither their content nor environment was changed.

MySQL database and database user: `u846738908_erpstage`. Credentials are protected hosting variables; API responses never return them. The connection pool uses five connections, UTC and bounded connection timeouts. Hostinger's automatically supplied DATABASE_URL is normalized from localhost to 127.0.0.1. Do not replace the full environment with a partial list: it would remove database credentials.

All production business writes go to this MySQL database. `erp_records` retains legacy ERP payload shapes with tenant/kind/id keys, project foreign keys, revision checks and archival, while users/roles/projects/work/report/approval/file records have dedicated relational tables. Categories and optional subcategories are stored as reusable category data; subcategories are not a separate SQL table. This adapts the existing UI models rather than rebuilding the ERP.

Private originals, previews and encrypted backups live under `/home/u846738908/domains/wishful-khaki-sheep-70.hostingersite.com/erp-data`. This is outside public_html and versioned application builds. Originals are immutable on normal upload, hashed, server-validated and accessible only through authenticated tenant/project-scoped API routes. Preview WebP files are separate from secure originals. Redeployment and restart persistence are tested using original-byte SHA-256 comparisons.

## Authorization

Platform Owner manages enterprise provisioning and licenses, with no automatic customer operational membership. Admin: Editor is the enterprise Super Admin and sole employee/role administrator. Employee templates are Purchase Manager, Accounts, Project Manager, Admin: Reviewer and Site Supervisor; custom roles and individual overrides are persisted in MySQL. Project assignments are required on protected project operations. Site management/review/reporting follow explicit grants. Accounts payment permissions are separate from review/approval permissions. Licensing/module checks also run on the server.

Passwords use per-user salted scrypt. Cookie sessions are HttpOnly, Secure and SameSite Strict in production. Password changes/resets rotate session versions; deactivation revokes existing sessions. Temporary password change is required before business access. Login buckets are stored in MySQL. Same-origin mutations require the custom request header and an allowed Origin. No credentials, upload tickets or password hashes are included in browser state or logs.

## Migrations and rollback

`server/migrations/001_hostinger.sql` adds ERP tables with IF NOT EXISTS, composite tenant foreign keys and indexes. `002_finance_permissions.sql` adds payment capabilities only to the built-in Accounts role, preserving custom roles and individual overrides. `schema_migrations` and a MySQL advisory lock make startup migration repeatable. There is no destructive down migration and no table drop.

A source/configuration backup was taken before implementation at `backups/pre-hostinger-20261119.zip`. Staging SQL and actual originals were backed up and the encrypted archive decoded before subsequent deployment. Source rollback: redeploy a retained known-good archive using the same dedicated domain, Node and entry settings; leave MySQL and ERP_DATA_DIR intact. Migration rollback: prefer the previous compatible application release. For a database rollback, restore into a new empty database and separate private directory first, verify it, then switch only the ERP server variables; keep the old database unchanged. Never drop customer records to roll back a test.

## Backup and retention

An enterprise Admin: Editor can download an encrypted database-plus-originals archive from Business Profile or User & Access Management. Files use gzip plus AES-256-GCM, authenticated on decode. Backups include archived historical rows and uploaded originals/previews. They exclude live sessions and platform credentials. The server triggers one automatic backup per enterprise per 24 hours on mutation activity and retains seven automatic snapshots. This requires no background worker or cron service. Manual snapshots are retained until an administrator's deliberate retention action; active submitted photos and documents are never pruned by abandoned-upload cleanup.

These snapshots protect redeployments and logical recovery but remain on the same Hostinger account. Keep downloaded copies plus the encryption key off the hosting account. A scheduled off-account copy, quota alerts, automatic restore drills and Hostinger account-level disaster recovery are not verified or provisioned. No paid backup service was purchased. The daily activity policy does not promise a continuously running offsite backup service.

Recovery command for a technician, using a NEW database/private directory and the same protected ERP_BACKUP_KEY:

```text
ERP_RESTORE_EMPTY_DATABASE=YES node --env-file=.env.restore server/restore-cli.mjs /secure/enterprise.erpbak
```

The CLI initializes additive schema without bootstrapping a platform user and refuses a database containing enterprise records. It decrypts and authenticates the archive before inserting. Keep the original archive and original database; a failed recovery attempt should be retried in another fresh recovery directory/database. Local encrypted roundtrip/tamper checks and actual staging archive decode pass; an end-to-end SQL restore into a separate Hostinger recovery database has not yet been verified.

## Deployment process

Package source, package/lock, index.html, TypeScript/Vite settings, server.cjs and server/. Exclude node_modules, dist, functions output, .env files, .runtime, uploaded originals, backups and credentials. Validate UTF-8 for every source file. Upload with authenticated TUS, verify offset, detect settings, then start one build at a time. Wait for a completed publication before uploading another archive: publication synchronizes public_html and can remove an archive uploaded during an earlier build. Inspect build/runtime logs, /healthz, /readyz, login, MySQL records and original hashes after publication. A successful local build alone is not deployment evidence.

## Limits and remaining verification

Actual Node.js/MySQL/private storage capability is verified on the existing plan. Exact CPU, memory, process and disk quotas were not exposed by the connected non-Agency API. Long-term storage capacity, a high-concurrency load test, account suspension recovery and off-account disaster recovery are unverified. The existing plan works for the tested workload; this is not a capacity guarantee for unlimited companies or daily photos.

Customer historical Firebase/browser records need an explicit reviewed export or authenticated source access. Legacy Firebase marketing, support, payment/AI-extraction source remains retained and is not certified against this native server. The current native production entry is the authenticated ERP. No claim is made that every historical external integration is deployed or that a customer's historical dataset has already been imported.

# Construction workflow correction — implementation and verification

Implemented on 19 November 2026. Source changes are local; this work did not deploy Firebase functions or modify production customer data.

## Changed source files

- `src/components/views/OperationsHubView.tsx`: replaces the old browser reporting write interface with authenticated construction operations; retains read-only historical reports, their original IndexedDB photos and equipment features.
- `src/components/auth/ConstructionOperationsGate.tsx`: embeds the cloud workspace in the existing ERP shell; obtains company choices from authenticated membership, never the demo role selector.
- `src/components/auth/SiteProgressWorkspace.tsx`: project CRUD, category management, allocation, project access controls, role-specific reporting/monitoring, supervisor filtering, quantity totals by unit, retry-stable submissions, 15-second visible-page refresh, complete work history and existing full-size private-photo gallery.
- `src/components/auth/SaaSAccess.tsx`: construction workspace naming; hides company team controls from site users and migration controls from nonowners.
- `functions/src/index.ts`: hardens existing callable APIs; adds project management, work history and migration endpoints; prevents cross-project allocation moves, changes of unit/category after reporting, false completion, invalid subcategories, duplicate daily records, changed retry payloads and excessive approvals. Corrects approved-zero recalculation and keeps archived history visible.
- `functions/src/migrations/constructionV2.ts`: additive tenant migration.
- `tests/construction-workflow.test.mjs`: tests production callable handlers through isolated Firestore/Auth/Storage test doubles.
- `package.json`: rebuilds backend before running tests so tests cannot silently execute stale compiled code.
- `docs/CONSTRUCTION_WORKFLOW.md`: this implementation and verification record.

Generated outputs: `functions/lib/index.js`, `functions/lib/migrations/constructionV2.js` and production `dist/` assets.

## Existing database and additive migration

The repository uses Firestore, not a relational database. Existing tenant roots and collection names are preserved. No tables are dropped or recreated; no production migration was run.

| Concept | Existing/extended Firestore path under `tenants/{tenantId}` |
|---|---|
| Enterprise | tenant root document |
| Enterprise users | `members/{uid}` and `roles/{roleId}` |
| Project/site | `projects/{projectId}` |
| Project access | member `siteProgressAccess.projectIds`, category IDs and permission level |
| Reusable categories/subcategories | `siteProgressCategories/{categoryId}`, embedded `subcategories` |
| Category uniqueness | `siteProgressCategoryNames/{nameHash}` |
| Allocations | `siteProgressWorkItems/{workItemId}` |
| Daily reports | `siteProgressReports/{reportId}` |
| Daily duplicate protection | `siteProgressSubmissionKeys/{hash(uid, workItemId, workDate)}` |
| Photos | `siteProgressPhotos/{photoId}` plus private Storage objects |
| Approval history | `siteProgressReportHistory/{eventId}` |
| Audit | `auditEvents/{eventId}` |
| Migration marker | `schemaMigrations/construction_v2` |

Run the administrator-only `initializeConstructionWorkflow({tenantId})` callable, exposed as **Initialize construction roles** under project management. It transactionally adds missing `site_manager` (read only) and `site_supervisor` (submit only) roles, then creates the migration marker. It preserves existing roles and reports and is safe to repeat. New report duplicate checks also inspect pre-migration reports; existing reports need no destructive backfill. Firestore creates the new collections on first write, so there is no SQL migration or foreign-key DDL. References are validated by server handlers. Existing deny-by-default Firestore and Storage rules keep progress records and original photos inaccessible through direct client writes/reads; callable handlers provide access.

Invite users through Company team after role initialization. Managers need both explicit role capabilities and assigned project access for review; allocation requires `siteProgress.allocate`, and assigning another user also requires `siteProgress.assign`. Reporting requires `siteProgress.submit` and assignment to the work item. Administrators cannot submit site reports. Category/access administration is restricted to owner/company_admin members of the selected tenant. No role implies membership of another tenant.

## Quantity and history behavior

Pending reports do not change approved totals. Review transactions replace a report's previously approved contribution rather than adding it again. A correction to zero remains zero; rejection removes its prior contribution. Target changes cannot reduce below approved totals. Unit/category changes after reporting require a new allocation, avoiding reinterpretation of historical quantities. Quantities support up to six decimal places and a maximum of one billion per allocation/report. An over-target submission is flagged and remains pending; approval must stay within the target. Repeated identical requests with the same report ID are idempotent. A second report ID for the same supervisor/work/date is rejected; a reviewer can correct the existing quantity with an audit trail.

Dashboard quantities are grouped by measurement unit; unrelated units are never added into a project percentage. Auto-approval is not enabled: all new reports require review.

Original JPG/PNG files use short-lived signed uploads, ownership validation, content signature/size/SHA-256 verification, and authenticated short-lived image access. Existing full-size next/previous viewing is retained. Preview requests currently use the original uploaded image, with lazy loading; resized image derivatives are not implemented.

## Verification results

- `npm test`: **10 passed, 0 failed**, including the existing financial calculation tests.
- `npm run lint`: TypeScript check passed.
- `npm --prefix functions run build`: passed (also run by `npm test`).
- `npm run build`: passed; existing bundle-size/config-loader/dynamic-import warnings remain.

| Requested scenario | Evidence/status |
|---|---|
| Admin Project A/category creation/100 sq ft allocation | Production handler tests pass |
| Assigned supervisor sees work; unrelated supervisor does not | Production handler tests pass |
| Submit 12 with remarks and two photo references | Production handler tests pass; pending total remains zero |
| Admin sees reports and obtains private photo access | Production handler tests pass using storage test doubles |
| Approve 12 -> approved 12, remaining 88, 12% | Pass |
| Next-day approval of 20 -> approved 32, remaining 68, 32% | Pass |
| Retry and repeated approval do not double count | Pass |
| Requery after writes retains cumulative data | Pass in test database; browser refresh/relogin not exercised |
| Enterprise isolation and manager project restrictions | Handler denial tests pass |
| Photo ownership, digest/signature rejection, upload-size rejection | Pass using a synthetic binary fixture, not actual site photos |
| Migration repeat and historical record retention | Pass |
| Real login, actual two-site-photo upload/view, browser refresh and subsequent login | **Not run against deployed Firebase** |

The tests execute compiled production handlers, but use in-memory service doubles. They do not prove Firebase transaction concurrency, deployed IAM, App Check, Storage CORS, genuine image decoding, or browser rendering. Firebase CLI/emulators and actual site photos were not available in this session. No screenshot was supplied with the request.

## Deployment and remaining live acceptance

Deploy the built functions and frontend using the existing Firebase project/deployment workflow. Keep the configured named Firestore database; do not create a replacement database. Existing production App Check configuration, Storage signing permissions and `storage.cors.json` must be configured for the deployed origin. Apply the additive role migration in each enterprise and grant manager projects/capabilities explicitly.

Then perform all 16 requested steps with two real uploaded site photos, separate admin/supervisor sessions and an unrelated enterprise account. Verify refreshed and new-login sessions read the same Firestore documents. These live checks and deployment remain outstanding; this document does not label them as passed. The workspace currently fetches up to 1,000 projects and 2,000 work items; report activity is paginated in batches of 100, while a work item's details query its complete report history. Larger-enterprise project/work-item pagination remains a scaling limitation.


## Supplied visual references — follow-up

The three supplied screenshots guide the admin overview, mobile daily report and allocation drawer. The allocation form now uses numbered detail/quantity/assignment/schedule/verification sections and an allocation preview; the overview displays progress bars and compact photo-access cards; the mobile reporter has a three-column quantity summary. Submission remains connected to the existing backend. Reference-only draft, BOQ costing and configurable photo/approval switches were not added as nonfunctional controls. No uploaded reference mockup is used as site-photo evidence. Visual browser comparison against authenticated live data remains outstanding.

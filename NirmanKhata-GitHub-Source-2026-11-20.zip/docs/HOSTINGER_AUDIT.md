# Hostinger ERP audit — 19 November 2026

Read-only audit completed before application changes. Existing React 19/Vite 8/TypeScript/Tailwind frontend; package includes Express but no server entry or start script. Firebase Functions backend is a separate deploy target and cannot run as the Hostinger server. Existing configured Firestore database has not been inspected with cloud credentials. Most original ERP features use localStorage and construction auxiliary features use localStorage plus IndexedDB photos. They survive browser refresh only, not another browser/device. React state alone holds unsaved uploads. Original production routes expose cloud record views rather than the original functional ERP forms.

Critical findings: no production listen() entry; no HttpOnly application session; Firebase token client auth does not meet requested cookie auth; browser financial balances and writes are not authoritative; generic financial persistence incomplete; profile onboarding absent; demo role switching has no server authority; build dependencies require Node >=22.12; Vite __dirname warning; no account MySQL databases; old hosted build logs reported five high vulnerabilities; no verified backup, restore or upload-retention workflow. Two unrelated existing Node.js websites must stay unchanged.

Hostinger evidence: account u846738908; active order 1010254165, plan identifier hostinger_unlimited_v6. Both existing websites already run Node 22/Express; API accepts Node 18/20/22/24. No MySQL databases listed. Existing free site uses server.cjs but the current local checkout does not contain it. Existing websites have masked unrelated auth/payment/mail env values, which must not be copied, replaced or guessed. CPU/RAM/storage quota details not exposed by the initial non-Agency API searches; exact limits remain unverified.

User selected creation of a separate free staging website. Created wishful-khaki-sheep-70.hostingersite.com on the existing order; setup completed. This is the only authorized mutation target. No paid service has been purchased. Existing domains remain untouched.

Implementation direction: preserve original React modules and historical Firebase code; introduce modular same-origin Express/MySQL backend, cookie sessions, transactional operations, durable private uploads outside deployment releases, and an explicit legacy import/backup path. Do not silently move or delete any Firebase or browser data. Validate all functionality against isolated staging data before declaring readiness.


## Implemented and verified outcome

Native production server: Express 4, mysql2 pool, Helmet, sharp-decoded original uploads and WebP previews, server sessions and scrypt. The root runtime no longer relies on Firebase login, browser finance state, temporary upload storage or demo persona switching. Original financial/operations screens were adapted to native commands. Read-only old-source references and intentional source-data imports remain; browser storage is not the native authority.

Created only a new free dedicated staging domain and new MySQL database on the existing plan. Original source/configuration was backed up before edits. No existing customer website or stored customer record was overwritten. A genuine existing hosted customer dataset was not available for a complete migration audit; no claim is made that historical Firebase or other-origin browser records have already moved to MySQL.

Corrected role workflows, forced password change, secure employee resets, module/project authorization, dynamic custom roles, permissions and license checks. Supervisor starts at reporting; Admin: Editor sees construction allocation/monitoring and cannot submit as a field worker. Pending work is separate from approved totals. Financial commands are transactional and idempotent; invalid funds/stock operations roll back.

Removed vulnerable spreadsheet dependency and updated affected packages; local full install audit and production npm advisory audit reported zero vulnerabilities on 19 November 2026. Local type check and production build pass. Native initial JS was reduced from about 1,075 KB to about 313 KB with screen-level lazy loading; original font is served from the app.

28 automated local tests passed. Of these, 20 are preserved calculation / legacy Firebase handler tests using service doubles, and 8 cover native security, backups, export safety and startup. Actual staging HTTPS/MySQL scripts passed 21 initial checks plus 8 extended checks; actual original hashes and approved quantities survive restart and redeployment. The test screenshots and reports use synthetic staging records and valid synthetic image fixtures, not fabricated customer evidence.

Unverified areas are explicitly tracked: exact hosting quotas, sustained load, complete customer historical import, full SQL recovery into a second hosting database, off-account scheduled backups and legacy external SaaS/AI/payment integrations. These prevent certifying every historical feature and the entire business as production-ready, even though the core deployed ERP workflow is tested.

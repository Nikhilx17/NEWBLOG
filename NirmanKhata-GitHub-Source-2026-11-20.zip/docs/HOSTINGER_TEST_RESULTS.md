# Test evidence — 19 November 2026

Target: https://wishful-khaki-sheep-70.hostingersite.com/app

Local: `npm run lint` passed; `npm run build` passed; `npm test` 28 passed / 0 failed. Legacy Firebase handler/service-double tests are preserved and are not substituted for the native live checks below. Production npm advisory audit reported zero vulnerabilities. Local Node is 26; the supported production build and startup were also verified on actual Hostinger Node 24.

Actual HTTPS/MySQL staging checks: 21 initial checks and 8 extended checks passed. Separate restart and redeployment checks verified 32 approved / 68 remaining / 32% and original-byte SHA-256 values. Image fixtures are valid uploaded PNGs, clearly labeled synthetic; no genuine customer site photographs were supplied.

## Live checks

- PASSED: HTTPS application and database / private-storage readiness
- PASSED: Platform Owner authenticates with secure HttpOnly cookie and changes temporary password
- PASSED: Platform provisions an isolated test enterprise and only its Admin: Editor credentials
- PASSED: Enterprise admin login enforces first-password-change before operational access
- PASSED: Enterprise onboarding permanently saves complete business profile
- PASSED: Admin creates all five employee role templates; each authenticates independently
- PASSED: Admin creates a persistent construction site and assigns employee project access
- PASSED: Admin creates reusable Tile Installation category and allocates 100 sq ft
- PASSED: Assigned supervisor sees work while unauthorized employee modules are denied
- PASSED: Supervisor uploads two real decoded image fixtures and submits 12 pending sq ft
- PASSED: Reviewer inspects originals and approves 12 -> remaining 88, completion 12%
- PASSED: Repeated report retry and approval never double-count quantities
- PASSED: Next-day 20 sq ft approval accumulates to 32 / 68 / 32%
- PASSED: Approved corrections preserve audit history and accurately recalculate zero and restored values
- PASSED: Purchase, finance, inventory and payroll commands persist atomically
- PASSED: Invalid money and stock transactions roll back without changing stored balances
- PASSED: Permission updates apply to the existing account; deactivation revokes existing cookies
- PASSED: Two live test enterprises cannot access each other’s APIs or original images
- PASSED: Enterprise records survive logout and a fresh login session
- PASSED: Encrypted database and original-file backup downloads successfully
- PASSED: No account listings expose passwords or hashes
- PASSED: Supervisor starts with reporting navigation; no BOQ or finance navigation
- PASSED: Accounts pays an approved supplier bill with separate payment permission
- PASSED: Client invoices recompute totals, reject tampered amounts and persist receipts
- PASSED: Subcontractor bill requires admin approval before Accounts can pay
- PASSED: BOQ, requisitions, tasks, equipment and bank reconciliation save to MySQL
- PASSED: Unassigned supervisor cannot read assigned work or photos; custom roles update live
- PASSED: Invalid units, negative quantities and over-target approvals are rejected
- PASSED: Fresh encrypted backup preserves all updated test records

## Mandatory scenario matrix

| # | Scenario | Result and evidence |
|---|---|---|
| 1 | Application starts on Hostinger | PASS: Node 24 deployed, listener and database-ready runtime logs. |
| 2 | Login page opens | PASS: HTTPS API and actual browser. |
| 3 | Platform Owner creates enterprise | PASS: two isolated synthetic test enterprises. |
| 4 | Admin: Editor login | PASS: secure cookie and first-password gate. |
| 5 | Enterprise onboarding persists | PASS: saved company profile returned after fresh login. |
| 6 | Admin creates employees | PASS: five default employee roles created by enterprise admin. |
| 7 | Employee login | PASS: independent credentials and personal password changes. |
| 8 | Role dashboards | PASS: live API navigation plus admin desktop and supervisor phone browser checks. |
| 9 | Unauthorized modules blocked | PASS: API 403 and navigation removal after grant changes. |
| 10 | Project creation | PASS: Greenfield Luxury Villas stored in MySQL. |
| 11 | Category creation | PASS: reusable Tile Installation category. |
| 12 | Work allocation | PASS: 100 sq ft allocated to supervisor. |
| 13 | Supervisor sees work | PASS: live API and browser dropdown. |
| 14 | Daily submission | PASS: separate pending records; no approved total until review. |
| 15 | Multiple image uploads | PASS with synthetic image fixtures: original bytes decoded and hashed. |
| 16 | Reviewer photo inspection | PASS: authenticated originals and actual browser gallery/next navigation. |
| 17 | Report approval | PASS: Admin: Reviewer and Admin: Editor approvals. |
| 18 | Quantity calculations | PASS: 12/88/12%, then 32/68/32%; zero/correction/retry checks. |
| 19 | Logout/login persistence | PASS: fresh cookies retain records. |
| 20 | Server restart persistence | PASS: actual Hostinger restart followed by record and hash verification. |
| 21 | Safe redeploy persistence | PASS: completed staging redeployment followed by record and hash verification. |
| 22 | Enterprise isolation | PASS: foreign tenant RPC denied, original image denied; unrelated supervisor denied. |
| 23 | Deactivated employee denied | PASS: existing cookie invalidated; reactivation does not revive old cookie. |
| 24 | Existing modules continue functioning | PARTIAL: core purchases/payment/expenses/banking/payroll/inventory/clients/invoices/subcontractors/BOQ/tasks/equipment/reconciliation APIs tested. Every historical UI path, legacy external integration and customer import is not certified. |
| 25 | No critical runtime log errors | PASS for inspected staging log windows; not a long-running production guarantee. |

## Browser evidence

Actual staging browser screenshots are in `docs/screenshots/`. Admin has allocation/monitoring controls and no daily submission form; supervisor has read-only balances, an assigned-work selector, photo controls and Submit Report. Desktop, tablet and phone layouts were inspected. The full original-image gallery was opened and next navigation verified. These are actual application captures.

## Backup evidence

An actual encrypted archive decrypted into 224 database records and six image files (three originals and three previews); all three originals matched stored SHA-256 values. A local encryption roundtrip preserves file chunks and rejects tampered archives. Runtime records show an automatic daily snapshot completed. Full SQL restore into a separate Hostinger database is NOT TESTED.

## Failures resolved and remaining gaps

- An initial local listener test was blocked by sandbox loopback networking; the authorized network-enabled run passed.
- A staging build failed on an invalid UTF-8 byte in SubcontractorsView; source encoding was corrected and subsequent Hostinger builds completed.
- One queued build had no archive/log after a preceding publication synchronized public_html; the archive was re-uploaded after that release completed and the build succeeded.
- An extended authorization assertion expected 404 but received valid 403 denial; the assertion now accepts either denied status, and the complete extended suite passed.
- Exact hosting quotas, high-concurrency load, full SQL restore, off-account backup scheduling, customer historical import and legacy external integrations remain unverified. No customer production rows were deleted to resolve tests.

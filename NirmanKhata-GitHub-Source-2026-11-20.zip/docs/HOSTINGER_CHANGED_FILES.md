# Actual files changed in Hostinger implementation

Compared byte-for-byte with backups/pre-hostinger-20261119.zip. No Git repository was available. Historical Firebase source was retained; its service-double tests are distinguished from actual native staging API tests. Generated secrets, runtime fixtures, database backup contents and deployment credentials are excluded from this inventory.

## Modified

- `README.md`
- `package-lock.json`
- `package.json`
- `src/App.tsx`
- `src/components/auth/ConstructionOperationsGate.tsx`
- `src/components/auth/EnterpriseUserManagementGate.tsx`
- `src/components/auth/PlatformEnterpriseAccounts.tsx`
- `src/components/auth/SiteProgressWorkspace.tsx`
- `src/components/auth/UserAccessManagement.tsx`
- `src/components/common/Navbar.tsx`
- `src/components/common/Sidebar.tsx`
- `src/components/views/BusinessSettingsView.tsx`
- `src/components/views/InvoiceUploadModal.tsx`
- `src/components/views/OperationsHubView.tsx`
- `src/components/views/PurchasesView.tsx`
- `src/components/views/SubcontractorsView.tsx`
- `src/components/views/TeamPermissionsView.tsx`
- `src/context/ContractorContext.tsx`
- `src/lib/exportUtils.ts`
- `src/lib/legacyMigration.ts`
- `src/lib/purchaseInvoiceDocuments.ts`
- `src/main.tsx`
- `vite.config.ts`

## Added

- `.hostinger/site.json`
- `docs/HOSTINGER_AUDIT.md`
- `docs/HOSTINGER_PRODUCTION.md`
- `docs/LEGACY_FIREBASE_README.md`
- `scripts/staging-extended.mjs`
- `scripts/staging-smoke.mjs`
- `server.cjs`
- `server/accounts.mjs`
- `server/app.mjs`
- `server/backup.mjs`
- `server/construction.mjs`
- `server/core.mjs`
- `server/database.mjs`
- `server/files.mjs`
- `server/migrations/001_hostinger.sql`
- `server/migrations/002_finance_permissions.sql`
- `server/records.mjs`
- `server/restore-cli.mjs`
- `src/components/auth/HostingerApp.tsx`
- `src/components/auth/NativeAdminTools.tsx`
- `src/context/HostingerSession.tsx`
- `src/lib/api.ts`
- `tests/export-security.test.mjs`
- `tests/server-backup.test.mjs`
- `tests/server-core.test.mjs`

## Migrations

- `server/migrations/001_hostinger.sql`: additive native tenant/auth/project/work/progress/file/audit schema.
- `server/migrations/002_finance_permissions.sql`: payment grants on built-in Accounts template only. No data deletion or custom-role overwrite.

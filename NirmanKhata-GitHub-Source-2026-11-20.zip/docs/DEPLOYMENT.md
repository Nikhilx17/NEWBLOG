# Deployment preparation

## Environments

Use separate Firebase projects for local/emulator, staging and production. Do not select a production project until the owner confirms its ID, database, bucket, Authentication domains and deployment access. This repository intentionally has no `.firebaserc` project selection.

## Required configuration

### Frontend build

Set `VITE_FIREBASE_APPCHECK_SITE_KEY` to the registered web App Check site key. Firebase web configuration in the app is public client configuration; it is not a secret. Restrict API key usage in Google Cloud and enable only required APIs.

### Functions environment

Copy `functions/.env.example` into the Firebase CLI environment file for the selected alias. Set the correct `FIRESTORE_DATABASE_ID`, `APP_CONTINUE_URL`, and `PLATFORM_ADMIN_UIDS` (Firebase Auth UIDs, not emails). Configure these secrets through Firebase Functions secret management:

- `RAZORPAY_KEY_ID`
- `RAZORPAY_KEY_SECRET`
- `RAZORPAY_WEBHOOK_SECRET`

Never put these values in `VITE_*` variables, source control or browser storage.

### Identity and email

Enable Firebase email/password Authentication, email verification and password reset. Add the final marketing, app and admin hostnames to authorized domains. Configure verification/reset email templates. Employee invitation currently returns a copyable sign-in link; it does not send email.

### Storage

Apply the CORS policy in `storage.cors.json` to the selected bucket after changing its origins to the exact final site origins. Confirm the Functions service account can sign V4 URLs and read/delete objects. Storage rules are deny-all for direct clients; only short-lived server-signed links should be used.

### Razorpay

Configure test credentials in a staging project and register the deployed `razorpayWebhook` endpoint with the chosen events. The webhook secret is distinct from the API key secret. Do not activate paid plans until checkout, webhook reconciliation, renewals, cancellations, failures and refunds have passed sandbox tests. The current code is not a recurring-subscription integration and is not ready to charge customers.

## Build and deployment order

From PowerShell at the repository root:

```powershell
npm install
npm run lint
npm run build
npm --prefix functions install
npm --prefix functions run build
```

Then, after selecting the staging Firebase project and testing rules in the Emulator Suite, deploy only the reviewed staging resources. Rules should be deployed and verified before enabling application reads. Deploy Hosting only after setting App Check config at build time. Do not deploy `firestore.rules` or Functions to the currently configured Firebase project without first verifying the project and database in the Firebase Console.

Firebase Hosting routes all app paths to `index.html` and sets baseline security headers. Route separation is by path and hostname in the frontend. Map the final public, app and admin domains to the chosen Hosting site and verify TLS, email links, App Check and callable region in staging.

## Current blockers to production

- No verified staging/production Firebase project access or Firebase CLI project alias.
- No App Check Enterprise key, Razorpay credentials/webhook secret or selected platform-admin UID.
- No customer email delivery provider.
- No deployed functions or rules emulator run in this environment.
- The ERP’s full cloud persistence, trusted financial workflows, backup/restore and recurring billing remain unfinished.

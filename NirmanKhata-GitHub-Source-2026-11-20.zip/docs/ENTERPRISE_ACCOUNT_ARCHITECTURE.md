# Enterprise account-management correction

Implementation date: 19 November 2026. Changes are in the existing React/Vite/Firebase ERP. No production database migration, provider setting, account creation or deployment was executed during this session.

## Architecture inspected before coding

The application uses Firebase Authentication, a named Firestore database (`ai-studio-6794c8ab-5e87-4ce8-ad85-d1290fbea6b0`), callable Cloud Functions, and private Storage. Inspection covered repository schemas, configuration, backend authorization, dashboard routing and existing tests. Production database contents and provider configuration were not inspected through an authenticated cloud session.

Previously `SaaSAccess.tsx` offered public registration/company creation, verified-email login and employee invitation links. Backend `createCompany`, `createEmployeeInvite` and `acceptEmployeeInvite` supported those flows. `TeamPermissionsView.tsx` separately managed browser-only role profiles. Most authorization lived in `functions/src/index.ts`; Firestore rules gave several role-based reads without project checks. These were the files and flows identified for correction before implementation.

## Resulting separation

```mermaid
flowchart TD
    PO[Platform Owner / separate allowlisted identity] --> PA[Platform provisioning and license APIs]
    PA --> ENT[Enterprise metadata and subscription]
    PA --> SA[Initial Admin: Editor identity]
    SA --> UM[User & Access Management]
    UM --> EA[Employee identities / roles / overrides / assigned projects]
    SA --> LOGIN[Shared username and password login]
    EA --> LOGIN
    LOGIN --> AUTH[Firebase Authentication]
    AUTH --> TEMP{Temporary password?}
    TEMP -->|Yes| CHANGE[Required password change and fresh sign-in]
    TEMP -->|No| ACCESS[Current membership + credential version + license + permissions]
    ACCESS --> NAV[Database-driven authorized navigation]
    ACCESS --> DATA[Only authorized enterprise and project data]
    UM --> AUDIT[Immutable account and permission audit events]
```

Platform provisioning creates no operational membership for the Platform Owner. Knowing an enterprise ID, or being on the platform allowlist, does not authorize enterprise operational APIs. The platform sees subscription and account-provisioning metadata, not private project/accounting records.

`admin_editor` is the canonical Admin: Editor / Enterprise Super Admin role. Existing server-side `owner` and `company_admin` roles are compatibility aliases for the same enterprise-administrator concept and display as Admin: Editor. They are not platform owners. Other roles, including Admin: Reviewer and custom roles with misleading names or team-related permissions, cannot manage employee credentials or self-promote.

## Account and login behavior

- Platform Owner creates an enterprise and its initial administrator from the existing platform dashboard. The form generates a login ID and strong temporary password on demand. Passwords must be recorded privately before saving; they are cleared after success and never returned by the API.
- Admin: Editor creates employees from User & Access Management, available in the enterprise dashboard and the existing ERP Team & Permissions view.
- Default templates: Admin: Editor, Purchase Manager, Accounts, Project Manager, Admin: Reviewer, Site Supervisor. Custom roles are database records, not component switches.
- Employees receive a role, optional exact permission override, project/site assignments and active/deactivated status. A null override inherits the current role; an empty override grants no actions. Employee-management powers cannot be granted through employee overrides.
- Login uses Username / Login ID and Password. Login IDs are globally unique, case-insensitive, 3–64 characters (`a-z`, digits, dots, underscores and hyphens). An enterprise prefix is recommended because a shared login has no enterprise selector before authentication.
- Usernames map to internal Firebase email/password identities at `username@login.nirmankhata.invalid`. These are internal identifiers, not delivery addresses. Legacy identities can still sign in with their existing email Login ID. No OTP, SMS, automatic email, public company signup or mandatory verification is used.
- Temporary credentials permit only the password-change gate and minimal own-enterprise metadata, not operational records. New passwords require 12–128 characters, uppercase, lowercase and a number. The user signs in again after changing the password.
- Passwords are write-only input to the trusted Firebase Admin SDK. Application Firestore documents, account listings, audit events and callable responses contain neither readable passwords nor password hashes. Firebase Authentication owns password storage and password verification.
- Firebase handles password sign-in throttling; the UI handles `auth/too-many-requests` without account-enumeration messages. This project does not add an independent application login endpoint, custom password hash store or custom token issuer.
- Credential versions are stored in protected memberships and signed Auth custom claims. Password changes/resets and managed-account status changes rotate the version, so old signed ID tokens cannot bypass the new access state. Role and permission changes are read from the database on each backend request; permission-only changes do not require a new account or a forced logout. Navigation refetches every 15 seconds and on window focus.
- Employee password reset requires an Admin: Editor session authenticated within ten minutes. It revokes sessions, installs a new temporary password, records an audit event and requires another password change. It sends no email/SMS.
- Shared legacy Auth identities are not silently password-reset across enterprises. The new reset API is restricted to managed per-enterprise identities. Legacy employee identities need a deliberate credential migration before that reset path can be used; historical UIDs and records are retained.
- The final administrator cannot be removed/demoted through account-management APIs. Self access changes are rejected, legacy unguarded account-mutation routes are disabled, and default administrator roles cannot be modified as custom roles. Provider-side client self-deletion must also be disabled during rollout, as described below.

Firebase references: [Admin user management](https://firebase.google.com/docs/auth/admin/manage-users), [session revocation](https://firebase.google.com/docs/auth/admin/manage-sessions), [provider limits](https://firebase.google.com/docs/auth/limits).

## Database adaptation and migration

No SQL tables are introduced because this ERP uses Firestore. Existing enterprise roots, operational collections and historical UIDs remain in place. References to roles/projects are validated inside server-side transactions; clients cannot write account/security records directly.

| Requested concept | Existing/extended storage |
|---|---|
| enterprises | `tenants/{tenantId}` |
| users / credential hashes | Firebase Authentication (managed passwords); no hashes in app DB |
| enterprise_memberships / user_roles | `tenants/{tenantId}/members/{uid}` plus `users/{uid}/memberships/{tenantId}` |
| roles / role_permissions | `tenants/{tenantId}/roles/{roleId}` with permission arrays |
| permissions | server-validated catalog and stored role/override selections |
| user_project_assignments | membership `projectIds`; synchronized construction `siteProgressAccess.projectIds` |
| individual action permissions | membership `permissionOverride` (null = inherit current role) |
| enabled dashboard modules | `tenants/{tenantId}/accessModules/{moduleId}` |
| enterprise_subscriptions | tenant `subscription` (status, employeeLimit, modules, endsAt) |
| audit_logs | tenant `auditEvents`; platform provisioning/license audit in platform audit collection |
| migration version | tenant `schemaMigrations/enterprise_accounts_v1` |

The actual additive migration is `functions/src/migrations/enterpriseAccountsV1.ts`. Admin: Editor can invoke `initializeEnterpriseAccounts({tenantId})`, exposed as **Initialize default roles**. It transactionally adds missing templates and the module registry without replacing existing users, custom roles or operational data. Repeat calls are idempotent. New enterprise provisioning installs the same schema immediately. Existing aliases retain their UIDs; no customer records are reassigned or deleted.

Employee creation checks the enterprise license, role existence and all selected project references in a Firestore transaction. It updates a tenant revision to serialize account-limit changes. Active employees consume seats; the initial administrator is excluded; `employeeLimit: -1` means unlimited. Activation checks the limit too. Auth identities are initially disabled and enabled only after account metadata commits. Failed database creation is compensated by deleting the newly created disabled identity. Interrupted disabled-identity provisioning can be retried using the same request ID. Do not change the submitted credential details during a retry; existing-account responses do not replace its password.

Project checks also cover existing purchase listing, invoice access/verification, document download and generic operational sync APIs. Sync validates old and new project ownership in a transaction, preventing a caller from moving an inaccessible record into an assigned project. Construction access is removed when a managed employee loses the project assignment, even if an old work allocation still contains their UID.

## Files changed for this request

| File | Change |
|---|---|
| `functions/src/enterpriseAccess.ts` | Central administrator aliases, default roles/module templates, effective permissions, account/license/project checks |
| `functions/src/enterpriseAccounts.ts` | Provisioning, employees, updates, resets, password gate, access metadata, sanitized account/audit listing, license management |
| `functions/src/migrations/enterpriseAccountsV1.ts` | Additive migration |
| `functions/src/index.ts` | Exports account APIs; centralizes existing permission enforcement; disables obsolete signup/invites/mutations; adds scoped module reads; strengthens existing purchase and sync APIs |
| `functions/scripts/configure-enterprise-auth.cjs` | Inspect/apply provider signup and self-deletion restrictions using a deployment identity |
| `functions/package.json` | Provider-configuration script command |
| `firestore.rules` | Account/password/version/license/action/project checks for direct reads; writes remain denied |
| `src/components/auth/EnterpriseWorkspace.tsx` | Shared login, required password change, live access/navigation and authorized module record views |
| `src/components/auth/UserAccessManagement.tsx` | Employee creation, role/permission/project/status edits, secure reset, custom roles and history |
| `src/components/auth/PlatformEnterpriseAccounts.tsx` | Initial administrator provisioning and license controls |
| `src/components/auth/EnterpriseUserManagementGate.tsx` | Authenticated user management inside the existing ERP shell |
| `src/components/auth/SaaSAccess.tsx` | Removes old registration/invite/verification/team flows; connects new screens; preserves support and historical import utilities |
| `src/components/auth/ConstructionOperationsGate.tsx` | Removes the mandatory email-verification gate |
| `src/components/auth/SiteProgressWorkspace.tsx` | Uses backend administrator classification when selecting assignees |
| `src/components/views/TeamPermissionsView.tsx` | Replaces browser role-editing UI with authenticated account management; preserves old profiles read-only |
| `src/lib/purchaseInvoiceDocuments.ts` | Sends the selected project with invoice uploads |
| `src/components/views/InvoiceUploadModal.tsx` | Passes the invoice project into secure upload |
| `tests/helpers/serviceHarness.mjs` | Shared isolated Auth/Firestore/Storage test doubles and compiled-handler loader |
| `tests/construction-workflow.test.mjs` | Reuses the shared harness; preserves prior construction regressions |
| `tests/enterprise-accounts.test.mjs` | Account-management/security scenario tests |
| `docs/ENTERPRISE_ACCOUNT_ARCHITECTURE.md` | Architecture, schema, rollout and verification record |

Generated outputs: compiled `functions/lib/` modules and production `dist/` assets. There is no Git repository in this workspace, so this is a changed-file manifest rather than a Git diff.

## Test results and requested scenario

`npm test`: **20 passed, 0 failed** (10 existing calculation/construction tests and 10 account/security tests). Tests execute compiled production callable handlers with isolated service doubles. `npm run lint` passes. Backend and frontend production builds pass; the existing Vite config/bundle-size/dynamic-import warnings remain. The provider-configuration script passes `node --check`.

| Mandatory steps | Result |
|---|---|
| 1–2 Platform creates Enterprise A and Admin: Editor credentials | Production handler tests pass with Auth service double; UI credential generation implemented |
| 3 Admin logs in | Temporary-password gate and post-change access tested; native Firebase password sign-in not live-tested |
| 4–8 Admin creates Purchase Manager, Accounts, Project Manager, Admin: Reviewer and Site Supervisor | All five production creation handlers exercised; role/project references and license checks pass |
| 9 Each employee logs in with own username/password | Unique identity/email mapping and first-login state tested; real password verification and browser sessions remain untested |
| 10 Employees see authorized modules | Server navigation/module catalog and per-user action denial tests pass; authenticated browser rendering not exercised |
| 11–12 Change permissions on the same account | Pass, including existing valid token, custom-role updates and before/after audit; no new identity needed |
| 13 Deactivated employees cannot access ERP | Backend denial, Auth disable and old-token denial after reactivation pass in service doubles |
| 14 Other enterprise/project data inaccessible | Membership denial, project-scoped purchase reads and revoked-work-assignment tests pass |
| 15 Existing features continue | Existing calculation/construction tests and builds pass; full historical ERP browser regression was not performed |

Additional coverage: password-change version rotation, administrator reset recency, forced reset gate, no credential exposure in account/audit DB output, failed-create cleanup, limit enforcement, unlimited license, repeated-create idempotency, obsolete route denial, administrator self-removal denial, custom-role changes, migration repeatability and historical record retention.

These are not emulator tests. Firebase password hashing, real login rate limiting, deployed IAM, rules evaluation, provider restrictions, cross-service fault injection and simultaneous transaction behavior still require live/emulator verification. The app is not represented as production-verified or deployed by these test results.

## Required rollout / remaining work

1. Deploy built functions, frontend and reviewed Firestore rules to the existing project/named database. Configure the existing App Check site key and production HTTPS origin. Keep the platform administrator UID allowlist separate from enterprise membership.
2. Use a deployment identity with Firebase Auth project-configuration privileges to inspect provider settings: `npm --prefix functions run configure:enterprise-auth`. This is read-only.
3. Apply the prepared provider restriction with `npm --prefix functions run configure:enterprise-auth -- --apply`. It disables client signup and client account deletion and verifies the returned flags. This script was not executed against the user's project during implementation. Provider support/IAM errors fail visibly rather than being skipped. [Official configuration fields](https://docs.cloud.google.com/identity-platform/docs/reference/rest/v2/Config).
4. For existing enterprises, run the additive account migration while signed in as the existing owner/company administrator. For new enterprises, use the platform provisioning form. Give the initial credentials privately to the enterprise administrator; do not send automatic messages.
5. Execute all 15 requested steps using actual platform/admin/employee browser sessions, including provider-level public-signup/self-deletion denial, first-login password changes, permission refresh, reset, deactivation and unrelated-enterprise checks. Review direct Firestore rules with the emulator before broad release.
6. Retain an authorized Firebase operator recovery runbook for legacy identities and cross-service Auth/Firestore failures; do not grant the Platform Owner automatic operational access as a recovery shortcut.

The original ERP financial/operations components and historical browser data remain intact. The new authenticated module navigator provides project-scoped cloud record views and the working construction workflow. It does not migrate every legacy financial editing form from browser context into tenant cloud synchronization; non-construction write-form integration and complete browser regression remain separate unfinished work. Modules without a connected cloud view identify that limitation instead of inventing financial data.

Prototype rules notice: I've set up prototype Security Rules to keep the data in Firestore safe. They are designed to be secure for enterprise membership, credential-version and temporary-password restrictions, explicit action permissions and assigned project scope. However, you should review and verify them before broadly sharing your app. If you'd like, I can help you harden these rules.

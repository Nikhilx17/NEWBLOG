# NirmanKhata

NirmanKhata is an existing contractor ERP built with React, TypeScript, Vite, Tailwind and Firebase. This repository keeps the existing contractor modules and adds the first SaaS foundation: verified Firebase sign-in, company creation, tenant membership and role records, server-side invitation and access operations, protected Firebase rules, a public product site, a platform-owner dashboard, server-side invoice extraction, a Razorpay order/webhook foundation, and a user-initiated legacy data importer.

## Run locally

```powershell
npm install
npm run dev
```

Open `http://localhost:3000`. The local development root still opens the existing ERP demo. Marketing pages are available at `/features`, `/industries`, `/pricing`, `/about`, `/contact`, `/faq`, `/privacy`, `/terms`, and `/refund`. SaaS account routes are `/register` and `/login`; `/app` is the authenticated customer entry point; `/admin` is the private platform administration entry point.

The production build serves the marketing website at `/` and routes `/app` and `/admin` to their authenticated experiences. An account can be created only after Firebase is configured. Until tenant-scoped cloud persistence for all ERP modules is connected, the authenticated customer route intentionally does not load the old unscoped local browser data. It offers an explicit backup and migration workflow instead.

## Firebase setup

The checked-in Firebase client configuration uses an existing named Firestore database. The Firebase project and production contents have not been inspected in this development environment. Select an isolated staging Firebase project before deploying anything.

1. Configure Firebase Authentication with email/password, email verification and the correct authorized domains.
2. Register the web app with Firebase App Check and reCAPTCHA Enterprise. Set `VITE_FIREBASE_APPCHECK_SITE_KEY` in the frontend build environment. Callable operations enforce App Check.
3. Install the Functions dependencies with `npm --prefix functions install` and build with `npm --prefix functions run build`.
4. Configure `functions/.env.<project-alias>` from `functions/.env.example`. Set `FIRESTORE_DATABASE_ID`, `APP_CONTINUE_URL` and the authorized platform administrator UID allowlist. Do not put secret values in this environment file.
5. Configure payment secrets with Firebase Functions secrets: `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET` and `RAZORPAY_WEBHOOK_SECRET`.
6. Configure the Storage bucket CORS policy from `storage.cors.json`. Replace the example domains with the exact HTTPS domains used by the deployment.
7. Build the frontend with `npm run build`. Review and test Firebase rules in the Emulator Suite against staging data, then deploy rules, Functions and Hosting as separate reviewed steps.

No Firebase rules, Functions, Storage configuration or Hosting site have been deployed by this work. The repository has no `.firebaserc` because the correct staging/production Firebase project and deployment authorization were not established.

### Firebase Functions

Functions source is in `functions/src/index.ts`. It implements:

- `createCompany`, idempotent by client request ID, with a 14-day trial and initial owner membership.
- `listMyCompanies`, company team listing, `createEmployeeInvite`, `acceptEmployeeInvite`, custom-role creation/update, member role assignment, and member deactivation.
- `migrateLegacyBatch`, with tenant checks, row limits, stable IDs, per-record source markers and duplicate/change detection.
- Private Storage upload URL issuance and file verification for legacy attachments; membership-checked, short-lived document download URLs.
- `syncTenantCollection`, currently limited to selected operational collections. It does not accept account ledgers, payments, payroll, documents or audit events.
- Private original purchase invoice uploads with SHA-256 verification, tenant-linked metadata, secure viewing/download links and audit events.
- Razorpay order creation, signature-checked webhook handling and payment-event idempotency.
- Private platform overview, subscription plan configuration and company status operations, demo-request management, and customer support inbox, restricted to `PLATFORM_ADMIN_UIDS`.
- Public pricing reads active plan settings from the server. Paid plan cards link to a demo request; checkout is not enabled.

### Purchase invoice documents

The existing Purchase Invoice form now uses manual entry only. Its existing fields, ITC checkbox, GST calculations and local submit behavior are retained. The added `ORIGINAL INVOICE DOCUMENT` field accepts one PDF, JPG/JPEG or PNG up to 10 MB and previews it before saving. A selected file stays as a browser `File`; it is never encoded into localStorage. For a signed-in user with an active company selection, the existing purchase screen uses trusted Functions to upload to private tenant Storage, save the linked purchase record, and issue five-minute view/download links. New cloud invoices start as `pending_verification`; verification/rejection records the actor, time and an audit event.

The local demo still supports manual purchase entry without a document. Uploading requires a verified account and company membership. The production `/app` route still shows the SaaS workspace placeholder rather than mounting the existing ERP, so this focused cloud purchase flow is currently available through the development ERP route only. Full production ERP integration and Firebase staging verification remain outstanding.

Functions deploy to `us-central1` and use the named database ID shown in the Firebase config unless overridden with `FIRESTORE_DATABASE_ID`. The current Functions runtime is Node 22. Local development in this environment used Node 26; the Functions package reports that engine difference, while TypeScript compilation succeeds.

## Legacy data import

The importer reads local browser storage only after the signed-in company owner explicitly requests a review, or reads a JSON export they select. It never clears local storage. It inventories the current ERP keys and the separate Construction Operations storage key, checks known project/client/supplier/worker/account references, warns about sample identifiers, and shows record and amount totals before the user confirms upload.

Base64 invoice attachments are moved to private company Storage using short-lived upload links before their records are imported. Unsupported or oversized files stop the import. Imported records keep their source IDs where valid, are associated with the new tenant, and retain the previous company ID in migration metadata. Legacy team profiles are preserved as historical profiles; they do not create employee credentials. Review totals and counts against a separate backup before using imported data.

## Security model

- Company membership is stored at `tenants/{tenantId}/members/{authUid}` and is created or changed only by trusted Functions.
- Roles live in `tenants/{tenantId}/roles/{roleId}`. Firestore read rules resolve the role’s current permissions; browser requests cannot assign roles.
- Tenant IDs from the browser are treated as selectors, then checked against authenticated membership on every callable operation.
- Direct client writes to tenant collections, company membership, role records, document metadata, platform records and audit events are denied by the checked-in rules.
- Generic collection sync excludes financial posting, account balances, payroll, file metadata and audit events. Dedicated trusted financial operations are still required before those modules can become cloud-backed.
- Storage rules deny direct access. The signed URL endpoints check active membership and document permission, and issue short-lived URLs.
- App Check complements authentication and membership checks; it does not replace them.
- `PLATFORM_ADMIN_UIDS` is a server-side allowlist. Platform screens do not read company financial data.

## Current implementation status

This is an implementation in progress, not a production-ready SaaS release. The existing ERP modules still use localStorage and the local demo personas remain in the development-only ERP. The new authenticated route is deliberately held before showing those records. Company team and role controls are available in the authenticated account area, but invitation links must currently be copied and sent by the administrator. Remaining major work includes connecting tenant-scoped cloud reads and writes for all ERP features, implementing validated financial posting and report queries, real recurring subscriptions and renewals, support ticket attachments, platform usage/storage analytics, tested Firestore/Storage rules, restore/backups, legal policy content, and staging integration/security tests. MRR/ARR is explicitly shown as not aggregated until a verified recurring-revenue calculation exists.

## Checks run

- `npm test` — passed (3 regression checks for existing financial calculation behavior).
- `npm run lint` — passed.
- `npm run build` — passed. Vite reports a large JavaScript bundle and config-loader warning to address during performance work.
- Functions TypeScript build — passed using the Functions TypeScript compiler.
- Rules Emulator tests, live Firebase integration tests, Razorpay sandbox verification and deployment — not run. Firebase CLI/Java, App Check site key, provider secrets and staging credentials are not configured here.

See [docs/SAAS_IMPLEMENTATION.md](docs/SAAS_IMPLEMENTATION.md) for architecture, data boundaries, configuration and remaining release work.
